# Deployment (Vercel)

## Environment variables

Set these in the Vercel project **Settings → Environment Variables** (Production and Preview):

### Firebase client (public)

- `NEXT_PUBLIC_FIREBASE_API_KEY`
- `NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN`
- `NEXT_PUBLIC_FIREBASE_PROJECT_ID`
- `NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET`
- `NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID`
- `NEXT_PUBLIC_FIREBASE_APP_ID`

### Firebase Admin (server — required for student session cookies)

- `FIREBASE_ADMIN_PROJECT_ID`
- `FIREBASE_ADMIN_CLIENT_EMAIL`
- `FIREBASE_ADMIN_PRIVATE_KEY` — paste the key with `\n` for newlines, or use a multiline value

Without Admin credentials, `POST /api/student/session` returns **401/503** and protected routes (`/student-dashboard`) will redirect back to login after sign-in.

## Firebase Authentication — authorized domains

In **Firebase Console → Authentication → Settings → Authorized domains**, add:

- `alizon-edu-webapp.vercel.app`
- Any custom production domain you use

This removes the OAuth iframe warning and enables popup/redirect sign-in on that host.

## Route validation

Before each production build, `npm run build` runs `npm run validate:routes` to ensure `src/` link targets match `app/**/page.tsx` routes.
