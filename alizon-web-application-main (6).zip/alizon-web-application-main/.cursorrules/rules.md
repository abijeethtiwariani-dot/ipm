# =========================================================
# Cursor Rules for Next.js Production Web Application
# Focus:
# - Security
# - Code Reusability
# - Scalability
# - SEO Optimization
# - Accessibility
# - Performance
# - Clean Architecture
# - Firebase Best Practices
# =========================================================

You are an expert senior full-stack engineer.

The project is built using:
- Next.js (App Router)
- React
- TypeScript
- Tailwind CSS
- Firebase / Firestore / Firebase Auth / Firebase Storage

Follow ALL rules below strictly while generating or modifying code.

# =========================================================
# GENERAL DEVELOPMENT RULES
# =========================================================

- Always write clean, scalable, reusable production-ready code.
- Never generate unnecessary files.
- Never duplicate logic.
- Reuse existing components, hooks, utilities, and services whenever possible.
- Prefer server components over client components unless interactivity is required.
- Keep components modular and maintainable.
- Follow consistent naming conventions.
- Avoid hardcoded values.
- Use environment variables for secrets and configs.
- Use TypeScript everywhere with strict typing.
- Avoid using "any".
- Prefer async/await over promise chains.
- Use absolute imports using configured aliases.
- Keep files under reasonable size limits.
- Split large components into reusable subcomponents.
- Always optimize for readability and maintainability.

# =========================================================
# NEXT.JS RULES
# =========================================================

- Use App Router architecture.
- Use Server Actions where appropriate.
- Use dynamic imports for heavy components.
- Use Suspense and loading.tsx where needed.
- Use error.tsx for proper error boundaries.
- Use route groups and layouts correctly.
- Use metadata API for SEO.
- Use generateMetadata for dynamic SEO pages.
- Avoid unnecessary client-side rendering.
- Use caching strategically.
- Use ISR or SSR when beneficial for SEO.
- Use image optimization with next/image.
- Use font optimization with next/font.

# =========================================================
# SECURITY RULES
# =========================================================

- Never expose API keys or secrets in frontend code.
- Always validate and sanitize user input.
- Prevent XSS vulnerabilities.
- Prevent CSRF vulnerabilities.
- Prevent SQL/NoSQL injection attacks.
- Never trust client-side data.
- Validate all API requests.
- Implement proper authentication checks.
- Implement role-based authorization.
- Protect admin routes.
- Use secure HTTP headers.
- Use rate limiting on sensitive APIs.
- Avoid exposing internal error details.
- Use Firebase security rules properly.
- Validate uploaded files before storage.
- Restrict upload file size and file types.
- Never store sensitive data in localStorage.
- Use secure cookies when applicable.
- Prevent open redirect vulnerabilities.
- Escape dynamic HTML properly.
- Always use HTTPS URLs.
- Do not log sensitive user data.
- Sanitize all Firestore queries.
- Use middleware for route protection.
- Always verify Firebase auth tokens server-side.
- Never expose Firebase admin credentials.

# =========================================================
# FIREBASE RULES
# =========================================================

- Use modular Firebase SDK.
- Keep Firebase config in environment variables.
- Use Firestore indexes efficiently.
- Avoid unnecessary reads and writes.
- Paginate Firestore queries.
- Use batched writes where needed.
- Use transactions for critical operations.
- Implement proper Firestore security rules.
- Validate ownership before accessing documents.
- Structure collections for scalability.
- Avoid deeply nested Firestore structures.
- Optimize Firebase Storage usage.
- Compress images before upload.
- Delete unused storage files.
- Use server-side validation before writes.

# =========================================================
# CODE REUSABILITY RULES
# =========================================================

- Create reusable UI components.
- Create reusable form components.
- Create reusable modal components.
- Create reusable table components.
- Create reusable hooks.
- Create reusable utility functions.
- Centralize API logic.
- Centralize validation schemas.
- Use constants instead of duplicated strings.
- Use shared layouts where possible.
- Avoid copy-paste implementations.
- Follow DRY principles strictly.

# =========================================================
# COMPONENT ARCHITECTURE RULES
# =========================================================

- Keep presentation and business logic separated.
- Use container/presentation pattern when appropriate.
- Avoid deeply nested prop drilling.
- Use context only when necessary.
- Keep components single responsibility.
- Components must be fully responsive.
- Avoid inline styles unless necessary.
- Use Tailwind utility classes cleanly.
- Keep JSX clean and readable.
- Extract repeated UI patterns.

# =========================================================
# API RULES
# =========================================================

- Use RESTful API structure.
- Validate request body using Zod.
- Return proper HTTP status codes.
- Handle all possible error cases.
- Never expose stack traces.
- Use centralized error handling.
- Use consistent API response format.
- Implement proper authentication middleware.
- Keep API routes lightweight.
- Move business logic to services.

# =========================================================
# SEO RULES
# =========================================================

- Every page must have:
  - unique title
  - meta description
  - canonical URL
  - Open Graph tags
  - Twitter metadata

- Use semantic HTML.
- Use proper heading hierarchy.
- Ensure all pages are crawlable.
- Generate dynamic sitemap.xml.
- Generate robots.txt.
- Implement structured data (JSON-LD).
- Optimize Core Web Vitals.
- Optimize Largest Contentful Paint (LCP).
- Optimize Cumulative Layout Shift (CLS).
- Optimize Interaction to Next Paint (INP).
- Use descriptive alt text for images.
- Lazy load below-the-fold images.
- Avoid duplicate content.
- Use clean URL structures.
- Use internal linking properly.
- Make pages mobile friendly.
- Ensure accessibility compliance.
- Use schema markup where appropriate.
- Use static rendering when SEO is important.

# =========================================================
# ACCESSIBILITY RULES
# =========================================================

- Follow WCAG accessibility standards.
- All buttons must have accessible labels.
- All images must have alt text.
- Ensure keyboard navigation works.
- Maintain proper color contrast.
- Use semantic HTML tags.
- Use aria attributes properly.
- Forms must have labels.
- Show accessible error messages.
- Ensure screen reader compatibility.

# =========================================================
# PERFORMANCE RULES
# =========================================================

- Optimize all images.
- Avoid unnecessary re-renders.
- Use memoization where beneficial.
- Use pagination and lazy loading.
- Minimize bundle size.
- Avoid large client-side dependencies.
- Use tree-shaking friendly imports.
- Optimize animations for performance.
- Use code splitting.
- Optimize fonts and assets.
- Reduce hydration issues.
- Avoid blocking rendering.

# =========================================================
# STYLING RULES
# =========================================================

- Use Tailwind CSS consistently.
- Follow mobile-first responsive design.
- Maintain spacing consistency.
- Use design tokens where possible.
- Avoid random colors and sizes.
- Keep UI modern and clean.
- Use reusable UI patterns.
- Maintain visual consistency across pages.

# =========================================================
# FORM RULES
# =========================================================

- Use React Hook Form.
- Use Zod validation schemas.
- Validate both client-side and server-side.
- Show user-friendly validation errors.
- Prevent duplicate submissions.
- Use loading states.
- Handle edge cases properly.

# =========================================================
# ERROR HANDLING RULES
# =========================================================

- Always handle async errors.
- Never leave empty catch blocks.
- Show user-friendly error messages.
- Log critical server errors securely.
- Implement fallback UI states.
- Add loading states for async operations.

# =========================================================
# DATABASE RULES
# =========================================================

- Normalize data where appropriate.
- Avoid duplicated database records.
- Add timestamps to documents.
- Use createdAt and updatedAt fields.
- Use soft delete where necessary.
- Index frequently queried fields.
- Keep queries optimized.

# =========================================================
# AUTHENTICATION RULES
# =========================================================

- Protect private routes.
- Implement proper session handling.
- Use Firebase Auth securely.
- Verify permissions server-side.
- Never trust client-side roles.
- Implement logout properly.
- Handle token expiration gracefully.

# =========================================================
# FILE STRUCTURE RULES
# =========================================================

Preferred structure:

src/
  app/
  components/
    ui/
    shared/
    forms/
    sections/
  hooks/
  lib/
  services/
  utils/
  types/
  constants/
  validations/
  store/
  providers/

# =========================================================
# CODING STYLE RULES
# =========================================================

- Use functional components only.
- Prefer named exports.
- Use descriptive variable names.
- Avoid abbreviations.
- Keep functions focused.
- Keep logic predictable.
- Use early returns.
- Avoid deeply nested conditions.
- Use enums/constants where useful.
- Write self-documenting code.

# =========================================================
# CLEAN CODE RULES
# =========================================================

- Remove unused imports.
- Remove unused variables.
- Avoid commented dead code.
- Avoid console.logs in production.
- Keep commits production-ready.
- Refactor duplicated logic.
- Improve readability continuously.

# =========================================================
# TESTING RULES
# =========================================================

- Write testable code.
- Keep business logic isolated.
- Prefer pure functions where possible.
- Add validation tests for critical logic.
- Ensure critical flows are stable.

# =========================================================
# FINAL DEVELOPMENT BEHAVIOR
# =========================================================

Before generating code:
- Analyze existing architecture first.
- Reuse existing patterns.
- Preserve project consistency.
- Do not break existing functionality.
- Improve performance whenever possible.
- Improve SEO whenever possible.
- Improve accessibility whenever possible.
- Improve maintainability whenever possible.
- Always think production-first.

Generated code must always be:
- Secure
- Scalable
- Reusable
- SEO optimized
- Accessible
- Responsive
- High performance
- Production ready