/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    formats: ["image/avif", "image/webp"],
    remotePatterns: [
      {
        protocol: "https",
        hostname: "firebasestorage.googleapis.com",
      },
      {
        protocol: "https",
        hostname: "storage.googleapis.com",
      },
      {
        protocol: "https",
        hostname: "alizon-sandbox.firebasestorage.app",
      },
    ],
  },
  async redirects() {
    return [
      { source: "/students", destination: "/student-login", permanent: true },
      { source: "/student-info", destination: "/student-login", permanent: true },
      { source: "/academics", destination: "/programs", permanent: true },
      {
        source: "/testimonials",
        destination: "https://www.alizon.in/alizon-testimonials",
        permanent: true,
      },
    ];
  },
};

export default nextConfig;
