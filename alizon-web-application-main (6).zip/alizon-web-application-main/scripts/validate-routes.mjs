#!/usr/bin/env node
// Ensures internal href="/path" links in src/ match app route page.tsx files.
import { readdirSync, readFileSync, statSync } from "fs";
import { dirname, join, relative } from "path";
import { fileURLToPath } from "url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const appDir = join(root, "app");
const srcDir = join(root, "src");

/** @param {string} dir */
function collectPageRoutes(dir, base = "") {
  /** @type {Set<string>} */
  const routes = new Set();
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    if (!statSync(full).isDirectory()) continue;
    const segment = entry.startsWith("(") ? "" : `/${entry}`;
    const nextBase = base + segment;
    const pageFile = join(full, "page.tsx");
    try {
      if (statSync(pageFile).isFile()) {
        routes.add(nextBase || "/");
      }
    } catch {
      // no page.tsx in this folder
    }
    for (const r of collectPageRoutes(full, nextBase)) {
      routes.add(r);
    }
  }
  return routes;
}

/** @param {string} dir */
function walkSrcFiles(dir) {
  /** @type {string[]} */
  const files = [];
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    if (statSync(full).isDirectory()) {
      files.push(...walkSrcFiles(full));
    } else if (/\.(tsx?|jsx?)$/.test(entry)) {
      files.push(full);
    }
  }
  return files;
}

const appRoutes = collectPageRoutes(appDir);
try {
  if (statSync(join(appDir, "page.tsx")).isFile()) {
    appRoutes.add("/");
  }
} catch {
  // no root page
}
const hrefPattern = /href=["'](\/[^"'#?]*?)["']/g;

/** @type {Map<string, string[]>} */
const violations = new Map();

for (const file of walkSrcFiles(srcDir)) {
  const content = readFileSync(file, "utf8");
  let match;
  while ((match = hrefPattern.exec(content)) !== null) {
    const path = match[1];
    if (path.startsWith("/admin")) continue;
    if (!appRoutes.has(path)) {
      const rel = relative(root, file);
      if (!violations.has(path)) violations.set(path, []);
      violations.get(path).push(rel);
    }
  }
}

if (violations.size > 0) {
  console.error("Route validation failed — href targets with no app page:\n");
  for (const [path, files] of violations) {
    console.error(`  ${path}`);
    for (const f of files) console.error(`    - ${f}`);
  }
  console.error(`\nKnown app routes (${appRoutes.size}): ${[...appRoutes].sort().join(", ")}`);
  process.exit(1);
}

console.log(`Route validation passed (${appRoutes.size} app routes, ${walkSrcFiles(srcDir).length} src files scanned).`);
