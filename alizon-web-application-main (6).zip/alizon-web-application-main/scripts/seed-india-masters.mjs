/**
 * Seed masterStates, masterDistricts, and educationQualifications in Firestore.
 *
 * Usage (from project root):
 *   GOOGLE_APPLICATION_CREDENTIALS=path/to/serviceAccount.json node scripts/seed-india-masters.mjs
 */
import { readFileSync } from "fs";
import { dirname, join } from "path";
import { fileURLToPath } from "url";
import { initializeApp, cert, getApps } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";

const __dirname = dirname(fileURLToPath(import.meta.url));
const seedPath = join(__dirname, "../src/data/india-locations-seed.json");
const seed = JSON.parse(readFileSync(seedPath, "utf8"));

const EDUCATION_QUALIFICATIONS = [
  "High School / Secondary School",
  "Higher Secondary / Senior Secondary (12th Grade)",
  "Diploma",
  "Associate Degree",
  "Bachelor's Degree",
  "Master's Degree",
  "MPhil",
  "Doctorate (PhD)",
  "MD / MS / Medical Degree",
  "Professional Degree",
  "Postdoctoral Fellowship",
  "Vocational / Technical Certification",
  "Other",
];

function slugify(name) {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "");
}

if (!getApps().length) {
  initializeApp();
}

const db = getFirestore();
const BATCH_LIMIT = 400;

async function commitBatches(writes) {
  for (let i = 0; i < writes.length; i += BATCH_LIMIT) {
    const batch = db.batch();
    for (const w of writes.slice(i, i + BATCH_LIMIT)) {
      batch.set(w.ref, w.data, { merge: true });
    }
    await batch.commit();
    console.log(`Committed ${Math.min(i + BATCH_LIMIT, writes.length)} / ${writes.length}`);
  }
}

async function seedStates() {
  const writes = seed.states.map((s) => ({
    ref: db.collection("masterStates").doc(s.id),
    data: { id: s.id, name: s.name, code: s.code ?? "", active: true },
  }));
  await commitBatches(writes);
  console.log(`Seeded ${writes.length} states`);
}

async function seedDistricts() {
  const writes = [];
  for (const [stateId, names] of Object.entries(seed.districts)) {
    for (const name of names) {
      const id = `${stateId}--${slugify(name)}`;
      writes.push({
        ref: db.collection("masterDistricts").doc(id),
        data: { id, stateId, name, active: true },
      });
    }
  }
  for (const s of seed.states) {
    if (!seed.districts[s.id]) {
      const id = `${s.id}--general`;
      writes.push({
        ref: db.collection("masterDistricts").doc(id),
        data: { id, stateId: s.id, name: "General", active: true },
      });
    }
  }
  await commitBatches(writes);
  console.log(`Seeded ${writes.length} districts`);
}

async function seedEducation() {
  const writes = EDUCATION_QUALIFICATIONS.map((name, index) => {
    const id = slugify(name);
    return {
      ref: db.collection("educationQualifications").doc(id),
      data: { id, name, sortOrder: index, active: true },
    };
  });
  await commitBatches(writes);
  console.log(`Seeded ${writes.length} education qualifications`);
}

async function main() {
  await seedStates();
  await seedDistricts();
  await seedEducation();
  console.log("Done.");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
