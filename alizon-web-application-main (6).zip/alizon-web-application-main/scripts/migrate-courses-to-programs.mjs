import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { initializeApp, cert, getApps } from "firebase-admin/app";
import { getFirestore, FieldValue } from "firebase-admin/firestore";

function slugify(name) {
  return String(name || "")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

function initFirebaseAdmin() {
  if (getApps().length > 0) return;
  const serviceAccountPath = process.env.FIREBASE_SERVICE_ACCOUNT_PATH;
  if (!serviceAccountPath) {
    throw new Error("Set FIREBASE_SERVICE_ACCOUNT_PATH before running migration.");
  }
  const raw = readFileSync(resolve(serviceAccountPath), "utf-8");
  initializeApp({ credential: cert(JSON.parse(raw)) });
}

async function run() {
  initFirebaseAdmin();
  const db = getFirestore();

  const coursesSnap = await db.collection("courses").get();
  for (const courseDoc of coursesSnap.docs) {
    const data = courseDoc.data();
    const name = data.name || courseDoc.id;
    const status = data.active === false ? "inactive" : "active";

    await courseDoc.ref.set(
      {
        id: courseDoc.id,
        slug: data.slug || slugify(name),
        shortDescription: data.shortDescription || "",
        fullDescription: data.fullDescription || "",
        category: data.category || "",
        duration: data.duration || "",
        status,
        active: status === "active",
        moduleCount: Array.isArray(data.modules) ? data.modules.length : data.moduleCount || 0,
        studentCount: data.studentCount || 0,
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true },
    );

    const legacyModules = Array.isArray(data.modules) ? data.modules : [];
    for (let i = 0; i < legacyModules.length; i += 1) {
      const moduleName = String(legacyModules[i] || "").trim();
      if (!moduleName) continue;
      const modRef = courseDoc.ref.collection("modules").doc();
      await modRef.set({
        name: moduleName,
        code: `M-${String(i + 1).padStart(2, "0")}`,
        description: "",
        order: i + 1,
        status: "active",
        lessonCount: 0,
        fileCount: 0,
        videoCount: 0,
        createdAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp(),
      });
    }
  }

  const studentsSnap = await db.collection("students").get();
  const programsByName = new Map();
  for (const programDoc of coursesSnap.docs) {
    const p = programDoc.data();
    if (p.name) programsByName.set(String(p.name).toLowerCase().trim(), programDoc.id);
  }
  for (const studentDoc of studentsSnap.docs) {
    const student = studentDoc.data();
    const key = String(student.course || "").toLowerCase().trim();
    if (!key || !programsByName.has(key)) continue;
    await studentDoc.ref.set(
      { programId: programsByName.get(key), updatedAt: FieldValue.serverTimestamp() },
      { merge: true },
    );
  }

  console.log("Migration completed.");
}

run().catch((error) => {
  console.error(error);
  process.exit(1);
});
