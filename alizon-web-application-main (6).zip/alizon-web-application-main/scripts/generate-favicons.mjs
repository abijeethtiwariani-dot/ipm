import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import sharp from "sharp";
import pngToIco from "png-to-ico";

const __dirname = dirname(fileURLToPath(import.meta.url));
const root = join(__dirname, "..");
/** Source: Alizon brand mark (synced from public/Alizon_logo.png). */
const logoPath = join(root, "src/assets/alizon-logo.png");

const outputs = [
  { path: join(root, "public/favicon-16x16.png"), size: 16 },
  { path: join(root, "public/favicon-32x32.png"), size: 32 },
  { path: join(root, "public/apple-touch-icon.png"), size: 180 },
  { path: join(root, "public/android-chrome-192x192.png"), size: 192 },
  { path: join(root, "public/android-chrome-512x512.png"), size: 512 },
  { path: join(root, "app/icon.png"), size: 512 },
];

async function renderIcon(size) {
  return sharp(logoPath)
    .resize(size, size, {
      fit: "contain",
      background: { r: 255, g: 255, b: 255, alpha: 0 },
    })
    .png()
    .toBuffer();
}

mkdirSync(join(root, "public"), { recursive: true });

const png16 = await renderIcon(16);
const png32 = await renderIcon(32);

for (const { path, size } of outputs) {
  mkdirSync(dirname(path), { recursive: true });
  const buffer =
    size === 16 ? png16 : size === 32 ? png32 : await renderIcon(size);
  writeFileSync(path, buffer);
  console.log(`Wrote ${path}`);
}

const icoBuffer = await pngToIco([png16, png32]);
writeFileSync(join(root, "public/favicon.ico"), icoBuffer);
writeFileSync(join(root, "app/favicon.ico"), icoBuffer);
console.log("Wrote public/favicon.ico and app/favicon.ico");
