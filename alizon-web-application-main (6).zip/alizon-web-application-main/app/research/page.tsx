import Research from "@/views/Research";
import { BreadcrumbJsonLd } from "@/components/seo/BreadcrumbJsonLd";
import {
  generateCmsPageMetadata,
  resolveResearchPageSeo,
} from "@/lib/seo/cms-metadata";
import { ROUTES } from "@/lib/site-routes";

export const revalidate = 86400;

export async function generateMetadata() {
  return generateCmsPageMetadata(ROUTES.research, resolveResearchPageSeo);
}

export default function ResearchPage() {
  return (
    <>
      <BreadcrumbJsonLd
        currentPageName="Research & Insights"
        currentPagePath={ROUTES.research}
      />
      <Research />
    </>
  );
}
