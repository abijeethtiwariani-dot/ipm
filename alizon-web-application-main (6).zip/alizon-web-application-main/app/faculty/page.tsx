import Faculty from "@/views/Faculty";
import { BreadcrumbJsonLd } from "@/components/seo/BreadcrumbJsonLd";
import { FacultyLeadershipJsonLd } from "@/components/seo/FacultyLeadershipJsonLd";
import {
  fetchFacultyLeadershipForSchema,
  generateCmsPageMetadata,
  resolveFacultyPageSeo,
} from "@/lib/seo/cms-metadata";
import { ROUTES } from "@/lib/site-routes";

export const revalidate = 86400;

export async function generateMetadata() {
  return generateCmsPageMetadata(ROUTES.faculty, resolveFacultyPageSeo);
}

export default async function FacultyPage() {
  const leaders = await fetchFacultyLeadershipForSchema();

  return (
    <>
      <BreadcrumbJsonLd
        currentPageName="Faculty & Staff"
        currentPagePath={ROUTES.faculty}
      />
      <FacultyLeadershipJsonLd pagePath={ROUTES.faculty} leaders={leaders} />
      <Faculty />
    </>
  );
}
