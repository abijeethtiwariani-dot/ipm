import type { MetadataRoute } from "next";
import { fetchPublicAllotments } from "@/lib/allotments-server";
import { getFirebaseAdminDb, isFirebaseAdminConfigured } from "@/lib/firebase-admin";
import { fetchPublicJobs } from "@/lib/jobs-server";
import { fetchActiveProgramsForSitemap } from "@/lib/programs-server";
import {
  getSitemapChangeFrequency,
  getSitemapPriority,
  INDEXABLE_STATIC_PATHS,
} from "@/lib/seo/sitemap-config";
import { SITE_URL } from "@/lib/site-branding";
import { jobDetailPath, ROUTES } from "@/lib/site-routes";

// Revalidate sitemap every hour (ISR for dynamic slug URLs).
export const revalidate = 3600;

function toValidDate(value: unknown): Date {
  if (!value) return new Date();
  if (value instanceof Date && !Number.isNaN(value.getTime())) return value;
  if (
    typeof value === "object" &&
    value !== null &&
    "toDate" in value &&
    typeof (value as { toDate: () => Date }).toDate === "function"
  ) {
    const parsed = (value as { toDate: () => Date }).toDate();
    return Number.isNaN(parsed.getTime()) ? new Date() : parsed;
  }
  const parsed = new Date(String(value));
  return Number.isNaN(parsed.getTime()) ? new Date() : parsed;
}

function toAbsoluteUrl(path: string): string {
  return `${SITE_URL}${path.startsWith("/") ? path : `/${path}`}`;
}

function buildStaticEntries(): MetadataRoute.Sitemap {
  return INDEXABLE_STATIC_PATHS.map((path) => ({
    url: toAbsoluteUrl(path),
    lastModified: new Date(),
    changeFrequency: getSitemapChangeFrequency(path),
    priority: getSitemapPriority(path),
  }));
}

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const entries: MetadataRoute.Sitemap = buildStaticEntries();

  if (!isFirebaseAdminConfigured()) {
    return entries;
  }

  const db = getFirebaseAdminDb();

  try {
    const [programs, jobsResult, allotmentsResult] = await Promise.all([
      fetchActiveProgramsForSitemap(db),
      fetchPublicJobs(db),
      fetchPublicAllotments(db),
    ]);

    for (const program of programs) {
      entries.push({
        url: toAbsoluteUrl(`${ROUTES.programs}/${program.slug}`),
        lastModified: toValidDate(program.updatedAt),
        changeFrequency: "weekly",
        priority: 0.8,
      });
    }

    for (const job of jobsResult.jobs) {
      entries.push({
        url: toAbsoluteUrl(jobDetailPath(job.slug)),
        lastModified: toValidDate(job.updatedAt),
        changeFrequency: "weekly",
        priority: 0.7,
      });
    }

    for (const allotment of allotmentsResult.allotments) {
      entries.push({
        url: toAbsoluteUrl(`${ROUTES.allotment}/${allotment.slug}`),
        lastModified: toValidDate(
          allotment.updatedAt ?? allotment.updatedDate ?? allotment.publishDate,
        ),
        changeFrequency: "weekly",
        priority: 0.6,
      });
    }
  } catch {
    return entries;
  }

  return entries;
}
