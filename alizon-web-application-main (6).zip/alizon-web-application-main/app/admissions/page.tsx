import Admissions from "@/views/Admissions";
import { BreadcrumbJsonLd } from "@/components/seo/BreadcrumbJsonLd";
import {
  generateCmsPageMetadata,
  resolveAdmissionsPageSeo,
} from "@/lib/seo/cms-metadata";
import { ROUTES } from "@/lib/site-routes";

export const revalidate = 86400;

export async function generateMetadata() {
  return generateCmsPageMetadata(ROUTES.admissions, resolveAdmissionsPageSeo);
}

export default function AdmissionsPage() {
  return (
    <>
      <BreadcrumbJsonLd
        currentPageName="Admissions"
        currentPagePath={ROUTES.admissions}
      />
      <Admissions />
    </>
  );
}
