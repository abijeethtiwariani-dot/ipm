import Index from "@/views/Index";
import { HomePageJsonLd } from "@/components/seo/HomePageJsonLd";
import { buildPageMetadata } from "@/lib/seo/metadata";
import { STATIC_PAGE_SEO } from "@/lib/seo/page-seo";
import { ROUTES } from "@/lib/site-routes";

export const revalidate = 86400;

export const metadata = buildPageMetadata({
  ...STATIC_PAGE_SEO.home,
  path: ROUTES.home,
});

export default function HomePage() {
  return (
    <>
      <HomePageJsonLd />
      <Index />
    </>
  );
}
