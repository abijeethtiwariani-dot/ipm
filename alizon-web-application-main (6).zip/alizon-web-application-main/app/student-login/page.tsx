import { Suspense } from "react";
import { StudentLoginForm } from "@/components/student/StudentLoginForm";
import { LampLoginSkeleton } from "@/components/student/lamp-login/LampLoginSkeleton";

export const metadata = {
  title: "Student Login",
};

export default function StudentLoginPage() {
  return (
    <div className="w-full">
      <Suspense fallback={<LampLoginSkeleton />}>
        <StudentLoginForm />
      </Suspense>
    </div>
  );
}
