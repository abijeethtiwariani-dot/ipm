import News from "@/views/News";
import { BreadcrumbJsonLd } from "@/components/seo/BreadcrumbJsonLd";
import { NewsCollectionJsonLd } from "@/components/seo/NewsCollectionJsonLd";
import {
  fetchNewsArticlesForSchema,
  generateCmsPageMetadata,
  resolveNewsPageSeo,
} from "@/lib/seo/cms-metadata";
import { ROUTES } from "@/lib/site-routes";

export const revalidate = 3600;

export async function generateMetadata() {
  return generateCmsPageMetadata(ROUTES.news, resolveNewsPageSeo);
}

export default async function NewsPage() {
  const articles = await fetchNewsArticlesForSchema();

  return (
    <>
      <BreadcrumbJsonLd currentPageName="News" currentPagePath={ROUTES.news} />
      <NewsCollectionJsonLd
        pagePath={ROUTES.news}
        pageName="News"
        articles={articles}
      />
      <News />
    </>
  );
}
