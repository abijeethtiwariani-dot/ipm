import type { Metadata } from "next";
import NewsDetail from "@/views/NewsDetail";
import { BreadcrumbJsonLd } from "@/components/seo/BreadcrumbJsonLd";
import { NewsArticleJsonLd } from "@/components/seo/NewsArticleJsonLd";
import { getFirebaseAdminDb, isFirebaseAdminConfigured } from "@/lib/firebase-admin";
import { buildJobMetaDescription } from "@/lib/job-seo";
import { fetchPublicNewsCardById } from "@/lib/news-server";
import { buildPageMetadata } from "@/lib/seo/metadata";
import { getStaticPageSeo } from "@/lib/seo/page-seo";
import { newsDetailPath, ROUTES } from "@/lib/site-routes";

export const revalidate = 3600;

type Props = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id } = await params;
  const path = newsDetailPath(id);
  const fallback = getStaticPageSeo(ROUTES.news);

  if (!isFirebaseAdminConfigured()) {
    return buildPageMetadata({
      title: "News Article",
      description: fallback.description,
      path,
    });
  }

  const card = await fetchPublicNewsCardById(getFirebaseAdminDb(), id);
  if (!card) {
    return buildPageMetadata({
      title: "Article not found",
      description: fallback.description,
      path,
      noIndex: true,
    });
  }

  return buildPageMetadata({
    title: card.title,
    description: buildJobMetaDescription(card.subContent || card.content),
    path,
    ogImage: card.imageUrl || undefined,
    ogType: "article",
  });
}

export default async function NewsDetailPage({ params }: Props) {
  const { id } = await params;
  const path = newsDetailPath(id);
  const card = isFirebaseAdminConfigured()
    ? await fetchPublicNewsCardById(getFirebaseAdminDb(), id)
    : null;

  return (
    <>
      <BreadcrumbJsonLd
        items={[
          { name: "Home", path: ROUTES.home },
          { name: "News", path: ROUTES.news },
          { name: card?.title ?? "Article", path },
        ]}
      />
      {card ? <NewsArticleJsonLd card={card} /> : null}
      <NewsDetail id={id} />
    </>
  );
}
