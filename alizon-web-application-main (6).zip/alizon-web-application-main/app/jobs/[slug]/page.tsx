import type { Metadata } from "next";
import JobDetail from "@/views/JobDetail";
import { BreadcrumbJsonLd } from "@/components/seo/BreadcrumbJsonLd";
import { JobPostingJsonLd } from "@/components/seo/JobPostingJsonLd";
import { getFirebaseAdminDb, isFirebaseAdminConfigured } from "@/lib/firebase-admin";
import {
  buildJobMetaDescription,
  buildJobMetaKeywords,
  buildJobPageTitle,
} from "@/lib/job-seo";
import { fetchPublicJobBySlug } from "@/lib/jobs-server";
import { buildPageMetadata } from "@/lib/seo/metadata";
import { getStaticPageSeo } from "@/lib/seo/page-seo";
import { jobDetailPath, ROUTES } from "@/lib/site-routes";

export const revalidate = 3600;

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const path = jobDetailPath(slug);
  const fallback = getStaticPageSeo(ROUTES.jobs);

  if (!isFirebaseAdminConfigured()) {
    return buildPageMetadata({
      title: "Job Opening",
      description: fallback.description,
      path,
    });
  }

  const job = await fetchPublicJobBySlug(getFirebaseAdminDb(), slug);
  if (!job) {
    return buildPageMetadata({
      title: "Job not found",
      description: fallback.description,
      path,
      noIndex: true,
    });
  }

  return buildPageMetadata({
    title: buildJobPageTitle(job.title),
    description: buildJobMetaDescription(job.shortDescription),
    path,
    keywords: buildJobMetaKeywords({
      title: job.title,
      department: job.department,
      location: job.location,
    }),
    ogType: "article",
  });
}

export default async function JobDetailPage({ params }: Props) {
  const { slug } = await params;
  const path = jobDetailPath(slug);
  const job = isFirebaseAdminConfigured()
    ? await fetchPublicJobBySlug(getFirebaseAdminDb(), slug)
    : null;

  return (
    <>
      <BreadcrumbJsonLd
        items={[
          { name: "Home", path: ROUTES.home },
          { name: "Careers", path: ROUTES.careers },
          { name: job?.title ?? "Job", path },
        ]}
      />
      {job ? <JobPostingJsonLd job={job} /> : null}
      <JobDetail slug={slug} />
    </>
  );
}
