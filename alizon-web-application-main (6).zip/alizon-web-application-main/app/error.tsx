"use client";

import { Button } from "@/components/ui/button";

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <section className="container mx-auto flex min-h-[50vh] items-center justify-center px-4 py-24">
      <div className="max-w-md text-center">
        <h1 className="mb-4 text-3xl font-heading font-bold text-foreground">
          Something went wrong
        </h1>
        <p className="mb-6 text-muted-foreground">
          {error.message || "Please try again in a moment."}
        </p>
        <Button onClick={reset}>Try again</Button>
      </div>
    </section>
  );
}
