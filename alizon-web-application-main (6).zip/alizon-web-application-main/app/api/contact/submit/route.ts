import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import {
  getFirebaseAdminDb,
  isFirebaseAdminConfigured,
} from "@/lib/firebase-admin";
import { contactEnquirySubmitSchema } from "@/lib/contact-enquiry-schema";
import { COLLECTIONS } from "@/lib/student-constants";

export async function POST(request: Request) {
  if (!isFirebaseAdminConfigured()) {
    return NextResponse.json(
      { error: "Server is not configured." },
      { status: 503 },
    );
  }

  try {
    const body = await request.json();
    const parsed = contactEnquirySubmitSchema.safeParse(body);

    if (!parsed.success) {
      const first = parsed.error.errors[0];
      return NextResponse.json(
        { error: first?.message ?? "Invalid form data." },
        { status: 400 },
      );
    }

    const data = parsed.data;
    const docRef = await getFirebaseAdminDb()
      .collection(COLLECTIONS.contactEnquiries)
      .add({
        name: data.name.trim(),
        email: data.email.toLowerCase().trim(),
        phone: data.phone.trim(),
        department: data.department.trim(),
        message: data.message.trim(),
        createdAt: FieldValue.serverTimestamp(),
      });

    return NextResponse.json({ success: true, id: docRef.id });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to submit enquiry.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
