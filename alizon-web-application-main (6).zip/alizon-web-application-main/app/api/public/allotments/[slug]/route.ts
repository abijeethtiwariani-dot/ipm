import { NextResponse } from "next/server";
import { getFirebaseAdminDb, isFirebaseAdminConfigured } from "@/lib/firebase-admin";
import { fetchPublicAllotmentBySlug } from "@/lib/allotments-server";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ slug: string }> },
) {
  try {
    if (!isFirebaseAdminConfigured()) {
      return NextResponse.json({ allotment: null }, { status: 404 });
    }

    const { slug } = await params;
    const allotment = await fetchPublicAllotmentBySlug(getFirebaseAdminDb(), slug);

    if (!allotment) {
      return NextResponse.json({ allotment: null }, { status: 404 });
    }

    return NextResponse.json({ allotment });
  } catch {
    return NextResponse.json({ error: "Failed to load allotment." }, { status: 500 });
  }
}
