import { NextResponse } from "next/server";
import { getFirebaseAdminDb, isFirebaseAdminConfigured } from "@/lib/firebase-admin";
import { fetchPublicAllotments } from "@/lib/allotments-server";
import type { AllotmentSortOption } from "@/types/allotment";
import { ALLOTMENT_SORT_OPTIONS } from "@/types/allotment";

export async function GET(request: Request) {
  try {
    if (!isFirebaseAdminConfigured()) {
      return NextResponse.json({ categories: [], allotments: [] });
    }

    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") ?? undefined;
    const categoryId = searchParams.get("categoryId") ?? undefined;
    const sortParam = searchParams.get("sort") ?? "latest";
    const sort = ALLOTMENT_SORT_OPTIONS.includes(sortParam as AllotmentSortOption)
      ? (sortParam as AllotmentSortOption)
      : "latest";

    const data = await fetchPublicAllotments(getFirebaseAdminDb(), {
      search,
      categoryId: categoryId || undefined,
      sort,
    });

    return NextResponse.json(data);
  } catch {
    return NextResponse.json({ error: "Failed to load allotments." }, { status: 500 });
  }
}
