import { NextResponse } from "next/server";
import { getFirebaseAdminDb, isFirebaseAdminConfigured } from "@/lib/firebase-admin";
import { fetchPublicJobBySlug } from "@/lib/jobs-server";

type Props = { params: Promise<{ slug: string }> };

export async function GET(_request: Request, context: Props) {
  try {
    if (!isFirebaseAdminConfigured()) {
      return NextResponse.json({ error: "Job not found." }, { status: 404 });
    }

    const { slug } = await context.params;
    const job = await fetchPublicJobBySlug(getFirebaseAdminDb(), slug);

    if (!job) {
      return NextResponse.json({ error: "Job not found." }, { status: 404 });
    }

    return NextResponse.json({ job });
  } catch {
    return NextResponse.json({ error: "Failed to load job." }, { status: 500 });
  }
}
