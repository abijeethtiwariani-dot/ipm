import { NextResponse } from "next/server";
import { getFirebaseAdminDb, isFirebaseAdminConfigured } from "@/lib/firebase-admin";
import { fetchPublicJobs } from "@/lib/jobs-server";
import type { EmploymentType, JobSortOption } from "@/types/job";
import { EMPLOYMENT_TYPES, JOB_SORT_OPTIONS } from "@/types/job";

export async function GET(request: Request) {
  try {
    if (!isFirebaseAdminConfigured()) {
      return NextResponse.json({ jobs: [], departments: [], locations: [], total: 0 });
    }

    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") ?? searchParams.get("q") ?? undefined;
    const department = searchParams.get("department") ?? undefined;
    const location = searchParams.get("location") ?? undefined;
    const employmentTypeParam = searchParams.get("employmentType") ?? undefined;
    const employmentType = EMPLOYMENT_TYPES.includes(
      employmentTypeParam as EmploymentType,
    )
      ? (employmentTypeParam as EmploymentType)
      : undefined;
    const featured = searchParams.get("featured") === "true";
    const limitParam = searchParams.get("limit");
    const limit = limitParam ? Number(limitParam) : undefined;
    const sortParam = searchParams.get("sort") ?? "latest";
    const sort = JOB_SORT_OPTIONS.includes(sortParam as JobSortOption)
      ? (sortParam as JobSortOption)
      : "latest";

    const data = await fetchPublicJobs(getFirebaseAdminDb(), {
      search,
      department: department && department !== "all" ? department : undefined,
      location: location && location !== "all" ? location : undefined,
      employmentType,
      featured,
      limit: limit && limit > 0 ? limit : undefined,
      sort,
    });

    return NextResponse.json(data);
  } catch {
    return NextResponse.json({ error: "Failed to load jobs." }, { status: 500 });
  }
}
