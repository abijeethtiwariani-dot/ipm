import { NextResponse } from "next/server";
import { fetchResearchPageContent } from "@/lib/research-page-cms-server";
import { EMPTY_RESEARCH_PAGE_CONTENT } from "@/lib/research-page-cms";
import { getFirebaseAdminDb, isFirebaseAdminConfigured } from "@/lib/firebase-admin";

export async function GET() {
  try {
    if (!isFirebaseAdminConfigured()) {
      return NextResponse.json({ content: EMPTY_RESEARCH_PAGE_CONTENT });
    }

    const content = await fetchResearchPageContent(getFirebaseAdminDb());
    return NextResponse.json({ content });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to load research page content.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
