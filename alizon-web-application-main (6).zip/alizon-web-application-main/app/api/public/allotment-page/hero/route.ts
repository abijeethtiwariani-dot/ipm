import { NextResponse } from "next/server";
import {
  getFirebaseAdminDb,
  isFirebaseAdminConfigured,
} from "@/lib/firebase-admin";
import {
  ALLOTMENT_PAGE_CMS_PATHS,
  mapAllotmentPageHeroData,
} from "@/lib/allotment-page-cms";

export async function GET() {
  try {
    if (!isFirebaseAdminConfigured()) {
      return NextResponse.json({ data: null });
    }

    const db = getFirebaseAdminDb();
    const snap = await db
      .collection(ALLOTMENT_PAGE_CMS_PATHS.hero.collection)
      .doc(ALLOTMENT_PAGE_CMS_PATHS.hero.docId)
      .get();

    if (!snap.exists) {
      return NextResponse.json({ data: null });
    }

    const raw = snap.data() as Record<string, unknown>;
    const mapped = mapAllotmentPageHeroData(raw);

    return NextResponse.json({
      data: mapped,
      raw: process.env.NODE_ENV === "development" ? raw : undefined,
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to load hero.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
