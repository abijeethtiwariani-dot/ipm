import { NextResponse } from "next/server";
import { getFirebaseAdminDb, isFirebaseAdminConfigured } from "@/lib/firebase-admin";
import { COLLECTIONS } from "@/lib/student-constants";
import type { Program } from "@/types/program";

export async function GET() {
  try {
    if (!isFirebaseAdminConfigured()) {
      return NextResponse.json({ programs: [] });
    }
    const db = getFirebaseAdminDb();
    const snap = await db
      .collection(COLLECTIONS.courses)
      .where("active", "==", true)
      .get();
    const programs = snap.docs.map((doc) => ({ id: doc.id, ...doc.data() })) as Program[];
    programs.sort((a, b) => a.name.localeCompare(b.name));
    return NextResponse.json({ programs });
  } catch (error) {
    return NextResponse.json({ error: "Failed to load programs." }, { status: 500 });
  }
}
