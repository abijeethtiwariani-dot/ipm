import { NextResponse } from "next/server";
import { getFirebaseAdminDb, isFirebaseAdminConfigured } from "@/lib/firebase-admin";
import { COLLECTIONS } from "@/lib/student-constants";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ slug: string }> },
) {
  try {
    if (!isFirebaseAdminConfigured()) {
      return NextResponse.json({ program: null }, { status: 404 });
    }
    const { slug } = await params;
    const db = getFirebaseAdminDb();
    const snap = await db
      .collection(COLLECTIONS.courses)
      .where("slug", "==", slug)
      .where("active", "==", true)
      .limit(1)
      .get();
    if (snap.empty) return NextResponse.json({ program: null }, { status: 404 });
    const doc = snap.docs[0]!;
    const modules = await doc.ref.collection(COLLECTIONS.modules).orderBy("order", "asc").get();
    return NextResponse.json({
      program: {
        id: doc.id,
        ...doc.data(),
        modules: modules.docs.map((m) => ({ id: m.id, ...m.data() })),
      },
    });
  } catch (error) {
    return NextResponse.json({ error: "Failed to load program." }, { status: 500 });
  }
}
