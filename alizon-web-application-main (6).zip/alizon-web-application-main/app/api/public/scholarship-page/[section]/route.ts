import { NextResponse } from "next/server";
import {
  getFirebaseAdminDb,
  isFirebaseAdminConfigured,
} from "@/lib/firebase-admin";
import {
  mapScholarshipFaqCard,
  mapScholarshipPageBenefitsData,
  mapScholarshipPageDetailsData,
  mapScholarshipPageFeaturedScholarData,
  mapScholarshipPageFaqHeaderData,
  mapScholarshipPageHeroData,
  mapScholarshipPageOverviewData,
  mapScholarshipPageSectionHeaderData,
  mapScholarshipPageStatsData,
  mapScholarshipSuccessStoryCard,
  SCHOLARSHIP_PAGE_API_SECTION_PATHS,
  type ScholarshipPageApiSection,
} from "@/lib/scholarship-page-cms";

const VALID_SECTIONS = new Set<string>(
  Object.keys(SCHOLARSHIP_PAGE_API_SECTION_PATHS),
);

export async function GET(
  _request: Request,
  context: { params: Promise<{ section: string }> },
) {
  const { section } = await context.params;

  if (!VALID_SECTIONS.has(section)) {
    return NextResponse.json({ error: "Unknown section." }, { status: 404 });
  }

  const apiSection = section as ScholarshipPageApiSection;
  const path = SCHOLARSHIP_PAGE_API_SECTION_PATHS[apiSection];

  try {
    if (!isFirebaseAdminConfigured()) {
      return NextResponse.json({ data: null });
    }

    const db = getFirebaseAdminDb();

    if (path.isCards) {
      const snap = await db
        .collection(path.collection)
        .orderBy("order", "asc")
        .get();

      const cards = snap.docs
        .map((doc) => {
          const raw = doc.data() as Record<string, unknown>;
          if (apiSection === "success-stories") {
            return mapScholarshipSuccessStoryCard(doc.id, raw);
          }
          return mapScholarshipFaqCard(doc.id, raw);
        })
        .filter((item): item is NonNullable<typeof item> => item !== null);

      return NextResponse.json({ data: cards });
    }

    const snap = await db
      .collection(path.collection)
      .doc(path.docId!)
      .get();

    if (!snap.exists) {
      return NextResponse.json({ data: null });
    }

    const raw = snap.data() as Record<string, unknown>;
    let mapped: Record<string, unknown> | null = null;

    switch (apiSection) {
      case "hero":
        mapped = mapScholarshipPageHeroData(raw) as Record<string, unknown>;
        break;
      case "overview":
        mapped = mapScholarshipPageOverviewData(raw) as Record<string, unknown>;
        break;
      case "featured-scholar":
        mapped = mapScholarshipPageFeaturedScholarData(
          raw,
        ) as Record<string, unknown>;
        break;
      case "details":
        mapped = mapScholarshipPageDetailsData(raw) as Record<string, unknown>;
        break;
      case "success-stories-header":
        mapped = mapScholarshipPageSectionHeaderData(
          raw,
        ) as Record<string, unknown>;
        break;
      case "benefits":
        mapped = mapScholarshipPageBenefitsData(raw) as Record<string, unknown>;
        break;
      case "impact-stats":
        mapped = mapScholarshipPageStatsData(raw) as Record<string, unknown>;
        break;
      case "faq-header":
        mapped = mapScholarshipPageFaqHeaderData(raw) as Record<string, unknown>;
        break;
      default:
        mapped = raw;
    }

    return NextResponse.json({
      data: mapped,
      raw: process.env.NODE_ENV === "development" ? raw : undefined,
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to load section.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
