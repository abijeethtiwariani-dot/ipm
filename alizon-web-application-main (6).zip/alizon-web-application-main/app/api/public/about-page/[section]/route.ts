import { NextResponse } from "next/server";
import { getFirebaseAdminDb, isFirebaseAdminConfigured } from "@/lib/firebase-admin";
import {
  ABOUT_PAGE_API_SECTION_PATHS,
  mapAboutPageSectionData,
  type AboutPageApiSection,
} from "@/lib/about-page-cms";

const VALID_SECTIONS = new Set<string>(
  Object.keys(ABOUT_PAGE_API_SECTION_PATHS),
);

export async function GET(
  _request: Request,
  context: { params: Promise<{ section: string }> },
) {
  const { section } = await context.params;

  if (!VALID_SECTIONS.has(section)) {
    return NextResponse.json({ error: "Unknown section." }, { status: 404 });
  }

  const apiSection = section as AboutPageApiSection;

  try {
    if (!isFirebaseAdminConfigured()) {
      return NextResponse.json({ data: null });
    }

    const db = getFirebaseAdminDb();
    const path = ABOUT_PAGE_API_SECTION_PATHS[apiSection];
    const snap = await db.collection(path.collection).doc(path.docId).get();

    if (!snap.exists) {
      return NextResponse.json({ data: null });
    }

    const raw = snap.data() as Record<string, unknown>;
    const mapped = mapAboutPageSectionData(apiSection, raw);

    return NextResponse.json({
      data: mapped,
      raw: process.env.NODE_ENV === "development" ? raw : undefined,
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to load section.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
