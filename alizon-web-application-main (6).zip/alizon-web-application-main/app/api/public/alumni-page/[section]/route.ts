import { NextResponse } from "next/server";
import {
  getFirebaseAdminDb,
  isFirebaseAdminConfigured,
} from "@/lib/firebase-admin";
import {
  ALUMNI_PAGE_API_SECTION_PATHS,
  mapAlumniCommunityLinksData,
  mapAlumniLeader,
  mapAlumniLeadershipHeaderData,
  mapAlumniNotification,
  mapAlumniNotificationsHeaderData,
  mapAlumniPageHeroData,
  mapAlumniStatistic,
  mapAlumniTestimonial,
  type AlumniPageApiSection,
} from "@/lib/alumni-page-cms";

const VALID_SECTIONS = new Set<string>(
  Object.keys(ALUMNI_PAGE_API_SECTION_PATHS),
);

export async function GET(
  _request: Request,
  context: { params: Promise<{ section: string }> },
) {
  const { section } = await context.params;

  if (!VALID_SECTIONS.has(section)) {
    return NextResponse.json({ error: "Unknown section." }, { status: 404 });
  }

  const apiSection = section as AlumniPageApiSection;
  const path = ALUMNI_PAGE_API_SECTION_PATHS[apiSection];

  try {
    if (!isFirebaseAdminConfigured()) {
      return NextResponse.json({ data: null });
    }

    const db = getFirebaseAdminDb();

    if (path.isCards) {
      const snap = await db
        .collection(path.collection)
        .orderBy("order", "asc")
        .get();

      const cards = snap.docs
        .map((doc) => {
          const raw = { ...doc.data(), id: doc.id } as Record<string, unknown>;
          switch (apiSection) {
            case "leadership":
              return mapAlumniLeader(doc.id, raw);
            case "notifications":
              return mapAlumniNotification(doc.id, raw);
            case "statistics":
              return mapAlumniStatistic(doc.id, raw);
            case "testimonials":
              return mapAlumniTestimonial(doc.id, raw);
            default:
              return null;
          }
        })
        .filter((item): item is NonNullable<typeof item> => item !== null);

      return NextResponse.json({ data: cards });
    }

    const snap = await db
      .collection(path.collection)
      .doc(path.docId!)
      .get();

    if (!snap.exists) {
      return NextResponse.json({ data: null });
    }

    const raw = snap.data() as Record<string, unknown>;
    let mapped: Record<string, unknown> | null = null;

    switch (apiSection) {
      case "hero":
        mapped = mapAlumniPageHeroData(raw) as Record<string, unknown>;
        break;
      case "leadership-header":
        mapped = mapAlumniLeadershipHeaderData(raw) as Record<string, unknown>;
        break;
      case "notifications-header":
        mapped = mapAlumniNotificationsHeaderData(raw) as Record<string, unknown>;
        break;
      case "community-links":
        mapped = mapAlumniCommunityLinksData(raw) as Record<string, unknown>;
        break;
      default:
        mapped = raw;
    }

    return NextResponse.json({
      data: mapped,
      raw: process.env.NODE_ENV === "development" ? raw : undefined,
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to load section.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
