import { NextResponse } from "next/server";
import { getFirebaseAdminDb, isFirebaseAdminConfigured } from "@/lib/firebase-admin";
import {
  ADMISSION_PAGE_API_SECTION_PATHS,
  mapAdmissionPageSectionData,
  type AdmissionPageApiSection,
} from "@/lib/admission-page-cms";

const VALID_SECTIONS = new Set<string>(Object.keys(ADMISSION_PAGE_API_SECTION_PATHS));

export async function GET(
  _request: Request,
  context: { params: Promise<{ section: string }> },
) {
  const { section } = await context.params;

  if (!VALID_SECTIONS.has(section)) {
    return NextResponse.json({ error: "Unknown section." }, { status: 404 });
  }

  const apiSection = section as AdmissionPageApiSection;
  const path = ADMISSION_PAGE_API_SECTION_PATHS[apiSection];

  try {
    if (!isFirebaseAdminConfigured()) {
      return NextResponse.json({ data: null });
    }

    const snap = await getFirebaseAdminDb()
      .collection(path.collection)
      .doc(path.docId)
      .get();

    if (!snap.exists) {
      return NextResponse.json({ data: null });
    }

    const raw = snap.data() as Record<string, unknown>;
    const mapped = mapAdmissionPageSectionData(apiSection, raw);

    return NextResponse.json({
      data: mapped,
      raw: process.env.NODE_ENV === "development" ? raw : undefined,
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to load section.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
