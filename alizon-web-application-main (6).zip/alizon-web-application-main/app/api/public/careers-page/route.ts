import { NextResponse } from "next/server";
import { fetchCareersPageContent } from "@/lib/careers-page-cms-server";
import { EMPTY_CAREERS_PAGE_CONTENT } from "@/lib/careers-page-cms";
import { getFirebaseAdminDb, isFirebaseAdminConfigured } from "@/lib/firebase-admin";

export async function GET() {
  try {
    if (!isFirebaseAdminConfigured()) {
      return NextResponse.json({ content: EMPTY_CAREERS_PAGE_CONTENT });
    }

    const content = await fetchCareersPageContent(getFirebaseAdminDb());
    return NextResponse.json({ content });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to load careers page content.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
