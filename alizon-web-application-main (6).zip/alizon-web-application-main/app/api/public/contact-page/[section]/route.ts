import { NextResponse } from "next/server";
import {
  getFirebaseAdminDb,
  isFirebaseAdminConfigured,
} from "@/lib/firebase-admin";
import {
  CONTACT_PAGE_API_SECTION_PATHS,
  mapContactPageDepartmentCard,
  mapContactPageDepartmentsHeaderData,
  mapContactPageFormData,
  mapContactPageHeroData,
  mapContactPageInfoCard,
  mapContactPageMapData,
  type ContactPageApiSection,
} from "@/lib/contact-page-cms";

const VALID_SECTIONS = new Set<string>(
  Object.keys(CONTACT_PAGE_API_SECTION_PATHS),
);

export async function GET(
  _request: Request,
  context: { params: Promise<{ section: string }> },
) {
  const { section } = await context.params;

  if (!VALID_SECTIONS.has(section)) {
    return NextResponse.json({ error: "Unknown section." }, { status: 404 });
  }

  const apiSection = section as ContactPageApiSection;
  const path = CONTACT_PAGE_API_SECTION_PATHS[apiSection];

  try {
    if (!isFirebaseAdminConfigured()) {
      return NextResponse.json({ data: null });
    }

    const db = getFirebaseAdminDb();

    if (path.isCards) {
      const snap = await db
        .collection(path.collection)
        .orderBy("order", "asc")
        .get();

      const cards = snap.docs
        .map((doc) => {
          const raw = doc.data() as Record<string, unknown>;
          if (apiSection === "info-cards") {
            return mapContactPageInfoCard(doc.id, raw);
          }
          return mapContactPageDepartmentCard(doc.id, raw);
        })
        .filter((item): item is NonNullable<typeof item> => item !== null);

      return NextResponse.json({ data: cards });
    }

    const snap = await db
      .collection(path.collection)
      .doc(path.docId!)
      .get();

    if (!snap.exists) {
      return NextResponse.json({ data: null });
    }

    const raw = snap.data() as Record<string, unknown>;
    let mapped: Record<string, unknown> | null = null;

    switch (apiSection) {
      case "hero":
        mapped = mapContactPageHeroData(raw) as Record<string, unknown>;
        break;
      case "form":
        mapped = mapContactPageFormData(raw) as Record<string, unknown>;
        break;
      case "map":
        mapped = mapContactPageMapData(raw) as Record<string, unknown>;
        break;
      case "departments-header":
        mapped = mapContactPageDepartmentsHeaderData(
          raw,
        ) as Record<string, unknown>;
        break;
      default:
        mapped = raw;
    }

    return NextResponse.json({
      data: mapped,
      raw: process.env.NODE_ENV === "development" ? raw : undefined,
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to load section.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
