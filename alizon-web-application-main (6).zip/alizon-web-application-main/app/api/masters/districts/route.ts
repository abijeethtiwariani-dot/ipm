import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { loadMasterDistricts } from "@/lib/masters-server";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const stateId = searchParams.get("stateId")?.trim();
    if (!stateId) {
      return NextResponse.json({ error: "stateId is required." }, { status: 400 });
    }
    const districts = await loadMasterDistricts(getFirebaseAdminDb(), stateId);
    return NextResponse.json(
      { districts },
      { headers: { "Cache-Control": "public, max-age=3600, stale-while-revalidate=86400" } },
    );
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to load districts";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
