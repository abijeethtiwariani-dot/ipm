import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { loadMasterStates } from "@/lib/masters-server";

export async function GET() {
  try {
    const states = await loadMasterStates(getFirebaseAdminDb());
    return NextResponse.json(
      { states },
      { headers: { "Cache-Control": "public, max-age=3600, stale-while-revalidate=86400" } },
    );
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to load states";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
