import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { loadEducationQualifications } from "@/lib/masters-server";

export async function GET() {
  try {
    const qualifications = await loadEducationQualifications(getFirebaseAdminDb());
    return NextResponse.json(
      { qualifications },
      { headers: { "Cache-Control": "public, max-age=3600, stale-while-revalidate=86400" } },
    );
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to load qualifications";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
