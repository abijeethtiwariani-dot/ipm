import { NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { FieldValue } from "firebase-admin/firestore";
import {
  getFirebaseAdminDb,
  getFirebaseAdminStorage,
  isFirebaseAdminConfigured,
} from "@/lib/firebase-admin";
import { jobApplicationSubmitSchema } from "@/lib/job-application-schema";
import { validateJobApplicationCvFile } from "@/lib/job-application-upload-policy";
import { COLLECTIONS } from "@/lib/student-constants";

function formString(formData: FormData, key: string): string {
  const value = formData.get(key);
  return typeof value === "string" ? value : "";
}

export async function POST(request: Request) {
  if (!isFirebaseAdminConfigured()) {
    return NextResponse.json(
      { error: "Server is not configured." },
      { status: 503 },
    );
  }

  try {
    const formData = await request.formData();
    const parsed = jobApplicationSubmitSchema.safeParse({
      name: formString(formData, "name"),
      email: formString(formData, "email"),
      phone: formString(formData, "phone"),
      positionAppliedFor: formString(formData, "positionAppliedFor"),
      jobId: formString(formData, "jobId"),
      dateOfBirth: formString(formData, "dateOfBirth"),
      gender: formString(formData, "gender"),
      address: formString(formData, "address"),
      message: formString(formData, "message"),
      whatsappConsent: formString(formData, "whatsappConsent") === "true",
    });

    if (!parsed.success) {
      const first = parsed.error.errors[0];
      return NextResponse.json(
        { error: first?.message ?? "Invalid form data." },
        { status: 400 },
      );
    }

    const data = parsed.data;
    const cvFile = formData.get("cv");
    const db = getFirebaseAdminDb();
    const docRef = db.collection(COLLECTIONS.jobApplications).doc();

    let cvUrl = "";
    let cvFileName = "";
    let cvStoragePath = "";

    if (cvFile instanceof File && cvFile.size > 0) {
      const fileError = validateJobApplicationCvFile(
        cvFile.name,
        cvFile.type,
        cvFile.size,
      );
      if (fileError) {
        return NextResponse.json({ error: fileError }, { status: 400 });
      }

      const safeName = cvFile.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      cvStoragePath = `job-applications/${docRef.id}/${randomUUID()}-${safeName}`;
      cvFileName = cvFile.name;

      const bucket = getFirebaseAdminStorage().bucket();
      const bucketFile = bucket.file(cvStoragePath);
      const buffer = Buffer.from(await cvFile.arrayBuffer());

      await bucketFile.save(buffer, {
        contentType: cvFile.type || "application/octet-stream",
        metadata: { cacheControl: "public, max-age=31536000" },
      });
      await bucketFile.makePublic();
      cvUrl = bucketFile.publicUrl();
    }

    await docRef.set({
      name: data.name.trim(),
      email: data.email.toLowerCase().trim(),
      phone: data.phone.trim(),
      positionAppliedFor: data.positionAppliedFor.trim(),
      jobId: data.jobId.trim(),
      dateOfBirth: data.dateOfBirth,
      gender: data.gender,
      address: data.address.trim(),
      message: (data.message ?? "").trim(),
      whatsappConsent: Boolean(data.whatsappConsent),
      ...(cvUrl
        ? {
            cvUrl,
            cvFileName,
            cvStoragePath,
          }
        : {}),
      createdAt: FieldValue.serverTimestamp(),
    });

    return NextResponse.json({ success: true, id: docRef.id });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to submit application.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
