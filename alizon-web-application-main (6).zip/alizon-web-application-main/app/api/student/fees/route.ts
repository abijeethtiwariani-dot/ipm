import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireStudentSession } from "@/lib/server-student-session";
import { COLLECTIONS } from "@/lib/student-constants";
import {
  buildSummaryForStudent,
  loadPaymentsForStudent,
  loadPrograms,
} from "@/lib/fees-server";

export async function GET() {
  try {
    const { uid } = await requireStudentSession();
    const db = getFirebaseAdminDb();

    const [studentSnap, programs, payments] = await Promise.all([
      db.collection(COLLECTIONS.students).doc(uid).get(),
      loadPrograms(db),
      loadPaymentsForStudent(db, uid),
    ]);

    if (!studentSnap.exists) {
      return NextResponse.json({ error: "Student not found." }, { status: 404 });
    }

    const paymentsByStudent = new Map([[uid, payments]]);
    const summary = buildSummaryForStudent(
      { id: studentSnap.id, data: studentSnap.data() ?? {} },
      programs,
      paymentsByStudent,
    );

    if (!summary) {
      return NextResponse.json(
        { error: "Your account is not approved for fee access." },
        { status: 403 },
      );
    }

    return NextResponse.json({ summary, payments });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unauthorized";
    const status = message === "Unauthorized" || message === "Forbidden" ? 401 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
