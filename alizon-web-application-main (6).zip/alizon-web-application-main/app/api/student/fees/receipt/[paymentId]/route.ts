import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireStudentSession } from "@/lib/server-student-session";
import { mapFeePaymentDoc } from "@/lib/fees";
import {
  buildSummaryForStudent,
  loadPaymentsForStudent,
  loadPrograms,
} from "@/lib/fees-server";
import { COLLECTIONS } from "@/lib/student-constants";
import type { FeeReceiptData } from "@/types/fees";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ paymentId: string }> },
) {
  try {
    const { uid } = await requireStudentSession();
    const { paymentId } = await params;
    const db = getFirebaseAdminDb();

    const paymentSnap = await db.collection(COLLECTIONS.feePayments).doc(paymentId).get();
    if (!paymentSnap.exists) {
      return NextResponse.json({ error: "Payment not found." }, { status: 404 });
    }

    const payment = mapFeePaymentDoc(paymentSnap.id, paymentSnap.data() ?? {});
    if (payment.studentId !== uid) {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const [studentSnap, programs, payments] = await Promise.all([
      db.collection(COLLECTIONS.students).doc(uid).get(),
      loadPrograms(db),
      loadPaymentsForStudent(db, uid),
    ]);

    if (!studentSnap.exists) {
      return NextResponse.json({ error: "Student not found." }, { status: 404 });
    }

    const paymentsByStudent = new Map([[uid, payments]]);
    const summary = buildSummaryForStudent(
      { id: studentSnap.id, data: studentSnap.data() ?? {} },
      programs,
      paymentsByStudent,
    );

    if (!summary) {
      return NextResponse.json({ error: "Unable to build receipt." }, { status: 400 });
    }

    const receipt: FeeReceiptData = {
      payment,
      student: {
        name: summary.studentName,
        registrationId: summary.registrationId,
        email: String(studentSnap.data()?.email ?? ""),
      },
      program: { name: summary.programName },
      summary: {
        courseFee: summary.courseFee,
        scholarshipPercentage: summary.scholarshipPercentage,
        discountAmount: summary.discountAmount,
        finalPayableFee: summary.finalPayableFee,
        totalPaid: summary.totalPaid,
        dueAmount: summary.dueAmount,
      },
    };

    return NextResponse.json({ receipt });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unauthorized";
    const status = message === "Unauthorized" || message === "Forbidden" ? 401 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
