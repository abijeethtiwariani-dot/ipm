import { NextResponse } from "next/server";
import {
  getFirebaseAdminAuth,
  getFirebaseAdminDb,
  isFirebaseAdminConfigured,
} from "@/lib/firebase-admin";
import { COLLECTIONS } from "@/lib/student-constants";

export async function POST(request: Request) {
  if (!isFirebaseAdminConfigured()) {
    return NextResponse.json(
      { error: "Password reset is not available. Contact support." },
      { status: 503 },
    );
  }

  try {
    const body = (await request.json()) as {
      email?: string;
      phone?: string;
      newPassword?: string;
    };

    const email = body.email?.toLowerCase().trim();
    const phone = body.phone?.trim();
    const newPassword = body.newPassword;

    if (!email || !phone || !newPassword) {
      return NextResponse.json(
        { error: "Email, phone, and new password are required." },
        { status: 400 },
      );
    }

    if (newPassword.length < 8) {
      return NextResponse.json(
        { error: "Password must be at least 8 characters." },
        { status: 400 },
      );
    }

    const db = getFirebaseAdminDb();
    const studentsSnap = await db
      .collection(COLLECTIONS.students)
      .where("email", "==", email)
      .where("phone", "==", phone)
      .limit(1)
      .get();

    if (studentsSnap.empty) {
      return NextResponse.json(
        { error: "No student account matches the provided email and phone." },
        { status: 404 },
      );
    }

    const studentDoc = studentsSnap.docs[0]!;
    const uid = studentDoc.id;

    const auth = getFirebaseAdminAuth();
    await auth.updateUser(uid, { password: newPassword });

    return NextResponse.json({ success: true });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to reset password.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
