import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { mapModuleDoc } from "@/lib/modules";
import { mapProgramDoc } from "@/lib/programs";
import { resolveStudentProgramId } from "@/lib/program-student-count";
import { requireStudentSession } from "@/lib/server-student-session";
import { COLLECTIONS } from "@/lib/student-constants";

export async function GET() {
  try {
    const { uid } = await requireStudentSession();
    const db = getFirebaseAdminDb();

    const studentSnap = await db.collection(COLLECTIONS.students).doc(uid).get();
    if (!studentSnap.exists) {
      return NextResponse.json({ error: "Student not found." }, { status: 404 });
    }

    const studentData = studentSnap.data() ?? {};
    const programsSnap = await db.collection(COLLECTIONS.courses).get();
    const programs = programsSnap.docs.map((doc) => ({
      id: doc.id,
      name: String(doc.data().name ?? ""),
    }));

    const resolvedProgramId = resolveStudentProgramId(
      {
        programId: String(studentData.programId ?? ""),
        course: String(studentData.course ?? ""),
      },
      programs,
    );

    if (!resolvedProgramId) {
      return NextResponse.json({ program: null, modules: [] });
    }

    const [programSnap, modulesSnap] = await Promise.all([
      db.collection(COLLECTIONS.courses).doc(resolvedProgramId).get(),
      db
        .collection(COLLECTIONS.courses)
        .doc(resolvedProgramId)
        .collection(COLLECTIONS.modules)
        .orderBy("order", "asc")
        .get(),
    ]);

    if (!programSnap.exists) {
      return NextResponse.json({ program: null, modules: [] });
    }

    const program = mapProgramDoc(programSnap.id, programSnap.data() ?? {});
    const modules = modulesSnap.docs.map((doc) =>
      mapModuleDoc(resolvedProgramId, doc.id, doc.data()),
    );

    return NextResponse.json({ program, modules });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unauthorized";
    const status =
      message === "Unauthorized" || message === "Forbidden" ? 401 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
