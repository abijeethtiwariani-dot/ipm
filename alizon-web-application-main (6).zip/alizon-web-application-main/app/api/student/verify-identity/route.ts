import { NextResponse } from "next/server";
import {
  getFirebaseAdminDb,
  isFirebaseAdminConfigured,
} from "@/lib/firebase-admin";
import { COLLECTIONS } from "@/lib/student-constants";

export async function POST(request: Request) {
  if (!isFirebaseAdminConfigured()) {
    return NextResponse.json(
      { error: "Server is not configured." },
      { status: 503 },
    );
  }

  try {
    const { email, phone } = (await request.json()) as {
      email?: string;
      phone?: string;
    };

    if (!email?.trim() || !phone?.trim()) {
      return NextResponse.json(
        { error: "Email and phone are required." },
        { status: 400 },
      );
    }

    const snap = await getFirebaseAdminDb()
      .collection(COLLECTIONS.students)
      .where("email", "==", email.toLowerCase().trim())
      .where("phone", "==", phone.trim())
      .limit(1)
      .get();

    return NextResponse.json({ valid: !snap.empty });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Verification failed.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
