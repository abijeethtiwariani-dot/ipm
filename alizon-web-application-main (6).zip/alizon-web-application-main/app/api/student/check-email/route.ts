import { NextResponse } from "next/server";
import {
  getFirebaseAdminDb,
  isFirebaseAdminConfigured,
} from "@/lib/firebase-admin";
import { COLLECTIONS } from "@/lib/student-constants";

export async function POST(request: Request) {
  if (!isFirebaseAdminConfigured()) {
    return NextResponse.json(
      { error: "Server is not configured." },
      { status: 503 },
    );
  }

  try {
    const { email } = (await request.json()) as { email?: string };
    if (!email?.trim()) {
      return NextResponse.json({ error: "Email is required." }, { status: 400 });
    }

    const normalizedEmail = email.toLowerCase().trim();
    const snap = await getFirebaseAdminDb()
      .collection(COLLECTIONS.students)
      .where("email", "==", normalizedEmail)
      .limit(1)
      .get();

    return NextResponse.json({ taken: !snap.empty });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to check email.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
