import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb, isFirebaseAdminConfigured } from "@/lib/firebase-admin";
import { requireApprovedStudent } from "@/lib/server-student-auth";
import { COLLECTIONS } from "@/lib/student-constants";
import type { EvaluationComponentKey } from "@/types/student-evaluation";

export async function POST(request: Request) {
  if (!isFirebaseAdminConfigured()) {
    return NextResponse.json(
      { error: "Server authentication is not configured." },
      { status: 503 },
    );
  }

  try {
    const body = (await request.json()) as {
      idToken?: string;
      component?: EvaluationComponentKey;
      fileUrl?: string;
      storagePath?: string;
      fileName?: string;
    };

    if (!body.idToken || !body.component || !body.fileUrl || !body.storagePath) {
      return NextResponse.json({ error: "Missing required fields." }, { status: 400 });
    }

    if (body.component !== "internship" && body.component !== "elective") {
      return NextResponse.json({ error: "Invalid component." }, { status: 400 });
    }

    const student = await requireApprovedStudent(body.idToken);
    const ref = getFirebaseAdminDb()
      .collection(COLLECTIONS.studentEvaluations)
      .doc(student.uid);

    const existing = await ref.get();
    const componentData = existing.data()?.[body.component] as
      | { status?: string }
      | undefined;

    if (componentData?.status === "Graded") {
      return NextResponse.json(
        { error: "This submission has already been graded. Contact support to re-upload." },
        { status: 400 },
      );
    }

    await ref.set(
      {
        studentId: student.uid,
        registrationId: student.registrationId,
        [body.component]: {
          marks: null,
          feedback: "",
          status: "Pending",
          fileUrl: body.fileUrl,
          storagePath: body.storagePath,
          fileName: body.fileName ?? "",
          submittedAt: FieldValue.serverTimestamp(),
          gradedAt: null,
        },
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true },
    );

    return NextResponse.json({ success: true });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Upload failed.";
    const status = message.includes("approved") ? 403 : 401;
    return NextResponse.json({ error: message }, { status });
  }
}
