import { NextResponse } from "next/server";
import {
  getFirebaseAdminAuth,
  getFirebaseAdminDb,
  isFirebaseAdminConfigured,
} from "@/lib/firebase-admin";
import { canStudentAccessPortal, normalizeStudentAccountStatus } from "@/lib/student-account-status";
import { COLLECTIONS, STUDENT_SESSION_COOKIE } from "@/lib/student-constants";

const SESSION_EXPIRES_MS = 60 * 60 * 24 * 5 * 1000; // 5 days

export async function POST(request: Request) {
  if (!isFirebaseAdminConfigured()) {
    return NextResponse.json(
      { error: "Server authentication is not configured." },
      { status: 503 },
    );
  }

  try {
    const { idToken } = (await request.json()) as { idToken?: string };
    if (!idToken) {
      return NextResponse.json({ error: "Missing idToken." }, { status: 400 });
    }

    const auth = getFirebaseAdminAuth();
    const decoded = await auth.verifyIdToken(idToken);
    const studentSnap = await getFirebaseAdminDb()
      .collection(COLLECTIONS.students)
      .doc(decoded.uid)
      .get();

    if (!studentSnap.exists) {
      return NextResponse.json(
        { error: "Student profile not found." },
        { status: 403 },
      );
    }

    const accountStatus = normalizeStudentAccountStatus(
      studentSnap.data()?.accountStatus,
    );
    if (!canStudentAccessPortal(accountStatus)) {
      return NextResponse.json(
        { error: "Your account is not approved for portal access yet." },
        { status: 403 },
      );
    }

    const sessionCookie = await auth.createSessionCookie(idToken, {
      expiresIn: SESSION_EXPIRES_MS,
    });

    const response = NextResponse.json({ success: true });
    response.cookies.set(STUDENT_SESSION_COOKIE, sessionCookie, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: SESSION_EXPIRES_MS / 1000,
      path: "/",
    });
    return response;
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to create session.";
    return NextResponse.json({ error: message }, { status: 401 });
  }
}

export async function DELETE() {
  const response = NextResponse.json({ success: true });
  response.cookies.set(STUDENT_SESSION_COOKIE, "", {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 0,
    path: "/",
  });
  return response;
}
