import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import {
  getFirebaseAdminDb,
  getFirebaseAdminStorage,
  isFirebaseAdminConfigured,
} from "@/lib/firebase-admin";
import {
  getLatestAssignmentForModule,
  getModuleUploadEligibility,
  uploadEligibilityMessage,
  validateAssignmentSubmissionFile,
} from "@/lib/assignment-upload-policy";
import { normalizeAssignmentResubmissionDays } from "@/lib/programs";
import { requireApprovedStudent } from "@/lib/server-student-auth";
import { COLLECTIONS } from "@/lib/student-constants";

export async function POST(request: Request) {
  if (!isFirebaseAdminConfigured()) {
    return NextResponse.json(
      { error: "Server authentication is not configured." },
      { status: 503 },
    );
  }

  try {
    const body = (await request.json()) as {
      idToken?: string;
      programId?: string;
      moduleId?: string;
      moduleName?: string;
      assignmentTitle?: string;
      fileUrl?: string;
      storagePath?: string;
    };

    if (
      !body.idToken ||
      !body.moduleId ||
      !body.moduleName ||
      !body.assignmentTitle ||
      !body.fileUrl ||
      !body.storagePath
    ) {
      return NextResponse.json({ error: "Missing required fields." }, { status: 400 });
    }

    const fileName = body.storagePath.split("/").pop() ?? "";
    const fileTypeError = validateAssignmentSubmissionFile(fileName, "", 0);
    if (fileTypeError) {
      return NextResponse.json({ error: fileTypeError }, { status: 400 });
    }

    const student = await requireApprovedStudent(body.idToken);
    const db = getFirebaseAdminDb();
    const programId = String(body.programId ?? "").trim();

    let resubmissionDays = normalizeAssignmentResubmissionDays(undefined);
    if (programId) {
      const programSnap = await db.collection(COLLECTIONS.courses).doc(programId).get();
      if (programSnap.exists) {
        resubmissionDays = normalizeAssignmentResubmissionDays(
          programSnap.data()?.assignmentResubmissionDays,
        );
      }
    }

    const existingSnap = await db
      .collection(COLLECTIONS.assignments)
      .where("studentId", "==", student.uid)
      .where("moduleId", "==", body.moduleId)
      .get();

    const existingAssignments = existingSnap.docs.map((docSnap) => {
      const data = docSnap.data();
      return {
        id: docSnap.id,
        studentId: String(data.studentId ?? ""),
        registrationId: String(data.registrationId ?? ""),
        programId: String(data.programId ?? ""),
        moduleId: String(data.moduleId ?? ""),
        moduleName: String(data.moduleName ?? ""),
        assignmentTitle: String(data.assignmentTitle ?? ""),
        fileUrl: String(data.fileUrl ?? ""),
        storagePath: String(data.storagePath ?? ""),
        status: data.status as "Pending" | "Approved" | "Rejected",
        marks:
          data.marks !== undefined && data.marks !== null
            ? Number(data.marks)
            : null,
        feedback: String(data.feedback ?? ""),
        submittedAt: data.submittedAt,
        gradedAt: data.gradedAt,
      };
    });

    const latestAssignment = getLatestAssignmentForModule(
      existingAssignments,
      body.moduleId,
    );
    const latestDoc = latestAssignment
      ? existingSnap.docs.find((d) => d.id === latestAssignment.id)
      : undefined;

    const eligibility = getModuleUploadEligibility({
      assignment: latestAssignment,
      resubmissionDays,
    });

    if (eligibility !== "allowed_new" && eligibility !== "allowed_resubmit") {
      return NextResponse.json(
        {
          error: uploadEligibilityMessage(eligibility, resubmissionDays),
        },
        { status: 400 },
      );
    }

    const bucket = getFirebaseAdminStorage().bucket();

    if (eligibility === "allowed_resubmit" && latestDoc && latestAssignment) {
      const oldStoragePath = latestAssignment.storagePath;
      await latestDoc.ref.set(
        {
          programId,
          moduleId: body.moduleId,
          moduleName: body.moduleName.trim(),
          assignmentTitle: body.assignmentTitle.trim(),
          fileUrl: body.fileUrl,
          storagePath: body.storagePath,
          status: "Pending",
          marks: null,
          feedback: "",
          submittedAt: FieldValue.serverTimestamp(),
          gradedAt: null,
        },
        { merge: true },
      );

      if (oldStoragePath && oldStoragePath !== body.storagePath) {
        try {
          await bucket.file(oldStoragePath).delete();
        } catch {
          // ignore missing old file
        }
      }

      return NextResponse.json({ success: true, assignmentId: latestDoc.id });
    }

    const docRef = await db.collection(COLLECTIONS.assignments).add({
      studentId: student.uid,
      registrationId: student.registrationId,
      programId,
      moduleId: body.moduleId,
      moduleName: body.moduleName.trim(),
      assignmentTitle: body.assignmentTitle.trim(),
      fileUrl: body.fileUrl,
      storagePath: body.storagePath,
      status: "Pending",
      marks: null,
      feedback: "",
      submittedAt: FieldValue.serverTimestamp(),
    });

    return NextResponse.json({ success: true, assignmentId: docRef.id });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Submit failed.";
    const status = message.includes("approved") ? 403 : 401;
    return NextResponse.json({ error: message }, { status });
  }
}
