import { NextResponse } from "next/server";
import {
  getFirebaseAdminAuth,
  isFirebaseAdminConfigured,
} from "@/lib/firebase-admin";

export async function POST(request: Request) {
  if (!isFirebaseAdminConfigured()) {
    return NextResponse.json({ success: false }, { status: 503 });
  }

  try {
    const { uid } = (await request.json()) as { uid?: string };
    if (!uid) {
      return NextResponse.json({ error: "Missing uid." }, { status: 400 });
    }

    const auth = getFirebaseAdminAuth();
    await auth.deleteUser(uid);
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ success: false }, { status: 500 });
  }
}
