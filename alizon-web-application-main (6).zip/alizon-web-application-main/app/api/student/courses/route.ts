import { NextResponse } from "next/server";
import {
  getFirebaseAdminDb,
  isFirebaseAdminConfigured,
} from "@/lib/firebase-admin";
import { COLLECTIONS } from "@/lib/student-constants";

export async function GET() {
  if (!isFirebaseAdminConfigured()) {
    return NextResponse.json({ courses: [] });
  }

  try {
    const coursesCollection = getFirebaseAdminDb().collection(COLLECTIONS.courses);
    const [activeBoolSnap, activeStatusSnap] = await Promise.all([
      coursesCollection.where("active", "==", true).get(),
      coursesCollection.where("status", "==", "active").get(),
    ]);

    const byId = new Map<string, FirebaseFirestore.DocumentData>();
    for (const doc of activeBoolSnap.docs) byId.set(doc.id, doc.data());
    for (const doc of activeStatusSnap.docs) byId.set(doc.id, doc.data());

    const courses = [...byId.entries()]
      .map(([id, data]) => ({
        id,
        name: (data.name as string) ?? "",
        modules: Array.isArray(data.modules)
          ? (data.modules as string[])
          : [],
        active: data.active !== false && data.status !== "inactive",
      }))
      .sort((a, b) => a.name.localeCompare(b.name));

    return NextResponse.json({ courses });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to load courses.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
