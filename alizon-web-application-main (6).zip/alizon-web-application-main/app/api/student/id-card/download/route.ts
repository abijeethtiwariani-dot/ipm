import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireStudentSession } from "@/lib/server-student-session";
import { COLLECTIONS } from "@/lib/student-constants";
import {
  buildIdCardAttachmentDisposition,
  downloadIdCardBuffer,
} from "@/lib/student-id-card-server";

export async function GET() {
  try {
    const { uid } = await requireStudentSession();
    const db = getFirebaseAdminDb();
    const studentSnap = await db.collection(COLLECTIONS.students).doc(uid).get();
    if (!studentSnap.exists) {
      return NextResponse.json({ error: "Student not found." }, { status: 404 });
    }

    const idCard = studentSnap.data()?.idCard as
      | { storagePath?: string; fileName?: string; mimeType?: string }
      | undefined;
    if (!idCard?.storagePath) {
      return NextResponse.json({ error: "ID card not available." }, { status: 404 });
    }

    const buffer = await downloadIdCardBuffer(idCard.storagePath);
    const fileName = idCard.fileName ?? "student-id-card";
    const mimeType = idCard.mimeType ?? "application/octet-stream";

    return new NextResponse(new Uint8Array(buffer), {
      headers: {
        "Content-Type": mimeType,
        "Content-Disposition": buildIdCardAttachmentDisposition(fileName),
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Download failed.";
    const status =
      message === "Unauthorized" || message === "Forbidden" ? 401 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
