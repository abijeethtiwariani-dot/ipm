import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import {
  getFirebaseAdminDb,
  isFirebaseAdminConfigured,
} from "@/lib/firebase-admin";
import { validateGrievanceMessage } from "@/lib/grievance-validation";
import { requireApprovedStudent } from "@/lib/server-student-auth";
import { COLLECTIONS } from "@/lib/student-constants";

export async function POST(request: Request) {
  if (!isFirebaseAdminConfigured()) {
    return NextResponse.json(
      { error: "Server authentication is not configured." },
      { status: 503 },
    );
  }

  try {
    const body = (await request.json()) as {
      idToken?: string;
      assignmentId?: string;
      message?: string;
    };

    if (!body.idToken || !body.assignmentId) {
      return NextResponse.json({ error: "Missing required fields." }, { status: 400 });
    }

    const validated = validateGrievanceMessage(body.message);
    if (validated.ok === false) {
      return NextResponse.json({ error: validated.error }, { status: 400 });
    }

    const student = await requireApprovedStudent(body.idToken);
    const db = getFirebaseAdminDb();
    const ref = db.collection(COLLECTIONS.assignments).doc(body.assignmentId);
    const snap = await ref.get();

    if (!snap.exists) {
      return NextResponse.json({ error: "Assignment not found." }, { status: 404 });
    }

    const data = snap.data() ?? {};
    if (String(data.studentId ?? "") !== student.uid) {
      return NextResponse.json({ error: "Assignment not found." }, { status: 404 });
    }

    const status = String(data.status ?? "");
    if (status !== "Approved" && status !== "Rejected") {
      return NextResponse.json(
        { error: "Grievances can only be submitted for graded assignments." },
        { status: 400 },
      );
    }

    if (data.grievance && typeof data.grievance === "object") {
      return NextResponse.json(
        { error: "A grievance has already been submitted for this assignment." },
        { status: 400 },
      );
    }

    await ref.update({
      grievance: {
        message: validated.message,
        submittedAt: FieldValue.serverTimestamp(),
        adminStatus: "Pending",
        statusUpdatedAt: FieldValue.serverTimestamp(),
      },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to submit grievance.";
    const status = message.includes("not approved") ? 403 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
