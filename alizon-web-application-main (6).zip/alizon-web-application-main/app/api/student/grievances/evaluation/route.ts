import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import {
  getFirebaseAdminDb,
  isFirebaseAdminConfigured,
} from "@/lib/firebase-admin";
import { validateGrievanceMessage } from "@/lib/grievance-validation";
import { requireApprovedStudent } from "@/lib/server-student-auth";
import { COLLECTIONS } from "@/lib/student-constants";
import type { EvaluationGradeComponentKey } from "@/types/student-evaluation";

const VALID_COMPONENTS: EvaluationGradeComponentKey[] = [
  "viva",
  "internship",
  "elective",
];

export async function POST(request: Request) {
  if (!isFirebaseAdminConfigured()) {
    return NextResponse.json(
      { error: "Server authentication is not configured." },
      { status: 503 },
    );
  }

  try {
    const body = (await request.json()) as {
      idToken?: string;
      component?: EvaluationGradeComponentKey;
      message?: string;
    };

    if (!body.idToken || !body.component) {
      return NextResponse.json({ error: "Missing required fields." }, { status: 400 });
    }

    if (!VALID_COMPONENTS.includes(body.component)) {
      return NextResponse.json({ error: "Invalid component." }, { status: 400 });
    }

    const validated = validateGrievanceMessage(body.message);
    if (validated.ok === false) {
      return NextResponse.json({ error: validated.error }, { status: 400 });
    }

    const student = await requireApprovedStudent(body.idToken);
    const db = getFirebaseAdminDb();
    const ref = db.collection(COLLECTIONS.studentEvaluations).doc(student.uid);
    const snap = await ref.get();

    const data = snap.exists ? snap.data() ?? {} : {};
    const componentData = (data[body.component] as Record<string, unknown>) ?? {};

    if (String(componentData.status ?? "") !== "Graded") {
      return NextResponse.json(
        { error: "Grievances can only be submitted for graded evaluations." },
        { status: 400 },
      );
    }

    if (componentData.grievance && typeof componentData.grievance === "object") {
      return NextResponse.json(
        { error: "A grievance has already been submitted for this evaluation." },
        { status: 400 },
      );
    }

    await ref.set(
      {
        studentId: student.uid,
        registrationId: String(data.registrationId ?? student.registrationId),
        [body.component]: {
          ...componentData,
          grievance: {
            message: validated.message,
            submittedAt: FieldValue.serverTimestamp(),
            adminStatus: "Pending",
            statusUpdatedAt: FieldValue.serverTimestamp(),
          },
        },
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true },
    );

    return NextResponse.json({ success: true });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to submit grievance.";
    const status = message.includes("not approved") ? 403 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
