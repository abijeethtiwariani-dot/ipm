import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireStudentSession } from "@/lib/server-student-session";
import { getProfileCompletionPercent } from "@/lib/student-profile-completion";
import {
  mergeProfileWithDraft,
  normalizeStudentProfile,
  syncLegacyFieldsFromProfile,
} from "@/lib/student-profile-migration";
import { getEffectiveProfile, mapStudentDoc } from "@/lib/student-mapper";
import {
  studentProfileDraftSchema,
  studentProfileSchema,
} from "@/lib/student-profile-schema";
import { stripUndefinedDeep } from "@/lib/firestore-sanitize";
import { COLLECTIONS } from "@/lib/student-constants";
import type { StudentProfileDetails } from "@/types/student-profile";

const STUDENT_BLOCKED_KEYS = [
  "scholarshipPercentage",
  "feeNotes",
  "assignedBatch",
  "course",
  "programId",
  "accountStatus",
  "idCard",
];

export async function GET() {
  try {
    const { uid } = await requireStudentSession();
    const db = getFirebaseAdminDb();
    const ref = db.collection(COLLECTIONS.students).doc(uid);
    const snap = await ref.get();
    if (!snap.exists) {
      return NextResponse.json({ error: "Student not found." }, { status: 404 });
    }

    const data = snap.data() ?? {};
    let student = mapStudentDoc(snap.id, data);

    if (!data.profile) {
      const migrated = normalizeStudentProfile(undefined, {
        name: student.name,
        email: student.email,
        phone: student.phone,
      });
      await ref.set({ profile: stripUndefinedDeep(migrated) }, { merge: true });
      student = mapStudentDoc(snap.id, { ...data, profile: migrated });
    }

    const effectiveProfile = getEffectiveProfile(student);
    const completionPercent = getProfileCompletionPercent(effectiveProfile);

    return NextResponse.json({ student, effectiveProfile, completionPercent });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unauthorized";
    const status =
      message === "Unauthorized" || message === "Forbidden" ? 401 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}

export async function PATCH(request: Request) {
  try {
    const { uid } = await requireStudentSession();
    const { searchParams } = new URL(request.url);
    const isDraft = searchParams.get("draft") === "true";
    const body = (await request.json()) as Record<string, unknown>;

    for (const key of STUDENT_BLOCKED_KEYS) {
      if (key in body) {
        return NextResponse.json(
          { error: `Students cannot update ${key}.` },
          { status: 403 },
        );
      }
    }

    const db = getFirebaseAdminDb();
    const ref = db.collection(COLLECTIONS.students).doc(uid);
    const snap = await ref.get();
    if (!snap.exists) {
      return NextResponse.json({ error: "Student not found." }, { status: 404 });
    }

    const existing = snap.data() ?? {};
    const student = mapStudentDoc(snap.id, existing);

    if (isDraft) {
      const parsed = studentProfileDraftSchema.safeParse(body.profileDraft);
      if (!parsed.success) {
        return NextResponse.json(
          { error: parsed.error.flatten().fieldErrors },
          { status: 400 },
        );
      }
      await ref.set(
        {
          profileDraft: stripUndefinedDeep(parsed.data),
          profileDraftUpdatedAt: FieldValue.serverTimestamp(),
        },
        { merge: true },
      );
      return NextResponse.json({ success: true });
    }

    const parsed = studentProfileSchema.safeParse(body.profile);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Validation failed.", details: parsed.error.flatten() },
        { status: 400 },
      );
    }

    const profile = parsed.data as StudentProfileDetails;
    const legacy = syncLegacyFieldsFromProfile(profile);

    await ref.set(
      stripUndefinedDeep({
        profile,
        profileDraft: FieldValue.delete(),
        profileDraftUpdatedAt: FieldValue.delete(),
        profileUpdatedAt: FieldValue.serverTimestamp(),
        name: legacy.name,
        email: legacy.email,
        phone: legacy.phone,
      }),
      { merge: true },
    );

    const updatedSnap = await ref.get();
    const updated = mapStudentDoc(updatedSnap.id, updatedSnap.data() ?? {});
    const effectiveProfile = mergeProfileWithDraft(
      updated.profile ?? profile,
      undefined,
    );

    return NextResponse.json({
      student: updated,
      effectiveProfile,
      completionPercent: getProfileCompletionPercent(effectiveProfile),
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unauthorized";
    const status =
      message === "Unauthorized" || message === "Forbidden" ? 401 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
