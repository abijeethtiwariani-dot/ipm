import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireStudentSession } from "@/lib/server-student-session";
import { COLLECTIONS } from "@/lib/student-constants";

export async function PATCH(request: Request) {
  try {
    const { uid } = await requireStudentSession();
    const body = (await request.json()) as { profilePhotoUrl?: string };
    const url = body.profilePhotoUrl?.trim();
    if (!url || !url.startsWith("https://")) {
      return NextResponse.json({ error: "Invalid photo URL." }, { status: 400 });
    }

    await getFirebaseAdminDb()
      .collection(COLLECTIONS.students)
      .doc(uid)
      .set(
        {
          profilePhotoUrl: url,
          profileUpdatedAt: FieldValue.serverTimestamp(),
        },
        { merge: true },
      );

    return NextResponse.json({ success: true, profilePhotoUrl: url });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Unauthorized";
    const status =
      message === "Unauthorized" || message === "Forbidden" ? 401 : 500;
    return NextResponse.json({ error: message }, { status: status });
  }
}
