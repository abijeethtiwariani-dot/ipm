import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import {
  normalizeAssignmentResubmissionDays,
  normalizeEvaluationMaxMarks,
} from "@/lib/programs";
import { COLLECTIONS } from "@/lib/student-constants";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ programId: string }> },
) {
  try {
    await requireAdmin();
    const { programId } = await params;
    const snap = await getFirebaseAdminDb()
      .collection(COLLECTIONS.courses)
      .doc(programId)
      .get();
    if (!snap.exists) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    return NextResponse.json({ program: { id: snap.id, ...snap.data() } });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ programId: string }> },
) {
  try {
    await requireAdmin();
    const { programId } = await params;
    const payload = (await request.json()) as Record<string, unknown>;
    const nextPatch: Record<string, unknown> = { ...payload };

    if (payload.assignmentResubmissionDays !== undefined) {
      nextPatch.assignmentResubmissionDays = normalizeAssignmentResubmissionDays(
        payload.assignmentResubmissionDays,
      );
    }
    if (payload.vivaMaxMarks !== undefined) {
      nextPatch.vivaMaxMarks = normalizeEvaluationMaxMarks(payload.vivaMaxMarks);
    }
    if (payload.internshipMaxMarks !== undefined) {
      nextPatch.internshipMaxMarks = normalizeEvaluationMaxMarks(
        payload.internshipMaxMarks,
      );
    }
    if (payload.electiveMaxMarks !== undefined) {
      nextPatch.electiveMaxMarks = normalizeEvaluationMaxMarks(
        payload.electiveMaxMarks,
      );
    }
    if (typeof payload.status === "string") {
      nextPatch.active = payload.status === "active";
    } else if (typeof payload.active === "boolean") {
      nextPatch.status = payload.active ? "active" : "inactive";
    }
    await getFirebaseAdminDb()
      .collection(COLLECTIONS.courses)
      .doc(programId)
      .set({ ...nextPatch, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ programId: string }> },
) {
  try {
    await requireAdmin();
    const { programId } = await params;
    await getFirebaseAdminDb().collection(COLLECTIONS.courses).doc(programId).delete();
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
