import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import { normalizeAssignmentTotalMarks } from "@/lib/modules";
import { COLLECTIONS } from "@/lib/student-constants";

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ programId: string; moduleId: string }> },
) {
  try {
    await requireAdmin();
    const { programId, moduleId } = await params;
    const payload = (await request.json()) as Record<string, unknown>;
    const nextPatch: Record<string, unknown> = { ...payload };
    if (payload.assignmentTotalMarks !== undefined) {
      nextPatch.assignmentTotalMarks = normalizeAssignmentTotalMarks(
        payload.assignmentTotalMarks,
      );
    }
    await getFirebaseAdminDb()
      .collection(COLLECTIONS.courses)
      .doc(programId)
      .collection(COLLECTIONS.modules)
      .doc(moduleId)
      .set({ ...nextPatch, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ programId: string; moduleId: string }> },
) {
  try {
    await requireAdmin();
    const { programId, moduleId } = await params;
    const db = getFirebaseAdminDb();
    await db
      .collection(COLLECTIONS.courses)
      .doc(programId)
      .collection(COLLECTIONS.modules)
      .doc(moduleId)
      .delete();

    const count = (
      await db
        .collection(COLLECTIONS.courses)
        .doc(programId)
        .collection(COLLECTIONS.modules)
        .get()
    ).size;
    await db.collection(COLLECTIONS.courses).doc(programId).set(
      {
        moduleCount: count,
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true },
    );

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
