import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import { syncModuleResourceCounts } from "@/lib/module-resource-sync";
import { COLLECTIONS } from "@/lib/student-constants";
import type { ModuleResourceType } from "@/types/program";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ programId: string; moduleId: string }> },
) {
  try {
    await requireAdmin();
    const { programId, moduleId } = await params;
    const snap = await getFirebaseAdminDb()
      .collection(COLLECTIONS.courses)
      .doc(programId)
      .collection(COLLECTIONS.modules)
      .doc(moduleId)
      .collection(COLLECTIONS.resources)
      .get();

    const resources = snap.docs
      .map((doc) => ({
        id: doc.id,
        programId,
        moduleId,
        title: (doc.data().title as string) ?? "",
        type: doc.data().type,
        url: (doc.data().url as string) ?? "",
        storagePath: (doc.data().storagePath as string) ?? "",
        fileSize: Number(doc.data().fileSize ?? 0),
        mimeType: (doc.data().mimeType as string) ?? "",
        downloadCount: Number(doc.data().downloadCount ?? 0),
        createdAt: doc.data().createdAt,
        updatedAt: doc.data().updatedAt,
      }))
      .sort((a, b) => String(a.title).localeCompare(String(b.title)));

    return NextResponse.json({ resources });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ programId: string; moduleId: string }> },
) {
  try {
    await requireAdmin();
    const { programId, moduleId } = await params;
    const body = (await request.json()) as {
      title?: string;
      type?: ModuleResourceType;
      url?: string;
      storagePath?: string;
      fileSize?: number;
      mimeType?: string;
    };

    if (!body.title?.trim() || !body.url?.trim() || !body.type) {
      return NextResponse.json({ error: "Missing resource fields." }, { status: 400 });
    }

    const ref = await getFirebaseAdminDb()
      .collection(COLLECTIONS.courses)
      .doc(programId)
      .collection(COLLECTIONS.modules)
      .doc(moduleId)
      .collection(COLLECTIONS.resources)
      .add({
        title: body.title.trim(),
        type: body.type,
        url: body.url.trim(),
        storagePath: body.storagePath ?? "",
        fileSize: Number(body.fileSize ?? 0),
        mimeType: body.mimeType ?? "",
        downloadCount: 0,
        createdAt: FieldValue.serverTimestamp(),
        updatedAt: FieldValue.serverTimestamp(),
      });

    await syncModuleResourceCounts(programId, moduleId);

    return NextResponse.json({ id: ref.id });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Failed to create resource.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
