import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import { normalizeAssignmentTotalMarks } from "@/lib/modules";
import { COLLECTIONS } from "@/lib/student-constants";

function normalizeText(value: unknown): string {
  return String(value ?? "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ programId: string }> },
) {
  try {
    await requireAdmin();
    const { programId } = await params;
    const payload = (await request.json()) as Record<string, unknown>;
    const db = getFirebaseAdminDb();
    const modulesCollection = db
      .collection(COLLECTIONS.courses)
      .doc(programId)
      .collection(COLLECTIONS.modules);
    const moduleCode = normalizeText(payload.code);
    const moduleName = normalizeText(payload.name);
    const moduleOrder = Number(payload.order ?? 0);

    const existing = await modulesCollection.get();
    const duplicate = existing.docs.find((doc) => {
      const data = doc.data();
      const existingCode = normalizeText(data.code);
      const existingName = normalizeText(data.name);
      const existingOrder = Number(data.order ?? 0);
      return (
        existingCode === moduleCode &&
        existingName === moduleName &&
        existingOrder === moduleOrder
      );
    });

    const modulePayload = {
      ...payload,
      assignmentTotalMarks: normalizeAssignmentTotalMarks(
        payload.assignmentTotalMarks,
      ),
    };

    const ref = duplicate
      ? duplicate.ref
      : await modulesCollection.add({
          ...modulePayload,
          createdAt: FieldValue.serverTimestamp(),
          updatedAt: FieldValue.serverTimestamp(),
        });
    const count = (
      await db
        .collection(COLLECTIONS.courses)
        .doc(programId)
        .collection(COLLECTIONS.modules)
        .get()
    ).size;
    await db.collection(COLLECTIONS.courses).doc(programId).set(
      {
        moduleCount: count,
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true },
    );
    return NextResponse.json({ id: ref.id });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
