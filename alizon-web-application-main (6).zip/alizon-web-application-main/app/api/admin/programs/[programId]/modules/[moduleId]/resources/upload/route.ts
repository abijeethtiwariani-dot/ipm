import { NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { getFirebaseAdminStorage } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import {
  isAllowedModuleDocument,
  resourceTypeFromFileName,
} from "@/lib/module-resource-utils";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ programId: string; moduleId: string }> },
) {
  try {
    await requireAdmin();
    const { programId, moduleId } = await params;
    const formData = await request.formData();
    const file = formData.get("file");
    const title = String(formData.get("title") || "").trim();

    if (!(file instanceof File)) {
      return NextResponse.json({ error: "File is required." }, { status: 400 });
    }

    const validation = isAllowedModuleDocument(file.name, file.type, file.size);
    if (!validation.ok) {
      return NextResponse.json({ error: validation.message }, { status: 400 });
    }

    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
    const storagePath = `modules/${programId}/${moduleId}/${randomUUID()}-${safeName}`;
    const bucket = getFirebaseAdminStorage().bucket();
    const bucketFile = bucket.file(storagePath);
    const buffer = Buffer.from(await file.arrayBuffer());

    await bucketFile.save(buffer, {
      contentType: file.type || "application/octet-stream",
      metadata: { cacheControl: "public, max-age=31536000" },
    });
    await bucketFile.makePublic();

    return NextResponse.json({
      title: title || file.name,
      type: resourceTypeFromFileName(file.name),
      url: bucketFile.publicUrl(),
      storagePath,
      fileSize: file.size,
      mimeType: file.type,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Upload failed.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
