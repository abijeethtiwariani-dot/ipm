import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import { syncModuleResourceCounts } from "@/lib/module-resource-sync";
import { COLLECTIONS } from "@/lib/student-constants";

export async function DELETE(
  _request: Request,
  {
    params,
  }: { params: Promise<{ programId: string; moduleId: string; resourceId: string }> },
) {
  try {
    await requireAdmin();
    const { programId, moduleId, resourceId } = await params;
    await getFirebaseAdminDb()
      .collection(COLLECTIONS.courses)
      .doc(programId)
      .collection(COLLECTIONS.modules)
      .doc(moduleId)
      .collection(COLLECTIONS.resources)
      .doc(resourceId)
      .delete();
    await syncModuleResourceCounts(programId, moduleId);
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
