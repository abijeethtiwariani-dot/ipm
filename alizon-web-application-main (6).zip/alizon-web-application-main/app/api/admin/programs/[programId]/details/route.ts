import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { studentBelongsToProgram } from "@/lib/program-student-count";
import { requireAdmin } from "@/lib/server-admin-auth";
import { COLLECTIONS } from "@/lib/student-constants";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ programId: string }> },
) {
  try {
    await requireAdmin();
    const { programId } = await params;
    const db = getFirebaseAdminDb();

    const programSnap = await db.collection(COLLECTIONS.courses).doc(programId).get();
    if (!programSnap.exists) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    const modulesSnap = await db
      .collection(COLLECTIONS.courses)
      .doc(programId)
      .collection(COLLECTIONS.modules)
      .orderBy("order", "asc")
      .get();
    const modules = modulesSnap.docs.map(
      (doc) => ({ id: doc.id, ...doc.data() }) as { id: string; name?: string },
    );

    const resourcesNested = await Promise.all(
      modules.map(async (moduleItem) => {
        const resourcesSnap = await db
          .collection(COLLECTIONS.courses)
          .doc(programId)
          .collection(COLLECTIONS.modules)
          .doc(moduleItem.id)
          .collection(COLLECTIONS.resources)
          .get();
        return resourcesSnap.docs.map((resourceDoc) => ({
          id: resourceDoc.id,
          ...resourceDoc.data(),
          moduleId: moduleItem.id,
          moduleName: String(moduleItem.name ?? ""),
        }));
      }),
    );

    const programData = programSnap.data() ?? {};
    const program = {
      id: programSnap.id,
      name: String(programData.name ?? ""),
    };
    const studentsSnap = await db.collection(COLLECTIONS.students).get();
    const students = studentsSnap.docs
      .map((doc) => ({ id: doc.id, ...doc.data() } as Record<string, unknown> & {
        id: string;
        programId?: string;
        course?: string;
        accountStatus?: string;
        registrationId?: string;
      }))
      .filter((student) => studentBelongsToProgram(student, program))
      .sort((a, b) =>
        String(a.registrationId ?? "").localeCompare(String(b.registrationId ?? "")),
      );
    return NextResponse.json({
      program: {
        id: programSnap.id,
        ...programData,
        studentCount: students.length,
      },
      modules,
      resources: resourcesNested.flat(),
      students,
    });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
