import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { buildProgramStudentCounts } from "@/lib/program-student-count";
import { requireAdmin } from "@/lib/server-admin-auth";
import { COLLECTIONS } from "@/lib/student-constants";

export async function GET() {
  try {
    await requireAdmin();
    const db = getFirebaseAdminDb();
    const [programsSnap, studentsSnap] = await Promise.all([
      db.collection(COLLECTIONS.courses).get(),
      db.collection(COLLECTIONS.students).get(),
    ]);
    const programs = programsSnap.docs
      .map((doc) => ({ id: doc.id, ...doc.data() }) as { id: string; name?: string })
      .sort((a, b) => String(a.name ?? "").localeCompare(String(b.name ?? "")));
    const counts = buildProgramStudentCounts(
      programs.map((program) => ({ id: program.id, name: String(program.name ?? "") })),
      studentsSnap.docs.map((doc) => doc.data()),
    );
    return NextResponse.json({
      programs: programs.map((program) => ({
        ...program,
        studentCount: counts[program.id] ?? 0,
      })),
    });
  } catch (error) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function POST(request: Request) {
  try {
    await requireAdmin();
    const payload = (await request.json()) as Record<string, unknown>;
    const status = String(payload.status ?? "active");
    const active = status === "active";
    const ref = await getFirebaseAdminDb().collection(COLLECTIONS.courses).add({
      ...payload,
      status,
      active,
      moduleCount: Number(payload.moduleCount ?? 0),
      studentCount: Number(payload.studentCount ?? 0),
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    });
    await ref.set({ id: ref.id }, { merge: true });
    return NextResponse.json({ id: ref.id });
  } catch (error) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
