import { NextResponse } from "next/server";
import { buildAdminGrievanceList } from "@/lib/admin-grievances";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";

export async function GET() {
  try {
    await requireAdmin();
    const students = await buildAdminGrievanceList(getFirebaseAdminDb());
    return NextResponse.json({ students });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
