import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { mapAssignmentDoc } from "@/lib/assignments";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { mapGrievanceFromFirestore } from "@/lib/grievance-map";
import {
  GRIEVANCE_ADMIN_STATUSES,
  normalizeAdminStatus,
} from "@/lib/grievance-status";
import { requireAdmin } from "@/lib/server-admin-auth";
import { COLLECTIONS } from "@/lib/student-constants";
import type { Grievance, GrievanceAdminStatus } from "@/types/grievance";
import type { EvaluationGradeComponentKey } from "@/types/student-evaluation";

type GrievanceTarget = "assignment" | EvaluationGradeComponentKey;

function buildGrievanceStatusPatch(
  prefix: string,
  existing: Grievance,
  adminStatus: GrievanceAdminStatus,
): Record<string, unknown> {
  return {
    [`${prefix}.message`]: existing.message,
    [`${prefix}.submittedAt`]: existing.submittedAt,
    [`${prefix}.adminStatus`]: adminStatus,
    [`${prefix}.statusUpdatedAt`]: FieldValue.serverTimestamp(),
    [`${prefix}.resolvedAt`]:
      adminStatus === "Resolved"
        ? FieldValue.serverTimestamp()
        : FieldValue.delete(),
  };
}

function apiErrorFromCatch(error: unknown) {
  const message = error instanceof Error ? error.message : "Request failed.";
  if (message === "Unauthorized") {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  if (message === "Forbidden") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  console.error("[admin/grievances/status PATCH]", error);
  return NextResponse.json(
    { error: "Failed to update grievance status." },
    { status: 500 },
  );
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ studentId: string }> },
) {
  try {
    await requireAdmin();
    const { studentId } = await params;
    const body = (await request.json()) as {
      target?: GrievanceTarget;
      assignmentId?: string;
      adminStatus?: GrievanceAdminStatus;
    };

    const target = body.target;
    const adminStatus = normalizeAdminStatus(body.adminStatus);

    if (!target) {
      return NextResponse.json({ error: "Missing target." }, { status: 400 });
    }

    if (!GRIEVANCE_ADMIN_STATUSES.includes(adminStatus)) {
      return NextResponse.json({ error: "Invalid status." }, { status: 400 });
    }

    const db = getFirebaseAdminDb();
    const studentSnap = await db.collection(COLLECTIONS.students).doc(studentId).get();
    if (!studentSnap.exists) {
      return NextResponse.json({ error: "Student not found." }, { status: 404 });
    }

    if (target === "assignment") {
      if (!body.assignmentId) {
        return NextResponse.json(
          { error: "Missing assignmentId." },
          { status: 400 },
        );
      }

      const ref = db.collection(COLLECTIONS.assignments).doc(body.assignmentId);
      const snap = await ref.get();
      if (!snap.exists) {
        return NextResponse.json({ error: "Assignment not found." }, { status: 404 });
      }

      const assignment = mapAssignmentDoc(snap.id, snap.data() ?? {});
      if (assignment.studentId !== studentId) {
        return NextResponse.json({ error: "Assignment not found." }, { status: 404 });
      }

      const existing = mapGrievanceFromFirestore(snap.data()?.grievance);
      if (!existing) {
        return NextResponse.json({ error: "No grievance on record." }, { status: 400 });
      }

      await ref.update(buildGrievanceStatusPatch("grievance", existing, adminStatus));
      return NextResponse.json({ success: true });
    }

    if (!["viva", "internship", "elective"].includes(target)) {
      return NextResponse.json({ error: "Invalid target." }, { status: 400 });
    }

    const evalRef = db.collection(COLLECTIONS.studentEvaluations).doc(studentId);
    const evalSnap = await evalRef.get();
    const evalData = evalSnap.exists ? evalSnap.data() ?? {} : {};
    const componentData = (evalData[target] as Record<string, unknown>) ?? {};
    const existing = mapGrievanceFromFirestore(componentData.grievance);

    if (!existing) {
      return NextResponse.json({ error: "No grievance on record." }, { status: 400 });
    }

    await evalRef.update({
      ...buildGrievanceStatusPatch(`${target}.grievance`, existing, adminStatus),
      updatedAt: FieldValue.serverTimestamp(),
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    return apiErrorFromCatch(error);
  }
}
