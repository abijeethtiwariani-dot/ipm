import { NextResponse } from "next/server";
import { buildAdminStudentGrievanceDetail } from "@/lib/admin-grievances";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ studentId: string }> },
) {
  try {
    await requireAdmin();
    const { studentId } = await params;
    const detail = await buildAdminStudentGrievanceDetail(
      getFirebaseAdminDb(),
      studentId,
    );
    if (!detail) {
      return NextResponse.json({ error: "Student not found." }, { status: 404 });
    }
    return NextResponse.json({ detail });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
