import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { ALLOTMENT_RESULT_COLLECTIONS } from "@/lib/allotment-result-constants";
import {
  buildResultPayload,
  fetchAdminResults,
  isResultSlugTaken,
} from "@/lib/allotment-results-server";
import { isValidHttpsUrl, normalizeGoogleDriveUrl } from "@/lib/allotments";
import { mapResultDoc } from "@/lib/allotment-results";
import { requireAdmin } from "@/lib/server-admin-auth";
import type { AllotmentResultSortOption } from "@/types/allotment-result";
import { ALLOTMENT_RESULT_SORT_OPTIONS } from "@/types/allotment-result";

export async function GET(request: Request) {
  try {
    await requireAdmin();
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") ?? undefined;
    const categoryId = searchParams.get("categoryId") ?? undefined;
    const status = searchParams.get("status") ?? undefined;
    const dateFrom = searchParams.get("dateFrom") ?? undefined;
    const dateTo = searchParams.get("dateTo") ?? undefined;
    const sortParam = searchParams.get("sort") ?? "latest";
    const sort = ALLOTMENT_RESULT_SORT_OPTIONS.includes(
      sortParam as AllotmentResultSortOption,
    )
      ? (sortParam as AllotmentResultSortOption)
      : "latest";
    const page = Number(searchParams.get("page") ?? 1);
    const pageSize = Number(searchParams.get("pageSize") ?? 10);

    const result = await fetchAdminResults(getFirebaseAdminDb(), {
      search,
      categoryId,
      status,
      sort,
      dateFrom,
      dateTo,
      page,
      pageSize,
    });

    return NextResponse.json(result);
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function POST(request: Request) {
  try {
    const admin = await requireAdmin();
    const body = (await request.json()) as Record<string, unknown>;

    if (!String(body.title ?? "").trim()) {
      return NextResponse.json({ error: "Title is required." }, { status: 400 });
    }
    if (!String(body.categoryId ?? "")) {
      return NextResponse.json({ error: "Category is required." }, { status: 400 });
    }
    if (!String(body.shortDescription ?? "").trim()) {
      return NextResponse.json({ error: "Short description is required." }, { status: 400 });
    }

    const driveUrl = normalizeGoogleDriveUrl(body.googleDriveUrl as string | undefined);
    if (driveUrl && !isValidHttpsUrl(driveUrl)) {
      return NextResponse.json({ error: "Invalid Google Drive URL." }, { status: 400 });
    }

    const payload = buildResultPayload(body, admin.email ?? admin.uid);

    const slug = String(payload.slug);
    if (await isResultSlugTaken(getFirebaseAdminDb(), slug)) {
      return NextResponse.json({ error: "Slug already exists." }, { status: 400 });
    }

    const ref = await getFirebaseAdminDb()
      .collection(ALLOTMENT_RESULT_COLLECTIONS.results)
      .add(payload);

    const doc = await ref.get();
    return NextResponse.json({
      result: mapResultDoc(ref.id, doc.data() as Record<string, unknown>),
    });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
