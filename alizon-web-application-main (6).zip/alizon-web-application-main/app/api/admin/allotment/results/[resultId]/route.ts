import { NextResponse } from "next/server";
import { getFirebaseAdminDb, getFirebaseAdminStorage } from "@/lib/firebase-admin";
import {
  buildResultPayload,
  deleteResultWithFiles,
  fetchAdminResultById,
  isResultSlugTaken,
} from "@/lib/allotment-results-server";
import { isValidHttpsUrl, normalizeGoogleDriveUrl } from "@/lib/allotments";
import { ALLOTMENT_RESULT_COLLECTIONS } from "@/lib/allotment-result-constants";
import { requireAdmin } from "@/lib/server-admin-auth";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ resultId: string }> },
) {
  try {
    await requireAdmin();
    const { resultId } = await params;
    const result = await fetchAdminResultById(getFirebaseAdminDb(), resultId);
    if (!result) {
      return NextResponse.json({ error: "Not found." }, { status: 404 });
    }
    return NextResponse.json({ result });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ resultId: string }> },
) {
  try {
    await requireAdmin();
    const { resultId } = await params;
    const body = (await request.json()) as Record<string, unknown>;

    const driveUrl = normalizeGoogleDriveUrl(body.googleDriveUrl as string | undefined);
    if (driveUrl && !isValidHttpsUrl(driveUrl)) {
      return NextResponse.json({ error: "Invalid Google Drive URL." }, { status: 400 });
    }

    const payload = buildResultPayload(body);
    const slug = String(payload.slug);
    if (await isResultSlugTaken(getFirebaseAdminDb(), slug, resultId)) {
      return NextResponse.json({ error: "Slug already exists." }, { status: 400 });
    }

    await getFirebaseAdminDb()
      .collection(ALLOTMENT_RESULT_COLLECTIONS.results)
      .doc(resultId)
      .set(payload, { merge: true });

    const result = await fetchAdminResultById(getFirebaseAdminDb(), resultId);
    return NextResponse.json({ result });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ resultId: string }> },
) {
  try {
    await requireAdmin();
    const { resultId } = await params;
    const bucket = getFirebaseAdminStorage().bucket();

    await deleteResultWithFiles(
      getFirebaseAdminDb(),
      resultId,
      async (path) => {
        await bucket.file(path).delete();
      },
    );

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
