import { NextResponse } from "next/server";
import { getFirebaseAdminDb, getFirebaseAdminStorage } from "@/lib/firebase-admin";
import { ALLOTMENT_RESULT_COLLECTIONS } from "@/lib/allotment-result-constants";
import { requireAdmin } from "@/lib/server-admin-auth";

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ resultId: string; fileId: string }> },
) {
  try {
    await requireAdmin();
    const { resultId, fileId } = await params;
    const ref = getFirebaseAdminDb()
      .collection(ALLOTMENT_RESULT_COLLECTIONS.results)
      .doc(resultId)
      .collection(ALLOTMENT_RESULT_COLLECTIONS.files)
      .doc(fileId);

    const doc = await ref.get();
    if (!doc.exists) {
      return NextResponse.json({ error: "Not found." }, { status: 404 });
    }

    const path = String((doc.data() as Record<string, unknown>).filePath ?? "");
    if (path) {
      try {
        await getFirebaseAdminStorage().bucket().file(path).delete();
      } catch {
        // ignore
      }
    }

    await ref.delete();
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
