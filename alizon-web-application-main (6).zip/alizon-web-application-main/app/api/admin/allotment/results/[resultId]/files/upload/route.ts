import { NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb, getFirebaseAdminStorage } from "@/lib/firebase-admin";
import {
  ALLOTMENT_RESULT_COLLECTIONS,
  ALLOTMENT_RESULT_STORAGE_PREFIX,
} from "@/lib/allotment-result-constants";
import { isAllowedAllotmentResultFile } from "@/lib/allotment-result-upload-policy";
import { requireAdmin } from "@/lib/server-admin-auth";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ resultId: string }> },
) {
  try {
    await requireAdmin();
    const { resultId } = await params;
    const formData = await request.formData();
    const file = formData.get("file");

    if (!(file instanceof File)) {
      return NextResponse.json({ error: "File is required." }, { status: 400 });
    }

    const validation = isAllowedAllotmentResultFile(file.name, file.type, file.size);
    if (validation.ok === false) {
      return NextResponse.json({ error: validation.message }, { status: 400 });
    }

    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
    const storagePath = `${ALLOTMENT_RESULT_STORAGE_PREFIX}/${resultId}/${randomUUID()}-${safeName}`;
    const bucket = getFirebaseAdminStorage().bucket();
    const bucketFile = bucket.file(storagePath);
    const buffer = Buffer.from(await file.arrayBuffer());

    await bucketFile.save(buffer, {
      contentType: file.type || "application/octet-stream",
      metadata: { cacheControl: "public, max-age=31536000" },
    });
    await bucketFile.makePublic();

    const ref = await getFirebaseAdminDb()
      .collection(ALLOTMENT_RESULT_COLLECTIONS.results)
      .doc(resultId)
      .collection(ALLOTMENT_RESULT_COLLECTIONS.files)
      .add({
        fileName: file.name,
        filePath: storagePath,
        fileType: file.type || "application/octet-stream",
        fileSize: file.size,
        url: bucketFile.publicUrl(),
        createdAt: FieldValue.serverTimestamp(),
      });

    return NextResponse.json({
      file: {
        id: ref.id,
        resultId,
        fileName: file.name,
        filePath: storagePath,
        fileType: file.type,
        fileSize: file.size,
        url: bucketFile.publicUrl(),
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Upload failed.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
