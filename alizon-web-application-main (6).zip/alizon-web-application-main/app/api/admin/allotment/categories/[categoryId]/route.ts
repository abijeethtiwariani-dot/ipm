import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { ALLOTMENT_COLLECTIONS } from "@/lib/allotment-constants";
import {
  buildCategoryPayload,
  fetchCategoryById,
  isCategorySlugTaken,
} from "@/lib/allotments-server";
import { mapCategoryDoc } from "@/lib/allotments";
import { requireAdmin } from "@/lib/server-admin-auth";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ categoryId: string }> },
) {
  try {
    await requireAdmin();
    const { categoryId } = await params;
    const category = await fetchCategoryById(getFirebaseAdminDb(), categoryId);
    if (!category) {
      return NextResponse.json({ error: "Not found." }, { status: 404 });
    }
    return NextResponse.json({ category });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ categoryId: string }> },
) {
  try {
    await requireAdmin();
    const { categoryId } = await params;
    const body = (await request.json()) as Record<string, unknown>;
    const payload = buildCategoryPayload(body);

    const slug = String(payload.slug);
    if (await isCategorySlugTaken(getFirebaseAdminDb(), slug, categoryId)) {
      return NextResponse.json({ error: "Slug already exists." }, { status: 400 });
    }

    const ref = getFirebaseAdminDb()
      .collection(ALLOTMENT_COLLECTIONS.categories)
      .doc(categoryId);
    await ref.set(payload, { merge: true });

    const doc = await ref.get();
    return NextResponse.json({
      category: mapCategoryDoc(categoryId, doc.data() as Record<string, unknown>),
    });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ categoryId: string }> },
) {
  try {
    await requireAdmin();
    const { categoryId } = await params;
    const db = getFirebaseAdminDb();

    const used = await db
      .collection(ALLOTMENT_COLLECTIONS.allotments)
      .where("categoryId", "==", categoryId)
      .limit(1)
      .get();

    if (!used.empty) {
      return NextResponse.json(
        { error: "Cannot delete category that has allotments." },
        { status: 400 },
      );
    }

    await db.collection(ALLOTMENT_COLLECTIONS.categories).doc(categoryId).delete();
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
