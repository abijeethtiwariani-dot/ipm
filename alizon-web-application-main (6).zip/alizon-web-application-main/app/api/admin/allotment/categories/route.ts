import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { ALLOTMENT_COLLECTIONS } from "@/lib/allotment-constants";
import {
  buildCategoryPayload,
  fetchAllCategories,
  isCategorySlugTaken,
} from "@/lib/allotments-server";
import { mapCategoryDoc } from "@/lib/allotments";
import { requireAdmin } from "@/lib/server-admin-auth";

export async function GET() {
  try {
    await requireAdmin();
    const categories = await fetchAllCategories(getFirebaseAdminDb());
    return NextResponse.json({ categories });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function POST(request: Request) {
  try {
    await requireAdmin();
    const body = (await request.json()) as Record<string, unknown>;
    const payload = buildCategoryPayload(body);

    if (!String(payload.name)) {
      return NextResponse.json({ error: "Category name is required." }, { status: 400 });
    }

    const slug = String(payload.slug);
    if (await isCategorySlugTaken(getFirebaseAdminDb(), slug)) {
      return NextResponse.json({ error: "Slug already exists." }, { status: 400 });
    }

    const ref = await getFirebaseAdminDb()
      .collection(ALLOTMENT_COLLECTIONS.categories)
      .add({
        ...payload,
        createdAt: FieldValue.serverTimestamp(),
      });

    const doc = await ref.get();
    return NextResponse.json({
      category: mapCategoryDoc(ref.id, doc.data() as Record<string, unknown>),
    });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
