import { NextResponse } from "next/server";
import { getFirebaseAdminDb, getFirebaseAdminStorage } from "@/lib/firebase-admin";
import { ALLOTMENT_COLLECTIONS } from "@/lib/allotment-constants";
import {
  buildAllotmentPayload,
  deleteAllotmentWithFiles,
  fetchAdminAllotmentById,
  isAllotmentSlugTaken,
} from "@/lib/allotments-server";
import { isValidHttpsUrl, normalizeGoogleDriveUrl } from "@/lib/allotments";
import { requireAdmin } from "@/lib/server-admin-auth";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ allotmentId: string }> },
) {
  try {
    await requireAdmin();
    const { allotmentId } = await params;
    const allotment = await fetchAdminAllotmentById(getFirebaseAdminDb(), allotmentId);
    if (!allotment) {
      return NextResponse.json({ error: "Not found." }, { status: 404 });
    }
    return NextResponse.json({ allotment });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ allotmentId: string }> },
) {
  try {
    await requireAdmin();
    const { allotmentId } = await params;
    const body = (await request.json()) as Record<string, unknown>;

    const driveUrl = normalizeGoogleDriveUrl(body.googleDriveUrl as string | undefined);
    if (driveUrl && !isValidHttpsUrl(driveUrl)) {
      return NextResponse.json({ error: "Invalid Google Drive URL." }, { status: 400 });
    }

    const payload = buildAllotmentPayload(body);
    const slug = String(payload.slug);
    if (await isAllotmentSlugTaken(getFirebaseAdminDb(), slug, allotmentId)) {
      return NextResponse.json({ error: "Slug already exists." }, { status: 400 });
    }

    await getFirebaseAdminDb()
      .collection(ALLOTMENT_COLLECTIONS.allotments)
      .doc(allotmentId)
      .set(payload, { merge: true });

    const allotment = await fetchAdminAllotmentById(getFirebaseAdminDb(), allotmentId);
    return NextResponse.json({ allotment });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ allotmentId: string }> },
) {
  try {
    await requireAdmin();
    const { allotmentId } = await params;
    const bucket = getFirebaseAdminStorage().bucket();

    await deleteAllotmentWithFiles(
      getFirebaseAdminDb(),
      allotmentId,
      async (path) => {
        await bucket.file(path).delete();
      },
    );

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
