import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { ALLOTMENT_COLLECTIONS } from "@/lib/allotment-constants";
import { requireAdmin } from "@/lib/server-admin-auth";
import { ALLOTMENT_STATUSES } from "@/types/allotment";

export async function POST(request: Request) {
  try {
    await requireAdmin();
    const body = (await request.json()) as { ids?: string[]; status?: string };
    const ids = Array.isArray(body.ids) ? [...new Set(body.ids.filter(Boolean))] : [];
    const status = String(body.status ?? "");

    if (ids.length === 0) {
      return NextResponse.json({ error: "No allotments selected." }, { status: 400 });
    }
    if (!ALLOTMENT_STATUSES.includes(status as (typeof ALLOTMENT_STATUSES)[number])) {
      return NextResponse.json({ error: "Invalid status." }, { status: 400 });
    }

    const db = getFirebaseAdminDb();
    const batch = db.batch();
    for (const id of ids) {
      batch.update(db.collection(ALLOTMENT_COLLECTIONS.allotments).doc(id), {
        status,
        updatedAt: FieldValue.serverTimestamp(),
      });
    }
    await batch.commit();

    return NextResponse.json({ success: true, updated: ids.length });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
