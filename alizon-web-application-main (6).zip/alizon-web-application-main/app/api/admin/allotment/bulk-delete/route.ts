import { NextResponse } from "next/server";
import { getFirebaseAdminDb, getFirebaseAdminStorage } from "@/lib/firebase-admin";
import { deleteAllotmentWithFiles } from "@/lib/allotments-server";
import { requireAdmin } from "@/lib/server-admin-auth";

export async function POST(request: Request) {
  try {
    await requireAdmin();
    const body = (await request.json()) as { ids?: string[] };
    const ids = Array.isArray(body.ids) ? [...new Set(body.ids.filter(Boolean))] : [];

    if (ids.length === 0) {
      return NextResponse.json({ error: "No allotments selected." }, { status: 400 });
    }

    const db = getFirebaseAdminDb();
    const bucket = getFirebaseAdminStorage().bucket();

    for (const id of ids) {
      await deleteAllotmentWithFiles(db, id, async (path) => {
        try {
          await bucket.file(path).delete();
        } catch {
          // ignore
        }
      });
    }

    return NextResponse.json({ success: true, deleted: ids.length });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
