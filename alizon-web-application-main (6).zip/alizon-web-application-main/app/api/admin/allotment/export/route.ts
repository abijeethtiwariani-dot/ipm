import { NextResponse } from "next/server";
import * as XLSX from "xlsx";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { fetchAdminAllotments } from "@/lib/allotments-server";
import { rowsToCsv } from "@/lib/export-fee-students-csv";
import { requireAdmin } from "@/lib/server-admin-auth";
import type { AllotmentSortOption } from "@/types/allotment";
import { ALLOTMENT_SORT_OPTIONS } from "@/types/allotment";

function allotmentToRow(item: {
  title: string;
  slug: string;
  categoryName?: string;
  categoryId: string;
  status: string;
  publishDate: string;
  updatedDate: string;
  createdBy: string;
  featured: boolean;
  sortOrder: number;
  googleDriveUrl: string | null;
}) {
  return {
    Title: item.title,
    Slug: item.slug,
    Category: item.categoryName ?? item.categoryId,
    Status: item.status,
    "Publish Date": item.publishDate,
    "Last Updated": item.updatedDate,
    "Created By": item.createdBy,
    Featured: item.featured ? "Yes" : "No",
    "Sort Order": item.sortOrder,
    "Google Drive URL": item.googleDriveUrl ?? "",
  };
}

export async function GET(request: Request) {
  try {
    await requireAdmin();
    const { searchParams } = new URL(request.url);
    const format = searchParams.get("format") ?? "csv";
    const search = searchParams.get("search") ?? undefined;
    const categoryId = searchParams.get("categoryId") ?? undefined;
    const status = searchParams.get("status") ?? undefined;
    const sortParam = searchParams.get("sort") ?? "latest";
    const sort = ALLOTMENT_SORT_OPTIONS.includes(sortParam as AllotmentSortOption)
      ? (sortParam as AllotmentSortOption)
      : "latest";

    const { items } = await fetchAdminAllotments(getFirebaseAdminDb(), {
      search,
      categoryId,
      status,
      sort,
      page: 1,
      pageSize: 10000,
    });

    const rows = items.map(allotmentToRow);
    const date = new Date().toISOString().slice(0, 10);

    if (format === "xlsx") {
      const worksheet = XLSX.utils.json_to_sheet(rows);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Allotments");
      const buffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });
      return new NextResponse(buffer, {
        headers: {
          "Content-Type":
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          "Content-Disposition": `attachment; filename="alizon-allotments-${date}.xlsx"`,
        },
      });
    }

    const csv = rowsToCsv(rows);
    return new NextResponse("\uFEFF" + csv, {
      headers: {
        "Content-Type": "text/csv;charset=utf-8",
        "Content-Disposition": `attachment; filename="alizon-allotments-${date}.csv"`,
      },
    });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
