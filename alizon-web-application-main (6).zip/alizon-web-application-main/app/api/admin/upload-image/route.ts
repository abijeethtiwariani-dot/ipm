import { NextResponse } from "next/server";
import {
  getFirebaseAdminStorage,
  isFirebaseAdminConfigured,
} from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import {
  getCmsImagePresetConfig,
  type CmsImagePreset,
} from "@/lib/cms-image-presets";
import {
  buildImageSetFromUrls,
  buildImageStoragePaths,
  mimeToFormatLabel,
  processImageToWebpVariants,
  validateImageFile,
} from "@/lib/image-processing";

const VALID_PRESETS = new Set<string>([
  "default",
  "heroDesktop",
  "heroMobile",
  "card4x3",
  "card4x5",
  "testimonialBackground",
  "avatarSquare",
  "admissionBanner",
]);

function resolvePreset(raw: string | null): CmsImagePreset {
  if (raw && VALID_PRESETS.has(raw)) {
    return raw as CmsImagePreset;
  }
  return "default";
}

export async function POST(request: Request) {
  if (!isFirebaseAdminConfigured()) {
    return NextResponse.json({ error: "Server is not configured." }, { status: 503 });
  }

  try {
    await requireAdmin();

    const formData = await request.formData();
    const file = formData.get("file");
    const folder = String(formData.get("folder") || "programs");
    const alt = String(formData.get("alt") || "");
    const preset = resolvePreset(String(formData.get("preset") || "default"));

    if (!(file instanceof File)) {
      return NextResponse.json({ error: "File is required." }, { status: 400 });
    }

    const presetConfig = getCmsImagePresetConfig(preset);
    validateImageFile(file.type, file.size, { maxBytes: presetConfig.maxBytes });

    const arrayBuffer = await file.arrayBuffer();
    const inputBuffer = Buffer.from(arrayBuffer);
    const originalFileSize = file.size;
    const originalFormat = mimeToFormatLabel(file.type);

    const processed = await processImageToWebpVariants(inputBuffer, preset);
    const paths = buildImageStoragePaths(folder);
    const bucket = getFirebaseAdminStorage().bucket();

    const urlMap: Record<string, string> = {};
    for (const variant of processed.variants) {
      const path = paths[variant.key];
      const bucketFile = bucket.file(path);
      await bucketFile.save(variant.buffer, {
        contentType: "image/webp",
        metadata: { cacheControl: "public, max-age=31536000, immutable" },
      });
      await bucketFile.makePublic();
      urlMap[variant.key] = bucketFile.publicUrl();
    }

    return NextResponse.json({
      image: buildImageSetFromUrls({
        thumbnailUrl: urlMap.thumbnail,
        mediumUrl: urlMap.medium,
        largeUrl: urlMap.large,
        width: processed.width,
        height: processed.height,
        alt,
      }),
      meta: {
        originalWidth: processed.width,
        originalHeight: processed.height,
        originalFormat,
        originalFileSize,
        optimizedFormat: "WEBP",
        preset,
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Upload failed.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
