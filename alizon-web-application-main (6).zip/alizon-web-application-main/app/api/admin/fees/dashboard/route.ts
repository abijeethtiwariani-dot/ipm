import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import { COLLECTIONS } from "@/lib/student-constants";
import {
  buildAllSummaries,
  buildDashboardStats,
  enrichDashboardWithPayments,
  loadAllPayments,
  loadPrograms,
} from "@/lib/fees-server";

export async function GET() {
  try {
    await requireAdmin();
    const db = getFirebaseAdminDb();
    const [programs, allPayments, studentsSnap] = await Promise.all([
      loadPrograms(db),
      loadAllPayments(db),
      db.collection(COLLECTIONS.students).get(),
    ]);

    const summaries = buildAllSummaries(studentsSnap, programs, allPayments);
    const stats = enrichDashboardWithPayments(
      buildDashboardStats(summaries),
      allPayments,
    );

    return NextResponse.json({ stats });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
