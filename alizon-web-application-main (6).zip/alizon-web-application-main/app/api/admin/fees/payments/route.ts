import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import { PAYMENT_METHODS } from "@/lib/fees";
import { COLLECTIONS } from "@/lib/student-constants";

export async function POST(request: Request) {
  try {
    await requireAdmin();
    const body = (await request.json()) as {
      studentId?: string;
      programId?: string;
      amount?: number;
      paymentDate?: string;
      paymentMethod?: string;
      transactionId?: string;
      notes?: string;
    };

    if (!body.studentId || !body.programId) {
      return NextResponse.json(
        { error: "Student and program are required." },
        { status: 400 },
      );
    }

    const amount = Number(body.amount);
    if (!Number.isFinite(amount) || amount <= 0) {
      return NextResponse.json({ error: "Invalid payment amount." }, { status: 400 });
    }

    const method = body.paymentMethod ?? "Cash";
    if (!PAYMENT_METHODS.includes(method as (typeof PAYMENT_METHODS)[number])) {
      return NextResponse.json({ error: "Invalid payment method." }, { status: 400 });
    }

    const paymentDate = body.paymentDate ?? new Date().toISOString().slice(0, 10);

    const ref = await getFirebaseAdminDb().collection(COLLECTIONS.feePayments).add({
      studentId: body.studentId,
      programId: body.programId,
      amount,
      paymentDate,
      paymentMethod: method,
      transactionId: String(body.transactionId ?? ""),
      notes: String(body.notes ?? ""),
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    });

    return NextResponse.json({ id: ref.id, success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
