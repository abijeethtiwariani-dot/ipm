import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import { PAYMENT_METHODS } from "@/lib/fees";
import { COLLECTIONS } from "@/lib/student-constants";

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ paymentId: string }> },
) {
  try {
    await requireAdmin();
    const { paymentId } = await params;
    const body = (await request.json()) as Record<string, unknown>;

    const update: Record<string, unknown> = { updatedAt: FieldValue.serverTimestamp() };

    if (body.amount !== undefined) {
      const amount = Number(body.amount);
      if (!Number.isFinite(amount) || amount <= 0) {
        return NextResponse.json({ error: "Invalid payment amount." }, { status: 400 });
      }
      update.amount = amount;
    }
    if (body.paymentDate !== undefined) update.paymentDate = String(body.paymentDate);
    if (body.paymentMethod !== undefined) {
      const method = String(body.paymentMethod);
      if (!PAYMENT_METHODS.includes(method as (typeof PAYMENT_METHODS)[number])) {
        return NextResponse.json({ error: "Invalid payment method." }, { status: 400 });
      }
      update.paymentMethod = method;
    }
    if (body.transactionId !== undefined) update.transactionId = String(body.transactionId);
    if (body.notes !== undefined) update.notes = String(body.notes);

    const ref = getFirebaseAdminDb().collection(COLLECTIONS.feePayments).doc(paymentId);
    const snap = await ref.get();
    if (!snap.exists) {
      return NextResponse.json({ error: "Payment not found." }, { status: 404 });
    }

    await ref.update(update);
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ paymentId: string }> },
) {
  try {
    await requireAdmin();
    const { paymentId } = await params;
    const ref = getFirebaseAdminDb().collection(COLLECTIONS.feePayments).doc(paymentId);
    const snap = await ref.get();
    if (!snap.exists) {
      return NextResponse.json({ error: "Payment not found." }, { status: 404 });
    }
    await ref.delete();
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
