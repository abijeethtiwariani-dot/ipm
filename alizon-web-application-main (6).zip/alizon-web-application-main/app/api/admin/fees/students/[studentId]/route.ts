import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import { COLLECTIONS } from "@/lib/student-constants";
import {
  buildSummaryForStudent,
  loadPaymentsForStudent,
  loadPrograms,
} from "@/lib/fees-server";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ studentId: string }> },
) {
  try {
    await requireAdmin();
    const { studentId } = await params;
    const db = getFirebaseAdminDb();

    const [studentSnap, programs, payments] = await Promise.all([
      db.collection(COLLECTIONS.students).doc(studentId).get(),
      loadPrograms(db),
      loadPaymentsForStudent(db, studentId),
    ]);

    if (!studentSnap.exists) {
      return NextResponse.json({ error: "Student not found." }, { status: 404 });
    }

    const paymentsByStudent = new Map([[studentId, payments]]);
    const summary = buildSummaryForStudent(
      { id: studentSnap.id, data: studentSnap.data() ?? {} },
      programs,
      paymentsByStudent,
    );

    if (!summary) {
      return NextResponse.json(
        { error: "Student is not approved for enrollment." },
        { status: 400 },
      );
    }

    return NextResponse.json({ summary, payments });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
