import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import { COLLECTIONS } from "@/lib/student-constants";
import {
  buildAllSummaries,
  loadAllPayments,
  loadPrograms,
} from "@/lib/fees-server";
import type { PaymentStatus } from "@/types/fees";

export async function GET(request: Request) {
  try {
    await requireAdmin();
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search")?.toLowerCase() ?? "";
    const programId = searchParams.get("programId") ?? "";
    const status = searchParams.get("status");

    const db = getFirebaseAdminDb();
    const [programs, allPayments, studentsSnap] = await Promise.all([
      loadPrograms(db),
      loadAllPayments(db),
      db.collection(COLLECTIONS.students).get(),
    ]);

    let summaries = buildAllSummaries(studentsSnap, programs, allPayments);

    if (search) {
      summaries = summaries.filter(
        (s) =>
          s.studentName.toLowerCase().includes(search) ||
          s.registrationId.toLowerCase().includes(search),
      );
    }
    if (programId && programId !== "all") {
      summaries = summaries.filter((s) => s.programId === programId);
    }
    if (status && status !== "all") {
      summaries = summaries.filter((s) => s.paymentStatus === (status as PaymentStatus));
    }

    return NextResponse.json({ students: summaries, programs });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
