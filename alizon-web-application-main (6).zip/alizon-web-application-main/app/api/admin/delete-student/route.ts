import { NextResponse } from "next/server";
import {
  getFirebaseAdminAuth,
  getFirebaseAdminDb,
  getFirebaseAdminStorage,
  isFirebaseAdminConfigured,
} from "@/lib/firebase-admin";
import { COLLECTIONS } from "@/lib/student-constants";

async function verifyAdmin(idToken: string): Promise<boolean> {
  const auth = getFirebaseAdminAuth();
  const decoded = await auth.verifyIdToken(idToken);
  const db = getFirebaseAdminDb();
  const adminDoc = await db.collection(COLLECTIONS.admins).doc(decoded.uid).get();
  return adminDoc.exists;
}

export async function POST(request: Request) {
  if (!isFirebaseAdminConfigured()) {
    return NextResponse.json(
      { error: "Server is not configured." },
      { status: 503 },
    );
  }

  try {
    const authHeader = request.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return NextResponse.json({ error: "Unauthorized." }, { status: 401 });
    }

    const idToken = authHeader.slice(7);
    const isAdmin = await verifyAdmin(idToken);
    if (!isAdmin) {
      return NextResponse.json({ error: "Forbidden." }, { status: 403 });
    }

    const { studentId } = (await request.json()) as { studentId?: string };
    if (!studentId) {
      return NextResponse.json({ error: "Missing studentId." }, { status: 400 });
    }

    const db = getFirebaseAdminDb();
    const studentDoc = await db
      .collection(COLLECTIONS.students)
      .doc(studentId)
      .get();

    if (!studentDoc.exists) {
      return NextResponse.json({ error: "Student not found." }, { status: 404 });
    }

    const registrationId = studentDoc.data()?.registrationId as string | undefined;

    // Delete assignments and results
    const assignmentsSnap = await db
      .collection(COLLECTIONS.assignments)
      .where("studentId", "==", studentId)
      .get();

    const batch = db.batch();
    for (const docSnap of assignmentsSnap.docs) {
      batch.delete(docSnap.ref);
      batch.delete(db.collection(COLLECTIONS.results).doc(docSnap.id));
    }
    batch.delete(studentDoc.ref);
    await batch.commit();

    // Delete storage files
    if (registrationId) {
      try {
        const bucket = getFirebaseAdminStorage().bucket();
        await bucket.deleteFiles({ prefix: `assignments/${registrationId}/` });
      } catch {
        // Storage cleanup is best-effort
      }
    }

    // Delete auth user
    const auth = getFirebaseAdminAuth();
    await auth.deleteUser(studentId);

    return NextResponse.json({ success: true });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Failed to delete student.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
