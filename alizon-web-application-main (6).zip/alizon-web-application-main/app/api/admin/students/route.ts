import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { mapStudentDoc } from "@/lib/student-mapper";
import { requireAdmin } from "@/lib/server-admin-auth";
import { COLLECTIONS } from "@/lib/student-constants";

export async function GET() {
  try {
    await requireAdmin();
    const snap = await getFirebaseAdminDb().collection(COLLECTIONS.students).get();
    const students = snap.docs
      .map((doc) => mapStudentDoc(doc.id, doc.data() as Record<string, unknown>))
      .sort((a, b) => a.registrationId.localeCompare(b.registrationId));
    return NextResponse.json({ students });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
