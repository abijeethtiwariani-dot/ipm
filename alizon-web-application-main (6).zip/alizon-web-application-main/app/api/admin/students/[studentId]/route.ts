import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminAuth, getFirebaseAdminDb, getFirebaseAdminStorage } from "@/lib/firebase-admin";
import { mapStudentDoc } from "@/lib/student-mapper";
import { requireAdmin } from "@/lib/server-admin-auth";
import { syncLegacyFieldsFromProfile } from "@/lib/student-profile-migration";
import { studentProfileSchema } from "@/lib/student-profile-schema";
import { resolveStudentProgramId } from "@/lib/program-student-count";
import { COLLECTIONS } from "@/lib/student-constants";
import type { StudentProfileDetails } from "@/types/student-profile";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ studentId: string }> },
) {
  try {
    await requireAdmin();
    const { studentId } = await params;
    const doc = await getFirebaseAdminDb()
      .collection(COLLECTIONS.students)
      .doc(studentId)
      .get();
    if (!doc.exists) {
      return NextResponse.json({ error: "Student not found." }, { status: 404 });
    }
    return NextResponse.json({ student: mapStudentDoc(doc.id, doc.data()!) });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ studentId: string }> },
) {
  try {
    await requireAdmin();
    const { studentId } = await params;
    const payload = (await request.json()) as Record<string, unknown>;
    if (
      payload.accountStatus !== undefined &&
      !["Pending", "Approved", "Rejected"].includes(
        payload.accountStatus as string,
      )
    ) {
      return NextResponse.json(
        { error: "Invalid account status." },
        { status: 400 },
      );
    }
    if (payload.scholarshipPercentage !== undefined) {
      const pct = Number(payload.scholarshipPercentage);
      if (!Number.isFinite(pct) || pct < 0 || pct > 100) {
        return NextResponse.json(
          { error: "Scholarship percentage must be between 0 and 100." },
          { status: 400 },
        );
      }
      payload.scholarshipPercentage = pct;
    }

    if (payload.profile !== undefined) {
      const parsed = studentProfileSchema.safeParse(payload.profile);
      if (!parsed.success) {
        return NextResponse.json(
          { error: "Invalid profile data.", details: parsed.error.flatten() },
          { status: 400 },
        );
      }
      const profile = parsed.data as StudentProfileDetails;
      const legacy = syncLegacyFieldsFromProfile(profile);
      payload.profile = profile;
      payload.name = legacy.name;
      payload.email = legacy.email;
      payload.phone = legacy.phone;
      payload.profileUpdatedAt = FieldValue.serverTimestamp();
      payload.profileDraft = FieldValue.delete();
      payload.profileDraftUpdatedAt = FieldValue.delete();
    }

    if (payload.assignedBatch !== undefined) {
      payload.assignedBatch = String(payload.assignedBatch).trim();
    }

    if (payload.course !== undefined) {
      const programsSnap = await getFirebaseAdminDb()
        .collection(COLLECTIONS.courses)
        .get();
      const programs = programsSnap.docs.map((doc) => ({
        id: doc.id,
        name: String(doc.data().name ?? ""),
      }));
      payload.programId = resolveStudentProgramId(
        {
          programId: String(payload.programId ?? ""),
          course: String(payload.course),
        },
        programs,
      );
    }

    await getFirebaseAdminDb().collection(COLLECTIONS.students).doc(studentId).set(payload, {
      merge: true,
    });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ studentId: string }> },
) {
  try {
    await requireAdmin();
    const { studentId } = await params;
    const db = getFirebaseAdminDb();
    const studentDoc = await db.collection(COLLECTIONS.students).doc(studentId).get();
    if (!studentDoc.exists) {
      return NextResponse.json({ error: "Student not found." }, { status: 404 });
    }
    const registrationId = studentDoc.data()?.registrationId as string | undefined;

    const [assignmentsSnap, feePaymentsSnap] = await Promise.all([
      db.collection(COLLECTIONS.assignments).where("studentId", "==", studentId).get(),
      db.collection(COLLECTIONS.feePayments).where("studentId", "==", studentId).get(),
    ]);
    const batch = db.batch();
    for (const docSnap of assignmentsSnap.docs) {
      batch.delete(docSnap.ref);
      batch.delete(db.collection(COLLECTIONS.results).doc(docSnap.id));
    }
    for (const docSnap of feePaymentsSnap.docs) {
      batch.delete(docSnap.ref);
    }
    batch.delete(studentDoc.ref);
    await batch.commit();

    if (registrationId) {
      const bucket = getFirebaseAdminStorage().bucket();
      await Promise.all([
        bucket.deleteFiles({ prefix: `assignments/${registrationId}/` }),
        bucket.deleteFiles({ prefix: `id-cards/${registrationId}/` }),
      ]);
    }
    await getFirebaseAdminAuth().deleteUser(studentId);
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
