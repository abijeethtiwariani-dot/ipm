import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb, getFirebaseAdminStorage } from "@/lib/firebase-admin";
import { mapStudentDoc } from "@/lib/student-mapper";
import { requireAdmin } from "@/lib/server-admin-auth";
import { COLLECTIONS } from "@/lib/student-constants";
import { isAllowedStudentIdCardFile } from "@/lib/student-id-card-policy";
import { SIGNED_ID_CARD_URL_EXPIRY_MS } from "@/lib/student-id-card-constants";
import {
  buildIdCardStoragePath,
  deleteIdCardFromStorage,
  getIdCardSignedDownloadUrl,
} from "@/lib/student-id-card-server";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ studentId: string }> },
) {
  try {
    await requireAdmin();
    const { studentId } = await params;
    const studentSnap = await getFirebaseAdminDb()
      .collection(COLLECTIONS.students)
      .doc(studentId)
      .get();
    if (!studentSnap.exists) {
      return NextResponse.json({ error: "Student not found." }, { status: 404 });
    }

    const idCard = studentSnap.data()?.idCard as { storagePath?: string } | undefined;
    if (!idCard?.storagePath) {
      return NextResponse.json({ error: "ID card not found." }, { status: 404 });
    }

    const url = await getIdCardSignedDownloadUrl(
      idCard.storagePath,
      SIGNED_ID_CARD_URL_EXPIRY_MS,
    );
    return NextResponse.json({ url });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Preview failed.";
    const status =
      message === "Unauthorized" || message === "Forbidden" ? 401 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}

export async function POST(
  request: Request,
  { params }: { params: Promise<{ studentId: string }> },
) {
  try {
    const admin = await requireAdmin();
    const { studentId } = await params;
    const formData = await request.formData();
    const file = formData.get("file");

    if (!(file instanceof File)) {
      return NextResponse.json({ error: "File is required." }, { status: 400 });
    }

    const validation = isAllowedStudentIdCardFile(file.name, file.type, file.size);
    if (validation.ok === false) {
      return NextResponse.json({ error: validation.message }, { status: 400 });
    }

    const db = getFirebaseAdminDb();
    const studentRef = db.collection(COLLECTIONS.students).doc(studentId);
    const studentSnap = await studentRef.get();
    if (!studentSnap.exists) {
      return NextResponse.json({ error: "Student not found." }, { status: 404 });
    }

    const studentData = studentSnap.data() ?? {};
    const registrationId = (studentData.registrationId as string) ?? "";
    if (!registrationId) {
      return NextResponse.json(
        { error: "Student has no registration ID." },
        { status: 400 },
      );
    }

    const existingIdCard = studentData.idCard as { storagePath?: string } | undefined;
    if (existingIdCard?.storagePath) {
      await deleteIdCardFromStorage(existingIdCard.storagePath);
    }

    const storagePath = buildIdCardStoragePath(registrationId, file.name);
    const bucket = getFirebaseAdminStorage().bucket();
    const bucketFile = bucket.file(storagePath);
    const buffer = Buffer.from(await file.arrayBuffer());

    await bucketFile.save(buffer, {
      contentType: file.type || "application/octet-stream",
      metadata: { cacheControl: "private, max-age=0" },
    });

    const idCard = {
      fileName: file.name,
      storagePath,
      mimeType: file.type || "application/octet-stream",
      fileSize: file.size,
      uploadedAt: FieldValue.serverTimestamp(),
      uploadedBy: admin.uid,
    };

    await studentRef.set({ idCard }, { merge: true });

    const updatedSnap = await studentRef.get();
    return NextResponse.json({
      student: mapStudentDoc(updatedSnap.id, updatedSnap.data() ?? {}),
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Upload failed.";
    const status =
      message === "Unauthorized" || message === "Forbidden" ? 401 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ studentId: string }> },
) {
  try {
    await requireAdmin();
    const { studentId } = await params;
    const db = getFirebaseAdminDb();
    const studentRef = db.collection(COLLECTIONS.students).doc(studentId);
    const studentSnap = await studentRef.get();
    if (!studentSnap.exists) {
      return NextResponse.json({ error: "Student not found." }, { status: 404 });
    }

    const studentData = studentSnap.data() ?? {};
    const existingIdCard = studentData.idCard as { storagePath?: string } | undefined;
    if (existingIdCard?.storagePath) {
      await deleteIdCardFromStorage(existingIdCard.storagePath);
    }

    await studentRef.update({ idCard: FieldValue.delete() });

    const updatedSnap = await studentRef.get();
    return NextResponse.json({
      student: mapStudentDoc(updatedSnap.id, updatedSnap.data() ?? {}),
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Delete failed.";
    const status =
      message === "Unauthorized" || message === "Forbidden" ? 401 : 500;
    return NextResponse.json({ error: message }, { status });
  }
}
