import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import {
  createJob,
  fetchAdminJobs,
  isJobSlugTaken,
  buildJobPayload,
} from "@/lib/jobs-server";
import { requireAdmin } from "@/lib/server-admin-auth";
import type { JobSortOption, JobStatus } from "@/types/job";
import { JOB_SORT_OPTIONS, JOB_STATUSES } from "@/types/job";

export async function GET(request: Request) {
  try {
    await requireAdmin();
    const { searchParams } = new URL(request.url);
    const search = searchParams.get("search") ?? undefined;
    const statusParam = searchParams.get("status") ?? undefined;
    const status = JOB_STATUSES.includes(statusParam as JobStatus)
      ? (statusParam as JobStatus)
      : undefined;
    const sortParam = searchParams.get("sort") ?? "latest";
    const sort = JOB_SORT_OPTIONS.includes(sortParam as JobSortOption)
      ? (sortParam as JobSortOption)
      : "latest";
    const page = Number(searchParams.get("page") ?? 1);
    const pageSize = Number(searchParams.get("pageSize") ?? 12);

    const result = await fetchAdminJobs(getFirebaseAdminDb(), {
      search,
      status,
      sort,
      page,
      pageSize,
    });

    return NextResponse.json(result);
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function POST(request: Request) {
  try {
    await requireAdmin();
    const body = (await request.json()) as Record<string, unknown>;

    if (!String(body.title ?? "").trim()) {
      return NextResponse.json({ error: "Job title is required." }, { status: 400 });
    }
    if (!String(body.department ?? "").trim()) {
      return NextResponse.json({ error: "Department is required." }, { status: 400 });
    }
    if (!String(body.location ?? "").trim()) {
      return NextResponse.json({ error: "Location is required." }, { status: 400 });
    }
    if (!String(body.shortDescription ?? "").trim()) {
      return NextResponse.json(
        { error: "Short description is required." },
        { status: 400 },
      );
    }

    const payload = buildJobPayload(body);
    const slug = String(payload.slug);
    if (await isJobSlugTaken(getFirebaseAdminDb(), slug)) {
      return NextResponse.json({ error: "Slug already exists." }, { status: 400 });
    }

    const job = await createJob(getFirebaseAdminDb(), body);
    return NextResponse.json({ job });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
