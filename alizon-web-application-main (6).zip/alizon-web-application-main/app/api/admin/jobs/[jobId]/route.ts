import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import {
  deleteJob,
  fetchAdminJobById,
  isJobSlugTaken,
  updateJob,
  buildJobPayload,
} from "@/lib/jobs-server";
import { requireAdmin } from "@/lib/server-admin-auth";

type Props = { params: Promise<{ jobId: string }> };

export async function GET(_request: Request, context: Props) {
  try {
    await requireAdmin();
    const { jobId } = await context.params;
    const job = await fetchAdminJobById(getFirebaseAdminDb(), jobId);
    return NextResponse.json({ job });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function PATCH(request: Request, context: Props) {
  try {
    await requireAdmin();
    const { jobId } = await context.params;
    const body = (await request.json()) as Record<string, unknown>;

    const existing = await fetchAdminJobById(getFirebaseAdminDb(), jobId);
    if (!existing) {
      return NextResponse.json({ error: "Job not found." }, { status: 404 });
    }

    const payload = buildJobPayload(body, existing);
    const slug = String(payload.slug);
    if (slug !== existing.slug && (await isJobSlugTaken(getFirebaseAdminDb(), slug, jobId))) {
      return NextResponse.json({ error: "Slug already exists." }, { status: 400 });
    }

    const job = await updateJob(getFirebaseAdminDb(), jobId, body);
    if (!job) {
      return NextResponse.json({ error: "Job not found." }, { status: 404 });
    }

    return NextResponse.json({ job });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function DELETE(_request: Request, context: Props) {
  try {
    await requireAdmin();
    const { jobId } = await context.params;
    const deleted = await deleteJob(getFirebaseAdminDb(), jobId);
    if (!deleted) {
      return NextResponse.json({ error: "Job not found." }, { status: 404 });
    }
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
