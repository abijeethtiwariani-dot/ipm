import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { updateJobStatus } from "@/lib/jobs-server";
import { requireAdmin } from "@/lib/server-admin-auth";
import type { JobStatus } from "@/types/job";
import { JOB_STATUSES } from "@/types/job";

type Props = { params: Promise<{ jobId: string }> };

export async function PATCH(request: Request, context: Props) {
  try {
    await requireAdmin();
    const { jobId } = await context.params;
    const body = (await request.json()) as { status?: JobStatus };
    const status = body.status;

    if (!status || !JOB_STATUSES.includes(status)) {
      return NextResponse.json({ error: "Invalid status." }, { status: 400 });
    }

    const job = await updateJobStatus(getFirebaseAdminDb(), jobId, status);
    if (!job) {
      return NextResponse.json({ error: "Job not found." }, { status: 404 });
    }

    return NextResponse.json({ job });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
