import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import {
  getProgramEvaluationMaxMarks,
  mapProgramDoc,
  normalizeEvaluationMaxMarks,
} from "@/lib/programs";
import { resolveStudentProgramId } from "@/lib/program-student-count";
import { COLLECTIONS } from "@/lib/student-constants";
import type { EvaluationGradeComponentKey } from "@/types/student-evaluation";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ studentId: string }> },
) {
  try {
    await requireAdmin();
    const { studentId } = await params;
    const body = (await request.json()) as {
      component?: EvaluationGradeComponentKey;
      marks?: number;
      feedback?: string;
    };

    if (
      !body.component ||
      !["viva", "internship", "elective"].includes(body.component)
    ) {
      return NextResponse.json({ error: "Invalid component." }, { status: 400 });
    }

    const db = getFirebaseAdminDb();

    const studentSnap = await db.collection(COLLECTIONS.students).doc(studentId).get();
    if (!studentSnap.exists) {
      return NextResponse.json({ error: "Student not found." }, { status: 404 });
    }

    const studentData = studentSnap.data() ?? {};
    const programsSnap = await db.collection(COLLECTIONS.courses).get();
    const programs = programsSnap.docs.map((doc) => ({
      id: doc.id,
      name: String(doc.data().name ?? ""),
    }));
    const resolvedProgramId = resolveStudentProgramId(
      {
        programId: String(studentData.programId ?? ""),
        course: String(studentData.course ?? ""),
      },
      programs,
    );

    let maxMarks = normalizeEvaluationMaxMarks(undefined);
    if (resolvedProgramId) {
      const programSnap = await db
        .collection(COLLECTIONS.courses)
        .doc(resolvedProgramId)
        .get();
      if (programSnap.exists) {
        const program = mapProgramDoc(programSnap.id, programSnap.data() ?? {});
        maxMarks = getProgramEvaluationMaxMarks(program, body.component!);
      }
    }

    const marks = Number(body.marks);
    if (!Number.isFinite(marks) || marks < 0 || marks > maxMarks) {
      return NextResponse.json(
        { error: `Marks must be between 0 and ${maxMarks}.` },
        { status: 400 },
      );
    }

    const ref = db.collection(COLLECTIONS.studentEvaluations).doc(studentId);
    const snap = await ref.get();

    const registrationId = String(studentData.registrationId ?? "");
    const existing = snap.data() ?? {};
    const componentData = (existing[body.component] as Record<string, unknown>) ?? {};

    if (body.component !== "viva") {
      const fileUrl = String(componentData.fileUrl ?? "");
      if (!fileUrl) {
        return NextResponse.json(
          { error: "Student has not submitted a document for this component." },
          { status: 400 },
        );
      }
    }

    await ref.set(
      {
        studentId,
        registrationId,
        [body.component]: {
          ...componentData,
          marks,
          feedback: body.feedback?.trim() ?? "",
          status: "Graded",
          gradedAt: FieldValue.serverTimestamp(),
        },
        updatedAt: FieldValue.serverTimestamp(),
      },
      { merge: true },
    );

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
