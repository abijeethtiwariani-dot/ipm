import { NextResponse } from "next/server";
import { getFirebaseAdminDb, getFirebaseAdminStorage } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import { COLLECTIONS } from "@/lib/student-constants";

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ studentId: string }> },
) {
  try {
    await requireAdmin();
    const { studentId } = await params;
    const db = getFirebaseAdminDb();

    const studentSnap = await db.collection(COLLECTIONS.students).doc(studentId).get();
    const registrationId = studentSnap.exists
      ? String(studentSnap.data()?.registrationId ?? "")
      : "";

    const evalRef = db.collection(COLLECTIONS.studentEvaluations).doc(studentId);
    const evalSnap = await evalRef.get();
    if (evalSnap.exists) {
      await evalRef.delete();
    }

    if (registrationId) {
      try {
        await getFirebaseAdminStorage().bucket().deleteFiles({
          prefix: `evaluations/${registrationId}/`,
        });
      } catch {
        // ignore storage errors
      }
    }

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
