import { NextResponse } from "next/server";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import {
  defaultEvaluationComponent,
  emptyStudentEvaluation,
  mapEvaluationDoc,
} from "@/lib/student-evaluations";
import { resolveStudentProgramId } from "@/lib/program-student-count";
import { COLLECTIONS } from "@/lib/student-constants";
import type { StudentEvaluationRow } from "@/types/student-evaluation";

export async function GET() {
  try {
    await requireAdmin();
    const db = getFirebaseAdminDb();

    const [studentsSnap, evaluationsSnap, programsSnap] = await Promise.all([
      db.collection(COLLECTIONS.students).get(),
      db.collection(COLLECTIONS.studentEvaluations).get(),
      db.collection(COLLECTIONS.courses).get(),
    ]);

    const programs = programsSnap.docs.map((doc) => ({
      id: doc.id,
      name: String(doc.data().name ?? ""),
    }));

    const evaluationByStudent = new Map(
      evaluationsSnap.docs.map((doc) => [
        doc.id,
        mapEvaluationDoc(doc.id, doc.data()),
      ]),
    );

    const evaluations: StudentEvaluationRow[] = studentsSnap.docs
      .map((doc) => {
        const data = doc.data();
        const base =
          evaluationByStudent.get(doc.id) ??
          emptyStudentEvaluation(doc.id, String(data.registrationId ?? ""));

        const course = String(data.course ?? "");
        const programId = String(data.programId ?? "");
        const resolvedProgramId = resolveStudentProgramId(
          { programId, course },
          programs,
        );

        return {
          ...base,
          studentId: doc.id,
          registrationId: String(data.registrationId ?? base.registrationId),
          programId,
          course,
          resolvedProgramId,
          studentName: String(data.name ?? ""),
          studentEmail: String(data.email ?? ""),
          viva: base.viva ?? defaultEvaluationComponent(),
          internship: base.internship ?? defaultEvaluationComponent(),
          elective: base.elective ?? defaultEvaluationComponent(),
        };
      })
      .sort((a, b) =>
        a.registrationId.localeCompare(b.registrationId),
      );

    return NextResponse.json({ evaluations });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
