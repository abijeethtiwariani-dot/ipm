import { NextResponse } from "next/server";
import { getFirebaseAdminDb, getFirebaseAdminStorage } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import { COLLECTIONS } from "@/lib/student-constants";

export async function POST(request: Request) {
  try {
    await requireAdmin();
    const body = (await request.json()) as { studentIds?: string[] };
    const studentIds = Array.isArray(body.studentIds)
      ? [...new Set(body.studentIds.filter(Boolean))]
      : [];

    if (studentIds.length === 0) {
      return NextResponse.json({ error: "No evaluations selected." }, { status: 400 });
    }

    const db = getFirebaseAdminDb();
    const bucket = getFirebaseAdminStorage().bucket();

    for (let i = 0; i < studentIds.length; i += 500) {
      const chunk = studentIds.slice(i, i + 500);
      const batch = db.batch();
      for (const studentId of chunk) {
        batch.delete(db.collection(COLLECTIONS.studentEvaluations).doc(studentId));
      }
      await batch.commit();
    }

    const studentsSnap = await Promise.all(
      studentIds.map((id) => db.collection(COLLECTIONS.students).doc(id).get()),
    );

    await Promise.all(
      studentsSnap.map(async (snap) => {
        if (!snap.exists) return;
        const registrationId = String(snap.data()?.registrationId ?? "");
        if (!registrationId) return;
        try {
          await bucket.deleteFiles({ prefix: `evaluations/${registrationId}/` });
        } catch {
          // ignore
        }
      }),
    );

    return NextResponse.json({ success: true, deleted: studentIds.length });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
