import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";

export async function GET(request: Request) {
  try {
    await requireAdmin();
    const { searchParams } = new URL(request.url);
    const collectionName = searchParams.get("collection");
    if (!collectionName) {
      return NextResponse.json({ error: "Missing collection." }, { status: 400 });
    }
    let queryRef: FirebaseFirestore.Query = getFirebaseAdminDb().collection(collectionName);
    const whereField = searchParams.get("whereField");
    const whereEq = searchParams.get("whereEq");
    if (whereField && whereEq !== null) {
      const eqValue = whereEq === "true" ? true : whereEq === "false" ? false : whereEq;
      queryRef = queryRef.where(whereField, "==", eqValue);
    }
    const orderByField = searchParams.get("orderBy") ?? "order";
    const orderDir = (searchParams.get("orderDir") as FirebaseFirestore.OrderByDirection) ?? "asc";
    queryRef = queryRef.orderBy(orderByField, orderDir);
    const limitValue = Number(searchParams.get("limit") ?? 0);
    if (Number.isFinite(limitValue) && limitValue > 0) {
      queryRef = queryRef.limit(limitValue);
    }
    const snap = await queryRef.get();
    return NextResponse.json({
      cards: snap.docs.map((doc) => ({ id: doc.id, ...doc.data() })),
    });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function POST(request: Request) {
  try {
    await requireAdmin();
    const { collection, data } = (await request.json()) as {
      collection?: string;
      data?: Record<string, unknown>;
    };
    if (!collection || !data) {
      return NextResponse.json({ error: "Missing payload." }, { status: 400 });
    }
    const ref = await getFirebaseAdminDb().collection(collection).add({
      ...data,
      createdAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    });
    return NextResponse.json({ id: ref.id });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
