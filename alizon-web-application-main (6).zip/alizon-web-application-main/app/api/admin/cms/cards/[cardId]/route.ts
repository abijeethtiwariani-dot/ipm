import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ cardId: string }> },
) {
  try {
    await requireAdmin();
    const { cardId } = await params;
    const { collection, data } = (await request.json()) as {
      collection?: string;
      data?: Record<string, unknown>;
    };
    if (!collection || !data) {
      return NextResponse.json({ error: "Missing payload." }, { status: 400 });
    }
    await getFirebaseAdminDb()
      .collection(collection)
      .doc(cardId)
      .set({ ...data, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ cardId: string }> },
) {
  try {
    await requireAdmin();
    const { cardId } = await params;
    const { searchParams } = new URL(request.url);
    const collection = searchParams.get("collection");
    if (!collection) {
      return NextResponse.json({ error: "Missing collection." }, { status: 400 });
    }
    await getFirebaseAdminDb().collection(collection).doc(cardId).delete();
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
