import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";

export async function GET(request: Request) {
  try {
    await requireAdmin();
    const { searchParams } = new URL(request.url);
    const collection = searchParams.get("collection");
    const docId = searchParams.get("docId");
    if (!collection || !docId) {
      return NextResponse.json({ error: "Missing path." }, { status: 400 });
    }
    const snap = await getFirebaseAdminDb().collection(collection).doc(docId).get();
    if (!snap.exists) {
      return NextResponse.json({ data: null });
    }
    return NextResponse.json({ data: snap.data() });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function PUT(request: Request) {
  try {
    await requireAdmin();
    const { collection, docId, data } = (await request.json()) as {
      collection?: string;
      docId?: string;
      data?: Record<string, unknown>;
    };
    if (!collection || !docId || !data) {
      return NextResponse.json({ error: "Missing payload." }, { status: 400 });
    }
    await getFirebaseAdminDb()
      .collection(collection)
      .doc(docId)
      .set({ ...data, updatedAt: FieldValue.serverTimestamp() }, { merge: true });
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
