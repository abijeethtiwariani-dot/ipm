import { NextResponse } from "next/server";
import {
  getFirebaseAdminDb,
  getFirebaseAdminStorage,
} from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import { COLLECTIONS } from "@/lib/student-constants";

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    await requireAdmin();
    const { id } = await params;
    const db = getFirebaseAdminDb();
    const applicationRef = db.collection(COLLECTIONS.jobApplications).doc(id);
    const snap = await applicationRef.get();

    if (!snap.exists) {
      return NextResponse.json(
        { error: "Application not found." },
        { status: 404 },
      );
    }

    const data = snap.data() ?? {};
    const storagePath = String(data.cvStoragePath ?? "");

    await applicationRef.delete();

    if (storagePath) {
      try {
        await getFirebaseAdminStorage().bucket().file(storagePath).delete();
      } catch {
        // File may already be missing
      }
    }

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
