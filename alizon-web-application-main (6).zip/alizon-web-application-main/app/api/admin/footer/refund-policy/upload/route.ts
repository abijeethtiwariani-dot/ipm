import { NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { getFirebaseAdminStorage } from "@/lib/firebase-admin";
import { isAllowedModuleDocument } from "@/lib/module-resource-utils";
import { requireAdmin } from "@/lib/server-admin-auth";

const REFUND_POLICY_STORAGE_PREFIX = "cms/footer/refund-policy";

export async function POST(request: Request) {
  try {
    await requireAdmin();
    const formData = await request.formData();
    const file = formData.get("file");

    if (!(file instanceof File)) {
      return NextResponse.json({ error: "File is required." }, { status: 400 });
    }

    const validation = isAllowedModuleDocument(file.name, file.type, file.size);
    if (validation.ok === false) {
      return NextResponse.json({ error: validation.message }, { status: 400 });
    }

    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
    const storagePath = `${REFUND_POLICY_STORAGE_PREFIX}/${randomUUID()}-${safeName}`;
    const bucket = getFirebaseAdminStorage().bucket();
    const bucketFile = bucket.file(storagePath);
    const buffer = Buffer.from(await file.arrayBuffer());

    await bucketFile.save(buffer, {
      contentType: file.type || "application/octet-stream",
      metadata: { cacheControl: "public, max-age=31536000" },
    });
    await bucketFile.makePublic();

    return NextResponse.json({
      file: {
        url: bucketFile.publicUrl(),
        fileName: file.name,
      },
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Upload failed.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
