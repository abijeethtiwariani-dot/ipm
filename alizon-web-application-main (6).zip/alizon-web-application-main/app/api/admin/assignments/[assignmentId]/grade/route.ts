import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import { normalizeAssignmentTotalMarks } from "@/lib/modules";
import { COLLECTIONS, DEFAULT_ASSIGNMENT_TOTAL_MARKS } from "@/lib/student-constants";

export async function POST(
  request: Request,
  { params }: { params: Promise<{ assignmentId: string }> },
) {
  try {
    await requireAdmin();
    const { assignmentId } = await params;
    const body = (await request.json()) as {
      status: "Pending" | "Approved" | "Rejected";
      marks: number | null;
      feedback: string;
    };
    const db = getFirebaseAdminDb();
    const assignmentRef = db.collection(COLLECTIONS.assignments).doc(assignmentId);
    const assignmentSnap = await assignmentRef.get();
    if (!assignmentSnap.exists) {
      return NextResponse.json({ error: "Assignment not found." }, { status: 404 });
    }
    const assignment = assignmentSnap.data() as Record<string, unknown>;

    let maxMarks = DEFAULT_ASSIGNMENT_TOTAL_MARKS;
    const programId = String(assignment.programId ?? "");
    const moduleId = String(assignment.moduleId ?? "");
    if (programId && moduleId) {
      const moduleSnap = await db
        .collection(COLLECTIONS.courses)
        .doc(programId)
        .collection(COLLECTIONS.modules)
        .doc(moduleId)
        .get();
      if (moduleSnap.exists) {
        maxMarks = normalizeAssignmentTotalMarks(
          moduleSnap.data()?.assignmentTotalMarks,
        );
      }
    }

    if (body.status === "Approved" && body.marks !== null && body.marks !== undefined) {
      const marks = Number(body.marks);
      if (!Number.isFinite(marks) || marks < 0 || marks > maxMarks) {
        return NextResponse.json(
          { error: `Marks must be between 0 and ${maxMarks}.` },
          { status: 400 },
        );
      }
    }

    await assignmentRef.set(
      {
        status: body.status,
        marks: body.status === "Approved" ? body.marks : null,
        feedback: body.feedback ?? "",
        gradedAt: FieldValue.serverTimestamp(),
      },
      { merge: true },
    );
    if (body.status === "Approved" || body.status === "Rejected") {
      await db
        .collection(COLLECTIONS.results)
        .doc(assignmentId)
        .set({
          studentId: assignment.studentId ?? "",
          registrationId: assignment.registrationId ?? "",
          programId,
          moduleId,
          moduleName: assignment.moduleName ?? "",
          assignmentTitle: assignment.assignmentTitle ?? "",
          marks: body.status === "Approved" ? body.marks : null,
          feedback: body.feedback ?? "",
          status: body.status,
          submittedAt: assignment.submittedAt ?? null,
          gradedAt: FieldValue.serverTimestamp(),
        });
    }
    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
