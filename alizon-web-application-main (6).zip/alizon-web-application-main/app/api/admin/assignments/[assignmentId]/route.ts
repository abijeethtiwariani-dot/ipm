import { NextResponse } from "next/server";
import { getFirebaseAdminDb, getFirebaseAdminStorage } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import { COLLECTIONS } from "@/lib/student-constants";

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ assignmentId: string }> },
) {
  try {
    await requireAdmin();
    const { assignmentId } = await params;
    const db = getFirebaseAdminDb();
    const assignmentRef = db.collection(COLLECTIONS.assignments).doc(assignmentId);
    const assignmentSnap = await assignmentRef.get();

    if (!assignmentSnap.exists) {
      return NextResponse.json({ error: "Assignment not found." }, { status: 404 });
    }

    const data = assignmentSnap.data() ?? {};
    const batch = db.batch();
    batch.delete(assignmentRef);
    batch.delete(db.collection(COLLECTIONS.results).doc(assignmentId));
    await batch.commit();

    const storagePath = String(data.storagePath ?? "");
    if (storagePath) {
      try {
        await getFirebaseAdminStorage().bucket().file(storagePath).delete();
      } catch {
        // File may already be missing
      }
    }

    return NextResponse.json({ success: true });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
