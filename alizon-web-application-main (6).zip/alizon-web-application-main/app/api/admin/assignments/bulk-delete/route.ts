import { NextResponse } from "next/server";
import { getFirebaseAdminDb, getFirebaseAdminStorage } from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";
import { COLLECTIONS } from "@/lib/student-constants";

export async function POST(request: Request) {
  try {
    await requireAdmin();
    const body = (await request.json()) as { ids?: string[] };
    const ids = Array.isArray(body.ids) ? [...new Set(body.ids.filter(Boolean))] : [];

    if (ids.length === 0) {
      return NextResponse.json({ error: "No assignments selected." }, { status: 400 });
    }

    const db = getFirebaseAdminDb();
    const bucket = getFirebaseAdminStorage().bucket();
    const storagePaths: string[] = [];

    for (let i = 0; i < ids.length; i += 250) {
      const chunk = ids.slice(i, i + 250);
      const batch = db.batch();
      const snaps = await Promise.all(
        chunk.map((id) => db.collection(COLLECTIONS.assignments).doc(id).get()),
      );

      for (const snap of snaps) {
        if (!snap.exists) continue;
        const data = snap.data() ?? {};
        const storagePath = String(data.storagePath ?? "");
        if (storagePath) storagePaths.push(storagePath);
        batch.delete(snap.ref);
        batch.delete(db.collection(COLLECTIONS.results).doc(snap.id));
      }
      await batch.commit();
    }

    await Promise.all(
      storagePaths.map(async (path) => {
        try {
          await bucket.file(path).delete();
        } catch {
          // ignore missing files
        }
      }),
    );

    return NextResponse.json({ success: true, deleted: ids.length });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
