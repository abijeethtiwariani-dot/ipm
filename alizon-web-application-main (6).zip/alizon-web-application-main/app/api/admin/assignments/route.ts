import { NextResponse } from "next/server";
import { mapAssignmentDoc } from "@/lib/assignments";
import { getFirebaseAdminDb } from "@/lib/firebase-admin";
import { timestampToMillis } from "@/lib/firestore-timestamp";
import { requireAdmin } from "@/lib/server-admin-auth";
import { COLLECTIONS } from "@/lib/student-constants";

export async function GET(request: Request) {
  try {
    await requireAdmin();
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");
    const ref = getFirebaseAdminDb().collection(COLLECTIONS.assignments);
    const snap =
      status && status !== "all" ? await ref.where("status", "==", status).get() : await ref.get();
    const assignments = snap.docs
      .map((doc) => mapAssignmentDoc(doc.id, doc.data()))
      .sort(
        (a, b) =>
          timestampToMillis(b.submittedAt) - timestampToMillis(a.submittedAt),
      );
    return NextResponse.json({ assignments });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
