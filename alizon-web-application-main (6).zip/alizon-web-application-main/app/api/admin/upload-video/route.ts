import { NextResponse } from "next/server";
import { randomUUID } from "crypto";
import {
  getFirebaseAdminStorage,
  isFirebaseAdminConfigured,
} from "@/lib/firebase-admin";
import { requireAdmin } from "@/lib/server-admin-auth";

const MAX_VIDEO_BYTES = 100 * 1024 * 1024;
const ALLOWED_VIDEO_TYPES = new Set([
  "video/mp4",
  "video/webm",
  "video/quicktime",
  "video/x-m4v",
]);

export async function POST(request: Request) {
  if (!isFirebaseAdminConfigured()) {
    return NextResponse.json({ error: "Server is not configured." }, { status: 503 });
  }

  try {
    await requireAdmin();
    const formData = await request.formData();
    const file = formData.get("file");
    const folder = String(formData.get("folder") || "cms/videos").replace(
      /^\/+|\/+$/g,
      "",
    );

    if (!(file instanceof File)) {
      return NextResponse.json({ error: "File is required." }, { status: 400 });
    }

    if (file.size > MAX_VIDEO_BYTES) {
      return NextResponse.json(
        { error: "Video must be under 100 MB." },
        { status: 400 },
      );
    }

    const typeOk =
      ALLOWED_VIDEO_TYPES.has(file.type) ||
      /\.(mp4|webm|mov|m4v)$/i.test(file.name);
    if (!typeOk) {
      return NextResponse.json(
        { error: "Only MP4, WebM, and MOV videos are allowed." },
        { status: 400 },
      );
    }

    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
    const storagePath = `${folder}/${randomUUID()}-${safeName}`;
    const bucket = getFirebaseAdminStorage().bucket();
    const bucketFile = bucket.file(storagePath);
    const buffer = Buffer.from(await file.arrayBuffer());

    await bucketFile.save(buffer, {
      contentType: file.type || "video/mp4",
      metadata: { cacheControl: "public, max-age=31536000" },
    });
    await bucketFile.makePublic();

    return NextResponse.json({
      url: bucketFile.publicUrl(),
      fileName: file.name,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Upload failed.";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
