import { StudentAuthPageShell } from "@/components/student/StudentAuthPageShell";
import { ForgotPasswordForm } from "@/components/student/ForgotPasswordForm";

export const metadata = {
  title: "Forgot Password",
};

export default function ForgotPasswordPage() {
  return (
    <StudentAuthPageShell>
      <ForgotPasswordForm />
    </StudentAuthPageShell>
  );
}
