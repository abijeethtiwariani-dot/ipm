import type { Metadata } from "next";
import { Suspense } from "react";
import SearchPage from "@/views/Search";
import { Skeleton } from "@/components/ui/skeleton";

export const revalidate = 3600;

function SearchFallback() {
  return (
    <div className="container mx-auto max-w-4xl space-y-4 px-4 py-12">
      <Skeleton className="h-10 w-full max-w-md" />
      <Skeleton className="h-64 w-full" />
    </div>
  );
}

export const metadata: Metadata = {
  title: "Search",
  description:
    "Search Alizon School of Medical & Digital Intelligence programs, admissions, scholarships, research, campus life, and support resources.",
};

export default function SearchRoutePage() {
  return (
    <Suspense fallback={<SearchFallback />}>
      <SearchPage />
    </Suspense>
  );
}
