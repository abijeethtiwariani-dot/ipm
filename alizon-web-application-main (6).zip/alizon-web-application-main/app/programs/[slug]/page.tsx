import type { Metadata } from "next";
import ProgramDetails from "@/views/ProgramDetails";
import { BreadcrumbJsonLd } from "@/components/seo/BreadcrumbJsonLd";
import { ProgramJsonLd } from "@/components/seo/ProgramJsonLd";
import { getFirebaseAdminDb, isFirebaseAdminConfigured } from "@/lib/firebase-admin";
import {
  buildJobMetaDescription,
} from "@/lib/job-seo";
import { buildPageMetadata } from "@/lib/seo/metadata";
import { getStaticPageSeo } from "@/lib/seo/page-seo";
import { fetchPublicProgramBySlug } from "@/lib/programs-server";
import { ROUTES } from "@/lib/site-routes";

export const revalidate = 3600;

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const path = `${ROUTES.programs}/${slug}`;
  const fallback = getStaticPageSeo(ROUTES.programs);

  if (!isFirebaseAdminConfigured()) {
    return buildPageMetadata({
      title: fallback.title,
      description: fallback.description,
      path,
    });
  }

  const program = await fetchPublicProgramBySlug(getFirebaseAdminDb(), slug);
  if (!program) {
    return buildPageMetadata({
      title: "Program not found",
      description: fallback.description,
      path,
      noIndex: true,
    });
  }

  return buildPageMetadata({
    title: program.seoTitle?.trim() || program.name,
    description: buildJobMetaDescription(
      program.seoDescription || program.shortDescription,
    ),
    path,
    keywords: program.seoKeywords?.trim() || undefined,
    ogImage:
      program.banner?.largeUrl ||
      program.banner?.mediumUrl ||
      program.thumbnail?.largeUrl ||
      undefined,
  });
}

export default async function ProgramDetailsPage({ params }: Props) {
  const { slug } = await params;
  const path = `${ROUTES.programs}/${slug}`;
  const program = isFirebaseAdminConfigured()
    ? await fetchPublicProgramBySlug(getFirebaseAdminDb(), slug)
    : null;

  return (
    <>
      <BreadcrumbJsonLd
        items={[
          { name: "Home", path: ROUTES.home },
          { name: "Programs", path: ROUTES.programs },
          { name: program?.name ?? "Program", path },
        ]}
      />
      {program ? <ProgramJsonLd program={program} /> : null}
      <ProgramDetails slug={slug} />
    </>
  );
}
