import Programs from "@/views/Programs";
import { BreadcrumbJsonLd } from "@/components/seo/BreadcrumbJsonLd";
import { ProgramsListJsonLd } from "@/components/seo/ProgramsListJsonLd";
import { buildStaticPageMetadata } from "@/lib/seo/cms-metadata";
import { getFirebaseAdminDb, isFirebaseAdminConfigured } from "@/lib/firebase-admin";
import { fetchActivePrograms } from "@/lib/programs-server";
import { ROUTES } from "@/lib/site-routes";

export const revalidate = 3600;

export const metadata = buildStaticPageMetadata(ROUTES.programs);

export default async function ProgramsPage() {
  const programs = isFirebaseAdminConfigured()
    ? await fetchActivePrograms(getFirebaseAdminDb())
    : [];

  return (
    <>
      <BreadcrumbJsonLd
        currentPageName="Programs"
        currentPagePath={ROUTES.programs}
      />
      <ProgramsListJsonLd programs={programs} />
      <Programs />
    </>
  );
}
