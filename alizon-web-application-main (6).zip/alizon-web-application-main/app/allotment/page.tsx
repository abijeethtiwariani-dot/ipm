import Allotment from "@/views/Allotment";
import { BreadcrumbJsonLd } from "@/components/seo/BreadcrumbJsonLd";
import { buildStaticPageMetadata } from "@/lib/seo/cms-metadata";
import { ROUTES } from "@/lib/site-routes";

export const revalidate = 86400;

export const metadata = buildStaticPageMetadata(ROUTES.allotment);

export default function AllotmentPage() {
  return (
    <>
      <BreadcrumbJsonLd
        currentPageName="Program Allotments"
        currentPagePath={ROUTES.allotment}
      />
      <Allotment />
    </>
  );
}
