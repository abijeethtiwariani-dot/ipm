import type { Metadata } from "next";
import AllotmentDetail from "@/views/AllotmentDetail";
import { BreadcrumbJsonLd } from "@/components/seo/BreadcrumbJsonLd";
import { JsonLd } from "@/components/seo/JsonLd";
import {
  buildAllotmentMetaDescription,
  buildAllotmentMetaKeywords,
  buildAllotmentPageTitle,
} from "@/lib/allotment-seo";
import { getFirebaseAdminDb, isFirebaseAdminConfigured } from "@/lib/firebase-admin";
import { fetchPublicAllotmentBySlug } from "@/lib/allotments-server";
import { buildPageMetadata } from "@/lib/seo/metadata";
import { getStaticPageSeo } from "@/lib/seo/page-seo";
import { ROUTES } from "@/lib/site-routes";
import { SITE_URL } from "@/lib/site-branding";

export const revalidate = 3600;

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const path = `${ROUTES.allotment}/${slug}`;
  const fallback = getStaticPageSeo(ROUTES.allotment);

  if (!isFirebaseAdminConfigured()) {
    return buildPageMetadata({
      title: "Allotment",
      description: fallback.description,
      path,
    });
  }

  const allotment = await fetchPublicAllotmentBySlug(getFirebaseAdminDb(), slug);
  if (!allotment) {
    return buildPageMetadata({
      title: "Allotment not found",
      description: fallback.description,
      path,
      noIndex: true,
    });
  }

  return buildPageMetadata({
    title: buildAllotmentPageTitle(allotment.title),
    description: buildAllotmentMetaDescription(allotment.shortDescription),
    path,
    keywords: buildAllotmentMetaKeywords({
      title: allotment.title,
      categoryName: allotment.categoryName,
      publishDate: allotment.publishDate,
    }),
    ogType: "article",
    publishedTime: allotment.publishDate || undefined,
  });
}

export default async function AllotmentDetailPage({ params }: Props) {
  const { slug } = await params;
  const path = `${ROUTES.allotment}/${slug}`;
  const allotment = isFirebaseAdminConfigured()
    ? await fetchPublicAllotmentBySlug(getFirebaseAdminDb(), slug)
    : null;

  const webPageSchema = allotment
    ? {
        "@context": "https://schema.org",
        "@type": "WebPage",
        name: allotment.title,
        description: allotment.shortDescription,
        url: `${SITE_URL}${path}`,
        datePublished: allotment.publishDate || undefined,
      }
    : null;

  return (
    <>
      <BreadcrumbJsonLd
        items={[
          { name: "Home", path: ROUTES.home },
          { name: "Allotment", path: ROUTES.allotment },
          { name: allotment?.title ?? "Allotment", path },
        ]}
      />
      {webPageSchema ? <JsonLd data={webPageSchema} /> : null}
      <AllotmentDetail slug={slug} />
    </>
  );
}
