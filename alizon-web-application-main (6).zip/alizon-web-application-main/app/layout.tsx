import type { Metadata, Viewport } from "next";
import { Layout } from "@/components/layout/Layout";
import { Providers } from "@/components/providers";
import { isSearchIndexingAllowed, NOINDEX_ROBOTS } from "@/lib/site-indexing";
import {
  DEFAULT_SITE_DESCRIPTION,
  INSTITUTION_DISPLAY_NAME,
  SITE_URL,
} from "@/lib/site-branding";
import "@/index.css";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default: INSTITUTION_DISPLAY_NAME,
    template: `%s | ${INSTITUTION_DISPLAY_NAME}`,
  },
  description: DEFAULT_SITE_DESCRIPTION,
  authors: [{ name: INSTITUTION_DISPLAY_NAME, url: SITE_URL }],
  creator: INSTITUTION_DISPLAY_NAME,
  alternates: {
    languages: {
      "en-US": "/",
    },
  },
  icons: {
    icon: [
      { url: "/favicon.ico" },
      { url: "/favicon-16x16.png", sizes: "16x16", type: "image/png" },
      { url: "/favicon-32x32.png", sizes: "32x32", type: "image/png" },
    ],
    apple: "/apple-touch-icon.png",
  },
  openGraph: {
    title: INSTITUTION_DISPLAY_NAME,
    description: DEFAULT_SITE_DESCRIPTION,
    type: "website",
    url: "/",
    siteName: INSTITUTION_DISPLAY_NAME,
    images: [
      {
        url: "/android-chrome-512x512.png",
        width: 512,
        height: 512,
        alt: INSTITUTION_DISPLAY_NAME,
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: INSTITUTION_DISPLAY_NAME,
    description: DEFAULT_SITE_DESCRIPTION,
    images: ["/android-chrome-512x512.png"],
  },
  ...(isSearchIndexingAllowed() ? {} : { robots: NOINDEX_ROBOTS }),
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning data-scroll-behavior="smooth">
      <body>
        <Providers>
          <Layout>{children}</Layout>
        </Providers>
      </body>
    </html>
  );
}
