import type { MetadataRoute } from "next";
import {
  INSTITUTION_DISPLAY_NAME,
  INSTITUTION_PRIMARY_NAME,
} from "@/lib/site-branding";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: INSTITUTION_DISPLAY_NAME,
    short_name: INSTITUTION_PRIMARY_NAME,
    icons: [
      {
        src: "/android-chrome-192x192.png",
        sizes: "192x192",
        type: "image/png",
      },
      {
        src: "/android-chrome-512x512.png",
        sizes: "512x512",
        type: "image/png",
      },
    ],
    theme_color: "#ffffff",
    background_color: "#ffffff",
    display: "standalone",
  };
}
