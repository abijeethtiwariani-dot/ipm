import { StudentAuthPageShell } from "@/components/student/StudentAuthPageShell";
import { StudentRegisterForm } from "@/components/student/StudentRegisterForm";

export const metadata = {
  title: "Student Registration",
};

export default function StudentRegisterPage() {
  return (
    <StudentAuthPageShell>
      <StudentRegisterForm />
    </StudentAuthPageShell>
  );
}
