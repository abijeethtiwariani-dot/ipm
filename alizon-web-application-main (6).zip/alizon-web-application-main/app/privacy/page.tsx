import Privacy from "@/views/Privacy";
import { BreadcrumbJsonLd } from "@/components/seo/BreadcrumbJsonLd";
import { buildStaticPageMetadata } from "@/lib/seo/cms-metadata";
import { ROUTES } from "@/lib/site-routes";

export const revalidate = 86400;

export const metadata = buildStaticPageMetadata(ROUTES.privacy);

export default function PrivacyPage() {
  return (
    <>
      <BreadcrumbJsonLd
        currentPageName="Privacy Policy"
        currentPagePath={ROUTES.privacy}
      />
      <Privacy />
    </>
  );
}
