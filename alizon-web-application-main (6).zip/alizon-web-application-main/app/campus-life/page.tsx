import CampusLife from "@/views/CampusLife";
import { BreadcrumbJsonLd } from "@/components/seo/BreadcrumbJsonLd";
import {
  generateCmsPageMetadata,
  resolveCampusLifePageSeo,
} from "@/lib/seo/cms-metadata";
import { ROUTES } from "@/lib/site-routes";

export const revalidate = 86400;

export async function generateMetadata() {
  return generateCmsPageMetadata(ROUTES.campusLife, resolveCampusLifePageSeo);
}

export default function CampusLifePage() {
  return (
    <>
      <BreadcrumbJsonLd
        currentPageName="Campus Life"
        currentPagePath={ROUTES.campusLife}
      />
      <CampusLife />
    </>
  );
}
