import { StudentResultsView } from "@/components/student/StudentResultsView";

export default function StudentResultsPage() {
  return <StudentResultsView />;
}
