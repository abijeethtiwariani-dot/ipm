import { StudentLayoutClient } from "@/components/student/StudentLayoutClient";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Student Results",
  robots: { index: false, follow: false },
};

export default function StudentResultsLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <StudentLayoutClient>{children}</StudentLayoutClient>;
}
