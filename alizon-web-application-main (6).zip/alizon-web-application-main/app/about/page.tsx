import About from "@/views/About";
import { BreadcrumbJsonLd } from "@/components/seo/BreadcrumbJsonLd";
import {
  generateCmsPageMetadata,
  resolveAboutPageSeo,
} from "@/lib/seo/cms-metadata";
import { ROUTES } from "@/lib/site-routes";

export const revalidate = 86400;

export async function generateMetadata() {
  return generateCmsPageMetadata(ROUTES.about, resolveAboutPageSeo);
}

export default function AboutPage() {
  return (
    <>
      <BreadcrumbJsonLd currentPageName="About" currentPagePath={ROUTES.about} />
      <About />
    </>
  );
}
