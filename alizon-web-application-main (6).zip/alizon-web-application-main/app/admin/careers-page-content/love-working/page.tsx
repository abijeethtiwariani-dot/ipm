import { CareersLoveWorkingManager } from "@/components/admin/careers-page/CareersLoveWorkingManager";

export default function AdminCareersLoveWorkingPage() {
  return <CareersLoveWorkingManager />;
}
