import { CareersWhyWorkManager } from "@/components/admin/careers-page/CareersWhyWorkManager";

export default function AdminCareersWhyWorkPage() {
  return <CareersWhyWorkManager />;
}
