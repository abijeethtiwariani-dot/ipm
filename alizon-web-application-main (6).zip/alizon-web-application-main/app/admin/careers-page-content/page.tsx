import { CareersPageContentHub } from "@/components/admin/CareersPageContentHub";

export default function AdminCareersPageContentPage() {
  return <CareersPageContentHub />;
}
