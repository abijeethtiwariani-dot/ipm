import { CareersSeoManager } from "@/components/admin/careers-page/CareersSeoManager";

export default function AdminCareersSeoPage() {
  return <CareersSeoManager />;
}
