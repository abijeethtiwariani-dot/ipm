import { CareersOpenPositionsManager } from "@/components/admin/careers-page/CareersOpenPositionsManager";

export default function AdminCareersOpenPositionsPage() {
  return <CareersOpenPositionsManager />;
}
