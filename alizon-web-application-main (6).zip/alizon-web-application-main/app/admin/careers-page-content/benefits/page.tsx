import { CareersBenefitsManager } from "@/components/admin/careers-page/CareersBenefitsManager";

export default function AdminCareersBenefitsPage() {
  return <CareersBenefitsManager />;
}
