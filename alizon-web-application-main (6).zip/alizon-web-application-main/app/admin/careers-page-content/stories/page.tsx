import { CareersStoriesManager } from "@/components/admin/careers-page/CareersStoriesManager";

export default function AdminCareersStoriesPage() {
  return <CareersStoriesManager />;
}
