import { CareersHeroManager } from "@/components/admin/careers-page/CareersHeroManager";

export default function AdminCareersHeroPage() {
  return <CareersHeroManager />;
}
