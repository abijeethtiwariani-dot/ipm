import { AssignmentsManager } from "@/components/admin/AssignmentsManager";

export default function AdminAssignmentsPage() {
  return <AssignmentsManager />;
}
