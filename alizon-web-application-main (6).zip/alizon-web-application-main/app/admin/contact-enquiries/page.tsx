import { ContactEnquiriesManager } from "@/components/admin/ContactEnquiriesManager";

export default function AdminContactEnquiriesPage() {
  return <ContactEnquiriesManager />;
}
