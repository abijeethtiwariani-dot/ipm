import { AdminStudentGrievanceDetailView } from "@/components/admin/AdminStudentGrievanceDetailView";

export default async function AdminStudentGrievanceDetailPage({
  params,
}: {
  params: Promise<{ studentId: string }>;
}) {
  const { studentId } = await params;
  return <AdminStudentGrievanceDetailView studentId={studentId} />;
}
