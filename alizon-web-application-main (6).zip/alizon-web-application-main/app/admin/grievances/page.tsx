import { GrievancesManager } from "@/components/admin/GrievancesManager";

export default function AdminGrievancesPage() {
  return <GrievancesManager />;
}
