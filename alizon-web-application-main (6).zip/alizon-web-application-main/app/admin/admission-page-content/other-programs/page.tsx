import { AdmissionPageOtherProgramsManager } from "@/components/admin/admission-page/AdmissionPageOtherProgramsManager";

export default function AdminAdmissionPageOtherProgramsPage() {
  return <AdmissionPageOtherProgramsManager />;
}
