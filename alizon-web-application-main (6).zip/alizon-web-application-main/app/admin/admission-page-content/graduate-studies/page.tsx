import { AdmissionPageGradManager } from "@/components/admin/admission-page/AdmissionPageGradManager";

export default function AdminAdmissionPageGradPage() {
  return <AdmissionPageGradManager />;
}
