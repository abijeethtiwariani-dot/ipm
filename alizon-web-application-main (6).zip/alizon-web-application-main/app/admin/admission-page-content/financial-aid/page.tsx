import { AdmissionPageFinancialAidManager } from "@/components/admin/admission-page/AdmissionPageFinancialAidManager";

export default function AdminAdmissionPageFinancialAidPage() {
  return <AdmissionPageFinancialAidManager />;
}
