import { AdmissionPageHeroManager } from "@/components/admin/admission-page/AdmissionPageHeroManager";

export default function AdminAdmissionPageHeroPage() {
  return <AdmissionPageHeroManager />;
}
