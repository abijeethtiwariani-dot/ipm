import { AdmissionPageUndergradManager } from "@/components/admin/admission-page/AdmissionPageUndergradManager";

export default function AdminAdmissionPageUndergradPage() {
  return <AdmissionPageUndergradManager />;
}
