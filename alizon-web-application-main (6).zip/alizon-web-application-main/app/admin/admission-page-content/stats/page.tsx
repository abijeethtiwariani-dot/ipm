import { AdmissionPageStatsManager } from "@/components/admin/admission-page/AdmissionPageStatsManager";

export default function AdminAdmissionPageStatsPage() {
  return <AdmissionPageStatsManager />;
}
