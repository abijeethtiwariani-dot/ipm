import { AdmissionPageApplyCtaManager } from "@/components/admin/admission-page/AdmissionPageApplyCtaManager";

export default function AdminAdmissionPageApplyCtaPage() {
  return <AdmissionPageApplyCtaManager />;
}
