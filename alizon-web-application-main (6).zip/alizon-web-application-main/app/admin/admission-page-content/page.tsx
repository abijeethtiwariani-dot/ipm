import { AdmissionPageContentHub } from "@/components/admin/AdmissionPageContentHub";

export default function AdminAdmissionPageContentPage() {
  return <AdmissionPageContentHub />;
}
