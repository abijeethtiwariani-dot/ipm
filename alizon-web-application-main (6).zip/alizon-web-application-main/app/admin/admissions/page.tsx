import { AdmissionsManager } from "@/components/admin/AdmissionsManager";

export default function AdminAdmissionsPage() {
  return <AdmissionsManager />;
}
