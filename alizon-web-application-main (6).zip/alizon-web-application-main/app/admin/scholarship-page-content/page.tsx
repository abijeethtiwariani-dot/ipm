import { ScholarshipPageContentHub } from "@/components/admin/ScholarshipPageContentHub";

export default function AdminScholarshipPageContentPage() {
  return <ScholarshipPageContentHub />;
}
