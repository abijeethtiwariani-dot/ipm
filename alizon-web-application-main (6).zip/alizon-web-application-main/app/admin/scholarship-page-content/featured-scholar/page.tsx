import { ScholarshipPageFeaturedScholarManager } from "@/components/admin/scholarship-page/ScholarshipPageFeaturedScholarManager";

export default function AdminScholarshipPageFeaturedScholarPage() {
  return <ScholarshipPageFeaturedScholarManager />;
}
