import { ScholarshipPageFaqManager } from "@/components/admin/scholarship-page/ScholarshipPageFaqManager";

export default function AdminScholarshipPageFaqPage() {
  return <ScholarshipPageFaqManager />;
}
