import { ScholarshipPageSuccessStoriesManager } from "@/components/admin/scholarship-page/ScholarshipPageSuccessStoriesManager";

export default function AdminScholarshipPageSuccessStoriesPage() {
  return <ScholarshipPageSuccessStoriesManager />;
}
