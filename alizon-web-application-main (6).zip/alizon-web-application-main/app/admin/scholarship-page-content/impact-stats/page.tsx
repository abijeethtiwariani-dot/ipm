import { ScholarshipPageImpactStatsManager } from "@/components/admin/scholarship-page/ScholarshipPageImpactStatsManager";

export default function AdminScholarshipPageImpactStatsPage() {
  return <ScholarshipPageImpactStatsManager />;
}
