import { ScholarshipPageBenefitsManager } from "@/components/admin/scholarship-page/ScholarshipPageBenefitsManager";

export default function AdminScholarshipPageBenefitsPage() {
  return <ScholarshipPageBenefitsManager />;
}
