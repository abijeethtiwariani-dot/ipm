import { ScholarshipPageDetailsManager } from "@/components/admin/scholarship-page/ScholarshipPageDetailsManager";

export default function AdminScholarshipPageDetailsPage() {
  return <ScholarshipPageDetailsManager />;
}
