import { ScholarshipPageOverviewManager } from "@/components/admin/scholarship-page/ScholarshipPageOverviewManager";

export default function AdminScholarshipPageOverviewPage() {
  return <ScholarshipPageOverviewManager />;
}
