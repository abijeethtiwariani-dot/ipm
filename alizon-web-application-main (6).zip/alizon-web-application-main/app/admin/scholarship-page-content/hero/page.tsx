import { ScholarshipPageHeroManager } from "@/components/admin/scholarship-page/ScholarshipPageHeroManager";

export default function AdminScholarshipPageHeroPage() {
  return <ScholarshipPageHeroManager />;
}
