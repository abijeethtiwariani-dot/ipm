import { ResearchLoveWorkingManager } from "@/components/admin/research-page/ResearchLoveWorkingManager";

export default function AdminResearchPageLoveWorkingPage() {
  return <ResearchLoveWorkingManager />;
}
