import { ResearchBenefitsManager } from "@/components/admin/research-page/ResearchBenefitsManager";

export default function AdminResearchPageBenefitsPage() {
  return <ResearchBenefitsManager />;
}
