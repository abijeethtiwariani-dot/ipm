import { ResearchHeroManager } from "@/components/admin/research-page/ResearchHeroManager";

export default function AdminResearchPageHeroPage() {
  return <ResearchHeroManager />;
}
