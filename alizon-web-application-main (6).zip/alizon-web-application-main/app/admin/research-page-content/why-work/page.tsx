import { ResearchWhyWorkManager } from "@/components/admin/research-page/ResearchWhyWorkManager";

export default function AdminResearchPageWhyWorkPage() {
  return <ResearchWhyWorkManager />;
}
