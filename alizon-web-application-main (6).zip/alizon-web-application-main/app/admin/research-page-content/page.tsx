import { ResearchPageContentHub } from "@/components/admin/ResearchPageContentHub";

export default function AdminResearchPageContentPage() {
  return <ResearchPageContentHub />;
}
