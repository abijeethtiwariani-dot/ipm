import { ResearchStoriesManager } from "@/components/admin/research-page/ResearchStoriesManager";

export default function AdminResearchPageStoriesPage() {
  return <ResearchStoriesManager />;
}
