import { ResearchSeoManager } from "@/components/admin/research-page/ResearchSeoManager";

export default function AdminResearchPageSeoPage() {
  return <ResearchSeoManager />;
}
