import { AllotmentForm } from "@/components/admin/AllotmentForm";

export default async function AdminAllotmentEditPage({
  params,
}: {
  params: Promise<{ allotmentId: string }>;
}) {
  const { allotmentId } = await params;
  return <AllotmentForm allotmentId={allotmentId} />;
}
