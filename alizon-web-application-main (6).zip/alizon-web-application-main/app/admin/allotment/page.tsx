import { AllotmentContentHub } from "@/components/admin/AllotmentContentHub";

export default function AdminAllotmentHubPage() {
  return <AllotmentContentHub />;
}
