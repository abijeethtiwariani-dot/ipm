import { AllotmentForm } from "@/components/admin/AllotmentForm";

export default function AdminAllotmentNewPage() {
  return <AllotmentForm />;
}
