import { AllotmentPageHeroManager } from "@/components/admin/allotment-page/AllotmentPageHeroManager";

export default function AdminAllotmentHeroPage() {
  return <AllotmentPageHeroManager />;
}
