import { AllotmentCategoriesManager } from "@/components/admin/AllotmentCategoriesManager";

export default function AdminAllotmentCategoriesPage() {
  return <AllotmentCategoriesManager />;
}
