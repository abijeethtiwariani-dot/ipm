import { AllotmentResultsManager } from "@/components/admin/AllotmentResultsManager";

export default function AdminAllotmentResultsPage() {
  return <AllotmentResultsManager />;
}
