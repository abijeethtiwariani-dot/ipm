import { AllotmentResultForm } from "@/components/admin/AllotmentResultForm";

export default function AdminAllotmentResultNewPage() {
  return <AllotmentResultForm />;
}
