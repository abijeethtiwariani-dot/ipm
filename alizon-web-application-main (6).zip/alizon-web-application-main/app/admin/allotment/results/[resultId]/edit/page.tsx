import { AllotmentResultForm } from "@/components/admin/AllotmentResultForm";

export default async function AdminAllotmentResultEditPage({
  params,
}: {
  params: Promise<{ resultId: string }>;
}) {
  const { resultId } = await params;
  return <AllotmentResultForm resultId={resultId} />;
}
