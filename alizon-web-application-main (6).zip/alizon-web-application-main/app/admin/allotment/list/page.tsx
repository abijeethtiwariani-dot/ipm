import { AllotmentsManager } from "@/components/admin/AllotmentsManager";

export default function AdminAllotmentsListPage() {
  return <AllotmentsManager />;
}
