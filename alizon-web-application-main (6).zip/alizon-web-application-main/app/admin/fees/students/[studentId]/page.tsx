import { StudentFeeDetail } from "@/components/admin/StudentFeeDetail";

export default async function AdminStudentFeeDetailPage({
  params,
}: {
  params: Promise<{ studentId: string }>;
}) {
  const { studentId } = await params;
  return <StudentFeeDetail studentId={studentId} />;
}
