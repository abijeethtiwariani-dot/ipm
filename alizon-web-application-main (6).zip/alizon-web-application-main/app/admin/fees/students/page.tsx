import { FeeStudentsList } from "@/components/admin/FeeStudentsList";

export default function AdminFeeStudentsPage() {
  return <FeeStudentsList />;
}
