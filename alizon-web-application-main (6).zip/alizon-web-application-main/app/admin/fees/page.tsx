import { FeesDashboard } from "@/components/admin/FeesDashboard";

export default function AdminFeesPage() {
  return <FeesDashboard />;
}
