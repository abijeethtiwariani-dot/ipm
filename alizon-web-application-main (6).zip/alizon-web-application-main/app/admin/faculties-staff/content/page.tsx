import { FacultyStaffContentManager } from "@/components/admin/FacultyStaffContentManager";

export default function AdminFacultyContentPage() {
  return <FacultyStaffContentManager />;
}
