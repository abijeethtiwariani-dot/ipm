import { FacultyPageBannerManager } from "@/components/admin/FacultyPageBannerManager";

export default function AdminFacultyBannerPage() {
  return <FacultyPageBannerManager />;
}
