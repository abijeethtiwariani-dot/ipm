import { FacultyStaffHub } from "@/components/admin/FacultyStaffHub";

export default function AdminFacultiesStaffPage() {
  return <FacultyStaffHub />;
}
