import { EvaluationsManager } from "@/components/admin/EvaluationsManager";

export default function AdminEvaluationsPage() {
  return <EvaluationsManager />;
}
