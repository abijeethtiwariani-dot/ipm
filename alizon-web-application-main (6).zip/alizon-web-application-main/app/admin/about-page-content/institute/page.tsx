import { AboutPageInstituteManager } from "@/components/admin/about-page/AboutPageInstituteManager";

export default function AdminAboutPageInstitutePage() {
  return <AboutPageInstituteManager />;
}
