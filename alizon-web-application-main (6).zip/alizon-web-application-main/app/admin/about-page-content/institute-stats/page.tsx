import { AboutPageInstituteStatsManager } from "@/components/admin/about-page/AboutPageInstituteStatsManager";

export default function AdminAboutPageInstituteStatsPage() {
  return <AboutPageInstituteStatsManager />;
}
