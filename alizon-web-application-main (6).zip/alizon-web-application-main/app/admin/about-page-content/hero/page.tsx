import { AboutPageHeroManager } from "@/components/admin/about-page/AboutPageHeroManager";

export default function AdminAboutPageHeroPage() {
  return <AboutPageHeroManager />;
}
