import { AboutPageContentHub } from "@/components/admin/AboutPageContentHub";

export default function AdminAboutPageContentPage() {
  return <AboutPageContentHub />;
}
