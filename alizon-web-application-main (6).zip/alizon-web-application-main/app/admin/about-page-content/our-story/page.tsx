import { AboutPageOurStoryManager } from "@/components/admin/about-page/AboutPageOurStoryManager";

export default function AdminAboutPageOurStoryPage() {
  return <AboutPageOurStoryManager />;
}
