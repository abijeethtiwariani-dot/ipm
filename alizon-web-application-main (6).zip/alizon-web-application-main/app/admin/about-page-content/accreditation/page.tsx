import { AboutPageAccreditationManager } from "@/components/admin/about-page/AboutPageAccreditationManager";

export default function AdminAboutPageAccreditationPage() {
  return <AboutPageAccreditationManager />;
}
