"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
} from "firebase/auth";
import { getFirebaseAuth, isFirebaseConfigured } from "@/lib/firebase";
import { isAdminUser } from "@/lib/admins";
import { setAdminSessionCookie } from "@/lib/admin-session";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { INSTITUTION_DISPLAY_NAME } from "@/lib/site-branding";

export default function AdminLoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [checkingAuth, setCheckingAuth] = useState(true);

  useEffect(() => {
    let active = true;
    let fallbackTimer: ReturnType<typeof setTimeout> | null = null;
    if (!isFirebaseConfigured()) {
      setCheckingAuth(false);
      return;
    }
    try {
      fallbackTimer = setTimeout(() => {
        if (active) setCheckingAuth(false);
      }, 2000);
      const unsubscribe = onAuthStateChanged(getFirebaseAuth(), async (user) => {
        if (!active) return;
        if (!user) {
          setCheckingAuth(false);
          return;
        }
        try {
          const isAdmin = await isAdminUser(user.uid);
          if (!isAdmin) {
            await signOut(getFirebaseAuth());
            if (active) setCheckingAuth(false);
            return;
          }
          router.replace("/admin");
        } catch {
          setCheckingAuth(false);
        }
      });
      return () => {
        active = false;
        if (fallbackTimer) clearTimeout(fallbackTimer);
        unsubscribe();
      };
    } catch {
      setCheckingAuth(false);
      return () => {
        active = false;
        if (fallbackTimer) clearTimeout(fallbackTimer);
      };
    }
  }, [router]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const credential = await signInWithEmailAndPassword(
        getFirebaseAuth(),
        email,
        password,
      );
      const isAdmin = await isAdminUser(credential.user.uid);
      if (!isAdmin) {
        await signOut(getFirebaseAuth());
        setError("You do not have admin access.");
        return;
      }
      await setAdminSessionCookie();
      router.replace("/admin");
    } catch (err) {
      const message =
        err instanceof Error ? err.message : "Invalid email or password";
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  if (checkingAuth) {
    return (
      <section className="min-h-screen flex items-center justify-center p-4">
        <Skeleton className="h-64 w-full max-w-md" />
      </section>
    );
  }

  return (
    <section className="min-h-screen flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-heading text-primary">
            Admin Portal
          </CardTitle>
          <CardDescription>{INSTITUTION_DISPLAY_NAME}</CardDescription>
          <p className="text-sm text-muted-foreground pt-1">
            Sign in to manage site content
          </p>
        </CardHeader>
        <CardContent>
          {!isFirebaseConfigured() && (
            <p className="text-sm text-destructive mb-4" role="alert">
              Firebase is not configured. Copy .env.example to .env.local and add
              your project credentials.
            </p>
          )}
          <form onSubmit={handleSubmit} className="space-y-4">
            <section className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </section>
            <section className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </section>
            {error && (
              <p className="text-sm text-destructive" role="alert">
                {error}
              </p>
            )}
            <Button
              type="submit"
              className="w-full"
              disabled={loading || !isFirebaseConfigured()}
            >
              {loading ? "Signing in..." : "Sign in"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </section>
  );
}
