import { HomePartnersManager } from "@/components/admin/HomePartnersManager";

export default function AdminHomePartnersPage() {
  return <HomePartnersManager />;
}
