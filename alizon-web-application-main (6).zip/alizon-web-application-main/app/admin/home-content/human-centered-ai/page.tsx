import { HomeHumanCenteredAiManager } from "@/components/admin/HomeHumanCenteredAiManager";

export default function AdminHomeHumanCenteredAiPage() {
  return <HomeHumanCenteredAiManager />;
}
