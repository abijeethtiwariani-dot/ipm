import { HomeEventsManager } from "@/components/admin/HomeEventsManager";

export default function AdminHomeEventsPage() {
  return <HomeEventsManager />;
}
