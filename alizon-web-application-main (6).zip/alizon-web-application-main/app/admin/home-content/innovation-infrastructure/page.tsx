import { HomeInnovationInfrastructureManager } from "@/components/admin/HomeInnovationInfrastructureManager";

export default function AdminHomeInnovationInfrastructurePage() {
  return <HomeInnovationInfrastructureManager />;
}
