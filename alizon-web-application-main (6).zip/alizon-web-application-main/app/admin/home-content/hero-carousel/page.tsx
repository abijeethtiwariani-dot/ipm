import { HomeHeroCarouselManager } from "@/components/admin/HomeHeroCarouselManager";

export default function AdminHomeHeroCarouselPage() {
  return <HomeHeroCarouselManager />;
}
