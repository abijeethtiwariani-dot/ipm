import { HomeTestimonialsManager } from "@/components/admin/HomeTestimonialsManager";

export default function AdminHomeTestimonialsPage() {
  return <HomeTestimonialsManager />;
}
