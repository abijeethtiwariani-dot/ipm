import { HomeResearchManager } from "@/components/admin/HomeResearchManager";

export default function AdminHomeResearchPage() {
  return <HomeResearchManager />;
}
