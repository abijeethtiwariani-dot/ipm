import { HomeShapingInnovationManager } from "@/components/admin/HomeShapingInnovationManager";

export default function AdminHomeShapingInnovationPage() {
  return <HomeShapingInnovationManager />;
}
