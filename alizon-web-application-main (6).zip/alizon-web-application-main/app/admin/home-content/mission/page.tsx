import { HomeMissionManager } from "@/components/admin/HomeMissionManager";

export default function AdminHomeMissionPage() {
  return <HomeMissionManager />;
}
