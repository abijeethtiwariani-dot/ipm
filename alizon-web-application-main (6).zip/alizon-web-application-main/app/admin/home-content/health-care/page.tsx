import { HomeHealthCareManager } from "@/components/admin/HomeHealthCareManager";

export default function AdminHomeHealthCarePage() {
  return <HomeHealthCareManager />;
}
