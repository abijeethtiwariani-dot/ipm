import { HomeFeaturedVideoManager } from "@/components/admin/HomeFeaturedVideoManager";

export default function AdminHomeFeaturedVideoPage() {
  return <HomeFeaturedVideoManager />;
}
