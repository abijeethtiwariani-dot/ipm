import { HomeAdmissionManager } from "@/components/admin/HomeAdmissionManager";

export default function AdminHomeAdmissionPage() {
  return <HomeAdmissionManager />;
}
