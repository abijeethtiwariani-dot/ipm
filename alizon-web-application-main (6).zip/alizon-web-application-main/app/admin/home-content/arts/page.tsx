import { HomeArtsManager } from "@/components/admin/HomeArtsManager";

export default function AdminHomeArtsPage() {
  return <HomeArtsManager />;
}
