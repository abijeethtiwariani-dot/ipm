import { HomeAthleticsManager } from "@/components/admin/HomeAthleticsManager";

export default function AdminHomeAthleticsPage() {
  return <HomeAthleticsManager />;
}
