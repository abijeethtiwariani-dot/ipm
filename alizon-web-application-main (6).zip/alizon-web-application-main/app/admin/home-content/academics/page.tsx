import { AcademicsManager } from "@/components/admin/AcademicsManager";

export default function AdminHomeAcademicsPage() {
  return <AcademicsManager />;
}
