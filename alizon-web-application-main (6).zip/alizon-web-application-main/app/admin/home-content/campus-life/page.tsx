import { HomeCampusLifeManager } from "@/components/admin/HomeCampusLifeManager";

export default function AdminHomeCampusLifePage() {
  return <HomeCampusLifeManager />;
}
