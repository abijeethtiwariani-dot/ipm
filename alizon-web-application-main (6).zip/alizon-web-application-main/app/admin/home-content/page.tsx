import { HomeContentHub } from "@/components/admin/HomeContentHub";

export default function AdminHomeContentPage() {
  return <HomeContentHub />;
}
