import { FooterPrivacyPolicyManager } from "@/components/admin/footer/FooterPrivacyPolicyManager";

export default function AdminFooterPrivacyPolicyPage() {
  return <FooterPrivacyPolicyManager />;
}
