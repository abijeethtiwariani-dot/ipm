import { FooterRefundPolicyManager } from "@/components/admin/footer/FooterRefundPolicyManager";

export default function AdminFooterRefundPolicyPage() {
  return <FooterRefundPolicyManager />;
}
