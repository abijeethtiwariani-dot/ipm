import { Suspense } from "react";
import { StudentDetailsView } from "@/components/admin/StudentDetailsView";

export default async function AdminStudentDetailsPage({
  params,
}: {
  params: Promise<{ studentId: string }>;
}) {
  const { studentId } = await params;
  return (
    <Suspense fallback={null}>
      <StudentDetailsView studentId={studentId} />
    </Suspense>
  );
}
