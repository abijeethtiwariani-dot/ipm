import { EditStudentPageView } from "@/components/admin/EditStudentPageView";

export default async function AdminStudentEditPage({
  params,
}: {
  params: Promise<{ studentId: string }>;
}) {
  const { studentId } = await params;
  return <EditStudentPageView studentId={studentId} />;
}
