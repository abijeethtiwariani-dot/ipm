import { AdminStudentProfileEditView } from "@/components/admin/AdminStudentProfileEditView";

export default async function AdminStudentProfileEditPage({
  params,
}: {
  params: Promise<{ studentId: string }>;
}) {
  const { studentId } = await params;
  return <AdminStudentProfileEditView studentId={studentId} />;
}
