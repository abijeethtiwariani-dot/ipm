import { Suspense } from "react";
import { StudentsManager } from "@/components/admin/StudentsManager";

export default function AdminStudentsPage() {
  return (
    <Suspense fallback={null}>
      <StudentsManager />
    </Suspense>
  );
}
