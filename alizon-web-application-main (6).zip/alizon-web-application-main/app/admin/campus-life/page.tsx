import { CampusLifeHub } from "@/components/admin/CampusLifeHub";

export default function AdminCampusLifePage() {
  return <CampusLifeHub />;
}
