import { CampusLifeBannerManager } from "@/components/admin/CampusLifeBannerManager";

export default function AdminCampusLifeBannerPage() {
  return <CampusLifeBannerManager />;
}
