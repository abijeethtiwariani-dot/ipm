import { CampusLifeGettingAroundManager } from "@/components/admin/CampusLifeGettingAroundManager";

export default function AdminCampusLifeGettingAroundPage() {
  return <CampusLifeGettingAroundManager />;
}
