import { CampusLifeManager } from "@/components/admin/CampusLifeManager";

export default function AdminCampusLifeCardsPage() {
  return <CampusLifeManager />;
}
