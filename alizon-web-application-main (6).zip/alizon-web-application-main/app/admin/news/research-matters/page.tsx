import { NewsResearchMattersManager } from "@/components/admin/NewsResearchMattersManager";

export default function AdminNewsResearchMattersPage() {
  return <NewsResearchMattersManager />;
}
