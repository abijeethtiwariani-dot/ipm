import { NewsContentHub } from "@/components/admin/NewsContentHub";

export default function AdminNewsPage() {
  return <NewsContentHub />;
}
