import { NewsCommunityManager } from "@/components/admin/NewsCommunityManager";

export default function AdminNewsCommunityPage() {
  return <NewsCommunityManager />;
}
