import { NewsInTheNewsManager } from "@/components/admin/NewsInTheNewsManager";

export default function AdminNewsInTheNewsPage() {
  return <NewsInTheNewsManager />;
}
