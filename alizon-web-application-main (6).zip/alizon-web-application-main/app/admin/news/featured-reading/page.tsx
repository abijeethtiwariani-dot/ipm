import { NewsFeaturedReadingManager } from "@/components/admin/NewsFeaturedReadingManager";

export default function AdminNewsFeaturedReadingPage() {
  return <NewsFeaturedReadingManager />;
}
