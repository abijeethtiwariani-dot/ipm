import { NewsReportSignupManager } from "@/components/admin/NewsReportSignupManager";

export default function AdminNewsReportSignupPage() {
  return <NewsReportSignupManager />;
}
