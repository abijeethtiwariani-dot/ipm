import { NewsHeroManager } from "@/components/admin/NewsHeroManager";

export default function AdminNewsHeroPage() {
  return <NewsHeroManager />;
}
