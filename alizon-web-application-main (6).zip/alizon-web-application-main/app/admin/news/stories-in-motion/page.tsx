import { NewsStoriesInMotionManager } from "@/components/admin/NewsStoriesInMotionManager";

export default function AdminNewsStoriesInMotionPage() {
  return <NewsStoriesInMotionManager />;
}
