import { NewsFeaturedResearchManager } from "@/components/admin/NewsFeaturedResearchManager";

export default function AdminNewsFeaturedResearchPage() {
  return <NewsFeaturedResearchManager />;
}
