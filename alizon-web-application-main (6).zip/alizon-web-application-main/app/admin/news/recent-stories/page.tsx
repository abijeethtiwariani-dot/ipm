import { NewsRecentStoriesManager } from "@/components/admin/NewsRecentStoriesManager";

export default function AdminNewsRecentStoriesPage() {
  return <NewsRecentStoriesManager />;
}
