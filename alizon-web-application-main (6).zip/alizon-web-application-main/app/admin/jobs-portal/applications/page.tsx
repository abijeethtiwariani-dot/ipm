import { JobApplicationsManager } from "@/components/admin/JobApplicationsManager";

export default function AdminJobApplicationsPage() {
  return <JobApplicationsManager />;
}
