import { JobForm } from "@/components/admin/JobForm";

type Props = { params: Promise<{ jobId: string }> };

export default async function AdminEditJobPage({ params }: Props) {
  const { jobId } = await params;
  return <JobForm jobId={jobId} />;
}
