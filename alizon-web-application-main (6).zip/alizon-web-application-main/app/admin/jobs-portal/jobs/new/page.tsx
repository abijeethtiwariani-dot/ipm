import { JobForm } from "@/components/admin/JobForm";

export default function AdminCreateJobPage() {
  return <JobForm />;
}
