import { JobsManager } from "@/components/admin/JobsManager";

export default function AdminJobsListPage() {
  return <JobsManager />;
}
