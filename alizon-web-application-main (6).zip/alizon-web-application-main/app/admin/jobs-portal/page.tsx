import { JobsPortalHub } from "@/components/admin/JobsPortalHub";

export default function AdminJobsPortalPage() {
  return <JobsPortalHub />;
}
