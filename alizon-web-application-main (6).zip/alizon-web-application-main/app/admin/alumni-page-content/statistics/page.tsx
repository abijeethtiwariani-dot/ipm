import { AlumniStatisticsManager } from "@/components/admin/alumni-page/AlumniStatisticsManager";

export default function AdminAlumniStatisticsPage() {
  return <AlumniStatisticsManager />;
}
