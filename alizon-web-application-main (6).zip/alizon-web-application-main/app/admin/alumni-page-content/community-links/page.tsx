import { AlumniCommunityLinksManager } from "@/components/admin/alumni-page/AlumniCommunityLinksManager";

export default function AdminAlumniCommunityLinksPage() {
  return <AlumniCommunityLinksManager />;
}
