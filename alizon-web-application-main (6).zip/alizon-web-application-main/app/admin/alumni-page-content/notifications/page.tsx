import { AlumniNotificationsManager } from "@/components/admin/alumni-page/AlumniNotificationsManager";

export default function AdminAlumniNotificationsPage() {
  return <AlumniNotificationsManager />;
}
