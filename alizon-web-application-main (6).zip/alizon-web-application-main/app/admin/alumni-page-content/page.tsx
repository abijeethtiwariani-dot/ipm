import { AlumniPageContentHub } from "@/components/admin/AlumniPageContentHub";

export default function AdminAlumniPageContentPage() {
  return <AlumniPageContentHub />;
}
