import { AlumniLeadershipManager } from "@/components/admin/alumni-page/AlumniLeadershipManager";

export default function AdminAlumniLeadershipPage() {
  return <AlumniLeadershipManager />;
}
