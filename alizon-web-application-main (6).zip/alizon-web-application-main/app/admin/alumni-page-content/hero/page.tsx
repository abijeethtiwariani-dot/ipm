import { AlumniPageHeroManager } from "@/components/admin/alumni-page/AlumniPageHeroManager";

export default function AdminAlumniHeroPage() {
  return <AlumniPageHeroManager />;
}
