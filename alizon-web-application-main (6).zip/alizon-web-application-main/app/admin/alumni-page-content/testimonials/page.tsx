import { AlumniTestimonialsManager } from "@/components/admin/alumni-page/AlumniTestimonialsManager";

export default function AdminAlumniTestimonialsPage() {
  return <AlumniTestimonialsManager />;
}
