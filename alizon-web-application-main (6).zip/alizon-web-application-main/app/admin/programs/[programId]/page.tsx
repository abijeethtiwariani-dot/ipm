import { ProgramDetailsView } from "@/components/admin/ProgramDetailsView";

export default async function ProgramDetailsPage({
  params,
}: {
  params: Promise<{ programId: string }>;
}) {
  const { programId } = await params;
  return <ProgramDetailsView programId={programId} />;
}
