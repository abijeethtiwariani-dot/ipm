import { EditProgramPageView } from "@/components/admin/EditProgramPageView";

export default async function EditProgramPage({
  params,
}: {
  params: Promise<{ programId: string }>;
}) {
  const { programId } = await params;
  return <EditProgramPageView programId={programId} />;
}
