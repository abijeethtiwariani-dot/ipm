import { ProgramForm } from "@/components/admin/ProgramForm";

export default function NewProgramPage() {
  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-heading font-bold">Add Program</h1>
      <ProgramForm />
    </div>
  );
}
