import { ContactPageFormManager } from "@/components/admin/contact-page/ContactPageFormManager";

export default function AdminContactPageFormPage() {
  return <ContactPageFormManager />;
}
