import { ContactPageContentHub } from "@/components/admin/ContactPageContentHub";

export default function AdminContactPageContentPage() {
  return <ContactPageContentHub />;
}
