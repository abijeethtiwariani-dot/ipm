import { ContactPageDepartmentsManager } from "@/components/admin/contact-page/ContactPageDepartmentsManager";

export default function AdminContactPageDepartmentsPage() {
  return <ContactPageDepartmentsManager />;
}
