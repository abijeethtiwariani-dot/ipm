import { ContactPageMapManager } from "@/components/admin/contact-page/ContactPageMapManager";

export default function AdminContactPageMapPage() {
  return <ContactPageMapManager />;
}
