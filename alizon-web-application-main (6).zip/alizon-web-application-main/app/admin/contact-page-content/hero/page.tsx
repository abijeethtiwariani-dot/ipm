import { ContactPageHeroManager } from "@/components/admin/contact-page/ContactPageHeroManager";

export default function AdminContactPageHeroPage() {
  return <ContactPageHeroManager />;
}
