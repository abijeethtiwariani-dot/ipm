import { ContactPageInfoCardsManager } from "@/components/admin/contact-page/ContactPageInfoCardsManager";

export default function AdminContactPageInfoCardsPage() {
  return <ContactPageInfoCardsManager />;
}
