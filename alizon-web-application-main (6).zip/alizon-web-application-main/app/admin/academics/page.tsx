import { redirect } from "next/navigation";

export default function AdminAcademicsRedirectPage() {
  redirect("/admin/home-content/academics");
}
