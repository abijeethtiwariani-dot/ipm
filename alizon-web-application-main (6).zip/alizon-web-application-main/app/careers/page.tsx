import Careers from "@/views/Careers";
import { BreadcrumbJsonLd } from "@/components/seo/BreadcrumbJsonLd";
import {
  generateCmsPageMetadata,
  resolveCareersPageSeo,
} from "@/lib/seo/cms-metadata";
import { ROUTES } from "@/lib/site-routes";

export const revalidate = 86400;

export async function generateMetadata() {
  return generateCmsPageMetadata(ROUTES.careers, resolveCareersPageSeo);
}

export default function CareersPage() {
  return (
    <>
      <BreadcrumbJsonLd
        currentPageName="Careers"
        currentPagePath={ROUTES.careers}
      />
      <Careers />
    </>
  );
}
