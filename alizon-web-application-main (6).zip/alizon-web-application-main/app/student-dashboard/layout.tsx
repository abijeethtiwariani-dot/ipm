import { StudentLayoutClient } from "@/components/student/StudentLayoutClient";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Student Portal",
  robots: { index: false, follow: false },
};

export default function StudentDashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <StudentLayoutClient>{children}</StudentLayoutClient>;
}
