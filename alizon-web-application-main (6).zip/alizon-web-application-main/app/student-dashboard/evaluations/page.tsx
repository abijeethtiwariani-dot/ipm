import { StudentEvaluationsView } from "@/components/student/StudentEvaluationsView";

export default function StudentEvaluationsPage() {
  return <StudentEvaluationsView />;
}
