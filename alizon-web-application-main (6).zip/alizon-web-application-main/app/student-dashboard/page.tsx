import { StudentHomeView } from "@/components/student/StudentHomeView";

export default function StudentDashboardPage() {
  return <StudentHomeView />;
}
