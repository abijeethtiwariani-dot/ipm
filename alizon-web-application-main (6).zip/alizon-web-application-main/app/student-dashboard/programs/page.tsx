import { StudentProgramsView } from "@/components/student/StudentProgramsView";

export default function StudentProgramsPage() {
  return <StudentProgramsView />;
}
