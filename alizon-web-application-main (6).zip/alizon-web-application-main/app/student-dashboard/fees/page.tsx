import { StudentFeesView } from "@/components/student/StudentFeesView";

export default function StudentFeesPage() {
  return <StudentFeesView />;
}
