import { StudentFeeHistoryView } from "@/components/student/StudentFeeHistoryView";

export default function StudentFeeHistoryPage() {
  return <StudentFeeHistoryView />;
}
