import { StudentModuleDetailView } from "@/components/student/StudentModuleDetailView";

export default async function StudentModuleDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ moduleId: string }>;
  searchParams: Promise<{ programId?: string }>;
}) {
  const { moduleId } = await params;
  const { programId } = await searchParams;
  return <StudentModuleDetailView moduleId={moduleId} programId={programId ?? ""} />;
}
