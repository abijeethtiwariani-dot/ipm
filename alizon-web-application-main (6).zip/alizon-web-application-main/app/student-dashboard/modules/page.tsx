import { StudentModulesView } from "@/components/student/StudentModulesView";

export default function StudentModulesPage() {
  return <StudentModulesView />;
}
