import Contact from "@/views/Contact";
import { BreadcrumbJsonLd } from "@/components/seo/BreadcrumbJsonLd";
import {
  generateCmsPageMetadata,
  resolveContactPageSeo,
} from "@/lib/seo/cms-metadata";
import { ROUTES } from "@/lib/site-routes";

export const revalidate = 86400;

export async function generateMetadata() {
  return generateCmsPageMetadata(ROUTES.contact, resolveContactPageSeo);
}

export default function ContactPage() {
  return (
    <>
      <BreadcrumbJsonLd
        currentPageName="Contact"
        currentPagePath={ROUTES.contact}
      />
      <Contact />
    </>
  );
}
