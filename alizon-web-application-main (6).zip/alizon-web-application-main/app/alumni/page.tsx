import Alumni from "@/views/Alumni";
import { BreadcrumbJsonLd } from "@/components/seo/BreadcrumbJsonLd";
import {
  generateCmsPageMetadata,
  resolveAlumniPageSeo,
} from "@/lib/seo/cms-metadata";
import { ROUTES } from "@/lib/site-routes";

export const revalidate = 86400;

export async function generateMetadata() {
  return generateCmsPageMetadata(ROUTES.alumni, resolveAlumniPageSeo);
}

export default function AlumniPage() {
  return (
    <>
      <BreadcrumbJsonLd currentPageName="Alumni" currentPagePath={ROUTES.alumni} />
      <Alumni />
    </>
  );
}
