import Link from "next/link";

export default function NotFound() {
  return (
    <section className="container mx-auto flex min-h-[50vh] items-center justify-center px-4 py-24">
      <div className="text-center">
        <h1 className="mb-4 text-4xl font-heading font-bold text-foreground">404</h1>
        <p className="mb-4 text-xl text-muted-foreground">Oops! Page not found</p>
        <Link href="/" className="text-primary underline hover:text-primary/90">
          Return to Home
        </Link>
      </div>
    </section>
  );
}
