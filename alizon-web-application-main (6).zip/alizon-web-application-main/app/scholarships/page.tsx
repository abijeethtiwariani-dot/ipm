import Scholarships from "@/views/Scholarships";
import { BreadcrumbJsonLd } from "@/components/seo/BreadcrumbJsonLd";
import { FaqJsonLd } from "@/components/seo/FaqJsonLd";
import {
  fetchScholarshipFaqsForSchema,
  generateCmsPageMetadata,
  resolveScholarshipsPageSeo,
} from "@/lib/seo/cms-metadata";
import { ROUTES } from "@/lib/site-routes";

export const revalidate = 86400;

export async function generateMetadata() {
  return generateCmsPageMetadata(
    ROUTES.scholarships,
    resolveScholarshipsPageSeo,
  );
}

export default async function ScholarshipsPage() {
  const faqs = await fetchScholarshipFaqsForSchema();

  return (
    <>
      <BreadcrumbJsonLd
        currentPageName="Scholarships"
        currentPagePath={ROUTES.scholarships}
      />
      <FaqJsonLd faqs={faqs} />
      <Scholarships />
    </>
  );
}
