"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import {
  fetchHomeMissionContentAdmin,
  saveHomeMissionContentAdmin,
} from "@/lib/admin-cms-api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { HomeSectionPublishToggle } from "@/components/admin/HomeSectionPublishToggle";

const formSchema = z.object({
  sectionHeading: z.string().min(1, "Section heading is required"),
  sectionIntro: z.string().min(1, "Section intro is required"),
  buttonText: z.string().min(1, "Button text is required"),
  buttonLink: z.string().min(1, "Button link is required"),
});

type FormValues = z.infer<typeof formSchema>;

export function HomeMissionManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      sectionHeading: "",
      sectionIntro: "",
      buttonText: "",
      buttonLink: "/about",
    },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchHomeMissionContentAdmin();
      form.reset({
        sectionHeading: data.sectionHeading,
        sectionIntro: data.sectionIntro,
        buttonText: data.buttonText,
        buttonLink: data.buttonLink,
      });
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load mission content",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    void loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    try {
      await saveHomeMissionContentAdmin({
        sectionHeading: values.sectionHeading.trim(),
        sectionIntro: values.sectionIntro.trim(),
        buttonText: values.buttonText.trim(),
        buttonLink: values.buttonLink.trim(),
      });
      toast.success("Mission section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save mission section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-2xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-24 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-2xl">
      <Button variant="ghost" size="sm" className="mb-4 -ml-2" asChild>
        <Link href="/admin/home-content">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Home page content
        </Link>
      </Button>

      <HomeSectionPublishToggle sectionKey="mission" />

      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Mission Section
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Copy and CTA shown below the homepage hero carousel (“A Mission Defined
          by Possibility” block).
        </p>
      </header>

      <form
        onSubmit={form.handleSubmit(onSubmit)}
        className="space-y-6 bg-card rounded-lg border border-border shadow-sm p-6 md:p-8"
      >
        <div className="space-y-2">
          <Label htmlFor="sectionHeading">Section heading</Label>
          <Input id="sectionHeading" {...form.register("sectionHeading")} />
          {form.formState.errors.sectionHeading ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.sectionHeading.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="sectionIntro">Section intro</Label>
          <Textarea
            id="sectionIntro"
            rows={6}
            {...form.register("sectionIntro")}
          />
          {form.formState.errors.sectionIntro ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.sectionIntro.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="buttonText">Button text</Label>
          <Input id="buttonText" {...form.register("buttonText")} />
          {form.formState.errors.buttonText ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.buttonText.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="buttonLink">Button link</Label>
          <Input
            id="buttonLink"
            placeholder="/about"
            {...form.register("buttonLink")}
          />
          {form.formState.errors.buttonLink ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.buttonLink.message}
            </p>
          ) : null}
        </div>

        <Button type="submit" disabled={saving}>
          {saving ? "Saving..." : "Save section"}
        </Button>
      </form>
    </section>
  );
}
