"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { onAuthStateChanged, signOut, type User } from "firebase/auth";
import { getFirebaseAuth, isFirebaseConfigured } from "@/lib/firebase";
import { isAdminUser } from "@/lib/admins";
import { Skeleton } from "@/components/ui/skeleton";

interface AuthGuardProps {
  children: React.ReactNode;
}

export function AuthGuard({ children }: AuthGuardProps) {
  const router = useRouter();
  const [user, setUser] = useState<User | null | undefined>(undefined);

  useEffect(() => {
    if (!isFirebaseConfigured()) {
      router.replace("/admin/login");
      setUser(null);
      return;
    }
    const unsubscribe = onAuthStateChanged(getFirebaseAuth(), async (firebaseUser) => {
      if (!firebaseUser) {
        setUser(null);
        router.replace("/admin/login");
        return;
      }
      const isAdmin = await isAdminUser(firebaseUser.uid);
      if (!isAdmin) {
        await signOut(getFirebaseAuth());
        setUser(null);
        router.replace("/admin/login");
        return;
      }
      setUser(firebaseUser);
    });
    return () => unsubscribe();
  }, [router]);

  if (user === undefined) {
    return (
      <div className="min-h-screen bg-muted/40 p-8">
        <Skeleton className="h-10 w-48 mb-6" />
        <Skeleton className="h-64 w-full max-w-4xl" />
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return <>{children}</>;
}
