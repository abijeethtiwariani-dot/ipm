"use client";

import Link from "next/link";
import {
  Award,
  BarChart3,
  BookOpen,
  ChevronRight,
  HelpCircle,
  Layers,
  Sparkles,
  Star,
  Users,
} from "lucide-react";
import { Card } from "@/components/ui/card";

const sections = [
  {
    title: "Hero Banner",
    description: "Page banner title, subtitle, and hero images.",
    href: "/admin/scholarship-page-content/hero",
    icon: Sparkles,
  },
  {
    title: "Overview",
    description: "Eyebrow, heading, intro, description, and section image.",
    href: "/admin/scholarship-page-content/overview",
    icon: BookOpen,
  },
  {
    title: "Featured Scholar Spotlight",
    description: "Spotlight scholar profile, testimonial, and person photo.",
    href: "/admin/scholarship-page-content/featured-scholar",
    icon: Star,
  },
  {
    title: "Scholarship Details",
    description: "Detail blocks for eligibility, benefits, process, and more.",
    href: "/admin/scholarship-page-content/details",
    icon: Layers,
  },
  {
    title: "Success Stories",
    description: "Carousel story cards with short and full testimonials.",
    href: "/admin/scholarship-page-content/success-stories",
    icon: Users,
  },
  {
    title: "Benefits",
    description: "Benefit icon cards grid below success stories.",
    href: "/admin/scholarship-page-content/benefits",
    icon: Award,
  },
  {
    title: "Impact Stats",
    description: "Animated statistics section with counters.",
    href: "/admin/scholarship-page-content/impact-stats",
    icon: BarChart3,
  },
  {
    title: "FAQ",
    description: "Frequently asked questions accordion items.",
    href: "/admin/scholarship-page-content/faq",
    icon: HelpCircle,
  },
];

export function ScholarshipPageContentHub() {
  return (
    <section>
      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Scholarship page content
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Manage sections on the public{" "}
          <code className="text-xs">/scholarships</code> page. The site uses
          sensible defaults until you save content here.
        </p>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 max-w-5xl">
        {sections.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href}>
              <Card className="p-6 h-full border border-border shadow-sm hover:shadow-md transition-shadow card-hover">
                <div className="flex items-start justify-between gap-4">
                  <div className="w-11 h-11 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-1" />
                </div>
                <h2 className="text-lg font-heading font-semibold text-foreground mt-4">
                  {item.title}
                </h2>
                <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                  {item.description}
                </p>
              </Card>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
