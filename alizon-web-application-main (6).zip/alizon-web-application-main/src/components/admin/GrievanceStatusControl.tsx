"use client";

import { useState } from "react";
import { CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { apiUpdateGrievanceStatus } from "@/lib/admin-grievances-api";
import { timestampToLocaleDateString } from "@/lib/firestore-timestamp";
import {
  GRIEVANCE_ADMIN_STATUSES,
  normalizeAdminStatus,
  statusBadgeVariant,
} from "@/lib/grievance-status";
import type { Grievance, GrievanceAdminStatus } from "@/types/grievance";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type GrievanceTarget = "assignment" | "viva" | "internship" | "elective";

export function GrievanceStatusBadge({ grievance }: { grievance: Grievance }) {
  const status = normalizeAdminStatus(grievance.adminStatus);
  return <Badge variant={statusBadgeVariant(status)}>{status}</Badge>;
}

export function GrievanceStatusControl({
  studentId,
  target,
  assignmentId,
  grievance,
  onUpdated,
}: {
  studentId: string;
  target: GrievanceTarget;
  assignmentId?: string;
  grievance: Grievance;
  onUpdated: () => void;
}) {
  const [saving, setSaving] = useState(false);
  const status = normalizeAdminStatus(grievance.adminStatus);

  const handleStatusChange = async (value: GrievanceAdminStatus) => {
    if (value === status) return;
    setSaving(true);
    try {
      await apiUpdateGrievanceStatus(studentId, {
        target,
        assignmentId,
        adminStatus: value,
      });
      toast.success("Status updated");
      onUpdated();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to update status",
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="rounded-md border bg-background p-4 space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Label className="text-sm font-medium">Admin status</Label>
          <GrievanceStatusBadge grievance={grievance} />
        </div>
        {status === "Resolved" && (
          <span className="flex items-center gap-1 text-sm text-success">
            <CheckCircle2 className="h-4 w-4" />
            Resolved
          </span>
        )}
      </div>

      <Select
        value={status}
        onValueChange={(v) => handleStatusChange(v as GrievanceAdminStatus)}
        disabled={saving}
      >
        <SelectTrigger className="w-full max-w-xs">
          <SelectValue placeholder="Select status" />
        </SelectTrigger>
        <SelectContent>
          {GRIEVANCE_ADMIN_STATUSES.map((s) => (
            <SelectItem key={s} value={s}>
              {s}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {status === "Resolved" ? (
        <p className="text-xs text-muted-foreground">
          Resolved on{" "}
          {timestampToLocaleDateString(grievance.resolvedAt) || "—"}
        </p>
      ) : grievance.statusUpdatedAt ? (
        <p className="text-xs text-muted-foreground">
          Last updated{" "}
          {timestampToLocaleDateString(grievance.statusUpdatedAt) || "—"}
        </p>
      ) : null}
    </div>
  );
}
