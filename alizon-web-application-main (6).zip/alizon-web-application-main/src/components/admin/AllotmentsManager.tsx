"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { format, parseISO } from "date-fns";
import {
  ArrowLeft,
  Download,
  ExternalLink,
  HardDrive,
  Pencil,
  Plus,
  Search,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import {
  apiBulkDeleteAllotments,
  apiBulkUpdateAllotmentStatus,
  apiDeleteAllotment,
  apiFetchAdminAllotments,
  apiFetchAllotmentCategories,
  getAllotmentExportUrl,
} from "@/lib/admin-allotment-api";
import type { Allotment, AllotmentCategory, AllotmentSortOption, AllotmentStatus } from "@/types/allotment";
import { ALLOTMENT_STATUSES } from "@/types/allotment";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import { AllotmentStatusBadge } from "@/components/allotment/AllotmentStatusBadge";
import { ROUTES } from "@/lib/site-routes";

function formatDate(value: string): string {
  if (!value) return "—";
  try {
    return format(parseISO(value), "MMM d, yyyy");
  } catch {
    return value;
  }
}

export function AllotmentsManager() {
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<Allotment[]>([]);
  const [categories, setCategories] = useState<AllotmentCategory[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(10);
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sort, setSort] = useState<AllotmentSortOption>("latest");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [deleteTarget, setDeleteTarget] = useState<Allotment | null>(null);
  const [bulkDeleting, setBulkDeleting] = useState(false);
  const [bulkStatus, setBulkStatus] = useState<AllotmentStatus | "">("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [list, cats] = await Promise.all([
        apiFetchAdminAllotments({
          search: search || undefined,
          categoryId: categoryFilter,
          status: statusFilter,
          sort,
          page,
          pageSize,
        }),
        apiFetchAllotmentCategories(),
      ]);
      setItems(list.items);
      setTotal(list.total);
      setCategories(cats);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to load allotments.");
    } finally {
      setLoading(false);
    }
  }, [categoryFilter, page, pageSize, search, sort, statusFilter]);

  useEffect(() => {
    void load();
  }, [load]);

  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const allSelected = items.length > 0 && items.every((i) => selected.has(i.id));

  const toggleSelectAll = () => {
    if (allSelected) {
      setSelected(new Set());
    } else {
      setSelected(new Set(items.map((i) => i.id)));
    }
  };

  const toggleRow = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const onDelete = async () => {
    if (!deleteTarget) return;
    try {
      await apiDeleteAllotment(deleteTarget.id);
      toast.success("Allotment deleted.");
      setDeleteTarget(null);
      await load();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Delete failed.");
    }
  };

  const onBulkDelete = async () => {
    const ids = [...selected];
    if (ids.length === 0) return;
    setBulkDeleting(true);
    try {
      await apiBulkDeleteAllotments(ids);
      toast.success(`Deleted ${ids.length} allotment(s).`);
      setSelected(new Set());
      await load();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Bulk delete failed.");
    } finally {
      setBulkDeleting(false);
    }
  };

  const onBulkStatus = async () => {
    const ids = [...selected];
    if (ids.length === 0 || !bulkStatus) return;
    try {
      await apiBulkUpdateAllotmentStatus(ids, bulkStatus);
      toast.success(`Updated status for ${ids.length} allotment(s).`);
      setSelected(new Set());
      setBulkStatus("");
      await load();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Bulk update failed.");
    }
  };

  const exportParams = useMemo(
    () => ({
      search: search || undefined,
      categoryId: categoryFilter !== "all" ? categoryFilter : undefined,
      status: statusFilter !== "all" ? statusFilter : undefined,
      sort,
    }),
    [categoryFilter, search, sort, statusFilter],
  );

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <Button variant="ghost" size="sm" asChild className="mb-2 -ml-2">
            <Link href="/admin/allotment">
              <ArrowLeft className="mr-1 h-4 w-4" />
              Allotment
            </Link>
          </Button>
          <h1 className="text-3xl font-heading font-bold">All allotments</h1>
          <p className="text-sm text-muted-foreground">
            Manage published allotment notices and documents.
          </p>
        </div>
        <Button asChild>
          <Link href="/admin/allotment/new">
            <Plus className="mr-2 h-4 w-4" />
            Create allotment
          </Link>
        </Button>
      </div>

      <div className="flex flex-col gap-3 rounded-2xl border p-4 md:flex-row md:flex-wrap">
        <div className="relative min-w-[200px] flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            className="pl-9"
            placeholder="Search allotments…"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
          />
        </div>
        <Select
          value={categoryFilter}
          onValueChange={(v) => {
            setCategoryFilter(v);
            setPage(1);
          }}
        >
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Category" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All categories</SelectItem>
            {categories.map((c) => (
              <SelectItem key={c.id} value={c.id}>
                {c.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select
          value={statusFilter}
          onValueChange={(v) => {
            setStatusFilter(v);
            setPage(1);
          }}
        >
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            {ALLOTMENT_STATUSES.map((s) => (
              <SelectItem key={s} value={s}>
                {s}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={sort} onValueChange={(v) => setSort(v as AllotmentSortOption)}>
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="Sort" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="latest">Latest first</SelectItem>
            <SelectItem value="oldest">Oldest first</SelectItem>
            <SelectItem value="az">A–Z</SelectItem>
            <SelectItem value="za">Z–A</SelectItem>
          </SelectContent>
        </Select>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" asChild>
            <a href={getAllotmentExportUrl({ format: "csv", ...exportParams })} download>
              <Download className="mr-2 h-4 w-4" />
              CSV
            </a>
          </Button>
          <Button variant="outline" size="sm" asChild>
            <a href={getAllotmentExportUrl({ format: "xlsx", ...exportParams })} download>
              <Download className="mr-2 h-4 w-4" />
              Excel
            </a>
          </Button>
        </div>
      </div>

      {selected.size > 0 && (
        <div className="flex flex-wrap items-center gap-3 rounded-lg border bg-muted/30 px-3 py-2">
          <span className="text-sm">{selected.size} selected</span>
          <Select value={bulkStatus} onValueChange={(v) => setBulkStatus(v as AllotmentStatus)}>
            <SelectTrigger className="w-[140px] h-8">
              <SelectValue placeholder="Set status" />
            </SelectTrigger>
            <SelectContent>
              {ALLOTMENT_STATUSES.map((s) => (
                <SelectItem key={s} value={s}>
                  {s}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button size="sm" variant="secondary" onClick={() => void onBulkStatus()} disabled={!bulkStatus}>
            Apply status
          </Button>
          <Button
            size="sm"
            variant="destructive"
            onClick={() => void onBulkDelete()}
            disabled={bulkDeleting}
          >
            Delete selected
          </Button>
        </div>
      )}

      {loading ? (
        <Skeleton className="h-64 w-full" />
      ) : (
        <div className="overflow-x-auto rounded-2xl border">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="w-10">
                  <Checkbox checked={allSelected} onCheckedChange={toggleSelectAll} aria-label="Select all" />
                </TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Publish</TableHead>
                <TableHead>Updated</TableHead>
                <TableHead>Created by</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center text-muted-foreground">
                    No allotments found.
                  </TableCell>
                </TableRow>
              ) : (
                items.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>
                      <Checkbox
                        checked={selected.has(item.id)}
                        onCheckedChange={() => toggleRow(item.id)}
                        aria-label={`Select ${item.title}`}
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2 font-medium">
                        {item.title}
                        {item.googleDriveUrl && (
                          <HardDrive className="h-3.5 w-3.5 text-primary" aria-label="Has Google Drive link" />
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{item.categoryName ?? "—"}</TableCell>
                    <TableCell>
                      <AllotmentStatusBadge status={item.status} />
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {formatDate(item.publishDate)}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {formatDate(item.updatedDate)}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">{item.createdBy || "—"}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="icon" asChild>
                        <a
                          href={`${ROUTES.allotment}/${item.slug}`}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <ExternalLink className="h-4 w-4" />
                        </a>
                      </Button>
                      <Button variant="ghost" size="icon" asChild>
                        <Link href={`/admin/allotment/${item.id}/edit`}>
                          <Pencil className="h-4 w-4" />
                        </Link>
                      </Button>
                      <Button variant="ghost" size="icon" onClick={() => setDeleteTarget(item)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      )}

      {totalPages > 1 && (
        <Pagination>
          <PaginationContent>
            <PaginationItem>
              <PaginationPrevious
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  setPage((p) => Math.max(1, p - 1));
                }}
              />
            </PaginationItem>
            {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => i + 1).map((p) => (
              <PaginationItem key={p}>
                <PaginationLink
                  href="#"
                  isActive={p === page}
                  onClick={(e) => {
                    e.preventDefault();
                    setPage(p);
                  }}
                >
                  {p}
                </PaginationLink>
              </PaginationItem>
            ))}
            <PaginationItem>
              <PaginationNext
                href="#"
                onClick={(e) => {
                  e.preventDefault();
                  setPage((p) => Math.min(totalPages, p + 1));
                }}
              />
            </PaginationItem>
          </PaginationContent>
        </Pagination>
      )}

      <AlertDialog open={Boolean(deleteTarget)} onOpenChange={() => setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete allotment?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the allotment and all uploaded files permanently.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => void onDelete()}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
