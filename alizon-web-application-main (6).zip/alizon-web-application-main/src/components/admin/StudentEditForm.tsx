"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { apiUpdateStudentProfile } from "@/lib/admin-students-api";
import { apiFetchStudentFeeDetail } from "@/lib/admin-fees-api";
import { fetchAllCourses } from "@/lib/courses";
import { fetchAllPrograms } from "@/lib/programs";
import { resolveStudentProgramId } from "@/lib/program-student-count";
import type { PaymentStatus } from "@/types/fees";
import type { Student } from "@/types/student";
import { PaymentStatusBadge } from "@/components/fees/PaymentStatusBadge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export const studentEditSchema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  phone: z.string().min(10),
  course: z.string(),
  scholarshipPercentage: z.coerce.number().min(0).max(100),
  feeNotes: z.string().optional(),
});

export type StudentEditFormValues = z.infer<typeof studentEditSchema>;

type StudentEditFormProps = {
  student: Student;
  onSuccess?: () => void;
  redirectTo?: string;
  showCancel?: boolean;
  cancelHref?: string;
};

export function StudentEditForm({
  student,
  onSuccess,
  redirectTo,
  showCancel = false,
  cancelHref,
}: StudentEditFormProps) {
  const router = useRouter();
  const [courses, setCourses] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus | null>(null);

  const form = useForm<StudentEditFormValues>({
    resolver: zodResolver(studentEditSchema),
    defaultValues: {
      name: student.name,
      email: student.email,
      phone: student.phone,
      course: student.course,
      scholarshipPercentage: student.scholarshipPercentage ?? 0,
      feeNotes: student.feeNotes ?? "",
    },
  });

  useEffect(() => {
    form.reset({
      name: student.name,
      email: student.email,
      phone: student.phone,
      course: student.course,
      scholarshipPercentage: student.scholarshipPercentage ?? 0,
      feeNotes: student.feeNotes ?? "",
    });
  }, [student, form]);

  useEffect(() => {
    void fetchAllCourses().then((list) => setCourses(list.map((c) => c.name)));
  }, []);

  useEffect(() => {
    void apiFetchStudentFeeDetail(student.uid)
      .then(({ summary }) => setPaymentStatus(summary.paymentStatus))
      .catch(() => setPaymentStatus("Pending"));
  }, [student.uid]);

  const handleSubmit = async (values: StudentEditFormValues) => {
    setSaving(true);
    try {
      const programs = await fetchAllPrograms();
      const programId = resolveStudentProgramId(
        { course: values.course },
        programs,
      );
      await apiUpdateStudentProfile(student.uid, {
        ...values,
        programId,
      });
      toast.success("Student updated");
      onSuccess?.();
      if (redirectTo) {
        router.push(redirectTo);
      }
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to update student",
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
      <div className="space-y-2">
        <Label>Name</Label>
        <Input {...form.register("name")} />
      </div>
      <div className="space-y-2">
        <Label>Email</Label>
        <Input type="email" {...form.register("email")} />
      </div>
      <div className="space-y-2">
        <Label>Phone</Label>
        <Input {...form.register("phone")} />
      </div>
      <div className="space-y-2">
        <Label>Course</Label>
        <Select
          value={form.watch("course") || "none"}
          onValueChange={(v) => form.setValue("course", v === "none" ? "" : v)}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">Not assigned</SelectItem>
            {courses.map((c) => (
              <SelectItem key={c} value={c}>
                {c}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <Label>Scholarship Percentage</Label>
        <Input
          type="number"
          min={0}
          max={100}
          {...form.register("scholarshipPercentage")}
        />
      </div>
      <div className="space-y-2">
        <Label>Payment Status</Label>
        <div>
          {paymentStatus ? (
            <PaymentStatusBadge status={paymentStatus} />
          ) : (
            <span className="text-sm text-muted-foreground">Loading...</span>
          )}
        </div>
      </div>
      <div className="space-y-2">
        <Label>Fee Notes</Label>
        <Textarea rows={3} {...form.register("feeNotes")} />
      </div>
      <div className="flex gap-2">
        <Button type="submit" disabled={saving}>
          {saving ? "Saving..." : "Save"}
        </Button>
        {showCancel && cancelHref ? (
          <Button type="button" variant="outline" asChild>
            <a href={cancelHref}>Cancel</a>
          </Button>
        ) : null}
      </div>
    </form>
  );
}
