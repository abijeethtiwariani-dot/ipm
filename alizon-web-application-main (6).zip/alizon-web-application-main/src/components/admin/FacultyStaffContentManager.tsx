"use client";

import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FacultyMembersTab } from "@/components/admin/faculty/FacultyMembersTab";
import { FacultyLeadersTab } from "@/components/admin/faculty/FacultyLeadersTab";
import { FacultyPageExtrasTab } from "@/components/admin/faculty/FacultyPageExtrasTab";

export function FacultyStaffContentManager() {
  return (
    <section>
      <Button variant="ghost" size="sm" className="mb-4 -ml-2" asChild>
        <Link href="/admin/faculties-staff">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Faculties & Staff page
        </Link>
      </Button>

      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Faculties information
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Manage faculty directory, leadership, and supporting page sections.
        </p>
      </header>

      <Tabs defaultValue="members" className="w-full">
        <TabsList className="mb-6 flex flex-wrap h-auto gap-1">
          <TabsTrigger value="members">Faculty members</TabsTrigger>
          <TabsTrigger value="leadership">Academic leadership</TabsTrigger>
          <TabsTrigger value="sections">Page sections</TabsTrigger>
        </TabsList>
        <TabsContent value="members">
          <FacultyMembersTab />
        </TabsContent>
        <TabsContent value="leadership">
          <FacultyLeadersTab />
        </TabsContent>
        <TabsContent value="sections">
          <FacultyPageExtrasTab />
        </TabsContent>
      </Tabs>
    </section>
  );
}
