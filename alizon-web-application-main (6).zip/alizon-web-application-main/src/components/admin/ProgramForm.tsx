"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { slugifyProgramName } from "@/lib/programs";
import { apiCreateProgram, apiUpdateProgram } from "@/lib/admin-programs-api";
import type { Program } from "@/types/program";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ImageUploadField } from "@/components/shared/ImageUploadField";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const schema = z.object({
  name: z.string().min(3),
  slug: z.string().min(2),
  shortDescription: z.string().min(6),
  fullDescription: z.string().min(12),
  duration: z.string().min(1),
  category: z.string().min(1),
  status: z.enum(["active", "inactive"]),
  totalCourseFee: z.coerce.number().min(0),
  seoTitle: z.string().optional(),
  seoDescription: z.string().optional(),
  seoKeywords: z.string().optional(),
});

type Values = z.infer<typeof schema>;

export function ProgramForm({ program }: { program?: Program | null }) {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [thumbnail, setThumbnail] = useState(program?.thumbnail ?? null);
  const [banner, setBanner] = useState(program?.banner ?? null);

  const form = useForm<Values>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: program?.name ?? "",
      slug: program?.slug ?? "",
      shortDescription: program?.shortDescription ?? "",
      fullDescription: program?.fullDescription ?? "",
      duration: program?.duration ?? "",
      category: program?.category ?? "",
      status: program?.status ?? "active",
      totalCourseFee: program?.totalCourseFee ?? 0,
      seoTitle: program?.seoTitle ?? "",
      seoDescription: program?.seoDescription ?? "",
      seoKeywords: program?.seoKeywords ?? "",
    },
  });

  useEffect(() => {
    if (!program) return;
    form.reset({
      name: program.name ?? "",
      slug: program.slug ?? "",
      shortDescription: program.shortDescription ?? "",
      fullDescription: program.fullDescription ?? "",
      duration: program.duration ?? "",
      category: program.category ?? "",
      status: program.status ?? "active",
      totalCourseFee: program.totalCourseFee ?? 0,
      seoTitle: program.seoTitle ?? "",
      seoDescription: program.seoDescription ?? "",
      seoKeywords: program.seoKeywords ?? "",
    });
    setThumbnail(program.thumbnail ?? null);
    setBanner(program.banner ?? null);
  }, [form, program]);

  const name = form.watch("name");
  useEffect(() => {
    if (!program) {
      form.setValue("slug", slugifyProgramName(name));
    }
  }, [form, name, program]);

  const submit = form.handleSubmit(async (values) => {
    setSaving(true);
    try {
      if (program) {
        await apiUpdateProgram(program.id, { ...values, thumbnail, banner });
      } else {
        const id = await apiCreateProgram({ ...values, thumbnail, banner });
        router.replace(`/admin/programs/${id}`);
        return;
      }
      toast.success("Program saved.");
      router.replace(`/admin/programs/${program.id}`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Save failed.");
    } finally {
      setSaving(false);
    }
  });

  return (
    <Card>
      <CardContent className="p-6">
        <form onSubmit={submit} className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Program Name</Label>
              <Input {...form.register("name")} />
            </div>
            <div className="space-y-2">
              <Label>Slug</Label>
              <Input {...form.register("slug")} />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Short Description</Label>
            <Textarea rows={2} {...form.register("shortDescription")} />
          </div>
          <div className="space-y-2">
            <Label>Full Description</Label>
            <Textarea rows={5} {...form.register("fullDescription")} />
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <Label>Duration</Label>
              <Input {...form.register("duration")} />
            </div>
            <div className="space-y-2">
              <Label>Category</Label>
              <Input {...form.register("category")} />
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select
                value={form.watch("status")}
                onValueChange={(value) => form.setValue("status", value as Values["status"])}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Total Course Fee (₹)</Label>
              <Input type="number" min={0} step={1} {...form.register("totalCourseFee")} />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <ImageUploadField
              label="Program Thumbnail"
              folder="programs/thumbnail"
              value={thumbnail}
              onChange={setThumbnail}
            />
            <ImageUploadField
              label="Program Banner"
              folder="programs/banner"
              value={banner}
              onChange={setBanner}
            />
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <Label>SEO Title</Label>
              <Input {...form.register("seoTitle")} />
            </div>
            <div className="space-y-2">
              <Label>SEO Description</Label>
              <Input {...form.register("seoDescription")} />
            </div>
            <div className="space-y-2">
              <Label>SEO Keywords</Label>
              <Input {...form.register("seoKeywords")} />
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={() => router.back()}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
