"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format, parseISO } from "date-fns";
import {
  ArrowLeft,
  CalendarIcon,
  Clock,
  Pencil,
  Plus,
  Star,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import type { HomeEventCard, HomeEventsSectionContent } from "@/types/cms";
import {
  HOME_EVENT_CARD_ORDERS,
  getHomeEventCardOrderLabel,
} from "@/types/cms";
import {
  createHomeEventCard,
  deleteHomeEventCard,
  fetchHomeEventCards,
  fetchHomeEventsContent,
  saveHomeEventsContent,
  updateHomeEventCard,
  validateFeaturedHomeEventsLimit,
  validateHomeEventCardOrder,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { HomeSectionPublishToggle } from "@/components/admin/HomeSectionPublishToggle";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { cn } from "@/lib/utils";

const sectionFormSchema = z.object({
  sectionHeading: z.string().min(1, "Section heading is required"),
  buttonText: z.string().min(1, "Button text is required"),
  buttonLink: z.string().min(1, "Button link is required"),
});

const cardFormSchema = z.object({
  category: z.string().min(1, "Category is required"),
  title: z.string().min(1, "Title is required"),
  subtitle: z.string().optional(),
  link: z.string().optional(),
  imageUrl: z.string().optional(),
  featured: z.boolean(),
  order: z.string(),
});

type SectionFormValues = z.infer<typeof sectionFormSchema>;
type CardFormValues = z.infer<typeof cardFormSchema>;

function formatUpdatedAt(updatedAt: HomeEventCard["updatedAt"]): string {
  if (!updatedAt) return "—";
  if (
    typeof updatedAt === "object" &&
    updatedAt !== null &&
    "toDate" in updatedAt &&
    typeof (updatedAt as { toDate: () => Date }).toDate === "function"
  ) {
    return format((updatedAt as { toDate: () => Date }).toDate(), "MMM d, yyyy");
  }
  if (updatedAt instanceof Date) {
    return format(updatedAt, "MMM d, yyyy");
  }
  return "—";
}

function formatEventDateLabel(eventDate: string): string {
  if (!eventDate) return "—";
  try {
    return format(parseISO(eventDate), "MMM d, yyyy");
  } catch {
    return eventDate;
  }
}

const DEFAULT_EVENT_TIME_ZONE = "PT";

function parseEventTimeString(value: string): {
  time24: string;
  timeZone: string;
} {
  const trimmed = value.trim();
  if (!trimmed) {
    return { time24: "", timeZone: DEFAULT_EVENT_TIME_ZONE };
  }

  if (/^\d{2}:\d{2}$/.test(trimmed)) {
    return { time24: trimmed, timeZone: DEFAULT_EVENT_TIME_ZONE };
  }

  const match = trimmed.match(
    /^(\d{1,2}):(\d{2})\s*(AM|PM)(?:\s+(.+))?$/i,
  );
  if (match) {
    let hours = parseInt(match[1], 10);
    const minutes = match[2];
    const meridiem = match[3].toUpperCase();
    const timeZone = match[4]?.trim() || DEFAULT_EVENT_TIME_ZONE;
    if (meridiem === "PM" && hours < 12) hours += 12;
    if (meridiem === "AM" && hours === 12) hours = 0;
    return {
      time24: `${String(hours).padStart(2, "0")}:${minutes}`,
      timeZone,
    };
  }

  return { time24: "", timeZone: DEFAULT_EVENT_TIME_ZONE };
}

function formatEventTimeDisplay(time24: string, timeZone: string): string {
  if (!time24) return "";
  const [hoursPart, minutesPart] = time24.split(":");
  const hours = Number(hoursPart);
  const minutes = Number(minutesPart);
  if (Number.isNaN(hours) || Number.isNaN(minutes)) return "";

  const date = new Date(2000, 0, 1, hours, minutes);
  const formatted = format(date, "h:mm a");
  const zone = timeZone.trim();
  return zone ? `${formatted} ${zone}` : formatted;
}

export function HomeEventsManager() {
  const [cards, setCards] = useState<HomeEventCard[]>([]);
  const [loadingSection, setLoadingSection] = useState(true);
  const [loadingCards, setLoadingCards] = useState(true);
  const [savingSection, setSavingSection] = useState(false);
  const [savingCard, setSavingCard] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingCard, setEditingCard] = useState<HomeEventCard | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<HomeEventCard | null>(null);
  const [cardImage, setCardImage] = useState<CmsImageUploadValue | null>(null);
  const [imagePendingPreview, setImagePendingPreview] = useState<string | null>(
    null,
  );
  const [eventDate, setEventDate] = useState<Date | undefined>(undefined);
  const [datePickerOpen, setDatePickerOpen] = useState(false);
  const [eventTime24, setEventTime24] = useState("");
  const [eventTimeZone, setEventTimeZone] = useState(DEFAULT_EVENT_TIME_ZONE);

  const sectionForm = useForm<SectionFormValues>({
    resolver: zodResolver(sectionFormSchema),
    defaultValues: {
      sectionHeading: "Upcoming Events",
      buttonText: "More events",
      buttonLink: "/allotment",
    },
  });

  const cardForm = useForm<CardFormValues>({
    resolver: zodResolver(cardFormSchema),
    defaultValues: {
      category: "",
      title: "",
      subtitle: "",
      link: "",
      imageUrl: "",
      featured: false,
      order: "1",
    },
  });

  const featured = cardForm.watch("featured");
  const orderValue = cardForm.watch("order");

  const loadSection = useCallback(async () => {
    setLoadingSection(true);
    try {
      const data = await fetchHomeEventsContent();
      sectionForm.reset({
        sectionHeading: data.sectionHeading,
        buttonText: data.buttonText,
        buttonLink: data.buttonLink,
      });
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load section",
      );
    } finally {
      setLoadingSection(false);
    }
  }, [sectionForm]);

  const loadCards = useCallback(async () => {
    setLoadingCards(true);
    try {
      setCards(await fetchHomeEventCards());
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load events",
      );
    } finally {
      setLoadingCards(false);
    }
  }, []);

  useEffect(() => {
    loadSection();
    loadCards();
  }, [loadSection, loadCards]);

  const onSaveSection = async (values: SectionFormValues) => {
    setSavingSection(true);
    try {
      await saveHomeEventsContent(
        values as Omit<HomeEventsSectionContent, "updatedAt">,
      );
      toast.success("Section settings saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save section",
      );
    } finally {
      setSavingSection(false);
    }
  };

  const openCreate = () => {
    setEditingCard(null);
    setCardImage(null);
    setImagePendingPreview(null);
    setEventDate(undefined);
    setEventTime24("");
    setEventTimeZone(DEFAULT_EVENT_TIME_ZONE);
    cardForm.reset({
      category: "",
      title: "",
      subtitle: "",
      link: "",
      imageUrl: "",
      featured: false,
      order: "1",
    });
    setDialogOpen(true);
  };

  const openEdit = (card: HomeEventCard) => {
    setEditingCard(card);
    setCardImage(card.imageUrl ? { url: card.imageUrl } : null);
    setImagePendingPreview(null);
    setEventDate(card.eventDate ? parseISO(card.eventDate) : undefined);
    const parsedTime = parseEventTimeString(card.eventTime);
    setEventTime24(parsedTime.time24);
    setEventTimeZone(parsedTime.timeZone);
    cardForm.reset({
      category: card.category,
      title: card.title,
      subtitle: card.subtitle,
      link: card.link,
      imageUrl: card.imageUrl,
      featured: card.featured,
      order: String(card.order || 1),
    });
    setDialogOpen(true);
  };

  const onSubmitCard = async (values: CardFormValues) => {
    const order = Number(values.order);
    if (!cardImage?.url) {
      toast.error("Please upload an image");
      return;
    }
    if (!eventDate) {
      toast.error("Please select an event date");
      return;
    }
    if (!eventTime24) {
      toast.error("Please select an event time");
      return;
    }

    const eventTimeDisplay = formatEventTimeDisplay(eventTime24, eventTimeZone);

    const featuredCheck = await validateFeaturedHomeEventsLimit(
      values.featured,
      editingCard?.id,
    );
    if (!featuredCheck.ok) {
      toast.error(featuredCheck.message);
      return;
    }

    const orderCheck = await validateHomeEventCardOrder(
      order,
      values.featured,
      editingCard?.id,
    );
    if (!orderCheck.ok) {
      toast.error(orderCheck.message);
      return;
    }

    setSavingCard(true);
    try {
      const payload = {
        imageUrl: cardImage.url,
        eventDate: format(eventDate, "yyyy-MM-dd"),
        eventTime: eventTimeDisplay,
        category: values.category.trim(),
        title: values.title.trim(),
        subtitle: values.subtitle?.trim() ?? "",
        link: values.link?.trim() ?? "",
        featured: values.featured,
        order: values.featured ? order : 0,
      };

      if (editingCard) {
        await updateHomeEventCard(editingCard.id, payload);
        toast.success("Event updated");
      } else {
        await createHomeEventCard(payload);
        toast.success("Event created");
      }

      setDialogOpen(false);
      await loadCards();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save event",
      );
    } finally {
      setSavingCard(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteHomeEventCard(deleteTarget.id);
      toast.success("Event deleted");
      setDeleteTarget(null);
      await loadCards();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete event",
      );
    }
  };

  return (
    <section className="space-y-10">
      <header>
        <Button variant="ghost" size="sm" className="mb-4 -ml-2" asChild>
          <Link href="/admin/home-content">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Home page content
          </Link>
        </Button>
        <HomeSectionPublishToggle sectionKey="events" className="mb-6" />
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Upcoming events
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Manage homepage event cards. Up to 4 featured events appear on the home
          page.
        </p>
      </header>

      <section className="bg-card rounded-lg border border-border shadow-sm p-6 md:p-8">
        <h2 className="text-xl font-heading font-semibold text-foreground mb-6">
          Section settings
        </h2>
        {loadingSection ? (
          <div className="space-y-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        ) : (
          <form
            onSubmit={sectionForm.handleSubmit(onSaveSection)}
            className="space-y-5 max-w-2xl"
          >
            <div className="space-y-2">
              <Label htmlFor="sectionHeading">Section heading</Label>
              <Input
                id="sectionHeading"
                {...sectionForm.register("sectionHeading")}
              />
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="buttonText">Button text</Label>
                <Input id="buttonText" {...sectionForm.register("buttonText")} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="buttonLink">Button link</Label>
                <Input id="buttonLink" {...sectionForm.register("buttonLink")} />
              </div>
            </div>
            <Button type="submit" disabled={savingSection}>
              {savingSection ? "Saving..." : "Save section"}
            </Button>
          </form>
        )}
      </section>

      <section>
        <header className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <h2 className="text-xl font-heading font-semibold text-foreground">
            Events
          </h2>
          <Button onClick={openCreate}>
            <Plus className="w-4 h-4 mr-2" />
            Add event
          </Button>
        </header>

        <section className="bg-card rounded-lg border border-border shadow-sm overflow-hidden">
          {loadingCards ? (
            <section className="p-8 space-y-3">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </section>
          ) : cards.length === 0 ? (
            <p className="p-8 text-sm text-muted-foreground text-center">
              No events yet. Add featured events for the homepage.
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead>Title</TableHead>
                  <TableHead className="hidden md:table-cell">Date</TableHead>
                  <TableHead className="w-20">Featured</TableHead>
                  <TableHead className="w-28">Position</TableHead>
                  <TableHead className="hidden sm:table-cell w-32">
                    Updated
                  </TableHead>
                  <TableHead className="w-24 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {cards.map((card) => (
                  <TableRow key={card.id}>
                    <TableCell className="font-medium max-w-[200px]">
                      <span className="line-clamp-2">{card.title}</span>
                    </TableCell>
                    <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                      {formatEventDateLabel(card.eventDate)}
                    </TableCell>
                    <TableCell>
                      {card.featured ? (
                        <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {card.featured
                        ? getHomeEventCardOrderLabel(card.order)
                        : "—"}
                    </TableCell>
                    <TableCell className="hidden sm:table-cell text-sm text-muted-foreground">
                      {formatUpdatedAt(card.updatedAt)}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openEdit(card)}
                          aria-label="Edit"
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setDeleteTarget(card)}
                          aria-label="Delete"
                        >
                          <Trash2 className="w-4 h-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </section>
      </section>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-background">
          <DialogHeader>
            <DialogTitle className="font-heading text-xl">
              {editingCard ? "Edit event" : "New event"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-5">
            <CmsImageUploadField
              label="Event card image"
              preset="card4x5"
              folder="cms/home-events"
              storageFileName={editingCard?.id ?? `new-${Date.now()}`}
              value={cardImage}
              onChange={setCardImage}
              pendingPreviewUrl={imagePendingPreview}
              onPendingPreviewChange={setImagePendingPreview}
              required
            />

            <div className="space-y-2">
              <Label>
                Event date <span className="text-destructive">*</span>
              </Label>
              <Popover
                open={datePickerOpen}
                onOpenChange={setDatePickerOpen}
                modal
              >
                <PopoverTrigger asChild>
                  <Button
                    type="button"
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !eventDate && "text-muted-foreground",
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {eventDate ? format(eventDate, "PPP") : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent
                  className="z-[100] w-auto p-0"
                  align="start"
                  onOpenAutoFocus={(e) => e.preventDefault()}
                >
                  <Calendar
                    mode="single"
                    selected={eventDate}
                    defaultMonth={eventDate}
                    onSelect={(date) => {
                      setEventDate(date);
                      if (date) {
                        setDatePickerOpen(false);
                      }
                    }}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label htmlFor="eventTime">
                Event time <span className="text-destructive">*</span>
              </Label>
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Clock
                    className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none"
                    aria-hidden
                  />
                  <Input
                    id="eventTime"
                    type="time"
                    step={60}
                    value={eventTime24}
                    onChange={(e) => setEventTime24(e.target.value)}
                    className="pl-10 [&::-webkit-calendar-picker-indicator]:cursor-pointer"
                    required
                  />
                </div>
                <div className="sm:w-28 space-y-2">
                  <Label htmlFor="eventTimeZone" className="sr-only sm:not-sr-only">
                    Time zone
                  </Label>
                  <Input
                    id="eventTimeZone"
                    value={eventTimeZone}
                    onChange={(e) => setEventTimeZone(e.target.value)}
                    placeholder="PT"
                    aria-label="Time zone label"
                  />
                </div>
              </div>
              <p className="text-xs text-muted-foreground">
                {eventTime24
                  ? `Displayed as: ${formatEventTimeDisplay(eventTime24, eventTimeZone)}`
                  : "Use the clock control to pick a time."}
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">
                Category <span className="text-destructive">*</span>
              </Label>
              <Input
                id="category"
                placeholder="LECTURE/PRESENTATION/TALK"
                {...cardForm.register("category")}
              />
              <p className="text-xs text-muted-foreground">
                Shown in uppercase on the homepage card.
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="title">
                Title <span className="text-destructive">*</span>
              </Label>
              <Input id="title" {...cardForm.register("title")} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="subtitle">Subtitle / speaker (optional)</Label>
              <Textarea
                id="subtitle"
                rows={2}
                placeholder="Speaker name or short description"
                {...cardForm.register("subtitle")}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="link">Card link (optional)</Label>
              <Input
                id="link"
                placeholder="/allotment"
                {...cardForm.register("link")}
              />
            </div>

            <section className="flex items-start gap-3 rounded-lg border border-border p-4 bg-muted/30">
              <Checkbox
                id="featured"
                checked={featured}
                onCheckedChange={(checked) =>
                  cardForm.setValue("featured", checked === true)
                }
              />
              <div className="space-y-0.5">
                <Label htmlFor="featured" className="cursor-pointer font-medium">
                  Feature on homepage
                </Label>
                <p className="text-xs text-muted-foreground">
                  Up to 4 featured events appear on the home page.
                </p>
              </div>
            </section>

            {featured ? (
              <div className="space-y-2">
                <Label htmlFor="order">
                  Card position <span className="text-destructive">*</span>
                </Label>
                <Select
                  value={orderValue}
                  onValueChange={(value) => cardForm.setValue("order", value)}
                >
                  <SelectTrigger id="order">
                    <SelectValue placeholder="Select position" />
                  </SelectTrigger>
                  <SelectContent>
                    {HOME_EVENT_CARD_ORDERS.map((placement) => (
                      <SelectItem
                        key={placement.order}
                        value={String(placement.order)}
                      >
                        {placement.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ) : null}

            <DialogFooter className="gap-2 sm:gap-0 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button
                type="button"
                disabled={savingCard}
                onClick={cardForm.handleSubmit(onSubmitCard)}
              >
                {savingCard ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete event?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
