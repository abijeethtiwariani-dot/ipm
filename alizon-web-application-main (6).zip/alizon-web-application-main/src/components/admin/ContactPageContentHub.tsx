"use client";

import Link from "next/link";
import {
  Building2,
  ChevronRight,
  Mail,
  MapPin,
  MessageSquare,
  Sparkles,
} from "lucide-react";
import { Card } from "@/components/ui/card";

const sections = [
  {
    title: "Hero",
    description: "Page banner title, subtitle, and hero image.",
    href: "/admin/contact-page-content/hero",
    icon: Sparkles,
  },
  {
    title: "Contact Info Cards",
    description: "Email, phone, visit, and office hours cards below the hero.",
    href: "/admin/contact-page-content/info-cards",
    icon: Mail,
  },
  {
    title: "Message Form",
    description:
      "Send Us a Message section heading and success copy.",
    href: "/admin/contact-page-content/form",
    icon: MessageSquare,
  },
  {
    title: "Map",
    description: "Find Us section heading and Google Maps embed URL.",
    href: "/admin/contact-page-content/map",
    icon: MapPin,
  },
  {
    title: "Department Contacts",
    description: "Department contacts section heading and contact cards.",
    href: "/admin/contact-page-content/departments",
    icon: Building2,
  },
];

export function ContactPageContentHub() {
  return (
    <section>
      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Contact Us page content
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Manage sections on the public <code className="text-xs">/contact</code>{" "}
          page. The site uses sensible defaults until you save content here.
        </p>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 max-w-5xl">
        {sections.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href}>
              <Card className="p-6 h-full border border-border shadow-sm hover:shadow-md transition-shadow card-hover">
                <div className="flex items-start justify-between gap-4">
                  <div className="w-11 h-11 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-1" />
                </div>
                <h2 className="text-lg font-heading font-semibold text-foreground mt-4">
                  {item.title}
                </h2>
                <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                  {item.description}
                </p>
              </Card>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
