"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import type { NewsHeroContent } from "@/types/cms";
import {
  fetchNewsHeroContentAdmin,
  saveNewsHeroContentAdmin,
  uploadCmsImageUrl,
} from "@/lib/admin-cms-api";
import { NewsSectionBackLink } from "@/components/admin/NewsSectionBackLink";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const sidebarItemSchema = z.object({
  category: z.string().min(1, "Category is required"),
  title: z.string().min(1, "Title is required"),
  link: z.string().optional(),
});

const formSchema = z.object({
  featuredCategory: z.string().min(1, "Featured category is required"),
  featuredTitle: z.string().min(1, "Featured title is required"),
  featuredExcerpt: z.string().min(1, "Featured excerpt is required"),
  sidebar: z.array(sidebarItemSchema).length(3),
});

type FormValues = z.infer<typeof formSchema>;

const SIDEBAR_LABELS = ["Sidebar item 1", "Sidebar item 2", "Sidebar item 3"];

export function NewsHeroManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [featuredFile, setFeaturedFile] = useState<File | null>(null);
  const [featuredPreview, setFeaturedPreview] = useState<string | null>(null);
  const [existingFeaturedUrl, setExistingFeaturedUrl] = useState("");
  const [sidebarFiles, setSidebarFiles] = useState<(File | null)[]>([
    null,
    null,
    null,
  ]);
  const [sidebarPreviews, setSidebarPreviews] = useState<(string | null)[]>([
    null,
    null,
    null,
  ]);
  const [existingSidebarUrls, setExistingSidebarUrls] = useState<string[]>([
    "",
    "",
    "",
  ]);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      featuredCategory: "",
      featuredTitle: "",
      featuredExcerpt: "",
      sidebar: [
        { category: "", title: "", link: "" },
        { category: "", title: "", link: "" },
        { category: "", title: "", link: "" },
      ],
    },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchNewsHeroContentAdmin();
      setExistingFeaturedUrl(data.featuredImageUrl ?? "");
      setFeaturedPreview(data.featuredImageUrl || null);
      setExistingSidebarUrls(
        data.sidebar.map((item) => item.imageUrl ?? ""),
      );
      setSidebarPreviews(data.sidebar.map((item) => item.imageUrl || null));
      form.reset({
        featuredCategory: data.featuredCategory,
        featuredTitle: data.featuredTitle,
        featuredExcerpt: data.featuredExcerpt,
        sidebar: data.sidebar.map((item) => ({
          category: item.category,
          title: item.title,
          link: item.link ?? "",
        })) as FormValues["sidebar"],
      });
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load hero content",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onFeaturedFileChange = (file: File | null) => {
    setFeaturedFile(file);
    if (file) {
      setFeaturedPreview(URL.createObjectURL(file));
    } else {
      setFeaturedPreview(existingFeaturedUrl || null);
    }
  };

  const onSidebarFileChange = (index: number, file: File | null) => {
    setSidebarFiles((prev) => {
      const next = [...prev];
      next[index] = file;
      return next;
    });
    setSidebarPreviews((prev) => {
      const next = [...prev];
      next[index] = file
        ? URL.createObjectURL(file)
        : existingSidebarUrls[index] || null;
      return next;
    });
  };

  const onSubmit = async (values: FormValues) => {
    const hasFeatured = Boolean(existingFeaturedUrl) || Boolean(featuredFile);
    if (!hasFeatured) {
      toast.error("Please upload a featured image");
      return;
    }

    for (let i = 0; i < 3; i++) {
      const hasImage = Boolean(existingSidebarUrls[i]) || Boolean(sidebarFiles[i]);
      if (!hasImage) {
        toast.error(`Please upload an image for ${SIDEBAR_LABELS[i]}`);
        return;
      }
    }

    setSaving(true);
    try {
      let featuredImageUrl = existingFeaturedUrl;
      if (featuredFile) {
        featuredImageUrl = await uploadCmsImageUrl(
          `cms/news/hero/featured-${featuredFile.name}`,
          featuredFile,
        );
      }

      const sidebar = await Promise.all(
        values.sidebar.map(async (item, index) => {
          let imageUrl = existingSidebarUrls[index] ?? "";
          const file = sidebarFiles[index];
          if (file) {
            imageUrl = await uploadCmsImageUrl(
              `cms/news/hero/sidebar-${index + 1}-${file.name}`,
              file,
            );
          }
          return {
            category: item.category.trim(),
            title: item.title.trim(),
            imageUrl,
            ...(item.link?.trim() ? { link: item.link.trim() } : {}),
          };
        }),
      );

      const payload: Omit<NewsHeroContent, "updatedAt"> = {
        featuredCategory: values.featuredCategory.trim(),
        featuredTitle: values.featuredTitle.trim(),
        featuredExcerpt: values.featuredExcerpt.trim(),
        featuredImageUrl,
        sidebar,
      };

      await saveNewsHeroContentAdmin(payload);
      setExistingFeaturedUrl(featuredImageUrl);
      setFeaturedFile(null);
      setExistingSidebarUrls(sidebar.map((item) => item.imageUrl));
      setSidebarFiles([null, null, null]);
      toast.success("Hero section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save hero section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-2xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-40 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-2xl">
      <NewsSectionBackLink />

      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">Hero</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Featured story and three sidebar items at the top of the news page.
        </p>
      </header>

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <section className="space-y-6 rounded-lg border border-border bg-card p-6">
          <h2 className="text-lg font-heading font-semibold text-foreground">
            Featured story
          </h2>

          <div className="space-y-2">
            <Label htmlFor="featuredCategory">Category</Label>
            <Input id="featuredCategory" {...form.register("featuredCategory")} />
            {form.formState.errors.featuredCategory ? (
              <p className="text-sm text-destructive">
                {form.formState.errors.featuredCategory.message}
              </p>
            ) : null}
          </div>

          <div className="space-y-2">
            <Label htmlFor="featuredTitle">Title</Label>
            <Input id="featuredTitle" {...form.register("featuredTitle")} />
            {form.formState.errors.featuredTitle ? (
              <p className="text-sm text-destructive">
                {form.formState.errors.featuredTitle.message}
              </p>
            ) : null}
          </div>

          <div className="space-y-2">
            <Label htmlFor="featuredExcerpt">Excerpt</Label>
            <Textarea
              id="featuredExcerpt"
              rows={3}
              {...form.register("featuredExcerpt")}
            />
            {form.formState.errors.featuredExcerpt ? (
              <p className="text-sm text-destructive">
                {form.formState.errors.featuredExcerpt.message}
              </p>
            ) : null}
          </div>

          <div className="space-y-2">
            <Label htmlFor="featuredImage">Featured image</Label>
            {featuredPreview ? (
              <div className="relative aspect-[16/9] w-full max-w-xl overflow-hidden rounded-md border border-border mb-2">
                <Image
                  src={featuredPreview}
                  alt="Featured preview"
                  fill
                  className="object-cover"
                  unoptimized={featuredPreview.startsWith("blob:")}
                />
              </div>
            ) : null}
            <Input
              id="featuredImage"
              type="file"
              accept="image/*"
              onChange={(e) => onFeaturedFileChange(e.target.files?.[0] ?? null)}
            />
          </div>
        </section>

        {SIDEBAR_LABELS.map((label, index) => (
          <section
            key={label}
            className="space-y-4 rounded-lg border border-border bg-card p-6"
          >
            <h2 className="text-lg font-heading font-semibold text-foreground">
              {label}
            </h2>

            <div className="space-y-2">
              <Label htmlFor={`sidebar-${index}-category`}>Category</Label>
              <Input
                id={`sidebar-${index}-category`}
                {...form.register(`sidebar.${index}.category`)}
              />
              {form.formState.errors.sidebar?.[index]?.category ? (
                <p className="text-sm text-destructive">
                  {form.formState.errors.sidebar[index]?.category?.message}
                </p>
              ) : null}
            </div>

            <div className="space-y-2">
              <Label htmlFor={`sidebar-${index}-title`}>Title</Label>
              <Input
                id={`sidebar-${index}-title`}
                {...form.register(`sidebar.${index}.title`)}
              />
              {form.formState.errors.sidebar?.[index]?.title ? (
                <p className="text-sm text-destructive">
                  {form.formState.errors.sidebar[index]?.title?.message}
                </p>
              ) : null}
            </div>

            <div className="space-y-2">
              <Label htmlFor={`sidebar-${index}-link`}>Link (optional)</Label>
              <Input
                id={`sidebar-${index}-link`}
                placeholder="/news/example"
                {...form.register(`sidebar.${index}.link`)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor={`sidebar-${index}-image`}>Image</Label>
              {sidebarPreviews[index] ? (
                <div className="relative aspect-[4/3] w-full max-w-xs overflow-hidden rounded-md border border-border mb-2">
                  <Image
                    src={sidebarPreviews[index]!}
                    alt={`${label} preview`}
                    fill
                    className="object-cover"
                    unoptimized={sidebarPreviews[index]!.startsWith("blob:")}
                  />
                </div>
              ) : null}
              <Input
                id={`sidebar-${index}-image`}
                type="file"
                accept="image/*"
                onChange={(e) =>
                  onSidebarFileChange(index, e.target.files?.[0] ?? null)
                }
              />
            </div>
          </section>
        ))}

        <Button type="submit" disabled={saving}>
          {saving ? "Saving…" : "Save changes"}
        </Button>
      </form>
    </section>
  );
}
