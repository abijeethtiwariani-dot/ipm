"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import {
  fetchCareersSeoContentAdmin,
  saveCareersSeoContentAdmin,
  uploadCmsImageUrl,
} from "@/lib/admin-cms-api";
import {
  CareersPageAdminBackLink,
  CareersPageAdminHeader,
  CareersPageFormFooter,
} from "@/components/admin/careers-page/CareersPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z.object({
  metaTitle: z.string(),
  metaDescription: z.string(),
});

type FormValues = z.infer<typeof formSchema>;

export function CareersSeoManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [ogImageUrl, setOgImageUrl] = useState("");

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: { metaTitle: "", metaDescription: "" },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchCareersSeoContentAdmin();
      if (data) {
        form.reset({
          metaTitle: data.metaTitle,
          metaDescription: data.metaDescription,
        });
        setOgImageUrl(data.ogImageUrl ?? "");
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to load");
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    void loadContent();
  }, [loadContent]);

  const onOgUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const url = await uploadCmsImageUrl("cms/careers/seo/og", file);
      setOgImageUrl(url);
      toast.success("OG image uploaded.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Upload failed");
    }
  };

  const onSubmit = async (values: FormValues) => {
    if (saving) return;
    setSaving(true);
    try {
      await saveCareersSeoContentAdmin({
        metaTitle: values.metaTitle.trim(),
        metaDescription: values.metaDescription.trim(),
        ogImageUrl: ogImageUrl || undefined,
      });
      toast.success("SEO settings saved.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Skeleton className="h-64 w-full" />;

  return (
    <section>
      <CareersPageAdminBackLink />
      <CareersPageAdminHeader
        title="SEO"
        description="Search engine and social sharing metadata."
      />
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 max-w-2xl">
        <div className="space-y-2">
          <Label htmlFor="metaTitle">Meta Title</Label>
          <Input id="metaTitle" {...form.register("metaTitle")} placeholder="Careers" />
        </div>
        <div className="space-y-2">
          <Label htmlFor="metaDescription">Meta Description</Label>
          <Textarea id="metaDescription" rows={3} {...form.register("metaDescription")} />
        </div>
        <div className="space-y-2">
          <Label>OG Image</Label>
          <Input type="file" accept="image/*" onChange={onOgUpload} />
          {ogImageUrl && (
            <p className="text-xs text-muted-foreground truncate">Current: {ogImageUrl}</p>
          )}
        </div>
        <CareersPageFormFooter
          end={
            <Button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save SEO"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
