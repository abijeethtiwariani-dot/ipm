import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CAREERS_ICON_OPTIONS } from "@/types/cms";
import { CAREERS_ICON_LABELS } from "@/lib/careers-icon-map";

interface CareersIconSelectProps {
  value: string;
  onChange: (value: string) => void;
}

export function CareersIconSelect({ value, onChange }: CareersIconSelectProps) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger>
        <SelectValue placeholder="Select icon" />
      </SelectTrigger>
      <SelectContent>
        {CAREERS_ICON_OPTIONS.map((icon) => (
          <SelectItem key={icon} value={icon}>
            {CAREERS_ICON_LABELS[icon]}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
