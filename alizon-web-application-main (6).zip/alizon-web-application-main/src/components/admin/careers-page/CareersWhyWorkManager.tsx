"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { CareersWhyWorkCard, CareersWhyWorkContent, CareersIconKey } from "@/types/cms";
import {
  createCareersWhyWorkCardAdmin,
  deleteCareersWhyWorkCardAdmin,
  fetchCareersWhyWorkCardsAdmin,
  fetchCareersWhyWorkContentAdmin,
  saveCareersWhyWorkContentAdmin,
  updateCareersWhyWorkCardAdmin,
} from "@/lib/admin-cms-api";
import { WHY_WORK_DEFAULTS, mergeWhyWorkContent } from "@/lib/careers-why-work-defaults";
import {
  CareersPageAdminBackLink,
  CareersPageAdminHeader,
  CareersPageFormFooter,
} from "@/components/admin/careers-page/CareersPageAdminLayout";
import { CareersIconSelect } from "@/components/admin/careers-page/CareersIconSelect";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const sectionSchema = z.object({
  eyebrow: z.string(),
  heading: z.string().min(1, "Heading is required"),
  subtitle: z.string(),
  ctaText: z.string(),
  ctaHref: z.string(),
  backgroundType: z.enum(["image", "gradient"]),
  gradientType: z.enum(["linear", "radial"]),
  gradientColor1: z.string(),
  gradientColor2: z.string(),
  gradientColor3: z.string(),
  gradientDirection: z.enum(["to-r", "to-b", "to-br", "radial"]),
  overlayColor: z.string(),
  overlayOpacity: z.coerce.number().min(0).max(1),
  eyebrowColor: z.string(),
  headingColor: z.string(),
  descriptionColor: z.string(),
  ctaColor: z.string(),
  cardBackgroundColor: z.string(),
  cardOpacity: z.coerce.number().min(0.05).max(1),
  cardBlur: z.coerce.number().int().min(0).max(40),
  cardBorderColor: z.string(),
  cardTitleColor: z.string(),
  cardDescriptionColor: z.string(),
  cardCtaColor: z.string(),
  carouselAutoScroll: z.boolean(),
  carouselScrollSpeed: z.coerce.number().min(0.5).max(5),
  carouselLoop: z.boolean(),
  carouselCardsPerViewDesktop: z.coerce.number().int().min(1).max(3),
  carouselCardsPerViewTablet: z.coerce.number().int().min(1).max(3),
  carouselCardsPerViewMobile: z.coerce.number().int().min(1).max(2),
});

const cardSchema = z.object({
  icon: z.string(),
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  ctaText: z.string(),
  ctaLink: z.string(),
  enabled: z.boolean(),
  order: z.coerce.number().int().min(0),
});

type SectionValues = z.infer<typeof sectionSchema>;
type CardValues = z.infer<typeof cardSchema>;

function ColorField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <div className="flex gap-2">
        <Input
          type="color"
          value={value.startsWith("#") ? value : "#ffffff"}
          onChange={(e) => onChange(e.target.value)}
          className="h-10 w-14 shrink-0 cursor-pointer p-1"
        />
        <Input value={value} onChange={(e) => onChange(e.target.value)} />
      </div>
    </div>
  );
}

function sectionDefaults(): SectionValues {
  return {
    eyebrow: WHY_WORK_DEFAULTS.eyebrow,
    heading: WHY_WORK_DEFAULTS.heading,
    subtitle: WHY_WORK_DEFAULTS.subtitle,
    ctaText: WHY_WORK_DEFAULTS.ctaText,
    ctaHref: WHY_WORK_DEFAULTS.ctaHref,
    backgroundType: WHY_WORK_DEFAULTS.backgroundType,
    gradientType: WHY_WORK_DEFAULTS.gradientType,
    gradientColor1: WHY_WORK_DEFAULTS.gradientColor1,
    gradientColor2: WHY_WORK_DEFAULTS.gradientColor2,
    gradientColor3: WHY_WORK_DEFAULTS.gradientColor3 ?? "",
    gradientDirection: WHY_WORK_DEFAULTS.gradientDirection,
    overlayColor: WHY_WORK_DEFAULTS.overlayColor,
    overlayOpacity: WHY_WORK_DEFAULTS.overlayOpacity,
    eyebrowColor: WHY_WORK_DEFAULTS.eyebrowColor,
    headingColor: WHY_WORK_DEFAULTS.headingColor,
    descriptionColor: WHY_WORK_DEFAULTS.descriptionColor,
    ctaColor: WHY_WORK_DEFAULTS.ctaColor,
    cardBackgroundColor: WHY_WORK_DEFAULTS.cardBackgroundColor,
    cardOpacity: WHY_WORK_DEFAULTS.cardOpacity,
    cardBlur: WHY_WORK_DEFAULTS.cardBlur,
    cardBorderColor: WHY_WORK_DEFAULTS.cardBorderColor,
    cardTitleColor: WHY_WORK_DEFAULTS.cardTitleColor,
    cardDescriptionColor: WHY_WORK_DEFAULTS.cardDescriptionColor,
    cardCtaColor: WHY_WORK_DEFAULTS.cardCtaColor,
    carouselAutoScroll: WHY_WORK_DEFAULTS.carouselAutoScroll,
    carouselScrollSpeed: WHY_WORK_DEFAULTS.carouselScrollSpeed,
    carouselLoop: WHY_WORK_DEFAULTS.carouselLoop,
    carouselCardsPerViewDesktop: WHY_WORK_DEFAULTS.carouselCardsPerViewDesktop,
    carouselCardsPerViewTablet: WHY_WORK_DEFAULTS.carouselCardsPerViewTablet,
    carouselCardsPerViewMobile: WHY_WORK_DEFAULTS.carouselCardsPerViewMobile,
  };
}

function contentToFormValues(content: CareersWhyWorkContent): SectionValues {
  return {
    eyebrow: content.eyebrow,
    heading: content.heading,
    subtitle: content.subtitle,
    ctaText: content.ctaText,
    ctaHref: content.ctaHref,
    backgroundType: content.backgroundType,
    gradientType: content.gradientType,
    gradientColor1: content.gradientColor1,
    gradientColor2: content.gradientColor2,
    gradientColor3: content.gradientColor3 ?? "",
    gradientDirection: content.gradientDirection,
    overlayColor: content.overlayColor,
    overlayOpacity: content.overlayOpacity,
    eyebrowColor: content.eyebrowColor,
    headingColor: content.headingColor,
    descriptionColor: content.descriptionColor,
    ctaColor: content.ctaColor,
    cardBackgroundColor: content.cardBackgroundColor,
    cardOpacity: content.cardOpacity,
    cardBlur: content.cardBlur,
    cardBorderColor: content.cardBorderColor,
    cardTitleColor: content.cardTitleColor,
    cardDescriptionColor: content.cardDescriptionColor,
    cardCtaColor: content.cardCtaColor,
    carouselAutoScroll: content.carouselAutoScroll,
    carouselScrollSpeed: content.carouselScrollSpeed,
    carouselLoop: content.carouselLoop,
    carouselCardsPerViewDesktop: content.carouselCardsPerViewDesktop,
    carouselCardsPerViewTablet: content.carouselCardsPerViewTablet,
    carouselCardsPerViewMobile: content.carouselCardsPerViewMobile,
  };
}

function formValuesToContent(
  values: SectionValues,
  desktopImage?: string,
  mobileImage?: string,
): Omit<CareersWhyWorkContent, "updatedAt"> {
  return {
    eyebrow: values.eyebrow.trim() || WHY_WORK_DEFAULTS.eyebrow,
    heading: values.heading.trim(),
    subtitle: values.subtitle.trim(),
    ctaText: values.ctaText.trim() || WHY_WORK_DEFAULTS.ctaText,
    ctaHref: values.ctaHref.trim() || WHY_WORK_DEFAULTS.ctaHref,
    backgroundType: values.backgroundType,
    backgroundImageUrl: desktopImage || undefined,
    backgroundMobileImageUrl: mobileImage || undefined,
    gradientType: values.gradientType,
    gradientColor1: values.gradientColor1.trim() || WHY_WORK_DEFAULTS.gradientColor1,
    gradientColor2: values.gradientColor2.trim() || WHY_WORK_DEFAULTS.gradientColor2,
    gradientColor3: values.gradientColor3.trim() || undefined,
    gradientDirection: values.gradientDirection,
    overlayColor: values.overlayColor.trim() || WHY_WORK_DEFAULTS.overlayColor,
    overlayOpacity: values.overlayOpacity,
    eyebrowColor: values.eyebrowColor.trim() || WHY_WORK_DEFAULTS.eyebrowColor,
    headingColor: values.headingColor.trim() || WHY_WORK_DEFAULTS.headingColor,
    descriptionColor:
      values.descriptionColor.trim() || WHY_WORK_DEFAULTS.descriptionColor,
    ctaColor: values.ctaColor.trim() || WHY_WORK_DEFAULTS.ctaColor,
    cardBackgroundColor:
      values.cardBackgroundColor.trim() || WHY_WORK_DEFAULTS.cardBackgroundColor,
    cardOpacity: values.cardOpacity,
    cardBlur: values.cardBlur,
    cardBorderColor:
      values.cardBorderColor.trim() || WHY_WORK_DEFAULTS.cardBorderColor,
    cardTitleColor: values.cardTitleColor.trim() || WHY_WORK_DEFAULTS.cardTitleColor,
    cardDescriptionColor:
      values.cardDescriptionColor.trim() || WHY_WORK_DEFAULTS.cardDescriptionColor,
    cardCtaColor: values.cardCtaColor.trim() || WHY_WORK_DEFAULTS.cardCtaColor,
    carouselAutoScroll: values.carouselAutoScroll,
    carouselScrollSpeed: values.carouselScrollSpeed,
    carouselLoop: values.carouselLoop,
    carouselCardsPerViewDesktop: values.carouselCardsPerViewDesktop,
    carouselCardsPerViewTablet: values.carouselCardsPerViewTablet,
    carouselCardsPerViewMobile: values.carouselCardsPerViewMobile,
  };
}

export function CareersWhyWorkManager() {
  const [loading, setLoading] = useState(true);
  const [savingSection, setSavingSection] = useState(false);
  const [savingCard, setSavingCard] = useState(false);
  const [cards, setCards] = useState<CareersWhyWorkCard[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<CareersWhyWorkCard | null>(null);
  const [desktopBg, setDesktopBg] = useState<CmsImageUploadValue | null>(null);
  const [mobileBg, setMobileBg] = useState<CmsImageUploadValue | null>(null);
  const [cardImage, setCardImage] = useState<CmsImageUploadValue | null>(null);

  const sectionForm = useForm<SectionValues>({
    resolver: zodResolver(sectionSchema),
    defaultValues: sectionDefaults(),
  });

  const cardForm = useForm<CardValues>({
    resolver: zodResolver(cardSchema),
    defaultValues: {
      icon: "briefcase",
      title: "",
      description: "",
      ctaText: "",
      ctaLink: "",
      enabled: true,
      order: 0,
    },
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [content, cardList] = await Promise.all([
        fetchCareersWhyWorkContentAdmin(),
        fetchCareersWhyWorkCardsAdmin(),
      ]);
      if (content) {
        const merged = mergeWhyWorkContent(content);
        sectionForm.reset(contentToFormValues(merged));
        setDesktopBg(
          merged.backgroundImageUrl ? { url: merged.backgroundImageUrl } : null,
        );
        setMobileBg(
          merged.backgroundMobileImageUrl
            ? { url: merged.backgroundMobileImageUrl }
            : null,
        );
      } else {
        sectionForm.reset(sectionDefaults());
      }
      setCards(cardList);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to load");
    } finally {
      setLoading(false);
    }
  }, [sectionForm]);

  useEffect(() => {
    void load();
  }, [load]);

  const saveSection = async (values: SectionValues) => {
    if (savingSection) return;
    if (values.backgroundType === "image" && !desktopBg?.url) {
      toast.error("Upload a desktop background image or switch to gradient mode.");
      return;
    }
    setSavingSection(true);
    try {
      await saveCareersWhyWorkContentAdmin(
        formValuesToContent(values, desktopBg?.url, mobileBg?.url),
      );
      toast.success("Why Work section saved.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Save failed");
    } finally {
      setSavingSection(false);
    }
  };

  const openCreate = () => {
    setEditing(null);
    setCardImage(null);
    cardForm.reset({
      icon: "briefcase",
      title: "",
      description: "",
      ctaText: "",
      ctaLink: "",
      enabled: true,
      order: cards.length,
    });
    setDialogOpen(true);
  };

  const openEdit = (card: CareersWhyWorkCard) => {
    setEditing(card);
    setCardImage(card.imageUrl ? { url: card.imageUrl } : null);
    cardForm.reset({
      icon: card.icon,
      title: card.title,
      description: card.description,
      ctaText: card.ctaText ?? "",
      ctaLink: card.ctaLink ?? "",
      enabled: card.enabled !== false,
      order: card.order,
    });
    setDialogOpen(true);
  };

  const saveCard = async (values: CardValues) => {
    if (savingCard) return;

    const payload = {
      icon: values.icon as CareersIconKey,
      title: values.title.trim(),
      description: values.description.trim(),
      imageUrl: cardImage?.url,
      ctaText: values.ctaText.trim() || undefined,
      ctaLink: values.ctaLink.trim() || undefined,
      enabled: values.enabled,
      order: values.order,
    };

    setSavingCard(true);
    try {
      if (editing) {
        await updateCareersWhyWorkCardAdmin(editing.id, payload);
        toast.success("Card updated.");
      } else {
        await createCareersWhyWorkCardAdmin(payload);
        toast.success("Card created.");
      }
      setDialogOpen(false);
      await load();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Save failed");
    } finally {
      setSavingCard(false);
    }
  };

  const removeCard = async (id: string) => {
    try {
      await deleteCareersWhyWorkCardAdmin(id);
      toast.success("Card deleted.");
      await load();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Delete failed");
    }
  };

  if (loading) return <Skeleton className="h-96 w-full" />;

  const backgroundType = sectionForm.watch("backgroundType");

  return (
    <section>
      <CareersPageAdminBackLink />
      <CareersPageAdminHeader
        title="Why Work At Alizon"
        description="Immersive split layout with glass carousel cards."
      />

      <Tabs defaultValue="content" className="w-full">
        <TabsList className="mb-6 flex h-auto flex-wrap gap-1">
          <TabsTrigger value="content">Section Content</TabsTrigger>
          <TabsTrigger value="appearance">Section Appearance</TabsTrigger>
          <TabsTrigger value="styling">Text & Card Styling</TabsTrigger>
          <TabsTrigger value="carousel">Carousel</TabsTrigger>
          <TabsTrigger value="cards">Cards</TabsTrigger>
        </TabsList>

        <form onSubmit={sectionForm.handleSubmit(saveSection)}>
          <TabsContent value="content" className="max-w-2xl space-y-4">
            <div className="space-y-2">
              <Label>Eyebrow</Label>
              <Input {...sectionForm.register("eyebrow")} />
            </div>
            <div className="space-y-2">
              <Label>Heading</Label>
              <Input {...sectionForm.register("heading")} />
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea rows={3} {...sectionForm.register("subtitle")} />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>CTA Text</Label>
                <Input {...sectionForm.register("ctaText")} />
              </div>
              <div className="space-y-2">
                <Label>CTA Link</Label>
                <Input {...sectionForm.register("ctaHref")} placeholder="#careers-open-positions" />
              </div>
            </div>
            <CareersPageFormFooter
              end={
                <Button type="submit" disabled={savingSection}>
                  {savingSection ? "Saving…" : "Save Section"}
                </Button>
              }
            />
          </TabsContent>

          <TabsContent value="appearance" className="max-w-2xl space-y-6">
            <div className="space-y-2">
              <Label>Background Type</Label>
              <Select
                value={backgroundType}
                onValueChange={(v) =>
                  sectionForm.setValue("backgroundType", v as "image" | "gradient")
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="gradient">Gradient</SelectItem>
                  <SelectItem value="image">Image</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {backgroundType === "image" ? (
              <>
                <CmsImageUploadField
                  label="Desktop Background"
                  preset="heroDesktop"
                  folder="cms/careers/why-work"
                  storageFileName="background-desktop"
                  value={desktopBg}
                  onChange={setDesktopBg}
                />
                <CmsImageUploadField
                  label="Mobile Background (optional)"
                  preset="heroMobile"
                  folder="cms/careers/why-work"
                  storageFileName="background-mobile"
                  value={mobileBg}
                  onChange={setMobileBg}
                />
              </>
            ) : (
              <div className="space-y-4 rounded-lg border p-4">
                <div className="space-y-2">
                  <Label>Gradient Type</Label>
                  <Select
                    value={sectionForm.watch("gradientType")}
                    onValueChange={(v) =>
                      sectionForm.setValue("gradientType", v as "linear" | "radial")
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="linear">Linear</SelectItem>
                      <SelectItem value="radial">Radial</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-4 sm:grid-cols-3">
                  <ColorField
                    label="Color 1"
                    value={sectionForm.watch("gradientColor1")}
                    onChange={(v) => sectionForm.setValue("gradientColor1", v)}
                  />
                  <ColorField
                    label="Color 2"
                    value={sectionForm.watch("gradientColor2")}
                    onChange={(v) => sectionForm.setValue("gradientColor2", v)}
                  />
                  <ColorField
                    label="Color 3 (optional)"
                    value={sectionForm.watch("gradientColor3")}
                    onChange={(v) => sectionForm.setValue("gradientColor3", v)}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Direction</Label>
                  <Select
                    value={sectionForm.watch("gradientDirection")}
                    onValueChange={(v) =>
                      sectionForm.setValue(
                        "gradientDirection",
                        v as SectionValues["gradientDirection"],
                      )
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="to-r">Left to right</SelectItem>
                      <SelectItem value="to-b">Top to bottom</SelectItem>
                      <SelectItem value="to-br">Diagonal</SelectItem>
                      <SelectItem value="radial">Radial center</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            <div className="space-y-4 rounded-lg border p-4">
              <ColorField
                label="Overlay Color"
                value={sectionForm.watch("overlayColor")}
                onChange={(v) => sectionForm.setValue("overlayColor", v)}
              />
              <div className="space-y-2">
                <Label>Overlay Opacity ({sectionForm.watch("overlayOpacity")})</Label>
                <Input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  {...sectionForm.register("overlayOpacity")}
                />
              </div>
            </div>

            <CareersPageFormFooter
              end={
                <Button type="submit" disabled={savingSection}>
                  {savingSection ? "Saving…" : "Save Appearance"}
                </Button>
              }
            />
          </TabsContent>

          <TabsContent value="styling" className="max-w-2xl space-y-6">
            <div className="grid gap-4 sm:grid-cols-2">
              <ColorField
                label="Eyebrow Color"
                value={sectionForm.watch("eyebrowColor")}
                onChange={(v) => sectionForm.setValue("eyebrowColor", v)}
              />
              <ColorField
                label="Heading Color"
                value={sectionForm.watch("headingColor")}
                onChange={(v) => sectionForm.setValue("headingColor", v)}
              />
              <ColorField
                label="Description Color"
                value={sectionForm.watch("descriptionColor")}
                onChange={(v) => sectionForm.setValue("descriptionColor", v)}
              />
              <ColorField
                label="CTA Color"
                value={sectionForm.watch("ctaColor")}
                onChange={(v) => sectionForm.setValue("ctaColor", v)}
              />
            </div>

            <div className="space-y-4 rounded-lg border p-4">
              <h3 className="font-medium">Glass Card Styling</h3>
              <ColorField
                label="Card Background"
                value={sectionForm.watch("cardBackgroundColor")}
                onChange={(v) => sectionForm.setValue("cardBackgroundColor", v)}
              />
              <ColorField
                label="Card Border"
                value={sectionForm.watch("cardBorderColor")}
                onChange={(v) => sectionForm.setValue("cardBorderColor", v)}
              />
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Card Opacity ({sectionForm.watch("cardOpacity")})</Label>
                  <Input
                    type="range"
                    min={0.05}
                    max={1}
                    step={0.05}
                    {...sectionForm.register("cardOpacity")}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Blur ({sectionForm.watch("cardBlur")}px)</Label>
                  <Input
                    type="range"
                    min={0}
                    max={40}
                    step={1}
                    {...sectionForm.register("cardBlur")}
                  />
                </div>
              </div>
              <div className="grid gap-4 sm:grid-cols-3">
                <ColorField
                  label="Title Color"
                  value={sectionForm.watch("cardTitleColor")}
                  onChange={(v) => sectionForm.setValue("cardTitleColor", v)}
                />
                <ColorField
                  label="Description Color"
                  value={sectionForm.watch("cardDescriptionColor")}
                  onChange={(v) => sectionForm.setValue("cardDescriptionColor", v)}
                />
                <ColorField
                  label="Card CTA Color"
                  value={sectionForm.watch("cardCtaColor")}
                  onChange={(v) => sectionForm.setValue("cardCtaColor", v)}
                />
              </div>
            </div>

            <CareersPageFormFooter
              end={
                <Button type="submit" disabled={savingSection}>
                  {savingSection ? "Saving…" : "Save Styling"}
                </Button>
              }
            />
          </TabsContent>

          <TabsContent value="carousel" className="max-w-2xl space-y-4">
            <div className="flex items-center justify-between rounded-lg border p-4">
              <div>
                <Label>Auto-scroll</Label>
                <p className="text-sm text-muted-foreground">
                  Disabled automatically when reduced motion is preferred.
                </p>
              </div>
              <Switch
                checked={sectionForm.watch("carouselAutoScroll")}
                onCheckedChange={(v) => sectionForm.setValue("carouselAutoScroll", v)}
              />
            </div>
            <div className="flex items-center justify-between rounded-lg border p-4">
              <Label>Loop carousel</Label>
              <Switch
                checked={sectionForm.watch("carouselLoop")}
                onCheckedChange={(v) => sectionForm.setValue("carouselLoop", v)}
              />
            </div>
            <div className="space-y-2">
              <Label>Scroll Speed ({sectionForm.watch("carouselScrollSpeed")})</Label>
              <Input
                type="range"
                min={0.5}
                max={5}
                step={0.5}
                {...sectionForm.register("carouselScrollSpeed")}
              />
            </div>
            <div className="grid gap-4 sm:grid-cols-3">
              <div className="space-y-2">
                <Label>Cards per view (desktop)</Label>
                <Input
                  type="number"
                  min={1}
                  max={3}
                  {...sectionForm.register("carouselCardsPerViewDesktop")}
                />
              </div>
              <div className="space-y-2">
                <Label>Cards per view (tablet)</Label>
                <Input
                  type="number"
                  min={1}
                  max={3}
                  {...sectionForm.register("carouselCardsPerViewTablet")}
                />
              </div>
              <div className="space-y-2">
                <Label>Cards per view (mobile)</Label>
                <Input
                  type="number"
                  min={1}
                  max={2}
                  {...sectionForm.register("carouselCardsPerViewMobile")}
                />
              </div>
            </div>
            <CareersPageFormFooter
              end={
                <Button type="submit" disabled={savingSection}>
                  {savingSection ? "Saving…" : "Save Carousel Settings"}
                </Button>
              }
            />
          </TabsContent>
        </form>

        <TabsContent value="cards">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold">Feature Cards</h2>
            <Button onClick={openCreate} size="sm" disabled={savingCard}>
              <Plus className="mr-1 h-4 w-4" />
              Add Card
            </Button>
          </div>
          <div className="rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Order</TableHead>
                  <TableHead>Title</TableHead>
                  <TableHead>Enabled</TableHead>
                  <TableHead>Image</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {cards.map((card) => (
                  <TableRow key={card.id}>
                    <TableCell>{card.order}</TableCell>
                    <TableCell>{card.title}</TableCell>
                    <TableCell>{card.enabled !== false ? "Yes" : "No"}</TableCell>
                    <TableCell>{card.imageUrl ? "Yes" : card.icon}</TableCell>
                    <TableCell className="text-right">
                      <Button variant="ghost" size="sm" onClick={() => openEdit(card)}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => void removeCard(card.id)}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </TabsContent>
      </Tabs>

      <Dialog
        open={dialogOpen}
        onOpenChange={(open) => {
          if (savingCard) return;
          setDialogOpen(open);
          if (!open) setSavingCard(false);
        }}
      >
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Card" : "Add Card"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={cardForm.handleSubmit(saveCard)} className="space-y-4">
            <CmsImageUploadField
              label="Featured Image"
              preset="card4x3"
              folder="cms/careers/why-work/cards"
              storageFileName={editing?.id ?? "new-card"}
              value={cardImage}
              onChange={setCardImage}
            />
            <div className="space-y-2">
              <Label>Icon (fallback when no image)</Label>
              <CareersIconSelect
                value={cardForm.watch("icon")}
                onChange={(v) => cardForm.setValue("icon", v)}
              />
            </div>
            <div className="space-y-2">
              <Label>Title</Label>
              <Input {...cardForm.register("title")} />
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea rows={3} {...cardForm.register("description")} />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>CTA Text (optional)</Label>
                <Input {...cardForm.register("ctaText")} />
              </div>
              <div className="space-y-2">
                <Label>CTA Link (optional)</Label>
                <Input {...cardForm.register("ctaLink")} placeholder="#careers-open-positions" />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Order</Label>
              <Input type="number" {...cardForm.register("order")} />
            </div>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <Label>Enabled</Label>
              <Switch
                checked={cardForm.watch("enabled")}
                onCheckedChange={(v) => cardForm.setValue("enabled", v)}
              />
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                disabled={savingCard}
                onClick={() => {
                  setSavingCard(false);
                  setDialogOpen(false);
                }}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={savingCard}>
                {savingCard && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {savingCard ? "Saving…" : "Save Card"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </section>
  );
}
