"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import {
  fetchCareersOpenPositionsContentAdmin,
  saveCareersOpenPositionsContentAdmin,
} from "@/lib/admin-cms-api";
import {
  CareersPageAdminBackLink,
  CareersPageAdminHeader,
  CareersPageFormFooter,
} from "@/components/admin/careers-page/CareersPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z.object({
  heading: z.string().min(1, "Heading is required"),
  subtitle: z.string(),
  featuredCount: z.coerce.number().int().min(1).max(12),
});

type FormValues = z.infer<typeof formSchema>;

export function CareersOpenPositionsManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: { heading: "", subtitle: "", featuredCount: 6 },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchCareersOpenPositionsContentAdmin();
      if (data) {
        form.reset({
          heading: data.heading,
          subtitle: data.subtitle,
          featuredCount: data.featuredCount,
        });
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to load");
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    void loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    if (saving) return;
    setSaving(true);
    try {
      await saveCareersOpenPositionsContentAdmin({
        heading: values.heading.trim(),
        subtitle: values.subtitle.trim(),
        featuredCount: values.featuredCount,
      });
      toast.success("Open positions section saved.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Skeleton className="h-64 w-full" />;

  return (
    <section>
      <CareersPageAdminBackLink />
      <CareersPageAdminHeader
        title="Open Positions Preview"
        description="Heading for the featured jobs section. Jobs are managed in Jobs Portal."
      />
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 max-w-2xl">
        <div className="space-y-2">
          <Label>Section Heading</Label>
          <Input {...form.register("heading")} />
        </div>
        <div className="space-y-2">
          <Label>Subtitle</Label>
          <Textarea rows={2} {...form.register("subtitle")} />
        </div>
        <div className="space-y-2">
          <Label>Number of Featured Jobs to Show</Label>
          <Input type="number" min={1} max={12} {...form.register("featuredCount")} />
        </div>
        <CareersPageFormFooter
          end={
            <Button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save Section"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
