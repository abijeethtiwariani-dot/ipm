import type { ReactNode } from "react";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export function CareersPageAdminBackLink() {
  return (
    <Link
      href="/admin/careers-page-content"
      className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6"
    >
      <ArrowLeft className="w-4 h-4" />
      Back to Careers page content
    </Link>
  );
}

export function CareersPageAdminHeader({
  title,
  description,
}: {
  title: string;
  description: string;
}) {
  return (
    <header className="mb-8">
      <h1 className="text-3xl font-heading font-bold text-foreground">{title}</h1>
      <p className="text-sm text-muted-foreground mt-1">{description}</p>
      <p className="text-xs text-muted-foreground mt-2">
        Save to publish this section on the public careers page. No content appears until saved.
      </p>
    </header>
  );
}

export function CareersPageFormFooter({ end }: { end: ReactNode }) {
  return (
    <div className="flex justify-end border-t border-border pt-6">{end}</div>
  );
}
