"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  fetchCareersLoveWorkingContentAdmin,
  saveCareersLoveWorkingContentAdmin,
} from "@/lib/admin-cms-api";
import {
  CmsHeroImagePairField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import {
  CareersPageAdminBackLink,
  CareersPageAdminHeader,
  CareersPageFormFooter,
} from "@/components/admin/careers-page/CareersPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string(),
  stats: z.array(
    z.object({
      value: z.string().min(1),
      label: z.string().min(1),
    }),
  ),
});

type FormValues = z.infer<typeof formSchema>;

export function CareersLoveWorkingManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [desktopImage, setDesktopImage] = useState<CmsImageUploadValue | null>(null);
  const [mobileImage, setMobileImage] = useState<CmsImageUploadValue | null>(null);
  const [desktopPendingPreview, setDesktopPendingPreview] = useState<string | null>(null);
  const [mobilePendingPreview, setMobilePendingPreview] = useState<string | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      stats: [{ value: "", label: "" }],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "stats",
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchCareersLoveWorkingContentAdmin();
      if (data) {
        setDesktopImage(
          data.backgroundImageUrl ? { url: data.backgroundImageUrl } : null,
        );
        setMobileImage(
          data.backgroundMobileImageUrl
            ? { url: data.backgroundMobileImageUrl }
            : null,
        );
        form.reset({
          title: data.title,
          description: data.description,
          stats: data.stats.length > 0 ? data.stats : [{ value: "", label: "" }],
        });
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to load");
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    void loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    if (saving) return;
    if (!desktopImage?.url) {
      toast.error("Please upload a desktop background image");
      return;
    }
    setSaving(true);
    try {
      await saveCareersLoveWorkingContentAdmin({
        title: values.title.trim(),
        description: values.description.trim(),
        backgroundImageUrl: desktopImage.url,
        backgroundMobileImageUrl: mobileImage?.url,
        stats: values.stats
          .filter((s) => s.value.trim() && s.label.trim())
          .map((s) => ({ value: s.value.trim(), label: s.label.trim() })),
      });
      toast.success("Section saved.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Skeleton className="h-96 w-full" />;

  return (
    <section>
      <CareersPageAdminBackLink />
      <CareersPageAdminHeader
        title="Why People Love Working Here"
        description="Full-width image section with statistics."
      />
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 max-w-2xl">
        <div className="space-y-2">
          <Label>Title</Label>
          <Input {...form.register("title")} />
        </div>
        <div className="space-y-2">
          <Label>Description</Label>
          <Textarea rows={3} {...form.register("description")} />
        </div>
        <CmsHeroImagePairField
          desktop={desktopImage}
          mobile={mobileImage}
          onDesktopChange={setDesktopImage}
          onMobileChange={setMobileImage}
          folder="cms/careers/love-working"
          fileBaseName="background"
          desktopPendingPreview={desktopPendingPreview}
          mobilePendingPreview={mobilePendingPreview}
          onDesktopPendingPreviewChange={setDesktopPendingPreview}
          onMobilePendingPreviewChange={setMobilePendingPreview}
        />
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label>Statistics</Label>
            <Button type="button" variant="outline" size="sm" onClick={() => append({ value: "", label: "" })}>
              <Plus className="mr-1 h-4 w-4" />
              Add Stat
            </Button>
          </div>
          {fields.map((field, index) => (
            <div key={field.id} className="flex gap-2 items-end">
              <div className="flex-1 space-y-1">
                <Label className="text-xs">Value</Label>
                <Input {...form.register(`stats.${index}.value`)} placeholder="95%" />
              </div>
              <div className="flex-1 space-y-1">
                <Label className="text-xs">Label</Label>
                <Input {...form.register(`stats.${index}.label`)} placeholder="Employee Satisfaction" />
              </div>
              {fields.length > 1 && (
                <Button type="button" variant="ghost" size="icon" onClick={() => remove(index)}>
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              )}
            </div>
          ))}
        </div>
        <CareersPageFormFooter
          end={
            <Button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save Section"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
