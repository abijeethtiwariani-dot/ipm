"use client";

import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Trash2 } from "lucide-react";

interface AdminBulkSelectionBarProps {
  filteredCount: number;
  selectedCount: number;
  allFilteredSelected: boolean;
  onToggleSelectAll: () => void;
  onBulkDelete: () => void;
  deleting?: boolean;
  entityLabel?: string;
}

export function AdminBulkSelectionBar({
  filteredCount,
  selectedCount,
  allFilteredSelected,
  onToggleSelectAll,
  onBulkDelete,
  deleting = false,
  entityLabel = "items",
}: AdminBulkSelectionBarProps) {
  if (filteredCount === 0) return null;

  return (
    <div className="flex flex-wrap items-center gap-3 rounded-lg border bg-muted/30 px-3 py-2">
      <div className="flex items-center gap-2">
        <Checkbox
          id="select-all-filtered"
          checked={allFilteredSelected}
          onCheckedChange={onToggleSelectAll}
          aria-label="Select all filtered rows"
        />
        <Label htmlFor="select-all-filtered" className="text-sm font-normal cursor-pointer">
          Select all ({filteredCount} {entityLabel})
        </Label>
      </div>
      {selectedCount > 0 && (
        <>
          <span className="text-sm text-muted-foreground">
            {selectedCount} selected
          </span>
          <Button
            type="button"
            variant="destructive"
            size="sm"
            className="gap-1"
            onClick={onBulkDelete}
            disabled={deleting}
          >
            <Trash2 className="w-4 h-4" />
            {deleting ? "Deleting..." : "Delete selected"}
          </Button>
        </>
      )}
    </div>
  );
}
