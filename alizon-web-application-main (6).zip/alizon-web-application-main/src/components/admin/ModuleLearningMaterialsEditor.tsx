"use client";

import { useCallback, useEffect, useState } from "react";
import { FileText, Link2, Trash2, Video, Plus } from "lucide-react";
import { toast } from "sonner";
import {
  apiCreateModuleResource,
  apiDeleteModuleResource,
  apiFetchModuleResources,
  apiUploadModuleDocument,
} from "@/lib/admin-programs-api";
import {
  isAllowedModuleDocument,
  isValidDriveOrLinkUrl,
  isValidYoutubeUrl,
} from "@/lib/module-resource-utils";
import type { ModuleResource } from "@/types/program";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export type LearningMaterialKind = "document" | "drive" | "youtube";

export type PendingLearningMaterial =
  | { id: string; kind: "document"; title: string; file: File }
  | { id: string; kind: "drive"; title: string; url: string }
  | { id: string; kind: "youtube"; title: string; url: string };

const KIND_OPTIONS: { value: LearningMaterialKind; label: string }[] = [
  { value: "document", label: "Document (PDF, DOC, DOCX)" },
  { value: "drive", label: "Google Drive URL" },
  { value: "youtube", label: "YouTube Video URL" },
];

function kindLabel(kind: LearningMaterialKind) {
  return KIND_OPTIONS.find((o) => o.value === kind)?.label ?? kind;
}

export async function persistPendingLearningMaterials(
  programId: string,
  moduleId: string,
  pending: PendingLearningMaterial[],
) {
  for (const item of pending) {
    if (item.kind === "document") {
      const uploaded = await apiUploadModuleDocument(
        programId,
        moduleId,
        item.file,
        item.title,
      );
      await apiCreateModuleResource(programId, moduleId, uploaded);
    } else {
      await apiCreateModuleResource(programId, moduleId, {
        title: item.title,
        type: item.kind === "youtube" ? "youtube" : "link",
        url: item.url,
      });
    }
  }
}

export function ModuleLearningMaterialsEditor({
  programId,
  moduleId,
  pending,
  onPendingChange,
  disabled,
}: {
  programId: string;
  moduleId?: string | null;
  pending: PendingLearningMaterial[];
  onPendingChange: (items: PendingLearningMaterial[]) => void;
  disabled?: boolean;
}) {
  const [kind, setKind] = useState<LearningMaterialKind>("document");
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [existing, setExisting] = useState<ModuleResource[]>([]);
  const [loadingExisting, setLoadingExisting] = useState(false);

  const loadExisting = useCallback(async () => {
    if (!moduleId) {
      setExisting([]);
      return;
    }
    setLoadingExisting(true);
    try {
      setExisting(await apiFetchModuleResources(programId, moduleId));
    } catch {
      setExisting([]);
    } finally {
      setLoadingExisting(false);
    }
  }, [moduleId, programId]);

  useEffect(() => {
    void loadExisting();
  }, [loadExisting]);

  const resetDraft = () => {
    setTitle("");
    setUrl("");
    setFile(null);
  };

  const addPending = () => {
    const trimmedTitle = title.trim();
    if (kind === "document") {
      if (!file) {
        toast.error("Select a document to upload.");
        return;
      }
      const validation = isAllowedModuleDocument(file.name, file.type, file.size);
      if (!validation.ok) {
        toast.error(validation.message);
        return;
      }
      onPendingChange([
        ...pending,
        {
          id: crypto.randomUUID(),
          kind: "document",
          title: trimmedTitle || file.name,
          file,
        },
      ]);
    } else if (kind === "drive") {
      if (!trimmedTitle || !url.trim()) {
        toast.error("Enter a title and Google Drive URL.");
        return;
      }
      if (!isValidDriveOrLinkUrl(url)) {
        toast.error("Enter a valid URL.");
        return;
      }
      onPendingChange([
        ...pending,
        { id: crypto.randomUUID(), kind: "drive", title: trimmedTitle, url: url.trim() },
      ]);
    } else {
      if (!trimmedTitle || !url.trim()) {
        toast.error("Enter a title and YouTube URL.");
        return;
      }
      if (!isValidYoutubeUrl(url)) {
        toast.error("Enter a valid YouTube URL.");
        return;
      }
      onPendingChange([
        ...pending,
        { id: crypto.randomUUID(), kind: "youtube", title: trimmedTitle, url: url.trim() },
      ]);
    }
    resetDraft();
    toast.success("Material added to list.");
  };

  const removePending = (id: string) => {
    onPendingChange(pending.filter((item) => item.id !== id));
  };

  const removeExisting = async (resourceId: string) => {
    if (!moduleId) return;
    try {
      await apiDeleteModuleResource(programId, moduleId, resourceId);
      toast.success("Resource removed.");
      await loadExisting();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Delete failed.");
    }
  };

  return (
    <div className="space-y-4 rounded-lg border border-dashed p-4">
      <div>
        <h4 className="text-sm font-semibold">Learning Materials</h4>
        <p className="text-xs text-muted-foreground">
          Add documents, Google Drive links, or YouTube videos for this module.
        </p>
      </div>

      <div className="space-y-3">
        <div className="space-y-2">
          <Label>Material type</Label>
          <Select
            value={kind}
            onValueChange={(value) => {
              setKind(value as LearningMaterialKind);
              resetDraft();
            }}
            disabled={disabled}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {KIND_OPTIONS.map((option) => (
                <SelectItem key={option.value} value={option.value}>
                  {option.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label>Title</Label>
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Lecture notes"
            disabled={disabled}
          />
        </div>

        {kind === "document" ? (
          <div className="space-y-2">
            <Label>Upload document</Label>
            <Input
              key="document"
              type="file"
              accept=".pdf,.doc,.docx"
              disabled={disabled}
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            />
          </div>
        ) : (
          <div className="space-y-2">
            <Label>{kind === "youtube" ? "YouTube URL" : "Google Drive URL"}</Label>
            <Input
              key="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder={
                kind === "youtube"
                  ? "https://www.youtube.com/watch?v=..."
                  : "https://drive.google.com/..."
              }
              disabled={disabled}
            />
          </div>
        )}

        <Button type="button" variant="secondary" onClick={addPending} disabled={disabled}>
          <Plus className="mr-2 h-4 w-4" />
          Add to list
        </Button>
      </div>

      {pending.length > 0 ? (
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground">Pending (saved with module)</p>
          <ul className="space-y-2">
            {pending.map((item) => (
              <li
                key={item.id}
                className="flex items-center justify-between gap-2 rounded-md border bg-muted/30 px-3 py-2 text-sm"
              >
                <span className="flex items-center gap-2 truncate">
                  {item.kind === "document" ? (
                    <FileText className="h-4 w-4 shrink-0" />
                  ) : item.kind === "youtube" ? (
                    <Video className="h-4 w-4 shrink-0" />
                  ) : (
                    <Link2 className="h-4 w-4 shrink-0" />
                  )}
                  <span className="truncate">
                    {item.title} · {kindLabel(item.kind)}
                  </span>
                </span>
                <Button
                  type="button"
                  size="icon"
                  variant="ghost"
                  disabled={disabled}
                  onClick={() => removePending(item.id)}
                >
                  <Trash2 className="h-4 w-4 text-destructive" />
                </Button>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      {moduleId ? (
        <div className="space-y-2">
          <p className="text-xs font-medium text-muted-foreground">
            Saved materials {loadingExisting ? "(loading…)" : `(${existing.length})`}
          </p>
          {existing.length === 0 && !loadingExisting ? (
            <p className="text-xs text-muted-foreground">No saved materials yet.</p>
          ) : (
            <ul className="space-y-2">
              {existing.map((resource) => (
                <li
                  key={resource.id}
                  className="flex items-center justify-between gap-2 rounded-md border px-3 py-2 text-sm"
                >
                  <span className="truncate">
                    {resource.title} · {resource.type.toUpperCase()}
                  </span>
                  <Button
                    type="button"
                    size="icon"
                    variant="ghost"
                    disabled={disabled}
                    onClick={() => void removeExisting(resource.id)}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </div>
      ) : null}
    </div>
  );
}
