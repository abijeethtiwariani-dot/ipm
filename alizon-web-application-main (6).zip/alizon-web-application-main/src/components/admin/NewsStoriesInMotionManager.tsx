"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import type { NewsStoriesInMotionContent } from "@/types/cms";
import {
  fetchNewsStoriesInMotionContentAdmin,
  saveNewsStoriesInMotionContentAdmin,
  uploadCmsImageUrl,
} from "@/lib/admin-cms-api";
import { NewsSectionBackLink } from "@/components/admin/NewsSectionBackLink";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z.object({
  sectionHeading: z.string().min(1, "Section heading is required"),
  subtitle: z.string().min(1, "Subtitle is required"),
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  videoUrl: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export function NewsStoriesInMotionManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [existingImageUrl, setExistingImageUrl] = useState("");

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      sectionHeading: "",
      subtitle: "",
      title: "",
      description: "",
      videoUrl: "",
    },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchNewsStoriesInMotionContentAdmin();
      setExistingImageUrl(data.imageUrl ?? "");
      setImagePreview(data.imageUrl || null);
      form.reset({
        sectionHeading: data.sectionHeading,
        subtitle: data.subtitle,
        title: data.title,
        description: data.description,
        videoUrl: data.videoUrl ?? "",
      });
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load content",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onImageFileChange = (file: File | null) => {
    setImageFile(file);
    if (file) {
      setImagePreview(URL.createObjectURL(file));
    } else {
      setImagePreview(existingImageUrl || null);
    }
  };

  const onSubmit = async (values: FormValues) => {
    const hasImage = Boolean(existingImageUrl) || Boolean(imageFile);
    if (!hasImage) {
      toast.error("Please upload an image");
      return;
    }

    setSaving(true);
    try {
      let imageUrl = existingImageUrl;
      if (imageFile) {
        imageUrl = await uploadCmsImageUrl(
          `cms/news/stories-in-motion/image-${imageFile.name}`,
          imageFile,
        );
      }

      const payload: Omit<NewsStoriesInMotionContent, "updatedAt"> = {
        sectionHeading: values.sectionHeading.trim(),
        subtitle: values.subtitle.trim(),
        title: values.title.trim(),
        description: values.description.trim(),
        imageUrl,
        ...(values.videoUrl?.trim()
          ? { videoUrl: values.videoUrl.trim() }
          : {}),
      };

      await saveNewsStoriesInMotionContentAdmin(payload);
      setExistingImageUrl(imageUrl);
      setImageFile(null);
      toast.success("Stories in Motion section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-2xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-24 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-2xl">
      <NewsSectionBackLink />

      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Stories in Motion
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Video feature block with image, title, and description.
        </p>
      </header>

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="sectionHeading">Section heading</Label>
          <Input id="sectionHeading" {...form.register("sectionHeading")} />
          {form.formState.errors.sectionHeading ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.sectionHeading.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="subtitle">Subtitle</Label>
          <Input id="subtitle" {...form.register("subtitle")} />
          {form.formState.errors.subtitle ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.subtitle.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="title">Title</Label>
          <Input id="title" {...form.register("title")} />
          {form.formState.errors.title ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.title.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description</Label>
          <Textarea id="description" rows={4} {...form.register("description")} />
          {form.formState.errors.description ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.description.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="image">Image</Label>
          {imagePreview ? (
            <div className="relative aspect-[16/9] w-full max-w-xl overflow-hidden rounded-md border border-border mb-2">
              <Image
                src={imagePreview}
                alt="Preview"
                fill
                className="object-cover"
                unoptimized={imagePreview.startsWith("blob:")}
              />
            </div>
          ) : null}
          <Input
            id="image"
            type="file"
            accept="image/*"
            onChange={(e) => onImageFileChange(e.target.files?.[0] ?? null)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="videoUrl">Video URL (optional)</Label>
          <Input
            id="videoUrl"
            placeholder="https://youtube.com/..."
            {...form.register("videoUrl")}
          />
          <p className="text-xs text-muted-foreground">
            Optional. Used when the block links to or embeds a video.
          </p>
        </div>

        <Button type="submit" disabled={saving}>
          {saving ? "Saving…" : "Save changes"}
        </Button>
      </form>
    </section>
  );
}
