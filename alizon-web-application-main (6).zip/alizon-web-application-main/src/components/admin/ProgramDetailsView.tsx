"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import {
  ArrowLeft,
  Pencil,
  Plus,
  MoreHorizontal,
  Users,
  BookOpen,
  Clock3,
  FileText,
  Download,
  Eye,
  Trash2,
  Link2,
  Video,
  FileType2,
} from "lucide-react";
import { toast } from "sonner";
import { SITE_HOSTNAME } from "@/lib/site-branding";
import {
  apiCreateProgramModule,
  apiDeleteProgramModule,
  apiDeleteModuleResource,
  apiFetchProgramDetails,
  apiUpdateProgramModule,
} from "@/lib/admin-programs-api";
import { mapModuleDoc } from "@/lib/modules";
import {
  mapProgramDoc,
  normalizeAssignmentResubmissionDays,
  normalizeEvaluationMaxMarks,
} from "@/lib/programs";
import { apiUpdateProgram } from "@/lib/admin-programs-api";
import { toDateString } from "@/lib/students";
import {
  DEFAULT_ASSIGNMENT_RESUBMISSION_DAYS,
  DEFAULT_EVALUATION_MAX_MARKS,
  MAX_ASSIGNMENT_RESUBMISSION_DAYS,
  MAX_MARKS_CONFIG,
  MIN_ASSIGNMENT_RESUBMISSION_DAYS,
  MIN_MARKS_CONFIG,
} from "@/lib/student-constants";
import type { ModuleResource, Program, ProgramModule } from "@/types/program";
import type { Student } from "@/types/student";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { OptimizedImage } from "@/components/shared/OptimizedImage";
import { cn } from "@/lib/utils";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ModuleForm } from "@/components/admin/ModuleForm";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const tabs = [
  "Overview",
  "Modules",
  "Resources",
  "Students",
  "Evaluation Marks",
] as const;
type ProgramTab = (typeof tabs)[number];

type ResourceRow = ModuleResource & {
  moduleName: string;
};

export function ProgramDetailsView({ programId }: { programId: string }) {
  const [program, setProgram] = useState<Program | null>(null);
  const [modules, setModules] = useState<ProgramModule[]>([]);
  const [resources, setResources] = useState<ResourceRow[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<ProgramTab>("Overview");
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const [showModule, setShowModule] = useState(false);
  const [editModule, setEditModule] = useState<ProgramModule | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<ProgramModule | null>(null);
  const [deletingModule, setDeletingModule] = useState(false);
  const [resubmissionDays, setResubmissionDays] = useState(
    String(DEFAULT_ASSIGNMENT_RESUBMISSION_DAYS),
  );
  const [savingResubmissionDays, setSavingResubmissionDays] = useState(false);
  const [vivaMaxMarks, setVivaMaxMarks] = useState(String(DEFAULT_EVALUATION_MAX_MARKS));
  const [internshipMaxMarks, setInternshipMaxMarks] = useState(
    String(DEFAULT_EVALUATION_MAX_MARKS),
  );
  const [electiveMaxMarks, setElectiveMaxMarks] = useState(
    String(DEFAULT_EVALUATION_MAX_MARKS),
  );
  const [savingEvaluationMarks, setSavingEvaluationMarks] = useState(false);

  const loadDetails = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const details = await apiFetchProgramDetails(programId);
      const mappedProgram = mapProgramDoc(
        details.program.id,
        details.program as unknown as Record<string, unknown>,
      );
      setProgram(mappedProgram);
      setResubmissionDays(String(mappedProgram.assignmentResubmissionDays));
      setVivaMaxMarks(String(mappedProgram.vivaMaxMarks));
      setInternshipMaxMarks(String(mappedProgram.internshipMaxMarks));
      setElectiveMaxMarks(String(mappedProgram.electiveMaxMarks));
      setModules(
        details.modules.map((m) =>
          mapModuleDoc(programId, m.id, m as unknown as Record<string, unknown>),
        ),
      );
      setStudents(details.students);
      setResources(details.resources);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "Failed to load program.");
    } finally {
      setLoading(false);
    }
  }, [programId]);

  useEffect(() => {
    void loadDetails();
  }, [loadDetails]);

  const onModuleSaved = async () => {
    await loadDetails();
  };

  const onSaveEvaluationMarks = async () => {
    const parsedViva = Number(vivaMaxMarks);
    const parsedInternship = Number(internshipMaxMarks);
    const parsedElective = Number(electiveMaxMarks);
    if (
      !Number.isFinite(parsedViva) ||
      !Number.isFinite(parsedInternship) ||
      !Number.isFinite(parsedElective)
    ) {
      toast.error("Enter valid marks for all evaluation types.");
      return;
    }
    const normalizedViva = normalizeEvaluationMaxMarks(parsedViva);
    const normalizedInternship = normalizeEvaluationMaxMarks(parsedInternship);
    const normalizedElective = normalizeEvaluationMaxMarks(parsedElective);
    setSavingEvaluationMarks(true);
    try {
      await apiUpdateProgram(programId, {
        vivaMaxMarks: normalizedViva,
        internshipMaxMarks: normalizedInternship,
        electiveMaxMarks: normalizedElective,
      });
      setVivaMaxMarks(String(normalizedViva));
      setInternshipMaxMarks(String(normalizedInternship));
      setElectiveMaxMarks(String(normalizedElective));
      toast.success("Evaluation marks configuration saved.");
      await loadDetails();
    } catch (saveError) {
      toast.error(
        saveError instanceof Error
          ? saveError.message
          : "Failed to save evaluation marks.",
      );
    } finally {
      setSavingEvaluationMarks(false);
    }
  };

  const onSaveResubmissionDays = async () => {
    const parsed = Number(resubmissionDays);
    if (!Number.isFinite(parsed)) {
      toast.error("Enter a valid number of days.");
      return;
    }
    const normalized = normalizeAssignmentResubmissionDays(parsed);
    setSavingResubmissionDays(true);
    try {
      await apiUpdateProgram(programId, {
        assignmentResubmissionDays: normalized,
      });
      toast.success("Resubmission window updated.");
      await loadDetails();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Save failed.");
    } finally {
      setSavingResubmissionDays(false);
    }
  };

  const onDeleteResource = async (resource: ResourceRow) => {
    try {
      await apiDeleteModuleResource(programId, resource.moduleId, resource.id);
      toast.success("Resource deleted.");
      await loadDetails();
    } catch (deleteError) {
      toast.error(deleteError instanceof Error ? deleteError.message : "Delete failed.");
    }
  };

  const onDeleteModule = async (moduleId: string) => {
    setDeletingModule(true);
    try {
      await apiDeleteProgramModule(programId, moduleId);
      toast.success("Module deleted.");
      await loadDetails();
    } catch (deleteError) {
      toast.error(deleteError instanceof Error ? deleteError.message : "Delete failed.");
    } finally {
      setDeletingModule(false);
      setDeleteTarget(null);
    }
  };

  const iconForResourceType = (type: ModuleResource["type"]) => {
    if (type === "video_file" || type === "youtube") return Video;
    if (type === "link") return Link2;
    return FileType2;
  };

  if (loading) {
    return <div className="rounded-xl border bg-card p-6 text-sm text-muted-foreground">Loading program details...</div>;
  }

  if (error || !program) {
    return (
      <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-6 text-sm text-destructive">
        {error ?? "Program not found."}
      </div>
    );
  }

  return (
    <div className="max-w-7xl space-y-6">
      <Link
        href="/admin/programs"
        className="inline-flex items-center gap-1 text-sm text-muted-foreground transition hover:text-primary"
      >
        <ArrowLeft className="h-4 w-4" /> Back to Programs
      </Link>

      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        <div className="relative h-48 bg-muted md:h-64">
          <OptimizedImage image={program.banner} alt={program.name} fill />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-4 left-6 right-6 flex items-end justify-between gap-4">
            <div className="text-white">
              <Badge className="bg-white text-primary">{program.status}</Badge>
              <h1 className="mt-2 text-2xl font-bold md:text-4xl">{program.name}</h1>
              <p className="mt-1 max-w-2xl text-sm text-white/80">{program.shortDescription}</p>
            </div>
            <Button asChild className="bg-white text-primary hover:bg-white/90">
              <Link href={`/admin/programs/${program.id}/edit`}>
                <Pencil className="mr-2 h-4 w-4" /> Edit Program
              </Link>
            </Button>
          </div>
        </div>
        <div className="grid grid-cols-2 divide-x divide-border border-t border-border md:grid-cols-4">
          <Meta icon={<Clock3 className="h-4 w-4" />} label="Duration" value={program.duration || "N/A"} />
          <Meta icon={<BookOpen className="h-4 w-4" />} label="Modules" value={String(modules.length)} />
          <Meta icon={<Users className="h-4 w-4" />} label="Students" value={String(students.length)} />
          <Meta icon={<FileText className="h-4 w-4" />} label="Category" value={program.category || "General"} />
        </div>
      </div>

      <div className="-mx-4 flex gap-1 overflow-x-auto border-b border-border px-4 lg:mx-0 lg:px-0">
        {tabs.map((tabItem) => (
          <button
            key={tabItem}
            onClick={() => setTab(tabItem)}
            className={cn(
              "whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-medium transition",
              tab === tabItem
                ? "border-primary text-primary"
                : "border-transparent text-muted-foreground hover:text-foreground",
            )}
          >
            {tabItem}
          </button>
        ))}
      </div>

      <div className="animate-in fade-in duration-200">
        {tab === "Overview" ? (
          <div className="grid gap-6 lg:grid-cols-3">
            <div className="rounded-2xl border border-border bg-card p-6 lg:col-span-2">
              <h3 className="mb-3 font-semibold">About this program</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">
                {program.fullDescription || "No full description available."}
              </p>
              <div className="mt-6 border-t border-border pt-6">
                <h4 className="mb-3 text-sm font-medium">SEO Preview</h4>
                <div className="space-y-1 text-xs">
                  <div className="truncate text-primary">{SITE_HOSTNAME}/programs/{program.slug}</div>
                  <div className="font-medium">{program.seoTitle || `${program.name} | Alizon CMS`}</div>
                  <div className="text-muted-foreground">
                    {program.seoDescription || program.shortDescription || "Program details and curriculum."}
                  </div>
                </div>
              </div>
            </div>
            <div className="space-y-4 rounded-2xl border border-border bg-card p-6">
              <h3 className="font-semibold">Quick stats</h3>
              <Quick label="Created" value={toDateString(program.createdAt)} />
              <Quick label="Modules" value={`${modules.length} configured`} />
              <Quick label="Resources" value={`${resources.length} files`} />
            </div>
          </div>
        ) : null}

        {tab === "Modules" ? (
          <>
            <Card className="mb-4 border border-border">
              <CardContent className="p-4 space-y-3">
                <div>
                  <Label htmlFor="resubmission-days">
                    Assignment resubmission window (days)
                  </Label>
                  <p className="text-xs text-muted-foreground mt-1">
                    Students may resubmit a rejected assignment within this many days
                    after it was graded.
                  </p>
                </div>
                <div className="flex flex-wrap items-end gap-3">
                  <Input
                    id="resubmission-days"
                    type="number"
                    min={MIN_ASSIGNMENT_RESUBMISSION_DAYS}
                    max={MAX_ASSIGNMENT_RESUBMISSION_DAYS}
                    value={resubmissionDays}
                    onChange={(e) => setResubmissionDays(e.target.value)}
                    className="w-32"
                  />
                  <Button
                    type="button"
                    onClick={() => void onSaveResubmissionDays()}
                    disabled={savingResubmissionDays}
                  >
                    {savingResubmissionDays ? "Saving..." : "Save"}
                  </Button>
                </div>
              </CardContent>
            </Card>

            <div className="mb-4 flex items-center justify-between">
              <p className="text-sm text-muted-foreground">{modules.length} modules</p>
              <Button onClick={() => setShowModule(true)}>
                <Plus className="mr-2 h-4 w-4" /> Add Module
              </Button>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {modules.map((moduleItem) => (
                <div key={moduleItem.id} className="rounded-2xl border border-border bg-card p-5 transition hover:-translate-y-0.5 hover:shadow-sm">
                  <div className="mb-3 flex items-start justify-between">
                    <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 font-bold text-primary">
                      {moduleItem.code.slice(0, 2) || "MD"}
                    </div>
                    <DropdownMenu
                      open={openMenu === moduleItem.id}
                      onOpenChange={(open) => setOpenMenu(open ? moduleItem.id : null)}
                    >
                      <DropdownMenuTrigger asChild>
                        <button className="rounded-md p-1.5 hover:bg-muted" aria-label="Module actions">
                          <MoreHorizontal className="h-4 w-4" />
                        </button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-36">
                        <DropdownMenuItem
                          onClick={() => {
                            setOpenMenu(null);
                            setEditModule(moduleItem);
                            setShowModule(true);
                          }}
                        >
                          <Pencil className="mr-2 h-4 w-4" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          className="text-destructive focus:text-destructive"
                          onClick={() => {
                            setOpenMenu(null);
                            setDeleteTarget(moduleItem);
                          }}
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                  <div className="font-mono text-xs text-muted-foreground">{moduleItem.code || "—"}</div>
                  <div className="mt-0.5 font-semibold">{moduleItem.name}</div>
                  <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{moduleItem.description || "No description."}</p>
                  <div className="mt-4 flex items-center gap-2 border-t border-border pt-4 text-xs text-muted-foreground">
                    <span>{moduleItem.assignmentTotalMarks} assignment marks</span>
                    <span>·</span>
                    <span>{moduleItem.lessonCount} lessons</span>
                    <span>·</span>
                    <span>{moduleItem.fileCount} files</span>
                    <span>·</span>
                    <span>{moduleItem.videoCount} videos</span>
                  </div>
                  <div className="mt-3">
                    <Badge variant={moduleItem.status === "active" ? "default" : "secondary"}>
                      {moduleItem.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </>
        ) : null}

        {tab === "Resources" ? (
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {resources.map((resource) => {
              const Icon = iconForResourceType(resource.type);
              return (
                <div key={resource.id} className="rounded-2xl border border-border bg-card p-5 transition hover:-translate-y-0.5 hover:shadow-sm">
                  <div className="mb-3 flex items-start gap-3">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
                      <Icon className="h-5 w-5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-medium">{resource.title}</div>
                      <div className="text-xs text-muted-foreground">
                        {resource.type.toUpperCase()} · {resource.fileSize ? `${Math.round(resource.fileSize / 1024)} KB` : "N/A"}
                      </div>
                      <div className="text-xs text-muted-foreground">{resource.moduleName}</div>
                    </div>
                  </div>
                  <div className="flex items-center justify-between border-t border-border pt-3">
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Download className="h-3 w-3" /> {resource.downloadCount}
                    </div>
                    <div className="flex gap-1">
                      <a href={resource.url} target="_blank" rel="noreferrer" className="rounded p-1.5 hover:bg-muted">
                        <Eye className="h-4 w-4" />
                      </a>
                      <a href={resource.url} target="_blank" rel="noreferrer" className="rounded p-1.5 hover:bg-muted">
                        <Download className="h-4 w-4" />
                      </a>
                      <button onClick={() => void onDeleteResource(resource)} className="rounded p-1.5 text-destructive hover:bg-muted">
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
            {resources.length === 0 ? (
              <div className="col-span-full rounded-xl border bg-card p-6 text-sm text-muted-foreground">
                No resources added yet.
              </div>
            ) : null}
          </div>
        ) : null}

        {tab === "Students" ? (
          <div className="overflow-hidden rounded-2xl border border-border bg-card">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>ID</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {students.map((student) => (
                  <TableRow key={student.uid}>
                    <TableCell className="font-medium">{student.name}</TableCell>
                    <TableCell className="font-mono text-xs">{student.registrationId}</TableCell>
                  </TableRow>
                ))}
                {students.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={2} className="py-6 text-center text-sm text-muted-foreground">
                      No students enrolled for this program.
                    </TableCell>
                  </TableRow>
                ) : null}
              </TableBody>
            </Table>
          </div>
        ) : null}

        {tab === "Evaluation Marks" ? (
          <Card className="max-w-lg border border-border">
            <CardContent className="space-y-6 p-6">
              <div>
                <h3 className="font-semibold">Evaluation Marks</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  Maximum marks for viva, internship, and elective evaluations for
                  students enrolled in this program.
                </p>
              </div>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="viva-max-marks">Viva Maximum Marks</Label>
                  <Input
                    id="viva-max-marks"
                    type="number"
                    min={MIN_MARKS_CONFIG}
                    max={MAX_MARKS_CONFIG}
                    required
                    value={vivaMaxMarks}
                    onChange={(e) => setVivaMaxMarks(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="internship-max-marks">Internship Maximum Marks</Label>
                  <Input
                    id="internship-max-marks"
                    type="number"
                    min={MIN_MARKS_CONFIG}
                    max={MAX_MARKS_CONFIG}
                    required
                    value={internshipMaxMarks}
                    onChange={(e) => setInternshipMaxMarks(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="elective-max-marks">Elective Maximum Marks</Label>
                  <Input
                    id="elective-max-marks"
                    type="number"
                    min={MIN_MARKS_CONFIG}
                    max={MAX_MARKS_CONFIG}
                    required
                    value={electiveMaxMarks}
                    onChange={(e) => setElectiveMaxMarks(e.target.value)}
                  />
                </div>
              </div>
              <Button
                type="button"
                onClick={() => void onSaveEvaluationMarks()}
                disabled={savingEvaluationMarks}
              >
                {savingEvaluationMarks ? "Saving..." : "Save Configuration"}
              </Button>
            </CardContent>
          </Card>
        ) : null}
      </div>

      <ModuleForm
        open={showModule}
        onOpenChange={(open) => {
          setShowModule(open);
          if (!open) setEditModule(null);
        }}
        programId={programId}
        onSaved={onModuleSaved}
        module={editModule}
        createModuleOverride={async (payload) => {
          return apiCreateProgramModule(programId, payload);
        }}
        updateModuleOverride={async (moduleId, payload) => {
          await apiUpdateProgramModule(programId, moduleId, payload);
        }}
      />

      <AlertDialog
        open={Boolean(deleteTarget)}
        onOpenChange={(open) => {
          if (!open && !deletingModule) setDeleteTarget(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete module?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete{" "}
              <span className="font-medium text-foreground">
                {deleteTarget?.name ?? "this module"}
              </span>
              . This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deletingModule}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={deletingModule}
              onClick={(event) => {
                event.preventDefault();
                if (!deleteTarget) return;
                void onDeleteModule(deleteTarget.id);
              }}
            >
              {deletingModule ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function Meta({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="p-4 md:p-5">
      <div className="mb-1 flex items-center gap-2 text-xs text-muted-foreground">
        {icon} {label}
      </div>
      <div className="font-semibold">{value}</div>
    </div>
  );
}

function Quick({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between border-b border-border pb-3 text-sm last:border-0 last:pb-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}
