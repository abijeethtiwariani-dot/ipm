"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import {
  IndianRupee,
  AlertCircle,
  CheckCircle2,
  Users,
  Wallet,
} from "lucide-react";
import { toast } from "sonner";
import { apiFetchFeesDashboard } from "@/lib/admin-fees-api";
import { formatCurrency } from "@/lib/fees";
import type { FeesDashboardStats } from "@/types/fees";
import { FeeStatCard } from "@/components/fees/FeeStatCard";
import { FeeCharts } from "@/components/fees/FeeCharts";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export function FeesDashboard() {
  const [stats, setStats] = useState<FeesDashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await apiFetchFeesDashboard();
      setStats(data);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to load dashboard");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-heading font-bold md:text-3xl">
            Fees & Payments
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Monitor fee collection and pending dues across enrolled students.
          </p>
        </div>
        <Button asChild>
          <Link href="/admin/fees/students">View Student Fees</Link>
        </Button>
      </div>

      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      ) : stats ? (
        <>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            <FeeStatCard
              label="Total Revenue"
              value={formatCurrency(stats.totalRevenue)}
              icon={<IndianRupee className="h-5 w-5" />}
              accent
            />
            <FeeStatCard
              label="Total Pending Fees"
              value={formatCurrency(stats.totalPendingFees)}
              icon={<AlertCircle className="h-5 w-5" />}
            />
            <FeeStatCard
              label="Total Paid Amount"
              value={formatCurrency(stats.totalPaidAmount)}
              icon={<Wallet className="h-5 w-5" />}
            />
            <FeeStatCard
              label="Students with Due"
              value={stats.studentsWithDue}
              icon={<Users className="h-5 w-5" />}
            />
            <FeeStatCard
              label="Fully Paid Students"
              value={stats.fullyPaidStudents}
              icon={<CheckCircle2 className="h-5 w-5" />}
            />
          </div>
          <FeeCharts stats={stats} />
        </>
      ) : null}
    </div>
  );
}
