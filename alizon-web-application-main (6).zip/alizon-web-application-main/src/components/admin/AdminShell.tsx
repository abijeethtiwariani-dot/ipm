"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { signOut, onAuthStateChanged } from "firebase/auth";
import type { LucideIcon } from "lucide-react";
import {
  Award,
  Bell,
  Briefcase,
  MessageSquare,
  FileText,
  Building2,
  ChevronRight,
  ClipboardList,
  FileStack,
  FlaskConical,
  Folder,
  Info,
  Layers,
  GraduationCap,
  Users,
  Home,
  LayoutDashboard,
  LogOut,
  Mail,
  Newspaper,
  PanelBottom,
  UserPlus,
  Wallet,
} from "lucide-react";
import { toast } from "sonner";
import { getFirebaseAuth, isFirebaseConfigured } from "@/lib/firebase";
import { clearAdminSessionCookie } from "@/lib/admin-session";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

type NavItem = {
  href: string;
  label: string;
  icon: LucideIcon;
  exact: boolean;
};

const dashboardNavItem: NavItem = {
  href: "/admin",
  label: "Dashboard",
  icon: LayoutDashboard,
  exact: true,
};

const topLevelNavItems: NavItem[] = [
  { href: "/admin/programs", label: "Programs", icon: Layers, exact: false },
  {
    href: "/admin/students",
    label: "Students",
    icon: GraduationCap,
    exact: false,
  },
  {
    href: "/admin/faculties-staff",
    label: "Faculties & Staff",
    icon: Users,
    exact: false,
  },
  {
    href: "/admin/fees",
    label: "Fees & Payments",
    icon: Wallet,
    exact: false,
  },
  {
    href: "/admin/admissions",
    label: "Admissions",
    icon: UserPlus,
    exact: false,
  },
  {
    href: "/admin/contact-enquiries",
    label: "Contact Us Enquiry",
    icon: Mail,
    exact: false,
  },
  {
    href: "/admin/assignments",
    label: "Assignments",
    icon: ClipboardList,
    exact: false,
  },
  {
    href: "/admin/evaluations",
    label: "Evaluations",
    icon: Award,
    exact: false,
  },
  {
    href: "/admin/grievances",
    label: "Grievances",
    icon: MessageSquare,
    exact: false,
  },
  {
    href: "/admin/jobs-portal",
    label: "Jobs Portal",
    icon: Briefcase,
    exact: false,
  },
  {
    href: "/admin/footer",
    label: "Footer",
    icon: PanelBottom,
    exact: false,
  },
];

const pagesNavItems: Omit<NavItem, "exact">[] = [
  { href: "/admin/news", label: "News", icon: Newspaper },
  {
    href: "/admin/campus-life",
    label: "Campus Life",
    icon: Building2,
  },
  { href: "/admin/home-content", label: "Home Page Content", icon: Home },
  {
    href: "/admin/admission-page-content",
    label: "Admission Page Content",
    icon: FileText,
  },
  {
    href: "/admin/scholarship-page-content",
    label: "Scholarship Page Content",
    icon: GraduationCap,
  },
  {
    href: "/admin/alumni-page-content",
    label: "Alumni Page Content",
    icon: Users,
  },
  {
    href: "/admin/research-page-content",
    label: "Research Page Content",
    icon: FlaskConical,
  },
  {
    href: "/admin/about-page-content",
    label: "About Us Page Content",
    icon: Info,
  },
  { href: "/admin/notifications", label: "Notifications", icon: Bell },
  { href: "/admin/allotment", label: "Allotment", icon: FileStack },
  { href: "/admin/careers-page-content", label: "Careers", icon: Briefcase },
  {
    href: "/admin/contact-page-content",
    label: "Contact Us Page Content",
    icon: Mail,
  },
];

const navLinkClass = (active: boolean, nested = false) =>
  cn(
    "flex items-center gap-3 rounded-lg text-sm font-medium transition-colors",
    nested ? "py-2 pl-9 pr-3" : "px-3 py-2.5",
    active
      ? "bg-primary text-primary-foreground"
      : "text-foreground/80 hover:bg-muted hover:text-foreground",
  );

interface AdminShellProps {
  children: React.ReactNode;
}

export function AdminShell({ children }: AdminShellProps) {
  const pathname = usePathname();
  const router = useRouter();
  const [email, setEmail] = useState<string | null>(null);
  const [pagesExpanded, setPagesExpanded] = useState(false);

  useEffect(() => {
    if (!isFirebaseConfigured()) return;
    const unsubscribe = onAuthStateChanged(getFirebaseAuth(), (user) => {
      setEmail(user?.email ?? null);
    });
    return () => unsubscribe();
  }, []);

  const handleLogout = async () => {
    try {
      await clearAdminSessionCookie();
      await signOut(getFirebaseAuth());
      router.replace("/admin/login");
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to sign out";
      toast.error(message);
    }
  };

  const isActive = (href: string, exact: boolean) => {
    if (exact) return pathname === href;
    return pathname === href || pathname?.startsWith(`${href}/`);
  };

  const isPagesChildActive = pagesNavItems.some((item) =>
    isActive(item.href, false),
  );
  const pagesOpen = pagesExpanded || isPagesChildActive;

  const handlePagesOpenChange = (open: boolean) => {
    setPagesExpanded(open);
  };

  const DashboardIcon = dashboardNavItem.icon;

  return (
    <div className="typography-functional min-h-screen flex bg-muted/30">
      <aside className="w-60 flex-shrink-0 bg-background border-r border-border flex flex-col">
        <header className="p-6 border-b border-border">
          <h1 className="text-lg font-body font-bold text-primary">
            Alizon CMS
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">Admin Panel</p>
        </header>

        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          <Link
            href={dashboardNavItem.href}
            className={navLinkClass(
              isActive(dashboardNavItem.href, dashboardNavItem.exact),
            )}
          >
            <DashboardIcon className="w-4 h-4 flex-shrink-0" />
            {dashboardNavItem.label}
          </Link>

          <Collapsible open={pagesOpen} onOpenChange={handlePagesOpenChange}>
            <CollapsibleTrigger asChild>
              <button
                type="button"
                className={cn(
                  "flex w-full items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                  isPagesChildActive
                    ? "bg-primary text-primary-foreground"
                    : "text-foreground/80 hover:bg-muted hover:text-foreground",
                )}
              >
                <Folder className="w-4 h-4 flex-shrink-0" />
                <span className="flex-1 text-left">Pages</span>
                <ChevronRight
                  className={cn(
                    "w-4 h-4 flex-shrink-0 transition-transform duration-250",
                    pagesOpen && "rotate-90",
                  )}
                />
              </button>
            </CollapsibleTrigger>
            <CollapsibleContent className="overflow-hidden data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down">
              <div className="space-y-0.5 pt-0.5">
                {pagesNavItems.map((item) => {
                  const Icon = item.icon;
                  const active = isActive(item.href, false);
                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={navLinkClass(active, true)}
                    >
                      <Icon className="w-3.5 h-3.5 flex-shrink-0" />
                      {item.label}
                    </Link>
                  );
                })}
              </div>
            </CollapsibleContent>
          </Collapsible>

          {topLevelNavItems.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.href, item.exact);
            return (
              <Link
                key={item.href}
                href={item.href}
                className={navLinkClass(active)}
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <footer className="p-4 border-t border-border space-y-3">
          {email && (
            <p className="text-xs text-muted-foreground truncate px-1">
              {email}
            </p>
          )}
          <Button
            variant="outline"
            size="sm"
            className="w-full justify-start gap-2"
            onClick={handleLogout}
          >
            <LogOut className="w-4 h-4" />
            Logout
          </Button>
        </footer>
      </aside>

      <main className="flex-1 min-w-0 overflow-auto">
        <div className="p-6 md:p-8">{children}</div>
      </main>
    </div>
  );
}
