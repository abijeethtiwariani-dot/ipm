import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

export function NewsSectionBackLink() {
  return (
    <Button variant="ghost" size="sm" className="mb-6 -ml-2" asChild>
      <Link href="/admin/news">
        <ArrowLeft className="w-4 h-4 mr-2" />
        News sections
      </Link>
    </Button>
  );
}
