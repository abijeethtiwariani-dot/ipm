"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { ArrowLeft, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { HomeHeroSlide } from "@/types/cms";
import {
  HOME_HERO_SLIDE_ORDERS,
  MAX_HOME_HERO_SLIDES,
  getHomeHeroSlideOrderLabel,
} from "@/types/cms";
import {
  createHomeHeroSlideAdmin,
  deleteHomeHeroSlideAdmin,
  fetchHomeHeroSlidesAdmin,
  updateHomeHeroSlideAdmin,
  validateHomeHeroSlideLimitAdmin,
  validateHomeHeroSlideOrderAdmin,
} from "@/lib/admin-cms-api";
import {
  CmsHeroImagePairField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { HomeSectionPublishToggle } from "@/components/admin/HomeSectionPublishToggle";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const cardFormSchema = z.object({
  title: z.string().min(1, "Title is required"),
  subtitle: z.string().optional(),
  order: z.string(),
});

type CardFormValues = z.infer<typeof cardFormSchema>;

function formatUpdatedAt(updatedAt: HomeHeroSlide["updatedAt"]): string {
  if (!updatedAt) return "—";
  if (
    typeof updatedAt === "object" &&
    updatedAt !== null &&
    "toDate" in updatedAt &&
    typeof (updatedAt as { toDate: () => Date }).toDate === "function"
  ) {
    return format((updatedAt as { toDate: () => Date }).toDate(), "MMM d, yyyy");
  }
  if (updatedAt instanceof Date) {
    return format(updatedAt, "MMM d, yyyy");
  }
  return "—";
}

function toUploadValue(
  url: string | undefined,
  image?: HomeHeroSlide["image"],
): CmsImageUploadValue | null {
  if (!url?.trim()) return null;
  return { url: url.trim(), image: image ?? null };
}

export function HomeHeroCarouselManager() {
  const [slides, setSlides] = useState<HomeHeroSlide[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingSlide, setEditingSlide] = useState<HomeHeroSlide | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<HomeHeroSlide | null>(null);
  const [desktopImage, setDesktopImage] = useState<CmsImageUploadValue | null>(
    null,
  );
  const [mobileImage, setMobileImage] = useState<CmsImageUploadValue | null>(
    null,
  );
  const [desktopPendingPreview, setDesktopPendingPreview] = useState<
    string | null
  >(null);
  const [mobilePendingPreview, setMobilePendingPreview] = useState<
    string | null
  >(null);
  const submittingRef = useRef(false);

  const form = useForm<CardFormValues>({
    resolver: zodResolver(cardFormSchema),
    defaultValues: {
      title: "",
      subtitle: "",
      order: "1",
    },
  });

  const orderValue = form.watch("order");

  const loadSlides = useCallback(async () => {
    setLoading(true);
    try {
      setSlides(await fetchHomeHeroSlidesAdmin());
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load slides",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadSlides();
  }, [loadSlides]);

  const openCreate = async () => {
    const limitCheck = await validateHomeHeroSlideLimitAdmin();
    if (!limitCheck.ok) {
      toast.error(limitCheck.message);
      return;
    }

    setEditingSlide(null);
    setDesktopImage(null);
    setMobileImage(null);
    setDesktopPendingPreview(null);
    setMobilePendingPreview(null);
    form.reset({
      title: "",
      subtitle: "",
      order: "1",
    });
    setDialogOpen(true);
  };

  const openEdit = (slide: HomeHeroSlide) => {
    setEditingSlide(slide);
    setDesktopImage(toUploadValue(slide.imageUrl, slide.image));
    setMobileImage(toUploadValue(slide.mobileImageUrl, slide.mobileImage));
    setDesktopPendingPreview(null);
    setMobilePendingPreview(null);
    form.reset({
      title: slide.title,
      subtitle: slide.subtitle,
      order: String(slide.order || 1),
    });
    setDialogOpen(true);
  };

  const onSubmit = async (values: CardFormValues) => {
    if (submittingRef.current) return;
    submittingRef.current = true;
    setSaving(true);

    try {
      const order = Number(values.order);
      if (!desktopImage?.url) {
        toast.error("Please upload a desktop banner image");
        return;
      }

      const orderCheck = await validateHomeHeroSlideOrderAdmin(
        order,
        editingSlide?.id,
      );
      if (!orderCheck.ok) {
        toast.error(orderCheck.message);
        return;
      }

      if (!editingSlide) {
        const limitCheck = await validateHomeHeroSlideLimitAdmin();
        if (!limitCheck.ok) {
          toast.error(limitCheck.message);
          return;
        }
      }

      const payload = {
        title: values.title.trim(),
        subtitle: values.subtitle?.trim() ?? "",
        imageUrl: desktopImage.url,
        mobileImageUrl: mobileImage?.url?.trim() || "",
        image: desktopImage.image ?? null,
        mobileImage: mobileImage?.image ?? null,
        order,
      };

      if (editingSlide) {
        await updateHomeHeroSlideAdmin(editingSlide.id, payload);
        toast.success("Slide updated");
      } else {
        await createHomeHeroSlideAdmin(payload);
        toast.success("Slide created");
      }

      setDialogOpen(false);
      await loadSlides();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save slide",
      );
    } finally {
      submittingRef.current = false;
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteHomeHeroSlideAdmin(deleteTarget.id);
      toast.success("Slide deleted");
      setDeleteTarget(null);
      await loadSlides();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete slide",
      );
    }
  };

  const fileBaseName = `slide-${orderValue}-${editingSlide?.id ?? "new"}`;

  return (
    <section>
      <Button variant="ghost" size="sm" className="mb-4 -ml-2" asChild>
        <Link href="/admin/home-content">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Home page content
        </Link>
      </Button>

      <HomeSectionPublishToggle sectionKey="hero" />

      <header className="flex flex-wrap items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">
            Hero Banner Carousel
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Up to {MAX_HOME_HERO_SLIDES} full-width banner slides on the homepage
            hero.
          </p>
        </div>
        <Button onClick={() => void openCreate()}>
          <Plus className="w-4 h-4 mr-2" />
          Add slide
        </Button>
      </header>

      <section className="bg-card rounded-lg border border-border shadow-sm overflow-hidden">
        {loading ? (
          <section className="p-8 space-y-3">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </section>
        ) : slides.length === 0 ? (
          <p className="p-8 text-sm text-muted-foreground text-center">
            No slides yet. Add up to {MAX_HOME_HERO_SLIDES} hero banner slides.
          </p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="w-20">Preview</TableHead>
                <TableHead>Title</TableHead>
                <TableHead className="w-28">Slide</TableHead>
                <TableHead className="hidden sm:table-cell w-32">Updated</TableHead>
                <TableHead className="w-24 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {slides.map((slide) => (
                <TableRow key={slide.id}>
                  <TableCell>
                    {slide.imageUrl ? (
                      <div className="relative h-12 w-20 overflow-hidden rounded border bg-muted">
                        <Image
                          src={slide.imageUrl}
                          alt=""
                          fill
                          className="object-cover"
                        />
                      </div>
                    ) : (
                      "—"
                    )}
                  </TableCell>
                  <TableCell className="font-medium max-w-[240px]">
                    <span className="line-clamp-2">{slide.title}</span>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {getHomeHeroSlideOrderLabel(slide.order)}
                  </TableCell>
                  <TableCell className="hidden sm:table-cell text-sm text-muted-foreground">
                    {formatUpdatedAt(slide.updatedAt)}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEdit(slide)}
                        aria-label="Edit"
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteTarget(slide)}
                        aria-label="Delete"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </section>

      <Dialog
        open={dialogOpen}
        onOpenChange={(open) => {
          if (!open && saving) return;
          setDialogOpen(open);
        }}
      >
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto bg-background">
          <DialogHeader>
            <DialogTitle className="font-heading text-xl">
              {editingSlide ? "Edit slide" : "New slide"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <CmsHeroImagePairField
              desktop={desktopImage}
              mobile={mobileImage}
              onDesktopChange={setDesktopImage}
              onMobileChange={setMobileImage}
              folder="cms/home-hero"
              fileBaseName={fileBaseName}
              desktopPendingPreview={desktopPendingPreview}
              mobilePendingPreview={mobilePendingPreview}
              onDesktopPendingPreviewChange={setDesktopPendingPreview}
              onMobilePendingPreviewChange={setMobilePendingPreview}
            />

            <div className="space-y-2">
              <Label htmlFor="order">
                Slide position <span className="text-destructive">*</span>
              </Label>
              <Select
                value={orderValue}
                onValueChange={(value) => form.setValue("order", value)}
              >
                <SelectTrigger id="order">
                  <SelectValue placeholder="Select slide" />
                </SelectTrigger>
                <SelectContent>
                  {HOME_HERO_SLIDE_ORDERS.map((placement) => (
                    <SelectItem
                      key={placement.order}
                      value={String(placement.order)}
                    >
                      {placement.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="title">
                Title <span className="text-destructive">*</span>
              </Label>
              <Input id="title" {...form.register("title")} />
              {form.formState.errors.title ? (
                <p className="text-sm text-destructive">
                  {form.formState.errors.title.message}
                </p>
              ) : null}
            </div>

            <div className="space-y-2">
              <Label htmlFor="subtitle">Subtitle</Label>
              <Textarea id="subtitle" rows={3} {...form.register("subtitle")} />
            </div>

            <DialogFooter className="gap-2 sm:gap-0 pt-2">
              <Button
                type="button"
                variant="outline"
                disabled={saving}
                onClick={() => setDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving} aria-busy={saving}>
                {saving ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete slide?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => void handleDelete()}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
