"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import {
  fetchContactPageHeroContentAdmin,
  saveContactPageHeroContentAdmin,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import {
  ContactPageAdminBackLink,
  ContactPageAdminHeader,
  ContactPageFormFooter,
} from "@/components/admin/contact-page/ContactPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z.object({
  title: z.string().min(1, "Title is required"),
  subtitle: z.string(),
});

type FormValues = z.infer<typeof formSchema>;

export function ContactPageHeroManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [heroImage, setHeroImage] = useState<CmsImageUploadValue | null>(null);
  const [heroPendingPreview, setHeroPendingPreview] = useState<string | null>(
    null,
  );

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: { title: "", subtitle: "" },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchContactPageHeroContentAdmin();
      if (data) {
        setHeroImage(data.heroImageUrl ? { url: data.heroImageUrl } : null);
        form.reset({
          title: data.title,
          subtitle: data.subtitle,
        });
      } else {
        setHeroImage(null);
        form.reset({ title: "", subtitle: "" });
      }
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load hero content",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    try {
      await saveContactPageHeroContentAdmin({
        title: values.title.trim(),
        subtitle: values.subtitle.trim(),
        heroImageUrl: heroImage?.url?.trim() ?? "",
      });
      toast.success("Hero section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save hero section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-3xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-40 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-3xl">
      <ContactPageAdminBackLink />
      <ContactPageAdminHeader
        title="Hero"
        description="Top banner on the contact page. Upload an optional hero image; the default banner is used when empty."
      />

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="title">Title</Label>
          <Input id="title" {...form.register("title")} />
          {form.formState.errors.title ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.title.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="subtitle">Subtitle</Label>
          <Textarea id="subtitle" rows={3} {...form.register("subtitle")} />
        </div>

        <CmsImageUploadField
          label="Hero image"
          preset="heroDesktop"
          value={heroImage}
          onChange={setHeroImage}
          folder="cms/contact-page/hero"
          storageFileName="banner"
          pendingPreviewUrl={heroPendingPreview}
          onPendingPreviewChange={setHeroPendingPreview}
        />

        <ContactPageFormFooter
          end={
            <Button type="submit" disabled={saving} className="w-full sm:w-auto">
              {saving ? "Saving…" : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
