"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { ContactPageInfoCard } from "@/types/cms";
import { CONTACT_PAGE_INFO_ICONS } from "@/types/cms";
import {
  createContactPageInfoCardAdmin,
  deleteContactPageInfoCardAdmin,
  fetchContactPageInfoCardsAdmin,
  updateContactPageInfoCardAdmin,
} from "@/lib/admin-cms-api";
import {
  ContactPageAdminBackLink,
  ContactPageAdminHeader,
} from "@/components/admin/contact-page/ContactPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const cardFormSchema = z.object({
  icon: z.enum(CONTACT_PAGE_INFO_ICONS),
  title: z.string().min(1, "Title is required"),
  detailsText: z.string().min(1, "Add at least one detail line"),
  action: z.string(),
  order: z.string(),
});

type CardFormValues = z.infer<typeof cardFormSchema>;

export function ContactPageInfoCardsManager() {
  const [items, setItems] = useState<ContactPageInfoCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ContactPageInfoCard | null>(
    null,
  );
  const [deleteTarget, setDeleteTarget] = useState<ContactPageInfoCard | null>(
    null,
  );

  const form = useForm<CardFormValues>({
    resolver: zodResolver(cardFormSchema),
    defaultValues: {
      icon: "mail",
      title: "",
      detailsText: "",
      action: "",
      order: "0",
    },
  });

  const loadItems = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchContactPageInfoCardsAdmin();
      setItems(data);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load info cards",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadItems();
  }, [loadItems]);

  const openCreate = () => {
    setEditingItem(null);
    form.reset({
      icon: "mail",
      title: "",
      detailsText: "",
      action: "",
      order: String(items.length),
    });
    setDialogOpen(true);
  };

  const openEdit = (item: ContactPageInfoCard) => {
    setEditingItem(item);
    form.reset({
      icon: item.icon,
      title: item.title,
      detailsText: item.details.join("\n"),
      action: item.action ?? "",
      order: String(item.order),
    });
    setDialogOpen(true);
  };

  const onSubmit = async (values: CardFormValues) => {
    const details = values.detailsText
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean);
    if (details.length === 0) {
      toast.error("Add at least one detail line");
      return;
    }

    const payload = {
      icon: values.icon,
      title: values.title.trim(),
      details,
      action: values.action.trim() || null,
      order: Number(values.order) || 0,
    };

    setSaving(true);
    try {
      if (editingItem) {
        await updateContactPageInfoCardAdmin(editingItem.id, payload);
        toast.success("Info card updated");
      } else {
        await createContactPageInfoCardAdmin(payload);
        toast.success("Info card created");
      }
      setDialogOpen(false);
      await loadItems();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save info card",
      );
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteContactPageInfoCardAdmin(deleteTarget.id);
      toast.success("Info card deleted");
      setDeleteTarget(null);
      await loadItems();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete info card",
      );
    }
  };

  return (
    <section className="max-w-5xl">
      <ContactPageAdminBackLink />
      <ContactPageAdminHeader
        title="Contact Info Cards"
        description="Manage the four contact info cards shown below the hero."
      />

      <div className="flex justify-end mb-4">
        <Button onClick={openCreate}>
          <Plus className="w-4 h-4 mr-2" />
          Add card
        </Button>
      </div>

      {loading ? (
        <div className="space-y-2">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
        </div>
      ) : items.length === 0 ? (
        <p className="text-sm text-muted-foreground py-8 text-center">
          No info cards yet. Add your first card to publish this section.
        </p>
      ) : (
        <div className="overflow-x-auto rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order</TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Icon</TableHead>
                <TableHead>Details</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((item) => (
                <TableRow key={item.id}>
                  <TableCell>{item.order}</TableCell>
                  <TableCell className="font-medium">{item.title}</TableCell>
                  <TableCell>{item.icon}</TableCell>
                  <TableCell className="max-w-xs truncate">
                    {item.details.join(", ")}
                  </TableCell>
                  <TableCell className="text-right space-x-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => openEdit(item)}
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setDeleteTarget(item)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingItem ? "Edit info card" : "Add info card"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-2">
              <Label>Icon</Label>
              <Select
                value={form.watch("icon")}
                onValueChange={(value) =>
                  form.setValue("icon", value as CardFormValues["icon"])
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {CONTACT_PAGE_INFO_ICONS.map((icon) => (
                    <SelectItem key={icon} value={icon}>
                      {icon}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input id="title" {...form.register("title")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="detailsText">Details (one per line)</Label>
              <textarea
                id="detailsText"
                rows={4}
                className="w-full min-h-[100px] px-3 py-2 border border-input rounded-lg bg-background text-foreground"
                {...form.register("detailsText")}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="action">Action URL (optional)</Label>
              <Input
                id="action"
                placeholder="mailto:info@example.com, tel:+91..., or #map"
                {...form.register("action")}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="order">Order</Label>
              <Input id="order" type="number" {...form.register("order")} />
            </div>
            <DialogFooter>
              <Button type="submit" disabled={saving}>
                {saving ? "Saving…" : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={() => setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete info card?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove &quot;{deleteTarget?.title}&quot; from the contact
              page.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
