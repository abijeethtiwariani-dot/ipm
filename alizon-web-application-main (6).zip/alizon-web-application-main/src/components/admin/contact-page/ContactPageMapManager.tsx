"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import {
  fetchContactPageMapContentAdmin,
  saveContactPageMapContentAdmin,
} from "@/lib/admin-cms-api";
import {
  DEFAULT_CONTACT_PAGE_MAP,
  normalizeContactPageMapContent,
  resolveContactPageEmbedUrl,
} from "@/lib/contact-page-cms";
import {
  isGoogleMapsEmbedUrl,
  isGoogleMapsLocationUrl,
  parseGoogleMapsEmbedInput,
} from "@/lib/google-maps-url";
import {
  ContactPageAdminBackLink,
  ContactPageAdminHeader,
  ContactPageFormFooter,
} from "@/components/admin/contact-page/ContactPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z
  .object({
    heading: z.string().min(1, "Heading is required"),
    embedUrl: z.string(),
    locationUrl: z.string(),
  })
  .superRefine((values, ctx) => {
    const embed = parseGoogleMapsEmbedInput(values.embedUrl);
    const location = values.locationUrl.trim();
    const hasEmbed = isGoogleMapsEmbedUrl(embed);
    const hasLocation = isGoogleMapsLocationUrl(location);

    if (!hasEmbed && !hasLocation) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message:
          "Enter a valid embed URL (or iframe HTML) and/or a valid Google Maps location link.",
        path: ["embedUrl"],
      });
    }

    if (values.embedUrl.trim() && !hasEmbed) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Enter a valid Google Maps embed URL or paste the full iframe HTML.",
        path: ["embedUrl"],
      });
    }

    if (location && !hasLocation) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Enter a valid Google Maps share link (e.g. maps.app.goo.gl).",
        path: ["locationUrl"],
      });
    }
  });

type FormValues = z.infer<typeof formSchema>;

export function ContactPageMapManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      heading: DEFAULT_CONTACT_PAGE_MAP.heading,
      embedUrl: DEFAULT_CONTACT_PAGE_MAP.embedUrl,
      locationUrl: DEFAULT_CONTACT_PAGE_MAP.locationUrl,
    },
  });

  const watchedEmbedUrl = form.watch("embedUrl");
  const previewEmbedSrc = useMemo(
    () => resolveContactPageEmbedUrl(watchedEmbedUrl),
    [watchedEmbedUrl],
  );

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchContactPageMapContentAdmin();
      if (data) {
        form.reset({
          heading: data.heading,
          embedUrl: data.embedUrl,
          locationUrl: data.locationUrl,
        });
      } else {
        form.reset({
          heading: DEFAULT_CONTACT_PAGE_MAP.heading,
          embedUrl: "",
          locationUrl: DEFAULT_CONTACT_PAGE_MAP.locationUrl,
        });
      }
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load map content",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    try {
      const normalized = normalizeContactPageMapContent({
        heading: values.heading,
        embedUrl: values.embedUrl,
        locationUrl: values.locationUrl,
      });
      await saveContactPageMapContentAdmin(normalized);
      form.reset({
        heading: normalized.heading,
        embedUrl: normalized.embedUrl,
        locationUrl: normalized.locationUrl,
      });
      toast.success("Map section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save map section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-3xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-[300px] w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-3xl">
      <ContactPageAdminBackLink />
      <ContactPageAdminHeader
        title="Map"
        description="Configure the Find Us map section on the contact page."
      />

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="heading">Section heading</Label>
          <Input id="heading" {...form.register("heading")} />
        </div>

        <div className="space-y-2">
          <Label htmlFor="embedUrl">Google Maps embed URL</Label>
          <Textarea
            id="embedUrl"
            rows={4}
            placeholder='https://www.google.com/maps/embed?pb=... or paste full <iframe> HTML'
            {...form.register("embedUrl")}
          />
          <p className="text-xs text-muted-foreground">
            In Google Maps: Share → Embed a map → copy the iframe{" "}
            <code className="text-xs">src</code> URL, or paste the entire iframe
            tag. Leave empty to use the default campus map on the site.
          </p>
          {form.formState.errors.embedUrl ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.embedUrl.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="locationUrl">Google Maps location URL</Label>
          <Input
            id="locationUrl"
            placeholder="https://maps.app.goo.gl/..."
            {...form.register("locationUrl")}
          />
          <p className="text-xs text-muted-foreground">
            Share link opened when visitors click the map on the contact page
            (e.g. maps.app.goo.gl or google.com/maps/place/...).
          </p>
          {form.formState.errors.locationUrl ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.locationUrl.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label>Map preview</Label>
          <div className="rounded-xl border border-border overflow-hidden h-[300px] bg-muted">
            <iframe
              src={previewEmbedSrc}
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Map preview"
            />
          </div>
          <p className="text-xs text-muted-foreground">
            Preview uses your embed URL, or the default campus map when embed is
            empty.
          </p>
        </div>

        <ContactPageFormFooter
          end={
            <Button type="submit" disabled={saving} className="w-full sm:w-auto">
              {saving ? "Saving…" : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
