"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import {
  fetchContactPageFormContentAdmin,
  saveContactPageFormContentAdmin,
} from "@/lib/admin-cms-api";
import { DEFAULT_CONTACT_PAGE_FORM } from "@/lib/contact-page-cms";
import {
  ContactPageAdminBackLink,
  ContactPageAdminHeader,
  ContactPageFormFooter,
} from "@/components/admin/contact-page/ContactPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z.object({
  heading: z.string().min(1, "Heading is required"),
  successTitle: z.string().min(1, "Success title is required"),
  successMessage: z.string().min(1, "Success message is required"),
});

type FormValues = z.infer<typeof formSchema>;

export function ContactPageFormManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      heading: DEFAULT_CONTACT_PAGE_FORM.heading,
      successTitle: DEFAULT_CONTACT_PAGE_FORM.successTitle,
      successMessage: DEFAULT_CONTACT_PAGE_FORM.successMessage,
    },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchContactPageFormContentAdmin();
      if (data) {
        form.reset({
          heading: data.heading,
          successTitle: data.successTitle,
          successMessage: data.successMessage,
        });
      } else {
        form.reset({
          heading: DEFAULT_CONTACT_PAGE_FORM.heading,
          successTitle: DEFAULT_CONTACT_PAGE_FORM.successTitle,
          successMessage: DEFAULT_CONTACT_PAGE_FORM.successMessage,
        });
      }
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load form content",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    try {
      await saveContactPageFormContentAdmin({
        heading: values.heading.trim(),
        successTitle: values.successTitle.trim(),
        successMessage: values.successMessage.trim(),
        departments: [],
      });
      toast.success("Form section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save form section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-3xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-24 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-3xl">
      <ContactPageAdminBackLink />
      <ContactPageAdminHeader
        title="Message Form"
        description="Configure the Send Us a Message section on the contact page."
      />

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="heading">Section heading</Label>
          <Input id="heading" {...form.register("heading")} />
        </div>

        <div className="space-y-2">
          <Label htmlFor="successTitle">Success title</Label>
          <Input id="successTitle" {...form.register("successTitle")} />
        </div>

        <div className="space-y-2">
          <Label htmlFor="successMessage">Success message</Label>
          <Textarea
            id="successMessage"
            rows={3}
            {...form.register("successMessage")}
          />
        </div>

        <ContactPageFormFooter
          end={
            <Button type="submit" disabled={saving} className="w-full sm:w-auto">
              {saving ? "Saving…" : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
