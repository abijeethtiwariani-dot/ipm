"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { ContactPageDepartmentCard } from "@/types/cms";
import {
  createContactPageDepartmentCardAdmin,
  deleteContactPageDepartmentCardAdmin,
  fetchContactPageDepartmentCardsAdmin,
  fetchContactPageDepartmentsHeaderContentAdmin,
  saveContactPageDepartmentsHeaderContentAdmin,
  updateContactPageDepartmentCardAdmin,
} from "@/lib/admin-cms-api";
import { DEFAULT_CONTACT_PAGE_DEPARTMENTS_HEADER } from "@/lib/contact-page-cms";
import {
  ContactPageAdminBackLink,
  ContactPageAdminHeader,
  ContactPageFormFooter,
} from "@/components/admin/contact-page/ContactPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const headerSchema = z.object({
  heading: z.string().min(1, "Heading is required"),
  intro: z.string().min(1, "Intro is required"),
});

const cardSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Enter a valid email"),
  phone: z.string().min(1, "Phone is required"),
  order: z.string(),
});

type HeaderFormValues = z.infer<typeof headerSchema>;
type CardFormValues = z.infer<typeof cardSchema>;

export function ContactPageDepartmentsManager() {
  const [loading, setLoading] = useState(true);
  const [savingHeader, setSavingHeader] = useState(false);
  const [savingCard, setSavingCard] = useState(false);
  const [items, setItems] = useState<ContactPageDepartmentCard[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ContactPageDepartmentCard | null>(
    null,
  );
  const [deleteTarget, setDeleteTarget] = useState<ContactPageDepartmentCard | null>(
    null,
  );

  const headerForm = useForm<HeaderFormValues>({
    resolver: zodResolver(headerSchema),
    defaultValues: {
      heading: DEFAULT_CONTACT_PAGE_DEPARTMENTS_HEADER.heading,
      intro: DEFAULT_CONTACT_PAGE_DEPARTMENTS_HEADER.intro,
    },
  });

  const cardForm = useForm<CardFormValues>({
    resolver: zodResolver(cardSchema),
    defaultValues: { name: "", email: "", phone: "", order: "0" },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const [header, cards] = await Promise.all([
        fetchContactPageDepartmentsHeaderContentAdmin(),
        fetchContactPageDepartmentCardsAdmin(),
      ]);
      headerForm.reset({
        heading: header?.heading ?? DEFAULT_CONTACT_PAGE_DEPARTMENTS_HEADER.heading,
        intro: header?.intro ?? DEFAULT_CONTACT_PAGE_DEPARTMENTS_HEADER.intro,
      });
      setItems(cards);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load departments",
      );
    } finally {
      setLoading(false);
    }
  }, [headerForm]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onSaveHeader = async (values: HeaderFormValues) => {
    setSavingHeader(true);
    try {
      await saveContactPageDepartmentsHeaderContentAdmin({
        heading: values.heading.trim(),
        intro: values.intro.trim(),
      });
      toast.success("Section header saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save section header",
      );
    } finally {
      setSavingHeader(false);
    }
  };

  const openCreate = () => {
    setEditingItem(null);
    cardForm.reset({
      name: "",
      email: "",
      phone: "",
      order: String(items.length),
    });
    setDialogOpen(true);
  };

  const openEdit = (item: ContactPageDepartmentCard) => {
    setEditingItem(item);
    cardForm.reset({
      name: item.name,
      email: item.email,
      phone: item.phone,
      order: String(item.order),
    });
    setDialogOpen(true);
  };

  const onSubmitCard = async (values: CardFormValues) => {
    const payload = {
      name: values.name.trim(),
      email: values.email.trim(),
      phone: values.phone.trim(),
      order: Number(values.order) || 0,
    };

    setSavingCard(true);
    try {
      if (editingItem) {
        await updateContactPageDepartmentCardAdmin(editingItem.id, payload);
        toast.success("Department card updated");
      } else {
        await createContactPageDepartmentCardAdmin(payload);
        toast.success("Department card created");
      }
      setDialogOpen(false);
      await loadContent();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save department card",
      );
    } finally {
      setSavingCard(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteContactPageDepartmentCardAdmin(deleteTarget.id);
      toast.success("Department card deleted");
      setDeleteTarget(null);
      await loadContent();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete department card",
      );
    }
  };

  if (loading) {
    return (
      <section className="max-w-5xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-24 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-5xl space-y-10">
      <div>
        <ContactPageAdminBackLink />
        <ContactPageAdminHeader
          title="Department Contacts"
          description="Manage the department contacts section heading and cards."
        />

        <form
          onSubmit={headerForm.handleSubmit(onSaveHeader)}
          className="space-y-4 max-w-3xl"
        >
          <div className="space-y-2">
            <Label htmlFor="heading">Section heading</Label>
            <Input id="heading" {...headerForm.register("heading")} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="intro">Section intro</Label>
            <Textarea id="intro" rows={3} {...headerForm.register("intro")} />
          </div>
          <ContactPageFormFooter
            end={
              <Button
                type="submit"
                disabled={savingHeader}
                className="w-full sm:w-auto"
              >
                {savingHeader ? "Saving…" : "Save header"}
              </Button>
            }
          />
        </form>
      </div>

      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-heading font-semibold">Department cards</h2>
          <Button onClick={openCreate}>
            <Plus className="w-4 h-4 mr-2" />
            Add card
          </Button>
        </div>

        {items.length === 0 ? (
          <p className="text-sm text-muted-foreground py-8 text-center">
            No department cards yet. Add cards to publish this section.
          </p>
        ) : (
          <div className="overflow-x-auto rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Order</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell>{item.order}</TableCell>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    <TableCell>{item.email}</TableCell>
                    <TableCell>{item.phone}</TableCell>
                    <TableCell className="text-right space-x-2">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEdit(item)}
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteTarget(item)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingItem ? "Edit department card" : "Add department card"}
            </DialogTitle>
          </DialogHeader>
          <form
            onSubmit={cardForm.handleSubmit(onSubmitCard)}
            className="space-y-4"
          >
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input id="name" {...cardForm.register("name")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" {...cardForm.register("email")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input id="phone" {...cardForm.register("phone")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="order">Order</Label>
              <Input id="order" type="number" {...cardForm.register("order")} />
            </div>
            <DialogFooter>
              <Button type="submit" disabled={savingCard}>
                {savingCard ? "Saving…" : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={() => setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete department card?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove &quot;{deleteTarget?.name}&quot; from the contact
              page.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
