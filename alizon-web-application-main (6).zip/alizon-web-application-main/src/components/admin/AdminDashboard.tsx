"use client";

import { useEffect, useState } from "react";
import { Building2, Newspaper, Star } from "lucide-react";
import { getAdminStats } from "@/lib/admin-cms-api";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

const statConfig = [
  {
    key: "newsCount" as const,
    label: "News",
    icon: Newspaper,
  },
  {
    key: "featuredCount" as const,
    label: "Featured News",
    icon: Star,
  },
  {
    key: "campusLifeCardCount" as const,
    label: "Campus Life Cards",
    icon: Building2,
  },
];

export function AdminDashboard() {
  const [stats, setStats] = useState<{
    newsCount: number;
    featuredCount: number;
    campusLifeCardCount: number;
  } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const data = await getAdminStats();
        setStats(data);
      } catch {
        setStats({ newsCount: 0, featuredCount: 0, campusLifeCardCount: 9 });
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return (
    <section>
      <h1 className="text-3xl font-heading font-bold text-foreground mb-8">
        Dashboard
      </h1>

      {loading ? (
        <section className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          <Skeleton className="h-28" />
          <Skeleton className="h-28" />
          <Skeleton className="h-28" />
        </section>
      ) : (
        <section className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {statConfig.map((item) => {
            const Icon = item.icon;
            const value = stats?.[item.key] ?? 0;
            return (
              <Card
                key={item.key}
                className="border border-border shadow-sm bg-card"
              >
                <CardContent className="p-6">
                  <Icon className="w-5 h-5 text-muted-foreground mb-3" />
                  <p className="text-3xl font-heading font-bold text-foreground">
                    {value}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {item.label}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </section>
      )}
    </section>
  );
}
