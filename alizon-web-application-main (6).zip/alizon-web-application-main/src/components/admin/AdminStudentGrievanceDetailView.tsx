"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { ArrowLeft, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import {
  GrievanceStatusBadge,
  GrievanceStatusControl,
} from "@/components/admin/GrievanceStatusControl";
import { apiFetchStudentGrievances } from "@/lib/admin-grievances-api";
import { timestampToLocaleDateString } from "@/lib/firestore-timestamp";
import type { AdminStudentGrievanceDetail } from "@/types/admin-grievance";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

function GrievanceMessageBlock({
  grievance,
}: {
  grievance: { message: string; submittedAt?: unknown };
}) {
  return (
    <div className="space-y-2">
      <p className="text-xs text-muted-foreground">
        Submitted {timestampToLocaleDateString(grievance.submittedAt) || "—"}
      </p>
      <div className="rounded-md border bg-muted/30 p-4 text-sm whitespace-pre-wrap">
        {grievance.message}
      </div>
    </div>
  );
}

export function AdminStudentGrievanceDetailView({
  studentId,
}: {
  studentId: string;
}) {
  const [detail, setDetail] = useState<AdminStudentGrievanceDetail | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await apiFetchStudentGrievances(studentId);
      setDetail(data);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load grievances",
      );
      setDetail(null);
    } finally {
      setLoading(false);
    }
  }, [studentId]);

  useEffect(() => {
    load();
  }, [load]);

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-32 w-full" />
      </div>
    );
  }

  if (!detail) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" size="sm" asChild>
          <Link href="/admin/grievances">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to grievances
          </Link>
        </Button>
        <p className="text-muted-foreground text-sm">Student not found.</p>
      </div>
    );
  }

  const hasAny =
    detail.assignments.length > 0 || detail.evaluations.length > 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4">
        <Button variant="ghost" size="sm" className="w-fit" asChild>
          <Link href="/admin/grievances">
            <ArrowLeft className="w-4 h-4 mr-1" />
            Back to grievances
          </Link>
        </Button>
        <div>
          <h1 className="text-2xl font-heading font-bold">
            {detail.studentName || "Student"}
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            <span className="font-mono">{detail.registrationId || "—"}</span>
            {detail.studentEmail ? ` · ${detail.studentEmail}` : null}
          </p>
        </div>
      </div>

      {!hasAny ? (
        <p className="text-muted-foreground text-sm py-8 text-center">
          This student has no grievances on record.
        </p>
      ) : (
        <>
          {detail.assignments.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Assignments</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Module</TableHead>
                      <TableHead>Title</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Marks</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {detail.assignments.map((item) => (
                      <TableRow key={item.assignmentId}>
                        <TableCell>{item.moduleName}</TableCell>
                        <TableCell>{item.assignmentTitle}</TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              item.status === "Approved"
                                ? "default"
                                : item.status === "Rejected"
                                  ? "destructive"
                                  : "secondary"
                            }
                          >
                            {item.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {item.marks !== null ? item.marks : "—"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                {detail.assignments.map((item) => (
                  <div
                    key={`grievance-${item.assignmentId}`}
                    className="space-y-3 border-t pt-6 first:border-t-0 first:pt-0"
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-medium">
                        {item.moduleName} — {item.assignmentTitle}
                      </p>
                      <GrievanceStatusBadge grievance={item.grievance} />
                    </div>
                    <GrievanceMessageBlock grievance={item.grievance} />
                    <GrievanceStatusControl
                      studentId={studentId}
                      target="assignment"
                      assignmentId={item.assignmentId}
                      grievance={item.grievance}
                      onUpdated={load}
                    />
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          {detail.evaluations.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-lg font-heading font-semibold">Evaluations</h2>
              {detail.evaluations.map((item) => (
                <Card key={item.component}>
                  <CardHeader>
                    <div className="flex flex-wrap items-center gap-2">
                      <CardTitle className="text-base">{item.label}</CardTitle>
                      <GrievanceStatusBadge grievance={item.grievance} />
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex flex-wrap items-center gap-3 text-sm">
                      <Badge
                        variant={
                          item.status === "Graded"
                            ? "default"
                            : item.status === "Pending"
                              ? "secondary"
                              : "outline"
                        }
                      >
                        {item.status}
                      </Badge>
                      <span>
                        Marks: {item.marks !== null ? item.marks : "—"}
                      </span>
                      {item.fileUrl && (
                        <Button variant="link" size="sm" className="h-auto p-0" asChild>
                          <a
                            href={item.fileUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <ExternalLink className="w-3 h-3 mr-1 inline" />
                            Document
                          </a>
                        </Button>
                      )}
                    </div>
                    <GrievanceMessageBlock grievance={item.grievance} />
                    <GrievanceStatusControl
                      studentId={studentId}
                      target={item.component}
                      grievance={item.grievance}
                      onUpdated={load}
                    />
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
