"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { CreditCard, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";
import {
  apiDeleteStudentIdCard,
  apiFetchStudentIdCardPreviewUrl,
  apiUploadStudentIdCard,
} from "@/lib/admin-student-id-card-api";
import { toDateString } from "@/lib/students";
import type { Student } from "@/types/student";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";

const ACCEPT =
  ".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/jpeg,image/png,image/webp";

export function StudentIdCardSection({
  studentId,
  student,
  onUpdated,
}: {
  studentId: string;
  student: Student;
  onUpdated: (student: Student) => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const idCard = student.idCard;
  const isImage = idCard?.mimeType?.startsWith("image/");

  const loadPreview = useCallback(async () => {
    if (!idCard || !isImage) {
      setPreviewUrl(null);
      return;
    }
    try {
      const url = await apiFetchStudentIdCardPreviewUrl(studentId);
      setPreviewUrl(url);
    } catch {
      setPreviewUrl(null);
    }
  }, [studentId, idCard, isImage]);

  useEffect(() => {
    void loadPreview();
  }, [loadPreview]);

  const onFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;

    setUploading(true);
    try {
      const updated = await apiUploadStudentIdCard(studentId, file);
      onUpdated(updated);
      toast.success(idCard ? "ID card replaced." : "ID card uploaded.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Upload failed.");
    } finally {
      setUploading(false);
    }
  };

  const onDelete = async () => {
    setDeleting(true);
    try {
      const updated = await apiDeleteStudentIdCard(studentId);
      onUpdated(updated);
      setPreviewUrl(null);
      toast.success("ID card removed.");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Delete failed.");
    } finally {
      setDeleting(false);
      setDeleteOpen(false);
    }
  };

  return (
    <>
      <Card className="md:col-span-2">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <CreditCard className="h-4 w-4" />
            Student ID Card
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {idCard ? (
            <div className="space-y-4">
              <div className="text-sm">
                <p>
                  <span className="text-muted-foreground">File: </span>
                  {idCard.fileName}
                </p>
                <p>
                  <span className="text-muted-foreground">Uploaded: </span>
                  {toDateString(idCard.uploadedAt) || "—"}
                </p>
              </div>
              {isImage && previewUrl ? (
                <div className="overflow-hidden rounded-md border bg-muted/30">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={previewUrl}
                    alt="Student ID card preview"
                    className="max-h-64 w-full object-contain"
                  />
                </div>
              ) : null}
              <div className="flex flex-wrap gap-2">
                <Button
                  type="button"
                  variant="outline"
                  disabled={uploading || deleting}
                  onClick={() => inputRef.current?.click()}
                >
                  <Upload className="mr-2 h-4 w-4" />
                  {uploading ? "Uploading…" : "Replace"}
                </Button>
                <Button
                  type="button"
                  variant="destructive"
                  disabled={uploading || deleting}
                  onClick={() => setDeleteOpen(true)}
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-2">
              <Label>Upload ID card (PDF, JPEG, PNG, WebP — max 10 MB)</Label>
              <Button
                type="button"
                variant="outline"
                disabled={uploading}
                onClick={() => inputRef.current?.click()}
              >
                <Upload className="mr-2 h-4 w-4" />
                {uploading ? "Uploading…" : "Choose file"}
              </Button>
            </div>
          )}
          <input
            ref={inputRef}
            type="file"
            className="sr-only"
            accept={ACCEPT}
            onChange={(e) => void onFileChange(e)}
            disabled={uploading || deleting}
          />
        </CardContent>
      </Card>

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete ID card?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove the uploaded ID card for this student.
              Students will no longer be able to download it.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={deleting}
              onClick={(e) => {
                e.preventDefault();
                void onDelete();
              }}
            >
              {deleting ? "Deleting…" : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
