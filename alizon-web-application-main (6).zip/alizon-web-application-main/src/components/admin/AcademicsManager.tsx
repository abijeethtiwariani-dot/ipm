"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { ArrowLeft, Pencil, Plus, Star, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { AcademicsCard } from "@/types/cms";
import {
  DEFAULT_ACADEMICS_CARD_LINK,
  createAcademicsCard,
  deleteAcademicsCard,
  fetchAcademicsCards,
  fetchAcademicsHomeContent,
  formatSchoolPointsLines,
  parseSchoolPointsLines,
  saveAcademicsHomeContent,
  updateAcademicsCard,
  validateFeaturedAcademicsLimit,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import { ROUTES } from "@/lib/site-routes";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { HomeSectionPublishToggle } from "@/components/admin/HomeSectionPublishToggle";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const sectionFormSchema = z.object({
  sectionHeading: z.string().min(1, "Section heading is required"),
  sectionSubContent: z.string().min(1, "Sub content is required"),
  schoolsHeading: z.string().min(1, "Schools heading is required"),
  schoolPointsText: z.string().min(1, "Add at least one school point"),
  buttonText: z.string().min(1, "Button text is required"),
  buttonLink: z.string().min(1, "Button link is required"),
});

const cardFormSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  imageUrl: z.string().optional(),
  link: z.string().min(1, "Link is required"),
  linkText: z.string().optional(),
  featured: z.boolean(),
});

type SectionFormValues = z.infer<typeof sectionFormSchema>;
type CardFormValues = z.infer<typeof cardFormSchema>;

type ImageSource = "url" | "upload";

function formatUpdatedAt(updatedAt: AcademicsCard["updatedAt"]): string {
  if (!updatedAt) return "—";
  if (
    typeof updatedAt === "object" &&
    updatedAt !== null &&
    "toDate" in updatedAt &&
    typeof (updatedAt as { toDate: () => Date }).toDate === "function"
  ) {
    return format((updatedAt as { toDate: () => Date }).toDate(), "MMM d, yyyy");
  }
  if (updatedAt instanceof Date) {
    return format(updatedAt, "MMM d, yyyy");
  }
  return "—";
}

function inferImageSource(imageUrl: string): ImageSource {
  if (!imageUrl) return "upload";
  if (
    imageUrl.includes("firebasestorage.googleapis.com") ||
    imageUrl.includes("firebase")
  ) {
    return "upload";
  }
  return "url";
}

export function AcademicsManager() {
  const [cards, setCards] = useState<AcademicsCard[]>([]);
  const [loadingCards, setLoadingCards] = useState(true);
  const [loadingSection, setLoadingSection] = useState(true);
  const [savingSection, setSavingSection] = useState(false);
  const [savingCard, setSavingCard] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingCard, setEditingCard] = useState<AcademicsCard | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<AcademicsCard | null>(null);
  const [imageSource, setImageSource] = useState<ImageSource>("upload");
  const [cardImage, setCardImage] = useState<CmsImageUploadValue | null>(null);
  const [imagePendingPreview, setImagePendingPreview] = useState<string | null>(
    null,
  );
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const sectionForm = useForm<SectionFormValues>({
    resolver: zodResolver(sectionFormSchema),
    defaultValues: {
      sectionHeading: "Academics",
      sectionSubContent: "",
      schoolsHeading: "",
      schoolPointsText: "",
      buttonText: "More about academics",
      buttonLink: ROUTES.programs,
    },
  });

  const cardForm = useForm<CardFormValues>({
    resolver: zodResolver(cardFormSchema),
    defaultValues: {
      title: "",
      description: "",
      imageUrl: "",
      link: ROUTES.programs,
      linkText: "",
      featured: false,
    },
  });

  const featured = cardForm.watch("featured");

  const loadSection = useCallback(async () => {
    setLoadingSection(true);
    try {
      const content = await fetchAcademicsHomeContent();
      sectionForm.reset({
        sectionHeading: content.sectionHeading,
        sectionSubContent: content.sectionSubContent,
        schoolsHeading: content.schoolsHeading,
        schoolPointsText: formatSchoolPointsLines(content.schoolPoints),
        buttonText: content.buttonText,
        buttonLink: content.buttonLink,
      });
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to load section";
      toast.error(message);
    } finally {
      setLoadingSection(false);
    }
  }, [sectionForm]);

  const loadCards = useCallback(async () => {
    setLoadingCards(true);
    try {
      const data = await fetchAcademicsCards();
      setCards(data);
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to load cards";
      toast.error(message);
    } finally {
      setLoadingCards(false);
    }
  }, []);

  useEffect(() => {
    loadSection();
    loadCards();
  }, [loadSection, loadCards]);

  const onSaveSection = async (values: SectionFormValues) => {
    setSavingSection(true);
    try {
      const schoolPoints = parseSchoolPointsLines(values.schoolPointsText);
      if (schoolPoints.length === 0) {
        toast.error("Add at least one school point (one per line)");
        return;
      }
      await saveAcademicsHomeContent({
        sectionHeading: values.sectionHeading,
        sectionSubContent: values.sectionSubContent,
        schoolsHeading: values.schoolsHeading,
        schoolPoints,
        buttonText: values.buttonText,
        buttonLink: values.buttonLink.trim() || ROUTES.programs,
      });
      toast.success("Section settings saved");
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to save section";
      toast.error(message);
    } finally {
      setSavingSection(false);
    }
  };

  const openCreate = () => {
    setEditingCard(null);
    setImageSource("upload");
    setCardImage(null);
    setImagePendingPreview(null);
    setImagePreview(null);
    cardForm.reset({
      title: "",
      description: "",
      imageUrl: "",
      link: ROUTES.programs,
      linkText: "",
      featured: false,
    });
    setDialogOpen(true);
  };

  const openEdit = (card: AcademicsCard) => {
    setEditingCard(card);
    setImageSource(inferImageSource(card.imageUrl));
    setCardImage(
      inferImageSource(card.imageUrl) === "upload" && card.imageUrl
        ? { url: card.imageUrl }
        : null,
    );
    setImagePendingPreview(null);
    setImagePreview(card.imageUrl || null);
    cardForm.reset({
      title: card.title,
      description: card.description,
      imageUrl: card.imageUrl,
      link: card.link,
      linkText: card.linkText,
      featured: card.featured,
    });
    setDialogOpen(true);
  };

  const onSubmitCard = async (values: CardFormValues) => {
    const hasExistingImage = Boolean(editingCard?.imageUrl);
    if (imageSource === "url") {
      if (!values.imageUrl?.trim() && !hasExistingImage) {
        toast.error("Please enter an image URL");
        return;
      }
    } else if (!cardImage?.url && !hasExistingImage) {
      toast.error("Please upload an image");
      return;
    }

    const featuredCheck = await validateFeaturedAcademicsLimit(
      values.featured,
      editingCard?.id,
    );
    if (!featuredCheck.ok) {
      toast.error(featuredCheck.message);
      return;
    }

    setSavingCard(true);
    try {
      let imageUrl = values.imageUrl?.trim() ?? editingCard?.imageUrl ?? "";

      if (imageSource === "upload" && cardImage?.url) {
        imageUrl = cardImage.url;
      } else if (imageSource === "url") {
        imageUrl = values.imageUrl?.trim() ?? imageUrl;
      }

      if (!imageUrl) {
        toast.error("Image is required");
        return;
      }

      const payload = {
        title: values.title,
        description: values.description,
        imageUrl,
        link: values.link.trim() || ROUTES.programs,
        linkText: values.linkText?.trim() ?? "",
        featured: values.featured,
      };

      if (editingCard) {
        await updateAcademicsCard(editingCard.id, payload);
        toast.success("Card updated");
      } else {
        const nextOrder =
          cards.length > 0 ? Math.max(...cards.map((c) => c.order)) + 1 : 0;
        await createAcademicsCard({ ...payload, order: nextOrder });
        toast.success("Card created");
      }

      setDialogOpen(false);
      await loadCards();
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to save card";
      toast.error(message);
    } finally {
      setSavingCard(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteAcademicsCard(deleteTarget.id);
      toast.success("Card deleted");
      setDeleteTarget(null);
      await loadCards();
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to delete card";
      toast.error(message);
    }
  };

  const handleUrlPreview = (url: string) => {
    if (url.trim()) setImagePreview(url.trim());
  };

  return (
    <section className="space-y-10">
      <header>
        <Button variant="ghost" size="sm" className="mb-4 -ml-2" asChild>
          <Link href="/admin/home-content">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Home page content
          </Link>
        </Button>
        <HomeSectionPublishToggle sectionKey="academics" className="mb-6" />
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Academics
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Manage the homepage Academics section and featured cards.
        </p>
      </header>

      {/* Section settings */}
      <section className="bg-card rounded-lg border border-border shadow-sm p-6 md:p-8">
        <h2 className="text-xl font-heading font-semibold text-foreground mb-6">
          Section settings
        </h2>
        {loadingSection ? (
          <div className="space-y-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        ) : (
          <form
            onSubmit={sectionForm.handleSubmit(onSaveSection)}
            className="space-y-5 max-w-2xl"
          >
            <div className="space-y-2">
              <Label htmlFor="sectionHeading">Section heading</Label>
              <Input
                id="sectionHeading"
                {...sectionForm.register("sectionHeading")}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="sectionSubContent">Sub content</Label>
              <Textarea
                id="sectionSubContent"
                rows={3}
                {...sectionForm.register("sectionSubContent")}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="schoolsHeading">Schools heading</Label>
              <Input
                id="schoolsHeading"
                {...sectionForm.register("schoolsHeading")}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="schoolPointsText">School points</Label>
              <Textarea
                id="schoolPointsText"
                rows={6}
                placeholder={"Medicine\nLaw|/programs\nEngineering"}
                {...sectionForm.register("schoolPointsText")}
              />
              <p className="text-xs text-muted-foreground">
                One point per line. Use{" "}
                <code className="text-xs">Label|/path</code> for a custom link;
                otherwise links default to {ROUTES.programs}.
              </p>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="buttonText">Button text</Label>
                <Input id="buttonText" {...sectionForm.register("buttonText")} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="buttonLink">Button link</Label>
                <Input
                  id="buttonLink"
                  placeholder={ROUTES.programs}
                  {...sectionForm.register("buttonLink")}
                />
              </div>
            </div>
            <Button type="submit" disabled={savingSection}>
              {savingSection ? "Saving..." : "Save section"}
            </Button>
          </form>
        )}
      </section>

      {/* Featured cards */}
      <section>
        <header className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <h2 className="text-xl font-heading font-semibold text-foreground">
            Featured cards
          </h2>
          <Button onClick={openCreate}>
            <Plus className="w-4 h-4 mr-2" />
            Add card
          </Button>
        </header>

        <section className="bg-card rounded-lg border border-border shadow-sm overflow-hidden">
          {loadingCards ? (
            <section className="p-8 space-y-3">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </section>
          ) : cards.length === 0 ? (
            <p className="p-8 text-sm text-muted-foreground text-center">
              No cards yet. Add up to 3 featured cards for the homepage.
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead>Title</TableHead>
                  <TableHead className="w-20">Featured</TableHead>
                  <TableHead className="hidden md:table-cell">Link</TableHead>
                  <TableHead className="hidden sm:table-cell w-32">
                    Updated
                  </TableHead>
                  <TableHead className="w-24 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {cards.map((card) => (
                  <TableRow key={card.id}>
                    <TableCell className="font-medium max-w-[240px]">
                      <span className="line-clamp-2">{card.title}</span>
                    </TableCell>
                    <TableCell>
                      {card.featured ? (
                        <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell className="hidden md:table-cell text-sm text-muted-foreground max-w-xs truncate">
                      {card.link}
                    </TableCell>
                    <TableCell className="hidden sm:table-cell text-sm text-muted-foreground">
                      {formatUpdatedAt(card.updatedAt)}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openEdit(card)}
                          aria-label="Edit"
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setDeleteTarget(card)}
                          aria-label="Delete"
                        >
                          <Trash2 className="w-4 h-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </section>
      </section>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-background">
          <DialogHeader>
            <DialogTitle className="font-heading text-xl">
              {editingCard ? "Edit card" : "New card"}
            </DialogTitle>
          </DialogHeader>
          <form
            onSubmit={cardForm.handleSubmit(onSubmitCard)}
            className="space-y-5"
          >
            <div className="space-y-2">
              <Label>Image source</Label>
              <Select
                value={imageSource}
                onValueChange={(v) => setImageSource(v as ImageSource)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="url">Image URL</SelectItem>
                  <SelectItem value="upload">Upload image</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {imageSource === "url" ? (
              <div className="space-y-2">
                <Label htmlFor="imageUrl">
                  Image URL <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="imageUrl"
                  placeholder="https://..."
                  {...cardForm.register("imageUrl", {
                    onChange: (e) => handleUrlPreview(e.target.value),
                  })}
                />
              </div>
            ) : (
              <CmsImageUploadField
                label="Card image"
                preset="card4x3"
                folder="cms/academics"
                storageFileName={editingCard?.id ?? `new-${Date.now()}`}
                value={cardImage}
                onChange={setCardImage}
                pendingPreviewUrl={imagePendingPreview}
                onPendingPreviewChange={setImagePendingPreview}
                required
              />
            )}

            {imageSource === "url" && imagePreview && (
              <div className="relative w-full h-44 rounded-lg overflow-hidden bg-muted border border-border">
                <Image
                  src={imagePreview}
                  alt="Preview"
                  fill
                  className="object-cover"
                  unoptimized
                />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="title">
                Title <span className="text-destructive">*</span>
              </Label>
              <Input id="title" {...cardForm.register("title")} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">
                Description <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="description"
                rows={4}
                {...cardForm.register("description")}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="link">
                Link <span className="text-destructive">*</span>
              </Label>
              <Input
                id="link"
                placeholder={ROUTES.programs}
                {...cardForm.register("link")}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="linkText">Link text</Label>
              <Input
                id="linkText"
                placeholder="Defaults to title on homepage"
                {...cardForm.register("linkText")}
              />
            </div>

            <div className="flex items-start gap-3 rounded-lg border border-border p-4 bg-muted/30">
              <Checkbox
                id="featured"
                checked={featured}
                onCheckedChange={(checked) =>
                  cardForm.setValue("featured", checked === true)
                }
              />
              <div className="space-y-0.5">
                <Label htmlFor="featured" className="cursor-pointer font-medium">
                  Show on homepage
                </Label>
                <p className="text-xs text-muted-foreground">
                  Up to 3 featured cards appear in the Academics section.
                </p>
              </div>
            </div>

            <DialogFooter className="gap-2 sm:gap-0 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={savingCard}>
                {savingCard ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete card?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
