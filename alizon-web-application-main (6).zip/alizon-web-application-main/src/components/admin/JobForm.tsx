"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format, parseISO } from "date-fns";
import { ArrowLeft, CalendarIcon, Loader2 } from "lucide-react";
import { toast } from "sonner";
import {
  apiCreateJob,
  apiFetchAdminJob,
  apiUpdateJob,
} from "@/lib/admin-jobs-api";
import { slugifyJobTitle } from "@/lib/jobs";
import { EMPLOYMENT_TYPES, JOB_STATUSES } from "@/types/job";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

const schema = z.object({
  title: z.string().min(1, "Title is required"),
  slug: z.string().min(1, "Slug is required"),
  jobCode: z.string(),
  department: z.string().min(1, "Department is required"),
  location: z.string().min(1, "Location is required"),
  employmentType: z.enum(["full_time", "part_time", "contract", "internship"]),
  experienceRequired: z.string(),
  salaryRange: z.string(),
  shortDescription: z.string().min(1, "Short description is required"),
  fullDescription: z.string(),
  responsibilities: z.string(),
  requirements: z.string(),
  benefits: z.string(),
  featured: z.boolean(),
  status: z.enum(["active", "closed"]),
  applicationDeadline: z.string(),
});

type FormValues = z.infer<typeof schema>;

function dateToIso(date: Date | undefined): string {
  if (!date) return "";
  return format(date, "yyyy-MM-dd");
}

function parseDateField(value: string): Date | undefined {
  if (!value) return undefined;
  try {
    return parseISO(value);
  } catch {
    return undefined;
  }
}

export function JobForm({ jobId }: { jobId?: string }) {
  const router = useRouter();
  const isEdit = Boolean(jobId);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(isEdit);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      title: "",
      slug: "",
      jobCode: "",
      department: "",
      location: "",
      employmentType: "full_time",
      experienceRequired: "",
      salaryRange: "",
      shortDescription: "",
      fullDescription: "",
      responsibilities: "",
      requirements: "",
      benefits: "",
      featured: false,
      status: "active",
      applicationDeadline: "",
    },
  });

  const title = form.watch("title");

  useEffect(() => {
    if (!isEdit && title) {
      form.setValue("slug", slugifyJobTitle(title));
    }
  }, [title, isEdit, form]);

  useEffect(() => {
    if (!jobId) return;
    void (async () => {
      setLoading(true);
      try {
        const data = await apiFetchAdminJob(jobId);
        if (!data) {
          toast.error("Job not found.");
          router.replace("/admin/jobs-portal/jobs");
          return;
        }
        form.reset({
          title: data.title,
          slug: data.slug,
          jobCode: data.jobCode,
          department: data.department,
          location: data.location,
          employmentType: data.employmentType,
          experienceRequired: data.experienceRequired,
          salaryRange: data.salaryRange ?? "",
          shortDescription: data.shortDescription,
          fullDescription: data.fullDescription,
          responsibilities: data.responsibilities,
          requirements: data.requirements,
          benefits: data.benefits,
          featured: data.featured,
          status: data.status,
          applicationDeadline: data.applicationDeadline ?? "",
        });
      } catch (error) {
        toast.error(error instanceof Error ? error.message : "Failed to load.");
      } finally {
        setLoading(false);
      }
    })();
  }, [jobId, form, router]);

  const onSubmit = form.handleSubmit(async (values) => {
    setSaving(true);
    try {
      const payload = {
        ...values,
        salaryRange: values.salaryRange.trim() || undefined,
        applicationDeadline: values.applicationDeadline.trim() || undefined,
      };
      if (isEdit && jobId) {
        await apiUpdateJob(jobId, payload);
        toast.success("Job updated.");
      } else {
        await apiCreateJob(payload);
        toast.success("Job created.");
      }
      router.push("/admin/jobs-portal/jobs");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Save failed.");
    } finally {
      setSaving(false);
    }
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <section>
      <Link
        href="/admin/jobs-portal/jobs"
        className="mb-4 inline-flex items-center text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="mr-1 h-4 w-4" />
        Back to jobs
      </Link>
      <h1 className="mb-8 text-3xl font-heading font-bold">
        {isEdit ? "Edit Job" : "Create Job"}
      </h1>

      <form onSubmit={onSubmit} className="space-y-8">
        <Card>
          <CardHeader>
            <CardTitle>Basic Information</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 md:grid-cols-2">
            <div className="md:col-span-2 space-y-2">
              <Label htmlFor="title">Job Title *</Label>
              <Input id="title" {...form.register("title")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="slug">Slug</Label>
              <Input id="slug" {...form.register("slug")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="jobCode">Job Code</Label>
              <Input id="jobCode" {...form.register("jobCode")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="department">Department *</Label>
              <Input id="department" {...form.register("department")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="location">Location *</Label>
              <Input id="location" {...form.register("location")} />
            </div>
            <div className="space-y-2">
              <Label>Employment Type</Label>
              <Select
                value={form.watch("employmentType")}
                onValueChange={(v) =>
                  form.setValue(
                    "employmentType",
                    v as FormValues["employmentType"],
                  )
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {EMPLOYMENT_TYPES.map((t) => (
                    <SelectItem key={t} value={t}>
                      {t.replace("_", " ").replace(/\b\w/g, (c) => c.toUpperCase())}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="experienceRequired">Experience Required</Label>
              <Input id="experienceRequired" {...form.register("experienceRequired")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="salaryRange">Salary Range (optional)</Label>
              <Input id="salaryRange" {...form.register("salaryRange")} placeholder="e.g. ₹8–12 LPA" />
            </div>
            <div className="space-y-2">
              <Label>Status</Label>
              <Select
                value={form.watch("status")}
                onValueChange={(v) => form.setValue("status", v as FormValues["status"])}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {JOB_STATUSES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {s === "active" ? "Active" : "Closed"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Application Deadline</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    type="button"
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !form.watch("applicationDeadline") && "text-muted-foreground",
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {form.watch("applicationDeadline")
                      ? format(parseDateField(form.watch("applicationDeadline"))!, "PPP")
                      : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={parseDateField(form.watch("applicationDeadline"))}
                    onSelect={(d) => form.setValue("applicationDeadline", dateToIso(d))}
                  />
                </PopoverContent>
              </Popover>
            </div>
            <div className="flex items-center gap-2 md:col-span-2">
              <Checkbox
                id="featured"
                checked={form.watch("featured")}
                onCheckedChange={(c) => form.setValue("featured", c === true)}
              />
              <Label htmlFor="featured">Featured job (shown on Careers page)</Label>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Job Description</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="shortDescription">Short Description *</Label>
              <Textarea id="shortDescription" rows={3} {...form.register("shortDescription")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="fullDescription">Full Description</Label>
              <Textarea id="fullDescription" rows={6} {...form.register("fullDescription")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="responsibilities">Responsibilities (one per line)</Label>
              <Textarea id="responsibilities" rows={5} {...form.register("responsibilities")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="requirements">Requirements (one per line)</Label>
              <Textarea id="requirements" rows={5} {...form.register("requirements")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="benefits">Benefits (one per line)</Label>
              <Textarea id="benefits" rows={4} {...form.register("benefits")} />
            </div>
          </CardContent>
        </Card>

        <div className="flex gap-3">
          <Button type="submit" disabled={saving}>
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {isEdit ? "Save Changes" : "Create Job"}
          </Button>
          <Button type="button" variant="outline" asChild>
            <Link href="/admin/jobs-portal/jobs">Cancel</Link>
          </Button>
        </div>
      </form>
    </section>
  );
}
