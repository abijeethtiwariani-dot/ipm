"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Download, Plus, Search } from "lucide-react";
import { toast } from "sonner";
import { apiFetchFeeStudents } from "@/lib/admin-fees-api";
import { downloadFeeStudentsCsv } from "@/lib/export-fee-students-csv";
import { formatCurrency } from "@/lib/fees";
import type { PaymentStatus, StudentFeeSummary } from "@/types/fees";
import { PaymentStatusBadge } from "@/components/fees/PaymentStatusBadge";
import { AddPaymentDialog } from "@/components/fees/AddPaymentDialog";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

function initials(name: string) {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

export function FeeStudentsList() {
  const router = useRouter();
  const [students, setStudents] = useState<StudentFeeSummary[]>([]);
  const [programs, setPrograms] = useState<{ id: string; name: string }[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [programFilter, setProgramFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState<PaymentStatus | "all">("all");
  const [addOpen, setAddOpen] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await apiFetchFeeStudents({
        search: search || undefined,
        programId: programFilter !== "all" ? programFilter : undefined,
        status: statusFilter !== "all" ? statusFilter : undefined,
      });
      setStudents(data.students);
      setPrograms(data.programs.map((p) => ({ id: p.id, name: p.name })));
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to load students");
    } finally {
      setLoading(false);
    }
  }, [search, programFilter, statusFilter]);

  useEffect(() => {
    const t = setTimeout(() => void load(), 300);
    return () => clearTimeout(t);
  }, [load]);

  const displayStudents = useMemo(() => students, [students]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-heading font-bold">Student Fee List</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Track fees, scholarships, and payment status for all students.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" asChild>
            <Link href="/admin/fees">Dashboard</Link>
          </Button>
          <Button
            variant="outline"
            disabled={loading || displayStudents.length === 0}
            onClick={() => {
              downloadFeeStudentsCsv(displayStudents);
              toast.success(`Exported ${displayStudents.length} student(s) to CSV.`);
            }}
          >
            <Download className="mr-2 h-4 w-4" />
            Download
          </Button>
          <Button onClick={() => setAddOpen(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Add Payment
          </Button>
        </div>
      </div>

      <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap">
        <div className="relative max-w-sm flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search student..."
            className="pl-9"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <Select value={programFilter} onValueChange={setProgramFilter}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Program" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All programs</SelectItem>
            {programs.map((p) => (
              <SelectItem key={p.id} value={p.id}>
                {p.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select
          value={statusFilter}
          onValueChange={(v) => setStatusFilter(v as PaymentStatus | "all")}
        >
          <SelectTrigger className="w-[180px]">
            <SelectValue placeholder="Payment status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="Fully Paid">Fully Paid</SelectItem>
            <SelectItem value="Partial Paid">Partial Paid</SelectItem>
            <SelectItem value="Pending">Pending</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <Skeleton className="h-64 w-full" />
      ) : displayStudents.length === 0 ? (
        <p className="py-12 text-center text-sm text-muted-foreground">
          No students match your filters.
        </p>
      ) : (
        <>
          <div className="hidden overflow-hidden rounded-2xl border bg-card shadow-soft md:block">
            <Table>
              <TableHeader>
                <TableRow className="bg-muted/50">
                  <TableHead>Student</TableHead>
                  <TableHead>ID</TableHead>
                  <TableHead>Program</TableHead>
                  <TableHead>Course Fee</TableHead>
                  <TableHead>Scholarship</TableHead>
                  <TableHead>Discount</TableHead>
                  <TableHead>Final Fee</TableHead>
                  <TableHead>Paid</TableHead>
                  <TableHead>Due</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Payment</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {displayStudents.map((s) => (
                  <TableRow
                    key={s.studentId}
                    className="cursor-pointer hover:bg-muted/40"
                    onClick={() => router.push(`/admin/fees/students/${s.studentId}`)}
                  >
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className="bg-primary/10 text-primary text-xs">
                            {initials(s.studentName)}
                          </AvatarFallback>
                        </Avatar>
                        <span className="font-medium">{s.studentName}</span>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-xs">{s.registrationId}</TableCell>
                    <TableCell>{s.programName}</TableCell>
                    <TableCell>{formatCurrency(s.courseFee)}</TableCell>
                    <TableCell>{s.scholarshipPercentage}%</TableCell>
                    <TableCell>{formatCurrency(s.discountAmount)}</TableCell>
                    <TableCell>{formatCurrency(s.finalPayableFee)}</TableCell>
                    <TableCell>{formatCurrency(s.totalPaid)}</TableCell>
                    <TableCell className={s.dueAmount > 0 ? "text-destructive font-medium" : ""}>
                      {formatCurrency(s.dueAmount)}
                    </TableCell>
                    <TableCell>
                      <PaymentStatusBadge status={s.paymentStatus} />
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {s.lastPaymentDate ?? "—"}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={(e) => {
                          e.stopPropagation();
                          router.push(`/admin/fees/students/${s.studentId}`);
                        }}
                      >
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <div className="grid gap-4 md:hidden">
            {displayStudents.map((s) => (
              <Card
                key={s.studentId}
                className="border-0 shadow-soft card-hover cursor-pointer"
                onClick={() => router.push(`/admin/fees/students/${s.studentId}`)}
              >
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar>
                        <AvatarFallback className="bg-primary/10 text-primary">
                          {initials(s.studentName)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-semibold">{s.studentName}</p>
                        <p className="text-xs text-muted-foreground">{s.registrationId}</p>
                      </div>
                    </div>
                    <PaymentStatusBadge status={s.paymentStatus} />
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <p className="text-muted-foreground">Due</p>
                      <p className="font-medium">{formatCurrency(s.dueAmount)}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Paid</p>
                      <p className="font-medium">{formatCurrency(s.totalPaid)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      )}

      <AddPaymentDialog open={addOpen} onOpenChange={setAddOpen} onSuccess={load} />
    </div>
  );
}
