"use client";

import { useCallback, useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { AdmissionPageStatCms, AdmissionPageStatKind } from "@/types/cms";
import {
  fetchAdmissionPageStatsContentAdmin,
  saveAdmissionPageStatsContentAdmin,
} from "@/lib/admin-cms-api";
import {
  AdmissionPageAdminBackLink,
  AdmissionPageAdminHeader,
  AdmissionPageFormFooter,
} from "@/components/admin/admission-page/AdmissionPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const emptyStat = (): AdmissionPageStatCms => ({
  value: "",
  label: "",
  kind: "counter",
  counterEnd: 0,
  counterSuffix: "+",
});

export function AdmissionPageStatsManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [stats, setStats] = useState<AdmissionPageStatCms[]>([]);

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchAdmissionPageStatsContentAdmin();
      setStats(data?.stats?.length ? data.stats : [emptyStat()]);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load statistics",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const updateStat = (index: number, patch: Partial<AdmissionPageStatCms>) => {
    setStats((prev) =>
      prev.map((s, i) => (i === index ? { ...s, ...patch } : s)),
    );
  };

  const setKind = (index: number, kind: AdmissionPageStatKind) => {
    updateStat(index, {
      kind,
      counterEnd: kind === "counter" ? stats[index].counterEnd ?? 0 : undefined,
      counterSuffix: kind === "counter" ? stats[index].counterSuffix ?? "+" : undefined,
    });
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const valid = stats.filter((s) => s.value.trim() && s.label.trim());
    if (valid.length === 0) {
      toast.error("Add at least one stat with value and label");
      return;
    }

    setSaving(true);
    try {
      await saveAdmissionPageStatsContentAdmin({
        stats: valid.map((s) => ({
          value: s.value.trim(),
          label: s.label.trim(),
          kind: s.kind,
          ...(s.kind === "counter"
            ? {
                counterEnd: Number(s.counterEnd) || 0,
                counterSuffix: s.counterSuffix?.trim() || "",
              }
            : {}),
        })),
      });
      toast.success("Statistics section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save statistics",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-2xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-32 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-2xl">
      <AdmissionPageAdminBackLink />
      <AdmissionPageAdminHeader
        title="Statistics"
        description="Stats row below the hero banner."
      />

      <form onSubmit={onSubmit} className="space-y-6">
        {stats.map((stat, index) => (
          <div
            key={index}
            className="space-y-3 rounded-lg border border-border p-4 relative"
          >
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium">Stat {index + 1}</p>
              {stats.length > 1 ? (
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => setStats((prev) => prev.filter((_, i) => i !== index))}
                  aria-label="Remove stat"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              ) : null}
            </div>

            <div className="space-y-2">
              <Label>Kind</Label>
              <Select
                value={stat.kind}
                onValueChange={(v) => setKind(index, v as AdmissionPageStatKind)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="counter">Counter (animated)</SelectItem>
                  <SelectItem value="featured">Featured (static text)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Display value</Label>
                <Input
                  value={stat.value}
                  onChange={(e) => updateStat(index, { value: e.target.value })}
                  placeholder={stat.kind === "counter" ? "8,500+" : "Class of 2029"}
                />
              </div>
              <div className="space-y-2">
                <Label>Label</Label>
                <Input
                  value={stat.label}
                  onChange={(e) => updateStat(index, { label: e.target.value })}
                />
              </div>
            </div>

            {stat.kind === "counter" ? (
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Counter end</Label>
                  <Input
                    type="number"
                    value={stat.counterEnd ?? ""}
                    onChange={(e) =>
                      updateStat(index, { counterEnd: Number(e.target.value) })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Counter suffix</Label>
                  <Input
                    value={stat.counterSuffix ?? ""}
                    onChange={(e) =>
                      updateStat(index, { counterSuffix: e.target.value })
                    }
                    placeholder="+"
                  />
                </div>
              </div>
            ) : null}
          </div>
        ))}

        <AdmissionPageFormFooter
          start={
            <Button
              type="button"
              variant="outline"
              className="w-full sm:w-auto"
              onClick={() => setStats((prev) => [...prev, emptyStat()])}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add stat
            </Button>
          }
          end={
            <Button type="submit" disabled={saving} className="w-full sm:w-auto">
              {saving ? "Saving…" : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
