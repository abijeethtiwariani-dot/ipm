"use client";

import { useCallback, useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { AdmissionPageLinkItemCms, AdmissionPageFloatingStatCms } from "@/types/cms";
import {
  fetchAdmissionPageUndergradContentAdmin,
  saveAdmissionPageUndergradContentAdmin,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import {
  AdmissionPageLinkItemFields,
  type LinkItemFormValues,
} from "@/components/admin/admission-page/AdmissionPageLinkItemFields";
import {
  AdmissionPageAdminBackLink,
  AdmissionPageAdminHeader,
  AdmissionPageFormFooter,
} from "@/components/admin/admission-page/AdmissionPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";

const emptyLink = (): LinkItemFormValues => ({
  title: "",
  body: "",
  linkLabel: "",
  href: "",
});

const emptyFloating = (): AdmissionPageFloatingStatCms => ({
  value: "",
  label: "",
});

export function AdmissionPageUndergradManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [sectionImage, setSectionImage] = useState<CmsImageUploadValue | null>(
    null,
  );
  const [imagePendingPreview, setImagePendingPreview] = useState<string | null>(
    null,
  );
  const [imageAlt, setImageAlt] = useState("");
  const [items, setItems] = useState<LinkItemFormValues[]>([emptyLink()]);
  const [floatingStats, setFloatingStats] = useState<AdmissionPageFloatingStatCms[]>([
    emptyFloating(),
  ]);

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchAdmissionPageUndergradContentAdmin();
      if (data) {
        setSectionImage(data.imageUrl ? { url: data.imageUrl } : null);
        setImageAlt(data.imageAlt);
        setItems(
          data.items.length
            ? data.items.map((i) => ({ ...i }))
            : [emptyLink()],
        );
        setFloatingStats(
          data.floatingStats.length
            ? data.floatingStats
            : [emptyFloating()],
        );
      } else {
        setSectionImage(null);
        setImageAlt("");
        setItems([emptyLink()]);
        setFloatingStats([emptyFloating()]);
      }
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load content",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validItems = items.filter(
      (i) => i.title.trim() && i.linkLabel.trim() && i.href.trim(),
    );
    if (!sectionImage?.url) {
      toast.error("Please upload a section image");
      return;
    }
    if (validItems.length === 0) {
      toast.error("Add at least one link card");
      return;
    }

    setSaving(true);
    try {
      await saveAdmissionPageUndergradContentAdmin({
        imageUrl: sectionImage.url,
        imageAlt: imageAlt.trim(),
        floatingStats: floatingStats.filter((s) => s.value.trim() && s.label.trim()),
        items: validItems.map((i) => ({
          title: i.title.trim(),
          body: i.body.trim(),
          linkLabel: i.linkLabel.trim(),
          href: i.href.trim(),
        })) as AdmissionPageLinkItemCms[],
      });
      toast.success("Undergraduates section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-2xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-40 w-full" />
        <Skeleton className="h-48 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-2xl">
      <AdmissionPageAdminBackLink />
      <AdmissionPageAdminHeader
        title="Undergraduates"
        description="Undergraduate admissions block with image and link cards."
      />

      <form onSubmit={onSubmit} className="space-y-8">
        <CmsImageUploadField
          label="Section image"
          preset="card4x5"
          folder="cms/admission-page/undergrad"
          storageFileName="section"
          value={sectionImage}
          onChange={setSectionImage}
          pendingPreviewUrl={imagePendingPreview}
          onPendingPreviewChange={setImagePendingPreview}
          required
        />

        <div className="space-y-2">
          <Label>Image alt text</Label>
          <Input value={imageAlt} onChange={(e) => setImageAlt(e.target.value)} />
        </div>

        <div className="space-y-4">
          <Label>Floating stats (on image)</Label>
          {floatingStats.map((stat, index) => (
            <div key={index} className="flex gap-2 items-end">
              <div className="flex-1 space-y-2">
                <Input
                  placeholder="Value"
                  value={stat.value}
                  onChange={(e) =>
                    setFloatingStats((prev) =>
                      prev.map((s, i) =>
                        i === index ? { ...s, value: e.target.value } : s,
                      ),
                    )
                  }
                />
              </div>
              <div className="flex-1 space-y-2">
                <Input
                  placeholder="Label"
                  value={stat.label}
                  onChange={(e) =>
                    setFloatingStats((prev) =>
                      prev.map((s, i) =>
                        i === index ? { ...s, label: e.target.value } : s,
                      ),
                    )
                  }
                />
              </div>
              {floatingStats.length > 1 ? (
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() =>
                    setFloatingStats((prev) => prev.filter((_, i) => i !== index))
                  }
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              ) : null}
            </div>
          ))}
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setFloatingStats((prev) => [...prev, emptyFloating()])}
          >
            <Plus className="h-4 w-4 mr-1" />
            Add stat
          </Button>
        </div>

        <div className="space-y-4">
          <Label>Link cards</Label>
          {items.map((item, index) => (
            <div key={index} className="relative">
              {items.length > 1 ? (
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-2 z-10"
                  onClick={() => setItems((prev) => prev.filter((_, i) => i !== index))}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              ) : null}
              <AdmissionPageLinkItemFields
                prefix={`item-${index}`}
                values={item}
                onChange={(v) =>
                  setItems((prev) => prev.map((p, i) => (i === index ? v : p)))
                }
              />
            </div>
          ))}
        </div>

        <AdmissionPageFormFooter
          start={
            <Button
              type="button"
              variant="outline"
              className="w-full sm:w-auto"
              onClick={() => setItems((prev) => [...prev, emptyLink()])}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add link card
            </Button>
          }
          end={
            <Button type="submit" disabled={saving} className="w-full sm:w-auto">
              {saving ? "Saving…" : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
