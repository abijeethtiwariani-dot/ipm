import type { ReactNode } from "react";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export function AdmissionPageAdminBackLink() {
  return (
    <Link
      href="/admin/admission-page-content"
      className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6"
    >
      <ArrowLeft className="w-4 h-4" />
      Back to Admission page content
    </Link>
  );
}

export function AdmissionPageAdminHeader({
  title,
  description,
}: {
  title: string;
  description: string;
}) {
  return (
    <header className="mb-8">
      <h1 className="text-3xl font-heading font-bold text-foreground">{title}</h1>
      <p className="text-sm text-muted-foreground mt-1">{description}</p>
      <p className="text-xs text-muted-foreground mt-2">
        Save to publish this section on the public admissions page. No content appears until saved.
      </p>
    </header>
  );
}

export function AdmissionPageFormFooter({
  start,
  end,
}: {
  start?: ReactNode;
  end: ReactNode;
}) {
  return (
    <div className="flex flex-col-reverse gap-3 border-t border-border pt-6 sm:flex-row sm:items-center sm:justify-between">
      {start ? (
        <div className="flex w-full flex-wrap items-center gap-3 sm:w-auto">
          {start}
        </div>
      ) : (
        <div className="hidden sm:block" />
      )}
      <div className="w-full shrink-0 sm:w-auto">{end}</div>
    </div>
  );
}
