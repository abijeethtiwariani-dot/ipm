"use client";

import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

export type LinkItemFormValues = {
  title: string;
  body: string;
  linkLabel: string;
  href: string;
};

export function AdmissionPageLinkItemFields({
  prefix,
  values,
  onChange,
}: {
  prefix: string;
  values: LinkItemFormValues;
  onChange: (values: LinkItemFormValues) => void;
}) {
  return (
    <div className="space-y-3 rounded-lg border border-border p-4">
      <div className="space-y-2">
        <Label htmlFor={`${prefix}-title`}>Title</Label>
        <Input
          id={`${prefix}-title`}
          value={values.title}
          onChange={(e) => onChange({ ...values, title: e.target.value })}
        />
      </div>
      <div className="space-y-2">
        <Label htmlFor={`${prefix}-body`}>Body</Label>
        <Textarea
          id={`${prefix}-body`}
          rows={3}
          value={values.body}
          onChange={(e) => onChange({ ...values, body: e.target.value })}
        />
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor={`${prefix}-linkLabel`}>Link label</Label>
          <Input
            id={`${prefix}-linkLabel`}
            value={values.linkLabel}
            onChange={(e) => onChange({ ...values, linkLabel: e.target.value })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor={`${prefix}-href`}>Link URL</Label>
          <Input
            id={`${prefix}-href`}
            value={values.href}
            onChange={(e) => onChange({ ...values, href: e.target.value })}
            placeholder="/programs"
          />
        </div>
      </div>
    </div>
  );
}
