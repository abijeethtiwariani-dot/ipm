"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import {
  fetchAdmissionPageApplyCtaContentAdmin,
  saveAdmissionPageApplyCtaContentAdmin,
} from "@/lib/admin-cms-api";
import {
  AdmissionPageAdminBackLink,
  AdmissionPageAdminHeader,
  AdmissionPageFormFooter,
} from "@/components/admin/admission-page/AdmissionPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  contactHref: z.string().min(1, "Contact link is required"),
});

type FormValues = z.infer<typeof formSchema>;

export function AdmissionPageApplyCtaManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: { title: "", description: "", contactHref: "" },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchAdmissionPageApplyCtaContentAdmin();
      if (data) {
        form.reset({
          title: data.title,
          description: data.description,
          contactHref: data.contactHref,
        });
      } else {
        form.reset({ title: "", description: "", contactHref: "" });
      }
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load CTA content",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    try {
      await saveAdmissionPageApplyCtaContentAdmin({
        title: values.title.trim(),
        description: values.description.trim(),
        contactHref: values.contactHref.trim(),
      });
      toast.success("Apply CTA section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save CTA section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-2xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-24 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-2xl">
      <AdmissionPageAdminBackLink />
      <AdmissionPageAdminHeader
        title="Apply CTA"
        description="Final call-to-action before the site footer."
      />

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="title">Title</Label>
          <Input id="title" {...form.register("title")} />
          {form.formState.errors.title ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.title.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description</Label>
          <Textarea id="description" rows={4} {...form.register("description")} />
          {form.formState.errors.description ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.description.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="contactHref">Contact link URL</Label>
          <Input id="contactHref" {...form.register("contactHref")} placeholder="/contact" />
          {form.formState.errors.contactHref ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.contactHref.message}
            </p>
          ) : null}
        </div>

        <AdmissionPageFormFooter
          end={
            <Button type="submit" disabled={saving} className="w-full sm:w-auto">
              {saving ? "Saving…" : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
