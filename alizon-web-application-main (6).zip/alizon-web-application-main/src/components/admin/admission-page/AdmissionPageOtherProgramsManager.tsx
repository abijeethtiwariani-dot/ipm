"use client";

import { useCallback, useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { AdmissionPageLinkItemCms } from "@/types/cms";
import {
  fetchAdmissionPageOtherProgramsContentAdmin,
  saveAdmissionPageOtherProgramsContentAdmin,
} from "@/lib/admin-cms-api";
import {
  AdmissionPageLinkItemFields,
  type LinkItemFormValues,
} from "@/components/admin/admission-page/AdmissionPageLinkItemFields";
import {
  AdmissionPageAdminBackLink,
  AdmissionPageAdminHeader,
  AdmissionPageFormFooter,
} from "@/components/admin/admission-page/AdmissionPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

const emptyLink = (): LinkItemFormValues => ({
  title: "",
  body: "",
  linkLabel: "",
  href: "",
});

export function AdmissionPageOtherProgramsManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [items, setItems] = useState<LinkItemFormValues[]>([emptyLink()]);

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchAdmissionPageOtherProgramsContentAdmin();
      setItems(
        data?.items?.length
          ? data.items.map((i) => ({ ...i }))
          : [emptyLink()],
      );
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load content",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const validItems = items.filter(
      (i) => i.title.trim() && i.linkLabel.trim() && i.href.trim(),
    );
    if (validItems.length === 0) {
      toast.error("Add at least one program card");
      return;
    }

    setSaving(true);
    try {
      await saveAdmissionPageOtherProgramsContentAdmin({
        items: validItems.map((i) => ({
          title: i.title.trim(),
          body: i.body.trim(),
          linkLabel: i.linkLabel.trim(),
          href: i.href.trim(),
        })) as AdmissionPageLinkItemCms[],
      });
      toast.success("Other programs section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-2xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-48 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-2xl">
      <AdmissionPageAdminBackLink />
      <AdmissionPageAdminHeader
        title="Other Programs"
        description="Additional program link cards on the admissions page."
      />

      <form onSubmit={onSubmit} className="space-y-6">
        {items.map((item, index) => (
          <div key={index} className="relative">
            {items.length > 1 ? (
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-2 top-2 z-10"
                onClick={() => setItems((prev) => prev.filter((_, i) => i !== index))}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            ) : null}
            <AdmissionPageLinkItemFields
              prefix={`other-${index}`}
              values={item}
              onChange={(v) =>
                setItems((prev) => prev.map((p, i) => (i === index ? v : p)))
              }
            />
          </div>
        ))}

        <AdmissionPageFormFooter
          start={
            <Button
              type="button"
              variant="outline"
              className="w-full sm:w-auto"
              onClick={() => setItems((prev) => [...prev, emptyLink()])}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add program card
            </Button>
          }
          end={
            <Button type="submit" disabled={saving} className="w-full sm:w-auto">
              {saving ? "Saving…" : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
