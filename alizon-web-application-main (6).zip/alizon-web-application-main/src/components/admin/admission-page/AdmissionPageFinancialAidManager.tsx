"use client";

import { useCallback, useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type {
  AdmissionPageFinancialAidCardCms,
  AdmissionPageFinancialAidCardKind,
  AdmissionPageFinancialAidIcon,
} from "@/types/cms";
import {
  fetchAdmissionPageFinancialAidContentAdmin,
  saveAdmissionPageFinancialAidContentAdmin,
} from "@/lib/admin-cms-api";
import { CmsImageUploadField } from "@/components/admin/CmsImageUploadField";
import {
  mapFinancialAidCard,
  parseCounterEnd,
  parseCounterSuffix,
} from "@/lib/admission-page-cms";
import { ROUTES } from "@/lib/site-routes";
import {
  AdmissionPageAdminBackLink,
  AdmissionPageAdminHeader,
  AdmissionPageFormFooter,
} from "@/components/admin/admission-page/AdmissionPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type CardFormState = AdmissionPageFinancialAidCardCms;

const emptyCard = (): CardFormState => ({
  id: `card-${Date.now()}`,
  kind: "glass",
  title: "",
  description: "",
});

const DEFAULT_FINANCIAL_AID_HEADING = "Financial Aid";
const DEFAULT_FINANCIAL_AID_TAGLINE =
  "We are committed to making a world-class education accessible and affordable.";

/** Canonical 5-card bento template (matches static admissions layout). */
const DEFAULT_FINANCIAL_AID_BENTO_CARDS: CardFormState[] = [
  {
    id: "featured",
    kind: "featured",
    title: "Students Receive Financial Aid",
    description: "Help making world-class education affordable.",
    icon: "graduation",
    counterEnd: 69,
    counterSuffix: "%",
    imageAlt: "Diverse Alizon School of Medical & Digital Intelligence students on campus",
  },
  {
    id: "tuition-covered",
    kind: "glass",
    title: "Tuition Covered",
    description: "For undergraduates with family incomes below $150,000",
    icon: "dollar",
  },
  {
    id: "scholarships",
    kind: "image",
    title: "Scholarships & Grants",
    description: "Need-based and merit-based opportunities available.",
    imageAlt: "Alizon School of Medical & Digital Intelligence scholarship recipients",
  },
  {
    id: "room-board",
    kind: "glass",
    title: "Tuition, Room & Board Covered",
    description: "For undergraduates with family incomes below $100,000",
    icon: "home",
  },
  {
    id: "cta",
    kind: "cta",
    title: "Need Help Funding Your Education?",
    description:
      "Explore scholarships, grants, loans and financial assistance programs.",
    href: ROUTES.scholarships,
    ctaLabel: "Explore Financial Aid",
  },
];

export function AdmissionPageFinancialAidManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [heading, setHeading] = useState(DEFAULT_FINANCIAL_AID_HEADING);
  const [tagline, setTagline] = useState(DEFAULT_FINANCIAL_AID_TAGLINE);
  const [cards, setCards] = useState<CardFormState[]>(
    DEFAULT_FINANCIAL_AID_BENTO_CARDS.map((c) => ({ ...c })),
  );

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchAdmissionPageFinancialAidContentAdmin();
      if (data?.cards?.length) {
        setHeading(data.heading?.trim() || DEFAULT_FINANCIAL_AID_HEADING);
        setTagline(data.tagline?.trim() || DEFAULT_FINANCIAL_AID_TAGLINE);
        setCards(
          data.cards
            .map((c) => mapFinancialAidCard(c))
            .filter((c): c is AdmissionPageFinancialAidCardCms => c !== null)
            .map((c) => ({ ...c })),
        );
      } else {
        setHeading(DEFAULT_FINANCIAL_AID_HEADING);
        setTagline(DEFAULT_FINANCIAL_AID_TAGLINE);
        setCards(DEFAULT_FINANCIAL_AID_BENTO_CARDS.map((c) => ({ ...c })));
      }
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load financial aid",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const updateCard = (index: number, patch: Partial<CardFormState>) => {
    setCards((prev) =>
      prev.map((c, i) => (i === index ? { ...c, ...patch } : c)),
    );
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!heading.trim()) {
      toast.error("Section heading is required");
      return;
    }
    if (!tagline.trim()) {
      toast.error("Tagline is required");
      return;
    }
    const valid = cards.filter((c) => c.id.trim() && c.title.trim() && c.description.trim());
    if (valid.length === 0) {
      toast.error("Add at least one bento card");
      return;
    }

    setSaving(true);
    try {
      const payload: AdmissionPageFinancialAidCardCms[] = [];

      for (const card of valid) {
        const imageUrl = card.imageUrl;
        const imageAlt = card.imageAlt;

        const entry: AdmissionPageFinancialAidCardCms = {
          id: card.id.trim(),
          kind: card.kind,
          title: card.title.trim(),
          description: card.description.trim(),
        };

        if (card.icon) entry.icon = card.icon;
        if (card.kind === "featured") {
          const end = parseCounterEnd(card.counterEnd);
          if (end !== undefined) entry.counterEnd = end;
          const suffix = parseCounterSuffix(card.counterSuffix);
          if (suffix !== undefined) entry.counterSuffix = suffix;
        }
        if (card.kind === "cta") {
          if (card.href) entry.href = card.href.trim();
          if (card.ctaLabel) entry.ctaLabel = card.ctaLabel.trim();
        }
        if ((card.kind === "featured" || card.kind === "image") && imageUrl) {
          entry.imageUrl = imageUrl;
          entry.imageAlt = imageAlt?.trim() || card.title;
        }

        payload.push(entry);
      }

      await saveAdmissionPageFinancialAidContentAdmin({
        heading: heading.trim(),
        tagline: tagline.trim(),
        cards: payload,
      });
      toast.success("Financial aid section saved");
      await loadContent();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save financial aid",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-3xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-64 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-3xl">
      <AdmissionPageAdminBackLink />
      <AdmissionPageAdminHeader
        title="Financial Aid"
        description="Bento grid cards for the financial aid section. Layout is driven by card kind (featured, glass, image, cta)—use one of each for the standard 5-tile grid. Upload images for the featured and image cards, then save."
      />

      <form onSubmit={onSubmit} className="space-y-8">
        <div className="space-y-4 rounded-lg border border-border p-4">
          <p className="font-medium text-sm">Section header</p>
          <div className="space-y-2">
            <Label htmlFor="financial-aid-heading">Section heading</Label>
            <Input
              id="financial-aid-heading"
              value={heading}
              onChange={(e) => setHeading(e.target.value)}
              placeholder={DEFAULT_FINANCIAL_AID_HEADING}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="financial-aid-tagline">Tagline</Label>
            <Textarea
              id="financial-aid-tagline"
              rows={2}
              value={tagline}
              onChange={(e) => setTagline(e.target.value)}
              placeholder={DEFAULT_FINANCIAL_AID_TAGLINE}
            />
          </div>
        </div>

        {cards.map((card, index) => (
          <div
            key={`${card.id}-${index}`}
            className="space-y-4 rounded-lg border border-border p-4"
          >
            <div className="flex items-center justify-between">
              <p className="font-medium text-sm">Card {index + 1}</p>
              {cards.length > 1 ? (
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => setCards((prev) => prev.filter((_, i) => i !== index))}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              ) : null}
            </div>

            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-2">
                <Label>Card ID (unique)</Label>
                <Input
                  value={card.id}
                  onChange={(e) => updateCard(index, { id: e.target.value })}
                  placeholder="featured"
                />
              </div>
              <div className="space-y-2">
                <Label>Kind</Label>
                <Select
                  value={card.kind}
                  onValueChange={(v) =>
                    updateCard(index, { kind: v as AdmissionPageFinancialAidCardKind })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="featured">Featured (image + counter)</SelectItem>
                    <SelectItem value="glass">Glass</SelectItem>
                    <SelectItem value="image">Image</SelectItem>
                    <SelectItem value="cta">CTA</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Title</Label>
              <Input
                value={card.title}
                onChange={(e) => updateCard(index, { title: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea
                rows={2}
                value={card.description}
                onChange={(e) => updateCard(index, { description: e.target.value })}
              />
            </div>

            {(card.kind === "glass" || card.kind === "featured") && (
              <div className="space-y-2">
                <Label>Icon</Label>
                <Select
                  value={card.icon ?? ""}
                  onValueChange={(v) =>
                    updateCard(index, {
                      icon: (v || undefined) as AdmissionPageFinancialAidIcon | undefined,
                    })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Optional" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="graduation">Graduation</SelectItem>
                    <SelectItem value="dollar">Dollar</SelectItem>
                    <SelectItem value="home">Home</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            {card.kind === "featured" && (
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Counter end</Label>
                  <Input
                    type="number"
                    value={
                      card.counterEnd != null && Number.isFinite(card.counterEnd)
                        ? String(card.counterEnd)
                        : ""
                    }
                    onChange={(e) => {
                      const raw = e.target.value;
                      updateCard(index, {
                        counterEnd:
                          raw === "" ? undefined : parseCounterEnd(raw),
                      });
                    }}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Counter suffix</Label>
                  <Input
                    value={card.counterSuffix ?? ""}
                    onChange={(e) =>
                      updateCard(index, { counterSuffix: e.target.value })
                    }
                  />
                </div>
              </div>
            )}

            {card.kind === "cta" && (
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>CTA label</Label>
                  <Input
                    value={card.ctaLabel ?? ""}
                    onChange={(e) => updateCard(index, { ctaLabel: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>CTA link</Label>
                  <Input
                    value={card.href ?? ""}
                    onChange={(e) => updateCard(index, { href: e.target.value })}
                  />
                </div>
              </div>
            )}

            {(card.kind === "featured" || card.kind === "image") && (
              <>
                <CmsImageUploadField
                  label="Card image"
                  preset="card4x3"
                  folder="cms/admission-page/financial-aid"
                  storageFileName={card.id.trim() || `card-${index}`}
                  value={card.imageUrl ? { url: card.imageUrl } : null}
                  onChange={(value) =>
                    updateCard(index, { imageUrl: value?.url ?? "" })
                  }
                />
                <div className="space-y-2">
                  <Label>Image alt</Label>
                  <Input
                    value={card.imageAlt ?? ""}
                    onChange={(e) => updateCard(index, { imageAlt: e.target.value })}
                  />
                </div>
              </>
            )}
          </div>
        ))}

        <AdmissionPageFormFooter
          start={
            <Button
              type="button"
              variant="outline"
              className="w-full sm:w-auto"
              onClick={() => setCards((prev) => [...prev, emptyCard()])}
            >
              <Plus className="h-4 w-4 mr-2" />
              Add card
            </Button>
          }
          end={
            <Button type="submit" disabled={saving} className="w-full sm:w-auto">
              {saving ? "Saving…" : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
