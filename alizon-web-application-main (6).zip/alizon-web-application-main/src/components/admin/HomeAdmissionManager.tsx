"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import type { HomeAdmissionContent } from "@/types/cms";
import {
  DEFAULT_HOME_ADMISSION_LINK,
  fetchHomeAdmissionContent,
  saveHomeAdmissionContent,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import { ROUTES } from "@/lib/site-routes";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { HomeSectionPublishToggle } from "@/components/admin/HomeSectionPublishToggle";

const formSchema = z.object({
  sectionHeading: z.string().min(1, "Section heading is required"),
  sectionSubContent: z.string().min(1, "Section subtitle is required"),
  heroImageUrl: z.string().optional(),
  leftColumnHeading: z.string().min(1, "Left column heading is required"),
  leftColumnBody: z.string().min(1, "Left column body is required"),
  rightColumnHeading: z.string().min(1, "Right column heading is required"),
  rightColumnBody: z.string().min(1, "Right column body is required"),
  buttonText: z.string().min(1, "Button text is required"),
  buttonLink: z.string().min(1, "Button link is required"),
});

type FormValues = z.infer<typeof formSchema>;

export function HomeAdmissionManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [heroImage, setHeroImage] = useState<CmsImageUploadValue | null>(null);
  const [heroPendingPreview, setHeroPendingPreview] = useState<string | null>(
    null,
  );

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      sectionHeading: "Admission",
      sectionSubContent: "",
      heroImageUrl: "",
      leftColumnHeading: "",
      leftColumnBody: "",
      rightColumnHeading: "",
      rightColumnBody: "",
      buttonText: "More about admission",
      buttonLink: ROUTES.admissions,
    },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchHomeAdmissionContent();
      setHeroImage(
        data.heroImageUrl
          ? { url: data.heroImageUrl }
          : null,
      );
      setHeroPendingPreview(null);
      form.reset({
        sectionHeading: data.sectionHeading,
        sectionSubContent: data.sectionSubContent,
        heroImageUrl: data.heroImageUrl,
        leftColumnHeading: data.leftColumnHeading,
        leftColumnBody: data.leftColumnBody,
        rightColumnHeading: data.rightColumnHeading,
        rightColumnBody: data.rightColumnBody,
        buttonText: data.buttonText,
        buttonLink: data.buttonLink || DEFAULT_HOME_ADMISSION_LINK,
      });
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load admission content",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    if (!heroImage?.url) {
      toast.error("Please upload a hero image");
      return;
    }

    setSaving(true);
    try {
      const heroImageUrl = heroImage.url;

      const payload: Omit<HomeAdmissionContent, "updatedAt"> = {
        sectionHeading: values.sectionHeading.trim(),
        sectionSubContent: values.sectionSubContent.trim(),
        heroImageUrl,
        leftColumnHeading: values.leftColumnHeading.trim(),
        leftColumnBody: values.leftColumnBody.trim(),
        rightColumnHeading: values.rightColumnHeading.trim(),
        rightColumnBody: values.rightColumnBody.trim(),
        buttonText: values.buttonText.trim(),
        buttonLink: values.buttonLink.trim(),
      };

      await saveHomeAdmissionContent(payload);
      setHeroImage({ url: heroImageUrl });
      form.setValue("heroImageUrl", heroImageUrl);
      toast.success("Admission section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save admission section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-2xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-40 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-2xl">
      <Link
        href="/admin/home-content"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to home page content
      </Link>

      <HomeSectionPublishToggle sectionKey="admission" />

      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Admission
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Homepage section after Athletics: hero image, two-column copy, and CTA.
        </p>
      </header>

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="sectionHeading">Section heading</Label>
          <Input id="sectionHeading" {...form.register("sectionHeading")} />
          {form.formState.errors.sectionHeading ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.sectionHeading.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="sectionSubContent">Section subtitle</Label>
          <Textarea
            id="sectionSubContent"
            rows={3}
            {...form.register("sectionSubContent")}
          />
          {form.formState.errors.sectionSubContent ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.sectionSubContent.message}
            </p>
          ) : null}
        </div>

        <CmsImageUploadField
          label="Hero image"
          preset="admissionBanner"
          folder="cms/home-admission"
          storageFileName="hero"
          value={heroImage}
          onChange={setHeroImage}
          pendingPreviewUrl={heroPendingPreview}
          onPendingPreviewChange={setHeroPendingPreview}
          required
        />

        <div className="space-y-2">
          <Label htmlFor="leftColumnHeading">Left column heading</Label>
          <Input
            id="leftColumnHeading"
            {...form.register("leftColumnHeading")}
          />
          {form.formState.errors.leftColumnHeading ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.leftColumnHeading.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="leftColumnBody">Left column body</Label>
          <Textarea
            id="leftColumnBody"
            rows={4}
            {...form.register("leftColumnBody")}
          />
          {form.formState.errors.leftColumnBody ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.leftColumnBody.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="rightColumnHeading">Right column heading</Label>
          <Input
            id="rightColumnHeading"
            {...form.register("rightColumnHeading")}
          />
          {form.formState.errors.rightColumnHeading ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.rightColumnHeading.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="rightColumnBody">Right column body</Label>
          <Textarea
            id="rightColumnBody"
            rows={4}
            {...form.register("rightColumnBody")}
          />
          {form.formState.errors.rightColumnBody ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.rightColumnBody.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="buttonText">Button text</Label>
          <Input id="buttonText" {...form.register("buttonText")} />
          {form.formState.errors.buttonText ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.buttonText.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="buttonLink">Button link</Label>
          <Input id="buttonLink" {...form.register("buttonLink")} />
          {form.formState.errors.buttonLink ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.buttonLink.message}
            </p>
          ) : null}
        </div>

        <Button type="submit" disabled={saving}>
          {saving ? "Saving…" : "Save changes"}
        </Button>
      </form>
    </section>
  );
}
