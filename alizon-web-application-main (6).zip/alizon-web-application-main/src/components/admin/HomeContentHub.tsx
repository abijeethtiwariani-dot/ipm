"use client";

import Link from "next/link";
import {
  BookOpen,
  Brain,
  Building2,
  Calendar,
  ChevronRight,
  FlaskConical,
  GalleryHorizontal,
  GraduationCap,
  Handshake,
  Heart,
  Map,
  MessageSquareQuote,
  Palette,
  Sparkles,
  Target,
  Trophy,
  Video,
} from "lucide-react";
import { Card } from "@/components/ui/card";

const sections = [
  {
    title: "Hero Banner Carousel",
    description:
      "Up to 4 full-width banner slides with image, title, and subtitle for the homepage hero.",
    href: "/admin/home-content/hero-carousel",
    icon: GalleryHorizontal,
  },
  {
    title: "Mission Section",
    description:
      "Heading, intro copy, and CTA for the mission block below the hero carousel.",
    href: "/admin/home-content/mission",
    icon: Target,
  },
  {
    title: "Featured Video",
    description:
      "Full-width homepage video after Campus News: YouTube, upload, or direct video URL.",
    href: "/admin/home-content/featured-video",
    icon: Video,
  },
  {
    title: "Academics",
    description:
      "Section copy, school points, CTA, and featured cards for the homepage Academics block.",
    href: "/admin/home-content/academics",
    icon: BookOpen,
  },
  {
    title: "Research",
    description:
      "Section copy, CTA, and up to 6 stat tiles for the homepage Research block.",
    href: "/admin/home-content/research",
    icon: FlaskConical,
  },
  {
    title: "Human-Centered AI",
    description:
      "Sticky left panel and scrolling right column after Research: intro, media, text cards, and YouTube.",
    href: "/admin/home-content/human-centered-ai",
    icon: Brain,
  },
  {
    title: "Infrastructure for Innovation",
    description:
      "Intro, innovation background image, and auto-scrolling institute cards after Human-Centered AI.",
    href: "/admin/home-content/innovation-infrastructure",
    icon: Building2,
  },
  {
    title: "Student Testimonial",
    description:
      "Manage homepage testimonial bands shown after Academics, Research, and Campus Life.",
    href: "/admin/home-content/testimonials",
    icon: MessageSquareQuote,
  },
  {
    title: "Campus Life",
    description:
      "Section copy and up to 3 featured cards for the homepage Campus Life block.",
    href: "/admin/home-content/campus-life",
    icon: Map,
  },
  {
    title: "The Arts",
    description:
      "Section copy and up to 3 featured cards for the homepage Arts block.",
    href: "/admin/home-content/arts",
    icon: Palette,
  },
  {
    title: "Upcoming events",
    description:
      "Section copy and up to 4 featured event cards with date and time.",
    href: "/admin/home-content/events",
    icon: Calendar,
  },
  {
    title: "Our Trusted Partners",
    description:
      "Section copy and partner logo marquee shown after Upcoming Events.",
    href: "/admin/home-content/partners",
    icon: Handshake,
  },
  {
    title: "Health Care",
    description:
      "Section copy and up to 3 featured cards for the homepage Health Care block.",
    href: "/admin/home-content/health-care",
    icon: Heart,
  },
  {
    title: "Athletics",
    description:
      "Section copy and up to 3 featured cards for the homepage Athletics block.",
    href: "/admin/home-content/athletics",
    icon: Trophy,
  },
  {
    title: "Admission",
    description:
      "Hero image, two-column copy, and CTA for the homepage Admission block.",
    href: "/admin/home-content/admission",
    icon: GraduationCap,
  },
  {
    title: "Shaping the future through innovation",
    description:
      "Sticky left panel and scrolling right column after Admission: intro, media, text cards, and YouTube.",
    href: "/admin/home-content/shaping-innovation",
    icon: Sparkles,
  },
];

export function HomeContentHub() {
  return (
    <section>
      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Home page content
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Manage sections that appear on the public homepage.
        </p>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 max-w-5xl">
        {sections.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href}>
              <Card className="p-6 h-full border border-border shadow-sm hover:shadow-md transition-shadow card-hover">
                <div className="flex items-start justify-between gap-4">
                  <div className="w-11 h-11 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-1" />
                </div>
                <h2 className="text-lg font-heading font-semibold text-foreground mt-4">
                  {item.title}
                </h2>
                <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                  {item.description}
                </p>
              </Card>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
