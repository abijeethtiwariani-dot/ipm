"use client";

import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import {
  fetchHomeSectionVisibilityAdmin,
  updateHomeSectionPublishedAdmin,
} from "@/lib/admin-cms-api";
import type { HomeSectionKey } from "@/types/cms";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";

type HomeSectionPublishToggleProps = {
  sectionKey: HomeSectionKey;
  className?: string;
};

export function HomeSectionPublishToggle({
  sectionKey,
  className,
}: HomeSectionPublishToggleProps) {
  const [published, setPublished] = useState(true);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const loadVisibility = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchHomeSectionVisibilityAdmin();
      setPublished(data.sections[sectionKey] !== false);
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : "Failed to load section visibility",
      );
    } finally {
      setLoading(false);
    }
  }, [sectionKey]);

  useEffect(() => {
    void loadVisibility();
  }, [loadVisibility]);

  const handleToggle = async (checked: boolean) => {
    const previous = published;
    setPublished(checked);
    setSaving(true);
    try {
      await updateHomeSectionPublishedAdmin(sectionKey, checked);
      toast.success(
        checked ? "Section published on homepage" : "Section hidden from homepage",
      );
    } catch (error) {
      setPublished(previous);
      toast.error(
        error instanceof Error
          ? error.message
          : "Failed to update section visibility",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <Skeleton className={cn("h-[72px] w-full max-w-2xl", className)} />;
  }

  return (
    <Card
      className={cn(
        "mb-6 flex flex-col gap-3 border border-border p-4 sm:flex-row sm:items-center sm:justify-between max-w-2xl",
        className,
      )}
    >
      <div className="space-y-1">
        <Label htmlFor={`home-section-published-${sectionKey}`} className="text-base">
          Published on homepage
        </Label>
        {!published ? (
          <p className="text-sm text-muted-foreground">
            This section is hidden on the public homepage.
          </p>
        ) : (
          <p className="text-sm text-muted-foreground">
            Visitors can see this section when its content is ready.
          </p>
        )}
      </div>
      <Switch
        id={`home-section-published-${sectionKey}`}
        checked={published}
        disabled={saving}
        onCheckedChange={(checked) => void handleToggle(checked)}
        aria-label="Published on homepage"
      />
    </Card>
  );
}
