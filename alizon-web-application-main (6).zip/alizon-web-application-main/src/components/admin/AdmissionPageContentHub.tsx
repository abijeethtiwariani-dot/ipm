"use client";

import Link from "next/link";
import {
  BarChart3,
  ChevronRight,
  ClipboardCheck,
  DollarSign,
  GraduationCap,
  Layers,
  Sparkles,
} from "lucide-react";
import { Card } from "@/components/ui/card";

const sections = [
  {
    title: "Hero",
    description:
      "Page banner title, subtitle, and desktop + mobile hero images.",
    href: "/admin/admission-page-content/hero",
    icon: Sparkles,
  },
  {
    title: "Statistics",
    description: "Counter and featured stat blocks below the hero.",
    href: "/admin/admission-page-content/stats",
    icon: BarChart3,
  },
  {
    title: "Undergraduates",
    description: "Link cards, section image, and floating stats.",
    href: "/admin/admission-page-content/undergraduates",
    icon: GraduationCap,
  },
  {
    title: "Graduate Studies",
    description: "Graduate link cards, image, and floating stats.",
    href: "/admin/admission-page-content/graduate-studies",
    icon: GraduationCap,
  },
  {
    title: "Financial Aid",
    description: "Bento grid cards (featured, glass, image, and CTA types).",
    href: "/admin/admission-page-content/financial-aid",
    icon: DollarSign,
  },
  {
    title: "Other Programs",
    description: "Summer, executive, and international program link cards.",
    href: "/admin/admission-page-content/other-programs",
    icon: Layers,
  },
  {
    title: "Apply CTA",
    description: "Final call-to-action block before the footer.",
    href: "/admin/admission-page-content/apply-cta",
    icon: ClipboardCheck,
  },
];

export function AdmissionPageContentHub() {
  return (
    <section>
      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Admission page content
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Manage sections on the public <code className="text-xs">/admissions</code> page.
          Each section appears only after you save it here.
        </p>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 max-w-5xl">
        {sections.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href}>
              <Card className="p-6 h-full border border-border shadow-sm hover:shadow-md transition-shadow card-hover">
                <div className="flex items-start justify-between gap-4">
                  <div className="w-11 h-11 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-1" />
                </div>
                <h2 className="text-lg font-heading font-semibold text-foreground mt-4">
                  {item.title}
                </h2>
                <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                  {item.description}
                </p>
              </Card>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
