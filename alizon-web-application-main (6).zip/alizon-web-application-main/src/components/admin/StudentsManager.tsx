"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { CheckCircle, Download, Eye, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  toDateString,
} from "@/lib/students";
import {
  apiDeleteStudent,
  apiUpdateStudentProfile,
} from "@/lib/admin-students-api";
import { ensureDefaultPharmacyCourses, fetchAllCourses } from "@/lib/courses";
import { useAdminStudents } from "@/hooks/useAdminStudents";
import {
  downloadStudentsCsv,
  downloadStudentsXlsx,
} from "@/lib/export-students";
import {
  buildStudentDetailPath,
  buildStudentsListPath,
  parseStudentsListFilters,
  type StudentsListFilters,
} from "@/lib/admin-students-list-query";
import type { Student, StudentAccountStatus } from "@/types/student";
import { StudentEditForm } from "@/components/admin/StudentEditForm";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";

const PAGE_SIZE = 10;

const reviewSchema = z.object({
  accountStatus: z.enum(["Pending", "Approved", "Rejected"]),
});

type ReviewFormValues = z.infer<typeof reviewSchema>;

export function StudentsManager() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const filters = useMemo(
    () => parseStudentsListFilters(searchParams),
    [searchParams],
  );
  const {
    data: students = [],
    isLoading,
    isError,
    refetch,
  } = useAdminStudents();
  const [courses, setCourses] = useState<string[]>([]);
  const [searchInput, setSearchInput] = useState(filters.q);
  const [editTarget, setEditTarget] = useState<Student | null>(null);
  const [reviewTarget, setReviewTarget] = useState<Student | null>(null);
  const [viewTarget, setViewTarget] = useState<Student | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Student | null>(null);
  const [saving, setSaving] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [exportFormat, setExportFormat] = useState<"csv" | "xlsx">("csv");

  const reviewForm = useForm<ReviewFormValues>({
    resolver: zodResolver(reviewSchema),
    defaultValues: { accountStatus: "Pending" },
  });

  const updateFilters = useCallback(
    (patch: Partial<StudentsListFilters>) => {
      const next = { ...parseStudentsListFilters(searchParams), ...patch };
      router.replace(buildStudentsListPath(next), { scroll: false });
    },
    [router, searchParams],
  );

  useEffect(() => {
    setSearchInput(filters.q);
  }, [filters.q]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchInput !== filters.q) {
        updateFilters({ q: searchInput, page: 1 });
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [searchInput, filters.q, updateFilters]);

  useEffect(() => {
    let cancelled = false;

    async function loadCourses() {
      try {
        await ensureDefaultPharmacyCourses();
        const courseList = await fetchAllCourses();
        if (!cancelled) {
          setCourses(courseList.map((c) => c.name));
        }
      } catch {
        if (!cancelled) {
          setCourses([]);
        }
      }
    }

    void loadCourses();
    return () => {
      cancelled = true;
    };
  }, []);

  const courseOptions = useMemo(() => {
    const names = new Set<string>();
    for (const course of courses) {
      names.add(course);
    }
    for (const student of students) {
      if (student.course) {
        names.add(student.course);
      }
    }
    if (filters.course !== "all") {
      names.add(filters.course);
    }
    return [...names].sort((a, b) => a.localeCompare(b));
  }, [courses, students, filters.course]);

  const filtered = useMemo(() => {
    const q = filters.q.toLowerCase().trim();
    const courseFilter = filters.course.trim();
    return students.filter((s) => {
      const matchesSearch =
        !q ||
        s.name.toLowerCase().includes(q) ||
        s.email.toLowerCase().includes(q) ||
        s.registrationId.toLowerCase().includes(q);
      const matchesCourse =
        filters.course === "all" || s.course.trim() === courseFilter;
      const matchesStatus =
        filters.status === "all" || s.accountStatus === filters.status;
      return matchesSearch && matchesCourse && matchesStatus;
    });
  }, [students, filters.q, filters.course, filters.status]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const page = Math.min(filters.page, totalPages);
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);
  const listFiltersSnapshot = useMemo(
    () => ({ ...filters, page }),
    [filters, page],
  );

  useEffect(() => {
    if (isLoading || students.length === 0) return;
    if (filters.page > totalPages) {
      updateFilters({ page: totalPages });
    }
  }, [filters.page, totalPages, updateFilters, isLoading, students.length]);

  const openReview = (student: Student) => {
    setReviewTarget(student);
    reviewForm.reset({ accountStatus: student.accountStatus });
  };

  const handleReview = async (values: ReviewFormValues) => {
    if (!reviewTarget) return;
    setSaving(true);
    try {
      await apiUpdateStudentProfile(reviewTarget.uid, {
        accountStatus: values.accountStatus,
      });
      toast.success("Student status updated");
      setReviewTarget(null);
      await refetch();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to update status",
      );
    } finally {
      setSaving(false);
    }
  };

  const openEdit = (student: Student) => {
    setEditTarget(student);
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setSaving(true);
    try {
      await apiDeleteStudent(deleteTarget.uid);
      toast.success("Student deleted");
      setDeleteTarget(null);
      await refetch();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete student",
      );
    } finally {
      setSaving(false);
    }
  };

  const handleExport = () => {
    if (filtered.length === 0) {
      toast.error("No students match the current filters.");
      return;
    }
    if (exportFormat === "csv") {
      downloadStudentsCsv(filtered);
    } else {
      downloadStudentsXlsx(filtered);
    }
    toast.success(`Exported ${filtered.length} student(s).`);
    setExportOpen(false);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-heading font-bold">Students</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Manage registered students
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <Input
          placeholder="Search by name, email, or ID..."
          value={searchInput}
          onChange={(e) => setSearchInput(e.target.value)}
          className="max-w-sm"
        />
        <Select
          value={filters.status}
          onValueChange={(v) =>
            updateFilters({
              status: v as StudentAccountStatus | "all",
              page: 1,
            })
          }
        >
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="Pending">Pending</SelectItem>
            <SelectItem value="Approved">Approved</SelectItem>
            <SelectItem value="Rejected">Rejected</SelectItem>
          </SelectContent>
        </Select>
        <Select
          value={filters.course}
          onValueChange={(course) => updateFilters({ course, page: 1 })}
        >
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Filter by course" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All courses</SelectItem>
            {courseOptions.map((c) => (
              <SelectItem key={c} value={c}>
                {c}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button variant="outline" onClick={() => setExportOpen(true)}>
          <Download className="mr-2 h-4 w-4" />
          Export
        </Button>
      </div>

      {isLoading && students.length === 0 ? (
        <div className="space-y-2">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
        </div>
      ) : isError ? (
        <div className="py-8 text-center space-y-3">
          <p className="text-muted-foreground text-sm">
            Could not load students.
          </p>
          <Button type="button" variant="outline" onClick={() => void refetch()}>
            Retry
          </Button>
        </div>
      ) : filtered.length === 0 ? (
        <p className="text-muted-foreground text-sm py-8 text-center">
          {students.length > 0
            ? "No students match the current filters."
            : "No students found."}
        </p>
      ) : (
        <>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Reg. ID</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Phone</TableHead>
                <TableHead>Course</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Joined</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginated.map((s) => (
                <TableRow key={s.uid}>
                  <TableCell className="font-mono text-sm">
                    {s.registrationId}
                  </TableCell>
                  <TableCell>
                    <Link
                      href={buildStudentDetailPath(s.uid, listFiltersSnapshot)}
                      className="font-medium hover:underline"
                    >
                      {s.name}
                    </Link>
                  </TableCell>
                  <TableCell>{s.email}</TableCell>
                  <TableCell>{s.phone}</TableCell>
                  <TableCell>{s.course || "—"}</TableCell>
                  <TableCell>
                    <Badge
                      variant={
                        s.accountStatus === "Approved"
                          ? "default"
                          : s.accountStatus === "Rejected"
                            ? "destructive"
                            : "secondary"
                      }
                    >
                      {s.accountStatus}
                    </Badge>
                  </TableCell>
                  <TableCell>{toDateString(s.createdAt)}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openReview(s)}
                        title="Review student"
                      >
                        <CheckCircle className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() =>
                          router.push(
                            buildStudentDetailPath(s.uid, listFiltersSnapshot),
                          )
                        }
                        title="View student details"
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEdit(s)}
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteTarget(s)}
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {totalPages > 1 && (
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      updateFilters({ page: Math.max(1, page - 1) });
                    }}
                    className={
                      page <= 1 ? "pointer-events-none opacity-50" : ""
                    }
                  />
                </PaginationItem>
                {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                  (p) => (
                    <PaginationItem key={p}>
                      <PaginationLink
                        href="#"
                        isActive={p === page}
                        onClick={(e) => {
                          e.preventDefault();
                          updateFilters({ page: p });
                        }}
                      >
                        {p}
                      </PaginationLink>
                    </PaginationItem>
                  ),
                )}
                <PaginationItem>
                  <PaginationNext
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      updateFilters({ page: Math.min(totalPages, page + 1) });
                    }}
                    className={
                      page >= totalPages
                        ? "pointer-events-none opacity-50"
                        : ""
                    }
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}
        </>
      )}

      <Dialog open={!!viewTarget} onOpenChange={() => setViewTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Student Profile</DialogTitle>
          </DialogHeader>
          {viewTarget && (
            <div className="grid gap-3 text-sm">
              <p>
                <span className="text-muted-foreground">ID: </span>
                {viewTarget.registrationId}
              </p>
              <p>
                <span className="text-muted-foreground">Name: </span>
                {viewTarget.name}
              </p>
              <p>
                <span className="text-muted-foreground">Email: </span>
                {viewTarget.email}
              </p>
              <p>
                <span className="text-muted-foreground">Phone: </span>
                {viewTarget.phone}
              </p>
              <p>
                <span className="text-muted-foreground">Course: </span>
                {viewTarget.course || "Not assigned"}
              </p>
              <p>
                <span className="text-muted-foreground">Status: </span>
                {viewTarget.accountStatus}
              </p>
              <p>
                <span className="text-muted-foreground">Scholarship: </span>
                {viewTarget.scholarshipPercentage ?? 0}%
              </p>
              {viewTarget.feeNotes ? (
                <p>
                  <span className="text-muted-foreground">Fee notes: </span>
                  {viewTarget.feeNotes}
                </p>
              ) : null}
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={!!reviewTarget} onOpenChange={() => setReviewTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Review Student</DialogTitle>
          </DialogHeader>
          {reviewTarget && (
            <p className="text-sm text-muted-foreground mb-2">
              {reviewTarget.name} — {reviewTarget.registrationId}
            </p>
          )}
          <form
            onSubmit={reviewForm.handleSubmit(handleReview)}
            className="space-y-4"
          >
            <div className="space-y-2">
              <Label>Account status</Label>
              <Select
                value={reviewForm.watch("accountStatus")}
                onValueChange={(v) =>
                  reviewForm.setValue("accountStatus", v as StudentAccountStatus)
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="Approved">Approved</SelectItem>
                  <SelectItem value="Rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <DialogFooter>
              <Button type="submit" disabled={saving}>
                {saving ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!editTarget} onOpenChange={() => setEditTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Student</DialogTitle>
          </DialogHeader>
          {editTarget && (
            <StudentEditForm
              student={editTarget}
              onSuccess={() => {
                setEditTarget(null);
                void refetch();
              }}
            />
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={exportOpen} onOpenChange={setExportOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Export students</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            {filtered.length} student(s) will be exported using the current search, status,
            and course filters.
          </p>
          <div className="space-y-2">
            <Label>Format</Label>
            <Select
              value={exportFormat}
              onValueChange={(value) => setExportFormat(value as "csv" | "xlsx")}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="csv">CSV</SelectItem>
                <SelectItem value="xlsx">Excel (.xlsx)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => setExportOpen(false)}>
              Cancel
            </Button>
            <Button type="button" onClick={handleExport} disabled={filtered.length === 0}>
              Download
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={() => setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete student?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete {deleteTarget?.name}&apos;s account,
              assignments, and uploaded files. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {saving ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
