"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import {
  fetchResearchHeroContentAdmin,
  saveResearchHeroContentAdmin,
} from "@/lib/research-page-admin-cms-api";
import {
  CmsHeroImagePairField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import {
  ResearchPageAdminBackLink,
  ResearchPageAdminHeader,
  ResearchPageFormFooter,
} from "@/components/admin/research-page/ResearchPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z.object({
  title: z.string().min(1, "Title is required"),
  subtitle: z.string(),
  imageAlt: z.string(),
  heroVideoUrl: z.string(),
});

type FormValues = z.infer<typeof formSchema>;

export function ResearchHeroManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [desktopImage, setDesktopImage] = useState<CmsImageUploadValue | null>(null);
  const [mobileImage, setMobileImage] = useState<CmsImageUploadValue | null>(null);
  const [desktopPendingPreview, setDesktopPendingPreview] = useState<string | null>(null);
  const [mobilePendingPreview, setMobilePendingPreview] = useState<string | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      subtitle: "",
      imageAlt: "",
      heroVideoUrl: "",
    },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchResearchHeroContentAdmin();
      if (data) {
        setDesktopImage(data.heroImageUrl ? { url: data.heroImageUrl } : null);
        setMobileImage(
          data.mobileHeroImageUrl ? { url: data.mobileHeroImageUrl } : null,
        );
        form.reset({
          title: data.title,
          subtitle: data.subtitle,
          imageAlt: data.imageAlt,
          heroVideoUrl: data.heroVideoUrl ?? "",
        });
      }
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to load");
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    void loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    if (saving) return;
    if (!desktopImage?.url) {
      toast.error("Please upload a hero image");
      return;
    }
    setSaving(true);
    try {
      await saveResearchHeroContentAdmin({
        title: values.title.trim(),
        subtitle: values.subtitle.trim(),
        heroImageUrl: desktopImage.url,
        mobileHeroImageUrl: mobileImage?.url,
        heroVideoUrl: values.heroVideoUrl.trim() || undefined,
        imageAlt: values.imageAlt.trim() || values.title.trim(),
      });
      toast.success("Hero saved.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Skeleton className="h-96 w-full" />;

  return (
    <section>
      <ResearchPageAdminBackLink />
      <ResearchPageAdminHeader
        title="Hero Section"
        description="Full-screen research banner with scroll reveal."
      />
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6 max-w-2xl">
        <div className="space-y-2">
          <Label htmlFor="title">Headline</Label>
          <Input id="title" {...form.register("title")} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="subtitle">Description</Label>
          <Textarea id="subtitle" rows={3} {...form.register("subtitle")} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="heroVideoUrl">Hero Video URL (optional)</Label>
          <Input id="heroVideoUrl" {...form.register("heroVideoUrl")} placeholder="https://..." />
        </div>
        <CmsHeroImagePairField
          desktop={desktopImage}
          mobile={mobileImage}
          onDesktopChange={setDesktopImage}
          onMobileChange={setMobileImage}
          folder="cms/research/hero"
          fileBaseName="banner"
          desktopPendingPreview={desktopPendingPreview}
          mobilePendingPreview={mobilePendingPreview}
          onDesktopPendingPreviewChange={setDesktopPendingPreview}
          onMobilePendingPreviewChange={setMobilePendingPreview}
        />
        <div className="space-y-2">
          <Label htmlFor="imageAlt">Image alt text</Label>
          <Input id="imageAlt" {...form.register("imageAlt")} />
        </div>
        <ResearchPageFormFooter
          end={
            <Button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save Hero"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
