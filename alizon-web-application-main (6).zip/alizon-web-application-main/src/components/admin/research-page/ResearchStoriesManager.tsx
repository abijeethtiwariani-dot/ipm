"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import Image from "next/image";
import { Loader2, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { ResearchStory } from "@/types/cms";
import {
  createResearchStoryAdmin,
  deleteResearchStoryAdmin,
  fetchResearchStoriesAdmin,
  updateResearchStoryAdmin,
} from "@/lib/research-page-admin-cms-api";
import { uploadCmsImageUrl } from "@/lib/admin-cms-api";
import {
  ResearchPageAdminBackLink,
  ResearchPageAdminHeader,
} from "@/components/admin/research-page/ResearchPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const cardSchema = z.object({
  name: z.string().min(1, "Name is required"),
  designation: z.string(),
  department: z.string(),
  testimonial: z.string().min(10, "Testimonial is required"),
  order: z.coerce.number().int().min(0),
  photoUrl: z.string(),
});

type CardValues = z.infer<typeof cardSchema>;

export function ResearchStoriesManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [stories, setStories] = useState<ResearchStory[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<ResearchStory | null>(null);
  const [photoPreview, setPhotoPreview] = useState("");
  const [photoUploading, setPhotoUploading] = useState(false);
  const [photoUploadProgress, setPhotoUploadProgress] = useState(0);

  const form = useForm<CardValues>({
    resolver: zodResolver(cardSchema),
    defaultValues: {
      name: "",
      designation: "",
      department: "",
      testimonial: "",
      order: 0,
      photoUrl: "",
    },
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setStories(await fetchResearchStoriesAdmin());
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to load");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const openCreate = () => {
    setEditing(null);
    setPhotoPreview("");
    form.reset({
      name: "",
      designation: "",
      department: "",
      testimonial: "",
      order: stories.length,
      photoUrl: "",
    });
    setDialogOpen(true);
  };

  const openEdit = (story: ResearchStory) => {
    setEditing(story);
    setPhotoPreview(story.photoUrl);
    form.reset({
      name: story.name,
      designation: story.designation,
      department: story.department,
      testimonial: story.testimonial,
      order: story.order,
      photoUrl: story.photoUrl,
    });
    setDialogOpen(true);
  };

  const onPhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setPhotoUploading(true);
    setPhotoUploadProgress(0);
    try {
      const url = await uploadCmsImageUrl("cms/research/stories", file, {
        onProgress: setPhotoUploadProgress,
      });
      setPhotoPreview(url);
      form.setValue("photoUrl", url);
      toast.success("Photo uploaded.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Upload failed");
    } finally {
      setPhotoUploading(false);
      setTimeout(() => setPhotoUploadProgress(0), 400);
      e.target.value = "";
    }
  };

  const saveStory = async (values: CardValues) => {
    if (saving) return;

    const payload = {
      name: values.name.trim(),
      designation: values.designation.trim(),
      department: values.department.trim(),
      testimonial: values.testimonial.trim(),
      order: values.order,
      photoUrl: values.photoUrl.trim(),
    };

    setSaving(true);
    try {
      if (editing) {
        await updateResearchStoryAdmin(editing.id, payload);
        toast.success("Story updated.");
      } else {
        await createResearchStoryAdmin(payload);
        toast.success("Story created.");
      }
      setDialogOpen(false);
      await load();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  const removeStory = async (id: string) => {
    try {
      await deleteResearchStoryAdmin(id);
      toast.success("Story deleted.");
      await load();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Delete failed");
    }
  };

  if (loading) return <Skeleton className="h-96 w-full" />;

  return (
    <section>
      <ResearchPageAdminBackLink />
      <ResearchPageAdminHeader
        title="Research Stories"
        description="Researcher testimonials for the carousel on the public research page."
      />
      <div className="flex justify-end mb-4">
        <Button onClick={openCreate} size="sm" disabled={saving}>
          <Plus className="mr-1 h-4 w-4" />
          Add Story
        </Button>
      </div>
      <div className="rounded-lg border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Designation</TableHead>
              <TableHead>Order</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {stories.map((story) => (
              <TableRow key={story.id}>
                <TableCell>{story.name}</TableCell>
                <TableCell>{story.designation}</TableCell>
                <TableCell>{story.order}</TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm" onClick={() => openEdit(story)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => void removeStory(story.id)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog
        open={dialogOpen}
        onOpenChange={(open) => {
          if (saving) return;
          setDialogOpen(open);
          if (!open) setSaving(false);
        }}
      >
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Story" : "Add Story"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(saveStory)} className="space-y-4">
            <div className="space-y-2">
              <Label>Name</Label>
              <Input {...form.register("name")} />
            </div>
            <div className="space-y-2">
              <Label>Designation</Label>
              <Input {...form.register("designation")} />
            </div>
            <div className="space-y-2">
              <Label>Department</Label>
              <Input {...form.register("department")} />
            </div>
            <div className="space-y-2">
              <Label>Photo</Label>
              <Input
                type="file"
                accept="image/*"
                onChange={onPhotoUpload}
                disabled={photoUploading}
              />
              {photoUploading || photoUploadProgress > 0 ? (
                <div className="space-y-1">
                  <Progress value={photoUploadProgress} className="h-2" />
                  <p className="text-xs text-muted-foreground">
                    Uploading… {photoUploadProgress}%
                  </p>
                </div>
              ) : null}
              {photoPreview && (
                <div className="relative h-20 w-20 overflow-hidden rounded-full">
                  <Image src={photoPreview} alt="" fill className="object-cover" />
                </div>
              )}
            </div>
            <div className="space-y-2">
              <Label>Testimonial</Label>
              <Textarea rows={4} {...form.register("testimonial")} />
            </div>
            <div className="space-y-2">
              <Label>Order</Label>
              <Input type="number" {...form.register("order")} />
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                disabled={saving}
                onClick={() => {
                  setSaving(false);
                  setDialogOpen(false);
                }}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving}>
                {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {saving ? "Saving…" : "Save Story"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </section>
  );
}
