"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { ResearchBenefitCard, CareersIconKey } from "@/types/cms";
import {
  createResearchBenefitAdmin,
  deleteResearchBenefitAdmin,
  fetchResearchBenefitsAdmin,
  updateResearchBenefitAdmin,
} from "@/lib/research-page-admin-cms-api";
import {
  ResearchPageAdminBackLink,
  ResearchPageAdminHeader,
} from "@/components/admin/research-page/ResearchPageAdminLayout";
import { ResearchIconSelect } from "@/components/admin/research-page/ResearchIconSelect";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const cardSchema = z.object({
  icon: z.string(),
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  order: z.coerce.number().int().min(0),
});

type CardValues = z.infer<typeof cardSchema>;

export function ResearchBenefitsManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [cards, setCards] = useState<ResearchBenefitCard[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<ResearchBenefitCard | null>(null);

  const form = useForm<CardValues>({
    resolver: zodResolver(cardSchema),
    defaultValues: { icon: "heart", title: "", description: "", order: 0 },
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setCards(await fetchResearchBenefitsAdmin());
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to load");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const openCreate = () => {
    setEditing(null);
    form.reset({ icon: "heart", title: "", description: "", order: cards.length });
    setDialogOpen(true);
  };

  const openEdit = (card: ResearchBenefitCard) => {
    setEditing(card);
    form.reset({
      icon: card.icon,
      title: card.title,
      description: card.description,
      order: card.order,
    });
    setDialogOpen(true);
  };

  const saveCard = async (values: CardValues) => {
    if (saving) return;

    const payload = {
      icon: values.icon as CareersIconKey,
      title: values.title.trim(),
      description: values.description.trim(),
      order: values.order,
    };

    setSaving(true);
    try {
      if (editing) {
        await updateResearchBenefitAdmin(editing.id, payload);
        toast.success("Benefit updated.");
      } else {
        await createResearchBenefitAdmin(payload);
        toast.success("Benefit created.");
      }
      setDialogOpen(false);
      await load();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Save failed");
    } finally {
      setSaving(false);
    }
  };

  const removeCard = async (id: string) => {
    try {
      await deleteResearchBenefitAdmin(id);
      toast.success("Benefit deleted.");
      await load();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Delete failed");
    }
  };

  if (loading) return <Skeleton className="h-96 w-full" />;

  return (
    <section>
      <ResearchPageAdminBackLink />
      <ResearchPageAdminHeader
        title="Benefits & Culture"
        description="Benefits and culture feature cards."
      />
      <div className="flex justify-end mb-4">
        <Button onClick={openCreate} size="sm" disabled={saving}>
          <Plus className="mr-1 h-4 w-4" />
          Add Benefit
        </Button>
      </div>
      <div className="rounded-lg border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Order</TableHead>
              <TableHead>Title</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {cards.map((card) => (
              <TableRow key={card.id}>
                <TableCell>{card.order}</TableCell>
                <TableCell>{card.title}</TableCell>
                <TableCell className="text-right">
                  <Button variant="ghost" size="sm" onClick={() => openEdit(card)}>
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => void removeCard(card.id)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog
        open={dialogOpen}
        onOpenChange={(open) => {
          if (saving) return;
          setDialogOpen(open);
          if (!open) setSaving(false);
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Benefit" : "Add Benefit"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(saveCard)} className="space-y-4">
            <div className="space-y-2">
              <Label>Icon</Label>
              <ResearchIconSelect
                value={form.watch("icon")}
                onChange={(v) => form.setValue("icon", v)}
              />
            </div>
            <div className="space-y-2">
              <Label>Title</Label>
              <Input {...form.register("title")} />
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Textarea rows={3} {...form.register("description")} />
            </div>
            <div className="space-y-2">
              <Label>Order</Label>
              <Input type="number" {...form.register("order")} />
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                disabled={saving}
                onClick={() => {
                  setSaving(false);
                  setDialogOpen(false);
                }}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving}>
                {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {saving ? "Saving…" : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </section>
  );
}
