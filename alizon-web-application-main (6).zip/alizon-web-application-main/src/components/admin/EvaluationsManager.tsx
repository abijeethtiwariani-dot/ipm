"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { CheckCircle, ExternalLink, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  apiBulkDeleteEvaluations,
  apiDeleteEvaluation,
  apiFetchAllEvaluations,
  apiGradeEvaluation,
} from "@/lib/admin-evaluations-api";
import {
  fetchAllPrograms,
  getProgramEvaluationMaxMarks,
} from "@/lib/programs";
import { resolveStudentProgramId } from "@/lib/program-student-count";
import type { Program } from "@/types/program";
import { AdminBulkSelectionBar } from "@/components/admin/AdminBulkSelectionBar";
import type {
  EvaluationComponent,
  EvaluationGradeComponentKey,
  EvaluationStatus,
  StudentEvaluationRow,
} from "@/types/student-evaluation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";

const PAGE_SIZE = 10;

const gradeSchema = z.object({
  marks: z.coerce.number().min(0),
  feedback: z.string(),
});

type GradeFormValues = z.infer<typeof gradeSchema>;

function statusBadge(status: EvaluationStatus) {
  const variant =
    status === "Graded"
      ? "default"
      : status === "Pending"
        ? "secondary"
        : "outline";
  return <Badge variant={variant}>{status}</Badge>;
}

function ComponentCell({
  component,
  label,
  maxMarks,
  onGrade,
}: {
  component: EvaluationComponent;
  label: EvaluationGradeComponentKey;
  maxMarks: number | null;
  onGrade: (key: EvaluationGradeComponentKey) => void;
}) {
  return (
    <div className="space-y-1 min-w-[140px]">
      {statusBadge(component.status)}
      <div className="text-sm">
        Marks:{" "}
        {component.marks !== null ? (
          maxMarks !== null ? (
            `${component.marks} / ${maxMarks}`
          ) : (
            <Skeleton className="inline-block h-4 w-14 align-middle" />
          )
        ) : (
          "—"
        )}
      </div>
      {component.fileUrl && (
        <Button variant="link" size="sm" className="h-auto p-0" asChild>
          <a href={component.fileUrl} target="_blank" rel="noopener noreferrer">
            <ExternalLink className="w-3 h-3 mr-1 inline" />
            Document
          </a>
        </Button>
      )}
      <Button
        variant="ghost"
        size="sm"
        className="h-7 px-2"
        onClick={() => onGrade(label)}
      >
        <CheckCircle className="w-3 h-3 mr-1" />
        Grade
      </Button>
    </div>
  );
}

export function EvaluationsManager() {
  const [rows, setRows] = useState<StudentEvaluationRow[]>([]);
  const [programs, setPrograms] = useState<Program[]>([]);
  const [programsLoading, setProgramsLoading] = useState(true);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<EvaluationStatus | "all">("all");
  const [page, setPage] = useState(1);
  const [gradeTarget, setGradeTarget] = useState<{
    row: StudentEvaluationRow;
    component: EvaluationGradeComponentKey;
  } | null>(null);
  const [saving, setSaving] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [deleteTarget, setDeleteTarget] = useState<StudentEvaluationRow | null>(null);
  const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const form = useForm<GradeFormValues>({
    resolver: zodResolver(gradeSchema),
    defaultValues: { marks: 0, feedback: "" },
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await apiFetchAllEvaluations();
      setRows(data);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load evaluations",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    setProgramsLoading(true);
    fetchAllPrograms()
      .then(setPrograms)
      .catch(() => setPrograms([]))
      .finally(() => setProgramsLoading(false));
  }, []);

  const programsById = useMemo(
    () => new Map(programs.map((p) => [p.id, p])),
    [programs],
  );

  const getRowProgramId = (row: StudentEvaluationRow): string =>
    row.resolvedProgramId ||
    resolveStudentProgramId(
      { programId: row.programId, course: row.course },
      programs,
    );

  const resolveMaxMarks = (
    row: StudentEvaluationRow,
    component: EvaluationGradeComponentKey,
  ): number | null => {
    if (programsLoading) return null;
    const programId = getRowProgramId(row);
    if (!programId) return null;
    const program = programsById.get(programId);
    if (!program) return null;
    return getProgramEvaluationMaxMarks(program, component);
  };

  const gradeMaxMarks = gradeTarget
    ? resolveMaxMarks(gradeTarget.row, gradeTarget.component)
    : null;

  const gradeProgramName = gradeTarget
    ? programsById.get(getRowProgramId(gradeTarget.row))?.name
    : undefined;

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    return rows.filter((row) => {
      const matchesSearch =
        !q ||
        row.studentName.toLowerCase().includes(q) ||
        row.studentEmail.toLowerCase().includes(q) ||
        row.registrationId.toLowerCase().includes(q);

      if (!matchesSearch) return false;

      if (statusFilter !== "all") {
        const matchesStatus = (["viva", "internship", "elective"] as const).some(
          (key) => row[key].status === statusFilter,
        );
        if (!matchesStatus) return false;
      }

      return true;
    });
  }, [rows, search, statusFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const filteredIds = useMemo(() => filtered.map((r) => r.studentId), [filtered]);
  const allFilteredSelected =
    filtered.length > 0 && filtered.every((r) => selectedIds.has(r.studentId));

  useEffect(() => {
    setPage(1);
  }, [search, statusFilter]);

  useEffect(() => {
    setSelectedIds((prev) => {
      const allowed = new Set(filteredIds);
      const next = new Set([...prev].filter((id) => allowed.has(id)));
      return next.size === prev.size ? prev : next;
    });
  }, [filteredIds]);

  const toggleSelectAll = () => {
    if (allFilteredSelected) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredIds));
    }
  };

  const toggleRow = (id: string, checked: boolean) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (checked) next.add(id);
      else next.delete(id);
      return next;
    });
  };

  const handleDeleteOne = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await apiDeleteEvaluation(deleteTarget.studentId);
      toast.success("Evaluation record deleted");
      setDeleteTarget(null);
      setSelectedIds((prev) => {
        const next = new Set(prev);
        next.delete(deleteTarget.studentId);
        return next;
      });
      await load();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete evaluation",
      );
    } finally {
      setDeleting(false);
    }
  };

  const handleBulkDelete = async () => {
    const ids = [...selectedIds];
    if (ids.length === 0) return;
    setDeleting(true);
    try {
      await apiBulkDeleteEvaluations(ids);
      toast.success(
        ids.length === 1
          ? "Evaluation record deleted"
          : `${ids.length} evaluation records deleted`,
      );
      setBulkDeleteOpen(false);
      setSelectedIds(new Set());
      await load();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete evaluations",
      );
    } finally {
      setDeleting(false);
    }
  };

  const openGrade = (
    row: StudentEvaluationRow,
    component: EvaluationGradeComponentKey,
  ) => {
    const comp = row[component];
    setGradeTarget({ row, component });
    form.reset({
      marks: comp.marks ?? 0,
      feedback: comp.feedback ?? "",
    });
  };

  const handleGrade = async (values: GradeFormValues) => {
    if (!gradeTarget) return;
    if (gradeMaxMarks === null) {
      toast.error("Program evaluation limits are still loading. Try again.");
      return;
    }
    if (values.marks > gradeMaxMarks) {
      toast.error(`Marks must be between 0 and ${gradeMaxMarks}.`);
      return;
    }
    setSaving(true);
    try {
      await apiGradeEvaluation(gradeTarget.row.studentId, {
        component: gradeTarget.component,
        marks: values.marks,
        feedback: values.feedback,
      });
      toast.success("Evaluation updated");
      setGradeTarget(null);
      await load();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save marks",
      );
    } finally {
      setSaving(false);
    }
  };

  const gradeLabel =
    gradeTarget?.component === "viva"
      ? "Viva"
      : gradeTarget?.component === "internship"
        ? "Internship"
        : "Elective";

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-heading font-bold">Evaluations</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Grade viva, internship, and elective marks
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 flex-wrap">
        <Input
          placeholder="Search by name, email, or ID..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-sm"
        />
        <Select
          value={statusFilter}
          onValueChange={(v) => setStatusFilter(v as EvaluationStatus | "all")}
        >
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="NotSubmitted">Not submitted</SelectItem>
            <SelectItem value="Pending">Pending</SelectItem>
            <SelectItem value="Graded">Graded</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="space-y-2">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
        </div>
      ) : filtered.length === 0 ? (
        <p className="text-muted-foreground text-sm py-8 text-center">
          No students found.
        </p>
      ) : (
        <>
          <AdminBulkSelectionBar
            filteredCount={filtered.length}
            selectedCount={selectedIds.size}
            allFilteredSelected={allFilteredSelected}
            onToggleSelectAll={toggleSelectAll}
            onBulkDelete={() => setBulkDeleteOpen(true)}
            deleting={deleting}
            entityLabel="students"
          />

          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10" />
                  <TableHead>Student</TableHead>
                  <TableHead>Reg. ID</TableHead>
                  <TableHead>Viva</TableHead>
                  <TableHead>Internship</TableHead>
                  <TableHead>Elective</TableHead>
                  <TableHead className="text-right w-16">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginated.map((row) => (
                  <TableRow key={row.studentId}>
                    <TableCell>
                      <Checkbox
                        checked={selectedIds.has(row.studentId)}
                        onCheckedChange={(checked) =>
                          toggleRow(row.studentId, checked === true)
                        }
                        aria-label={`Select ${row.studentName}`}
                      />
                    </TableCell>
                    <TableCell>
                      <p className="font-medium">{row.studentName}</p>
                      <p className="text-xs text-muted-foreground">
                        {row.studentEmail}
                      </p>
                    </TableCell>
                    <TableCell className="font-mono text-sm">
                      {row.registrationId}
                    </TableCell>
                    <TableCell>
                      <ComponentCell
                        component={row.viva}
                        label="viva"
                        maxMarks={resolveMaxMarks(row, "viva")}
                        onGrade={(key) => openGrade(row, key)}
                      />
                    </TableCell>
                    <TableCell>
                      <ComponentCell
                        component={row.internship}
                        label="internship"
                        maxMarks={resolveMaxMarks(row, "internship")}
                        onGrade={(key) => openGrade(row, key)}
                      />
                    </TableCell>
                    <TableCell>
                      <ComponentCell
                        component={row.elective}
                        label="elective"
                        maxMarks={resolveMaxMarks(row, "elective")}
                        onGrade={(key) => openGrade(row, key)}
                      />
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteTarget(row)}
                        title="Delete evaluation record"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {totalPages > 1 && (
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      setPage((p) => Math.max(1, p - 1));
                    }}
                    className={
                      page <= 1 ? "pointer-events-none opacity-50" : ""
                    }
                  />
                </PaginationItem>
                {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                  (p) => (
                    <PaginationItem key={p}>
                      <PaginationLink
                        href="#"
                        isActive={p === page}
                        onClick={(e) => {
                          e.preventDefault();
                          setPage(p);
                        }}
                      >
                        {p}
                      </PaginationLink>
                    </PaginationItem>
                  ),
                )}
                <PaginationItem>
                  <PaginationNext
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      setPage((p) => Math.min(totalPages, p + 1));
                    }}
                    className={
                      page >= totalPages
                        ? "pointer-events-none opacity-50"
                        : ""
                    }
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}
        </>
      )}

      <AlertDialog open={!!deleteTarget} onOpenChange={() => setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete evaluation record?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove viva, internship, and elective data for{" "}
              {deleteTarget?.studentName ?? "this student"} and delete any
              uploaded documents. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                void handleDeleteOne();
              }}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleting}
            >
              {deleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={bulkDeleteOpen} onOpenChange={setBulkDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete selected evaluation records?</AlertDialogTitle>
            <AlertDialogDescription>
              You are about to delete evaluation data for {selectedIds.size}{" "}
              student{selectedIds.size === 1 ? "" : "s"}, including marks and
              uploaded documents. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                void handleBulkDelete();
              }}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleting}
            >
              {deleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={!!gradeTarget} onOpenChange={() => setGradeTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Grade {gradeLabel}</DialogTitle>
          </DialogHeader>
          {gradeTarget && (
            <div className="mb-2 space-y-1 text-sm text-muted-foreground">
              <p>
                {gradeTarget.row.studentName} — {gradeTarget.row.registrationId}
              </p>
              {gradeProgramName ? (
                <p>
                  Program: <span className="text-foreground">{gradeProgramName}</span>
                </p>
              ) : null}
            </div>
          )}
          <form
            onSubmit={form.handleSubmit(handleGrade)}
            className="space-y-4"
          >
            <div className="space-y-2">
              {programsLoading ? (
                <>
                  <Label>Marks</Label>
                  <Skeleton className="h-10 w-full" />
                </>
              ) : gradeMaxMarks === null ? (
                <>
                  <Label>Marks</Label>
                  <p className="text-sm text-muted-foreground rounded-md border border-border p-3">
                    This student has no program assigned. Set their course on the
                    student profile, then try grading again.
                  </p>
                </>
              ) : (
                <>
                  <Label>Marks (0–{gradeMaxMarks})</Label>
                  <Input
                    type="number"
                    min={0}
                    max={gradeMaxMarks}
                    {...form.register("marks")}
                  />
                </>
              )}
            </div>
            <div className="space-y-2">
              <Label>Feedback</Label>
              <Textarea {...form.register("feedback")} rows={3} />
            </div>
            <DialogFooter>
              <Button
                type="submit"
                disabled={saving || programsLoading || gradeMaxMarks === null}
              >
                {saving ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
