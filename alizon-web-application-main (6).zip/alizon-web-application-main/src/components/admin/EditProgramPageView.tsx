"use client";

import { useEffect, useState } from "react";
import { apiFetchProgram } from "@/lib/admin-programs-api";
import type { Program } from "@/types/program";
import { ProgramForm } from "@/components/admin/ProgramForm";

export function EditProgramPageView({ programId }: { programId: string }) {
  const [program, setProgram] = useState<Program | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    void apiFetchProgram(programId)
      .then((data) => {
        if (!active) return;
        setProgram(data);
        setLoading(false);
        if (!data) setError("Program not found.");
      })
      .catch((loadError) => {
        if (!active) return;
        setError(loadError instanceof Error ? loadError.message : "Failed to load program.");
        setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [programId]);

  if (loading) {
    return <div className="rounded-xl border bg-card p-6 text-sm text-muted-foreground">Loading program...</div>;
  }

  if (error || !program) {
    return (
      <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-6 text-sm text-destructive">
        {error ?? "Program not found."}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h1 className="text-3xl font-heading font-bold">Edit Program</h1>
      <ProgramForm program={program} />
    </div>
  );
}
