"use client";

import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Download, ExternalLink, CheckCircle, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  toSubmissionDateString,
} from "@/lib/assignments";
import {
  apiBulkDeleteAssignments,
  apiDeleteAssignment,
  apiFetchAssignments,
  apiGradeAssignment,
} from "@/lib/admin-assignments-api";
import { AdminBulkSelectionBar } from "@/components/admin/AdminBulkSelectionBar";
import { getProgramModule } from "@/lib/modules";
import { fetchAllPrograms } from "@/lib/programs";
import { DEFAULT_ASSIGNMENT_TOTAL_MARKS } from "@/lib/student-constants";
import { apiFetchAllStudents } from "@/lib/admin-students-api";
import type { Program } from "@/types/program";
import type { Assignment, AssignmentStatus, Student } from "@/types/student";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";

const PAGE_SIZE = 10;

const gradeSchema = z.object({
  status: z.enum(["Pending", "Approved", "Rejected"]),
  marks: z.coerce.number().min(0).nullable().optional(),
  feedback: z.string(),
});

type GradeFormValues = z.infer<typeof gradeSchema>;

export function AssignmentsManager() {
  const [assignments, setAssignments] = useState<Assignment[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<AssignmentStatus | "all">(
    "all",
  );
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [gradeTarget, setGradeTarget] = useState<Assignment | null>(null);
  const [saving, setSaving] = useState(false);
  const [programFilter, setProgramFilter] = useState("all");
  const [programs, setPrograms] = useState<Program[]>([]);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [deleteTarget, setDeleteTarget] = useState<Assignment | null>(null);
  const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [gradeMaxMarks, setGradeMaxMarks] = useState(DEFAULT_ASSIGNMENT_TOTAL_MARKS);

  const form = useForm<GradeFormValues>({
    resolver: zodResolver(gradeSchema),
    defaultValues: { status: "Pending", marks: undefined, feedback: "" },
  });

  useEffect(() => {
    apiFetchAllStudents().then(setStudents).catch(() => setStudents([]));
    fetchAllPrograms().then(setPrograms).catch(() => setPrograms([]));
  }, []);

  useEffect(() => {
    setLoading(true);
    apiFetchAssignments(statusFilter)
      .then((data) => {
        setAssignments(data);
        setLoading(false);
      })
      .catch(() => {
        setAssignments([]);
        setLoading(false);
      });
  }, [statusFilter]);

  const studentMap = useMemo(
    () => new Map(students.map((s) => [s.uid, s])),
    [students],
  );

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    return assignments.filter((a) => {
      const student = studentMap.get(a.studentId);
      const byProgram =
        programFilter === "all" ||
        (a.programId && a.programId === programFilter) ||
        student?.programId === programFilter;
      const bySearch =
        !q ||
        a.moduleName.toLowerCase().includes(q) ||
        a.assignmentTitle.toLowerCase().includes(q) ||
        a.registrationId.toLowerCase().includes(q) ||
        student?.name.toLowerCase().includes(q) ||
        student?.email.toLowerCase().includes(q);
      return Boolean(byProgram && bySearch);
    });
  }, [assignments, search, studentMap, programFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const filteredIds = useMemo(() => filtered.map((a) => a.id), [filtered]);
  const allFilteredSelected =
    filtered.length > 0 && filtered.every((a) => selectedIds.has(a.id));

  useEffect(() => {
    setPage(1);
  }, [search, statusFilter, programFilter]);

  useEffect(() => {
    setSelectedIds((prev) => {
      const allowed = new Set(filteredIds);
      const next = new Set([...prev].filter((id) => allowed.has(id)));
      return next.size === prev.size ? prev : next;
    });
  }, [filteredIds]);

  const toggleSelectAll = () => {
    if (allFilteredSelected) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredIds));
    }
  };

  const toggleRow = (id: string, checked: boolean) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (checked) next.add(id);
      else next.delete(id);
      return next;
    });
  };

  const handleDeleteOne = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await apiDeleteAssignment(deleteTarget.id);
      toast.success("Assignment deleted");
      setDeleteTarget(null);
      setSelectedIds((prev) => {
        const next = new Set(prev);
        next.delete(deleteTarget.id);
        return next;
      });
      const refreshed = await apiFetchAssignments(statusFilter);
      setAssignments(refreshed);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete assignment",
      );
    } finally {
      setDeleting(false);
    }
  };

  const handleBulkDelete = async () => {
    const ids = [...selectedIds];
    if (ids.length === 0) return;
    setDeleting(true);
    try {
      await apiBulkDeleteAssignments(ids);
      toast.success(
        ids.length === 1 ? "Assignment deleted" : `${ids.length} assignments deleted`,
      );
      setBulkDeleteOpen(false);
      setSelectedIds(new Set());
      const refreshed = await apiFetchAssignments(statusFilter);
      setAssignments(refreshed);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete assignments",
      );
    } finally {
      setDeleting(false);
    }
  };

  const openGrade = async (assignment: Assignment) => {
    setGradeTarget(assignment);
    let maxMarks = DEFAULT_ASSIGNMENT_TOTAL_MARKS;
    if (assignment.programId && assignment.moduleId) {
      try {
        const module = await getProgramModule(
          assignment.programId,
          assignment.moduleId,
        );
        if (module) maxMarks = module.assignmentTotalMarks;
      } catch {
        // use default
      }
    }
    setGradeMaxMarks(maxMarks);
    form.reset({
      status: assignment.status,
      marks: assignment.marks ?? undefined,
      feedback: assignment.feedback,
    });
  };

  const handleGrade = async (values: GradeFormValues) => {
    if (!gradeTarget) return;
    if (
      values.status === "Approved" &&
      values.marks !== null &&
      values.marks !== undefined &&
      values.marks > gradeMaxMarks
    ) {
      toast.error(`Marks must be between 0 and ${gradeMaxMarks}.`);
      return;
    }
    setSaving(true);
    try {
      await apiGradeAssignment(gradeTarget.id, {
        status: values.status,
        marks:
          values.status === "Approved" ? (values.marks ?? null) : null,
        feedback: values.feedback,
      });
      const refreshed = await apiFetchAssignments(statusFilter);
      setAssignments(refreshed);
      toast.success("Assignment updated");
      setGradeTarget(null);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to update assignment",
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-heading font-bold">Assignments</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Review and grade student submissions
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <Input
          placeholder="Search student, module, title..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-sm"
        />
        <Select
          value={statusFilter}
          onValueChange={(v) =>
            setStatusFilter(v as AssignmentStatus | "all")
          }
        >
          <SelectTrigger className="w-[160px]">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All statuses</SelectItem>
            <SelectItem value="Pending">Pending</SelectItem>
            <SelectItem value="Approved">Approved</SelectItem>
            <SelectItem value="Rejected">Rejected</SelectItem>
          </SelectContent>
        </Select>
        <Select value={programFilter} onValueChange={setProgramFilter}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Program" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All programs</SelectItem>
            {programs.map((program) => (
              <SelectItem key={program.id} value={program.id}>
                {program.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {loading ? (
        <div className="space-y-2">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
        </div>
      ) : filtered.length === 0 ? (
        <p className="text-muted-foreground text-sm py-8 text-center">
          No assignments found.
        </p>
      ) : (
        <>
          <AdminBulkSelectionBar
            filteredCount={filtered.length}
            selectedCount={selectedIds.size}
            allFilteredSelected={allFilteredSelected}
            onToggleSelectAll={toggleSelectAll}
            onBulkDelete={() => setBulkDeleteOpen(true)}
            deleting={deleting}
            entityLabel="assignments"
          />

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-10" />
                <TableHead>Student</TableHead>
                <TableHead>Reg. ID</TableHead>
                <TableHead>Module</TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Submitted</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Marks</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginated.map((a) => {
                const student = studentMap.get(a.studentId);
                return (
                  <TableRow key={a.id}>
                    <TableCell>
                      <Checkbox
                        checked={selectedIds.has(a.id)}
                        onCheckedChange={(checked) =>
                          toggleRow(a.id, checked === true)
                        }
                        aria-label={`Select assignment ${a.assignmentTitle}`}
                      />
                    </TableCell>
                    <TableCell>{student?.name ?? "—"}</TableCell>
                    <TableCell className="font-mono text-sm">
                      {a.registrationId}
                    </TableCell>
                    <TableCell>{a.moduleName}</TableCell>
                    <TableCell>{a.assignmentTitle}</TableCell>
                    <TableCell>
                      {toSubmissionDateString(a.submittedAt)}
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant={
                          a.status === "Approved"
                            ? "default"
                            : a.status === "Rejected"
                              ? "destructive"
                              : "secondary"
                        }
                      >
                        {a.status}
                      </Badge>
                    </TableCell>
                    <TableCell>{a.marks !== null ? a.marks : "—"}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        {a.fileUrl && (
                          <>
                            <Button variant="ghost" size="icon" asChild>
                              <a
                                href={a.fileUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                              >
                                <ExternalLink className="w-4 h-4" />
                              </a>
                            </Button>
                            <Button variant="ghost" size="icon" asChild>
                              <a href={a.fileUrl} download>
                                <Download className="w-4 h-4" />
                              </a>
                            </Button>
                          </>
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openGrade(a)}
                        >
                          <CheckCircle className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setDeleteTarget(a)}
                          title="Delete assignment"
                        >
                          <Trash2 className="w-4 h-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>

          {totalPages > 1 && (
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      setPage((p) => Math.max(1, p - 1));
                    }}
                    className={
                      page <= 1 ? "pointer-events-none opacity-50" : ""
                    }
                  />
                </PaginationItem>
                {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                  (p) => (
                    <PaginationItem key={p}>
                      <PaginationLink
                        href="#"
                        isActive={p === page}
                        onClick={(e) => {
                          e.preventDefault();
                          setPage(p);
                        }}
                      >
                        {p}
                      </PaginationLink>
                    </PaginationItem>
                  ),
                )}
                <PaginationItem>
                  <PaginationNext
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      setPage((p) => Math.min(totalPages, p + 1));
                    }}
                    className={
                      page >= totalPages
                        ? "pointer-events-none opacity-50"
                        : ""
                    }
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}
        </>
      )}

      <AlertDialog open={!!deleteTarget} onOpenChange={() => setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete assignment?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the submission
              {deleteTarget ? ` "${deleteTarget.assignmentTitle}"` : ""} and any
              associated result. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                void handleDeleteOne();
              }}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleting}
            >
              {deleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={bulkDeleteOpen} onOpenChange={setBulkDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete selected assignments?</AlertDialogTitle>
            <AlertDialogDescription>
              You are about to delete {selectedIds.size} assignment
              {selectedIds.size === 1 ? "" : "s"} and their results. This cannot
              be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                void handleBulkDelete();
              }}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleting}
            >
              {deleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={!!gradeTarget} onOpenChange={() => setGradeTarget(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Grade Assignment</DialogTitle>
          </DialogHeader>
          {gradeTarget && (
            <p className="text-sm text-muted-foreground mb-2">
              {gradeTarget.assignmentTitle} — {gradeTarget.moduleName}
            </p>
          )}
          <form
            onSubmit={form.handleSubmit(handleGrade)}
            className="space-y-4"
          >
            <div className="space-y-2">
              <Label>Status</Label>
              <Select
                value={form.watch("status")}
                onValueChange={(v) =>
                  form.setValue("status", v as AssignmentStatus)
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="Approved">Approved</SelectItem>
                  <SelectItem value="Rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {form.watch("status") === "Approved" && (
              <div className="space-y-2">
                <Label>Marks (0–{gradeMaxMarks})</Label>
                <Input
                  type="number"
                  min={0}
                  max={gradeMaxMarks}
                  {...form.register("marks")}
                />
              </div>
            )}

            <div className="space-y-2">
              <Label>Feedback</Label>
              <Textarea {...form.register("feedback")} rows={3} />
            </div>

            <DialogFooter>
              <Button type="submit" disabled={saving}>
                {saving ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
