"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { ArrowLeft, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { HomeResearchStat } from "@/types/cms";
import {
  HOME_RESEARCH_STAT_ORDERS,
  MAX_HOME_RESEARCH_STATS,
  getHomeResearchStatOrderLabel,
} from "@/types/cms";
import {
  createHomeResearchStatAdmin,
  deleteHomeResearchStatAdmin,
  fetchHomeResearchContentAdmin,
  fetchHomeResearchStatsAdmin,
  saveHomeResearchContentAdmin,
  updateHomeResearchStatAdmin,
  validateHomeResearchStatLimitAdmin,
  validateHomeResearchStatOrderAdmin,
} from "@/lib/admin-cms-api";
import { ROUTES } from "@/lib/site-routes";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { HomeSectionPublishToggle } from "@/components/admin/HomeSectionPublishToggle";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const sectionFormSchema = z.object({
  sectionHeading: z.string().min(1, "Section heading is required"),
  sectionSubContent: z.string().min(1, "Section intro is required"),
  buttonText: z.string().min(1, "Button text is required"),
  buttonLink: z.string().min(1, "Button link is required"),
});

const statFormSchema = z
  .object({
    statType: z.enum(["counter", "headline"]),
    headline: z.string().optional(),
    description: z.string().min(1, "Description is required"),
    animateValue: z.string().optional(),
    suffix: z.string().optional(),
    order: z.string(),
  })
  .superRefine((data, ctx) => {
    if (data.statType === "headline" && !data.headline?.trim()) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Headline is required for text stats",
        path: ["headline"],
      });
    }
    if (data.statType === "counter") {
      const n = Number(data.animateValue);
      if (!Number.isFinite(n) || n < 0) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Enter a valid number",
          path: ["animateValue"],
        });
      }
    }
  });

type SectionFormValues = z.infer<typeof sectionFormSchema>;
type StatFormValues = z.infer<typeof statFormSchema>;

function formatUpdatedAt(updatedAt: HomeResearchStat["updatedAt"]): string {
  if (!updatedAt) return "—";
  if (
    typeof updatedAt === "object" &&
    updatedAt !== null &&
    "toDate" in updatedAt &&
    typeof (updatedAt as { toDate: () => Date }).toDate === "function"
  ) {
    return format((updatedAt as { toDate: () => Date }).toDate(), "MMM d, yyyy");
  }
  if (updatedAt instanceof Date) {
    return format(updatedAt, "MMM d, yyyy");
  }
  return "—";
}

function statDisplayValue(stat: HomeResearchStat): string {
  if (stat.animateValue != null && Number.isFinite(stat.animateValue)) {
    return `${stat.animateValue.toLocaleString()}${stat.suffix ?? ""}`;
  }
  return stat.headline;
}

function inferStatType(stat: HomeResearchStat): "counter" | "headline" {
  return stat.animateValue != null && Number.isFinite(stat.animateValue)
    ? "counter"
    : "headline";
}

export function HomeResearchManager() {
  const [stats, setStats] = useState<HomeResearchStat[]>([]);
  const [loadingSection, setLoadingSection] = useState(true);
  const [loadingStats, setLoadingStats] = useState(true);
  const [savingSection, setSavingSection] = useState(false);
  const [savingStat, setSavingStat] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingStat, setEditingStat] = useState<HomeResearchStat | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<HomeResearchStat | null>(null);
  const submittingStatRef = useRef(false);

  const sectionForm = useForm<SectionFormValues>({
    resolver: zodResolver(sectionFormSchema),
    defaultValues: {
      sectionHeading: "",
      sectionSubContent: "",
      buttonText: "",
      buttonLink: ROUTES.research,
    },
  });

  const statForm = useForm<StatFormValues>({
    resolver: zodResolver(statFormSchema),
    defaultValues: {
      statType: "counter",
      headline: "",
      description: "",
      animateValue: "",
      suffix: "",
      order: "1",
    },
  });

  const statType = statForm.watch("statType");
  const orderValue = statForm.watch("order");

  const loadSection = useCallback(async () => {
    setLoadingSection(true);
    try {
      const data = await fetchHomeResearchContentAdmin();
      sectionForm.reset({
        sectionHeading: data.sectionHeading,
        sectionSubContent: data.sectionSubContent,
        buttonText: data.buttonText,
        buttonLink: data.buttonLink || ROUTES.research,
      });
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load section",
      );
    } finally {
      setLoadingSection(false);
    }
  }, [sectionForm]);

  const loadStats = useCallback(async () => {
    setLoadingStats(true);
    try {
      setStats(await fetchHomeResearchStatsAdmin());
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load stats",
      );
    } finally {
      setLoadingStats(false);
    }
  }, []);

  useEffect(() => {
    void loadSection();
    void loadStats();
  }, [loadSection, loadStats]);

  const onSaveSection = async (values: SectionFormValues) => {
    setSavingSection(true);
    try {
      await saveHomeResearchContentAdmin({
        sectionHeading: values.sectionHeading.trim(),
        sectionSubContent: values.sectionSubContent.trim(),
        buttonText: values.buttonText.trim(),
        buttonLink: values.buttonLink.trim(),
      });
      toast.success("Research section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save section",
      );
    } finally {
      setSavingSection(false);
    }
  };

  const openCreateStat = async () => {
    const limitCheck = await validateHomeResearchStatLimitAdmin();
    if (!limitCheck.ok) {
      toast.error(limitCheck.message);
      return;
    }
    setEditingStat(null);
    statForm.reset({
      statType: "counter",
      headline: "",
      description: "",
      animateValue: "",
      suffix: "+",
      order: "1",
    });
    setDialogOpen(true);
  };

  const openEditStat = (stat: HomeResearchStat) => {
    const type = inferStatType(stat);
    setEditingStat(stat);
    statForm.reset({
      statType: type,
      headline: stat.headline,
      description: stat.description,
      animateValue:
        type === "counter" && stat.animateValue != null
          ? String(stat.animateValue)
          : "",
      suffix: stat.suffix ?? "",
      order: String(stat.order || 1),
    });
    setDialogOpen(true);
  };

  const onSubmitStat = async (values: StatFormValues) => {
    if (submittingStatRef.current) return;
    submittingStatRef.current = true;
    setSavingStat(true);

    try {
      const order = Number(values.order);
      const orderCheck = await validateHomeResearchStatOrderAdmin(
        order,
        editingStat?.id,
      );
      if (!orderCheck.ok) {
        toast.error(orderCheck.message);
        return;
      }

      if (!editingStat) {
        const limitCheck = await validateHomeResearchStatLimitAdmin();
        if (!limitCheck.ok) {
          toast.error(limitCheck.message);
          return;
        }
      }

      const isCounter = values.statType === "counter";
      const payload = {
        headline: isCounter ? "" : (values.headline?.trim() ?? ""),
        description: values.description.trim(),
        animateValue: isCounter ? Number(values.animateValue) : null,
        suffix: isCounter ? (values.suffix?.trim() ?? "") : "",
        order,
      };

      if (editingStat) {
        await updateHomeResearchStatAdmin(editingStat.id, payload);
        toast.success("Stat updated");
      } else {
        await createHomeResearchStatAdmin(payload);
        toast.success("Stat created");
      }

      setDialogOpen(false);
      await loadStats();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save stat",
      );
    } finally {
      submittingStatRef.current = false;
      setSavingStat(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteHomeResearchStatAdmin(deleteTarget.id);
      toast.success("Stat deleted");
      setDeleteTarget(null);
      await loadStats();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete stat",
      );
    }
  };

  return (
    <section className="space-y-10">
      <Button variant="ghost" size="sm" className="-ml-2" asChild>
        <Link href="/admin/home-content">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Home page content
        </Link>
      </Button>

      <HomeSectionPublishToggle sectionKey="research" />

      <header>
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Research
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Homepage Research block: section copy, CTA, and up to{" "}
          {MAX_HOME_RESEARCH_STATS} stat tiles. Nothing is shown on the site until
          you publish content here.
        </p>
      </header>

      <form
        onSubmit={sectionForm.handleSubmit(onSaveSection)}
        className="space-y-6 bg-card rounded-lg border border-border shadow-sm p-6 md:p-8 max-w-2xl"
      >
        <h2 className="text-lg font-heading font-semibold">Section settings</h2>
        {loadingSection ? (
          <div className="space-y-3">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-24 w-full" />
          </div>
        ) : (
          <>
            <div className="space-y-2">
              <Label htmlFor="sectionHeading">Section heading</Label>
              <Input
                id="sectionHeading"
                {...sectionForm.register("sectionHeading")}
              />
              {sectionForm.formState.errors.sectionHeading ? (
                <p className="text-sm text-destructive">
                  {sectionForm.formState.errors.sectionHeading.message}
                </p>
              ) : null}
            </div>
            <div className="space-y-2">
              <Label htmlFor="sectionSubContent">Section intro</Label>
              <Textarea
                id="sectionSubContent"
                rows={4}
                {...sectionForm.register("sectionSubContent")}
              />
              {sectionForm.formState.errors.sectionSubContent ? (
                <p className="text-sm text-destructive">
                  {sectionForm.formState.errors.sectionSubContent.message}
                </p>
              ) : null}
            </div>
            <div className="space-y-2">
              <Label htmlFor="buttonText">Button text</Label>
              <Input id="buttonText" {...sectionForm.register("buttonText")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="buttonLink">Button link</Label>
              <Input
                id="buttonLink"
                placeholder={ROUTES.research}
                {...sectionForm.register("buttonLink")}
              />
            </div>
            <Button type="submit" disabled={savingSection}>
              {savingSection ? "Saving..." : "Save section"}
            </Button>
          </>
        )}
      </form>

      <section className="bg-card rounded-lg border border-border shadow-sm overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-4 p-6 border-b border-border">
          <div>
            <h2 className="text-lg font-heading font-semibold">Stat tiles</h2>
            <p className="text-sm text-muted-foreground mt-1">
              Up to {MAX_HOME_RESEARCH_STATS} items in the homepage grid.
            </p>
          </div>
          <Button onClick={() => void openCreateStat()}>
            <Plus className="w-4 h-4 mr-2" />
            Add stat
          </Button>
        </div>

        {loadingStats ? (
          <div className="p-8 space-y-3">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        ) : stats.length === 0 ? (
          <p className="p-8 text-sm text-muted-foreground text-center">
            No stats yet. Add at least one stat to publish the Research section on
            the homepage.
          </p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="w-24">Position</TableHead>
                <TableHead>Display value</TableHead>
                <TableHead className="hidden md:table-cell">Description</TableHead>
                <TableHead className="hidden sm:table-cell w-32">Updated</TableHead>
                <TableHead className="w-24 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {stats.map((stat) => (
                <TableRow key={stat.id}>
                  <TableCell className="text-sm text-muted-foreground">
                    {getHomeResearchStatOrderLabel(stat.order)}
                  </TableCell>
                  <TableCell className="font-medium max-w-[200px]">
                    <span className="line-clamp-2">{statDisplayValue(stat)}</span>
                    <span className="text-xs text-muted-foreground block mt-0.5">
                      {inferStatType(stat) === "counter"
                        ? "Animated number"
                        : "Text headline"}
                    </span>
                  </TableCell>
                  <TableCell className="hidden md:table-cell text-sm text-muted-foreground max-w-[280px]">
                    <span className="line-clamp-2">{stat.description}</span>
                  </TableCell>
                  <TableCell className="hidden sm:table-cell text-sm text-muted-foreground">
                    {formatUpdatedAt(stat.updatedAt)}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEditStat(stat)}
                        aria-label="Edit"
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteTarget(stat)}
                        aria-label="Delete"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </section>

      <Dialog
        open={dialogOpen}
        onOpenChange={(open) => {
          if (!open && savingStat) return;
          setDialogOpen(open);
        }}
      >
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto bg-background">
          <DialogHeader>
            <DialogTitle className="font-heading text-xl">
              {editingStat ? "Edit stat" : "New stat"}
            </DialogTitle>
          </DialogHeader>
          <form
            onSubmit={statForm.handleSubmit(onSubmitStat)}
            className="space-y-5"
          >
            <div className="space-y-2">
              <Label htmlFor="order">
                Position <span className="text-destructive">*</span>
              </Label>
              <Select
                value={orderValue}
                onValueChange={(value) => statForm.setValue("order", value)}
              >
                <SelectTrigger id="order">
                  <SelectValue placeholder="Select position" />
                </SelectTrigger>
                <SelectContent>
                  {HOME_RESEARCH_STAT_ORDERS.map((placement) => (
                    <SelectItem
                      key={placement.order}
                      value={String(placement.order)}
                    >
                      {placement.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="statType">Stat type</Label>
              <Select
                value={statType}
                onValueChange={(value) =>
                  statForm.setValue("statType", value as "counter" | "headline")
                }
              >
                <SelectTrigger id="statType">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="counter">Animated number</SelectItem>
                  <SelectItem value="headline">Text headline</SelectItem>
                </SelectContent>
              </Select>
              {statType === "counter" ? (
                <p className="text-xs text-muted-foreground">
                  The homepage shows the animated count plus suffix (e.g. 5000+),
                  not a headline field.
                </p>
              ) : null}
            </div>

            {statType === "headline" ? (
              <div className="space-y-2">
                <Label htmlFor="headline">
                  Headline <span className="text-destructive">*</span>
                </Label>
                <Input id="headline" {...statForm.register("headline")} />
                {statForm.formState.errors.headline ? (
                  <p className="text-sm text-destructive">
                    {statForm.formState.errors.headline.message}
                  </p>
                ) : null}
              </div>
            ) : (
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="animateValue">
                    Number <span className="text-destructive">*</span>
                  </Label>
                  <Input
                    id="animateValue"
                    type="number"
                    min={0}
                    {...statForm.register("animateValue")}
                  />
                  {statForm.formState.errors.animateValue ? (
                    <p className="text-sm text-destructive">
                      {statForm.formState.errors.animateValue.message}
                    </p>
                  ) : null}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="suffix">Suffix (optional)</Label>
                  <Input
                    id="suffix"
                    placeholder="+"
                    {...statForm.register("suffix")}
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="description">
                Description <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="description"
                rows={3}
                {...statForm.register("description")}
              />
              {statForm.formState.errors.description ? (
                <p className="text-sm text-destructive">
                  {statForm.formState.errors.description.message}
                </p>
              ) : null}
            </div>

            <DialogFooter className="gap-2 sm:gap-0 pt-2">
              <Button
                type="button"
                variant="outline"
                disabled={savingStat}
                onClick={() => setDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={savingStat}>
                {savingStat ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete stat?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => void handleDelete()}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
