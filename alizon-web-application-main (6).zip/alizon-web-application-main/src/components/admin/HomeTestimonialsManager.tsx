"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { ArrowLeft, Pencil, Plus, Star, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { HomeTestimonial } from "@/types/cms";
import {
  HOME_TESTIMONIAL_PLACEMENTS,
  getHomeTestimonialPlacementLabel,
} from "@/types/cms";
import {
  DEFAULT_HOME_TESTIMONIAL_READ_MORE,
  createHomeTestimonial,
  deleteHomeTestimonial,
  fetchHomeTestimonials,
  updateHomeTestimonial,
  validateFeaturedHomeTestimonialsLimit,
  validateHomeTestimonialPlacement,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { HomeSectionPublishToggle } from "@/components/admin/HomeSectionPublishToggle";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const testimonialFormSchema = z.object({
  quote: z.string().min(10, "Quote must be at least 10 characters"),
  name: z.string().min(1, "Name is required"),
  subtitle: z.string().min(1, "Subtitle is required"),
  readMoreLabel: z.string().optional(),
  readMoreLink: z.string().optional(),
  featured: z.boolean(),
  order: z.string(),
  backgroundImageUrl: z.string().optional(),
  avatarImageUrl: z.string().optional(),
});

type TestimonialFormValues = z.infer<typeof testimonialFormSchema>;

function formatUpdatedAt(updatedAt: HomeTestimonial["updatedAt"]): string {
  if (!updatedAt) return "—";
  if (
    typeof updatedAt === "object" &&
    updatedAt !== null &&
    "toDate" in updatedAt &&
    typeof (updatedAt as { toDate: () => Date }).toDate === "function"
  ) {
    return format((updatedAt as { toDate: () => Date }).toDate(), "MMM d, yyyy");
  }
  if (updatedAt instanceof Date) {
    return format(updatedAt, "MMM d, yyyy");
  }
  return "—";
}

export function HomeTestimonialsManager() {
  const [items, setItems] = useState<HomeTestimonial[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<HomeTestimonial | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<HomeTestimonial | null>(null);
  const [backgroundImage, setBackgroundImage] =
    useState<CmsImageUploadValue | null>(null);
  const [backgroundPendingPreview, setBackgroundPendingPreview] = useState<
    string | null
  >(null);
  const [avatarImage, setAvatarImage] = useState<CmsImageUploadValue | null>(
    null,
  );
  const [avatarPendingPreview, setAvatarPendingPreview] = useState<
    string | null
  >(null);

  const form = useForm<TestimonialFormValues>({
    resolver: zodResolver(testimonialFormSchema),
    defaultValues: {
      quote: "",
      name: "",
      subtitle: "",
      readMoreLabel: DEFAULT_HOME_TESTIMONIAL_READ_MORE,
      readMoreLink: "",
      featured: false,
      order: "1",
      backgroundImageUrl: "",
      avatarImageUrl: "",
    },
  });

  const featured = form.watch("featured");
  const orderValue = form.watch("order");

  const loadItems = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchHomeTestimonials();
      setItems(data);
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to load testimonials";
      toast.error(message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadItems();
  }, [loadItems]);

  const openCreate = () => {
    setEditingItem(null);
    setBackgroundImage(null);
    setBackgroundPendingPreview(null);
    setAvatarImage(null);
    setAvatarPendingPreview(null);
    form.reset({
      quote: "",
      name: "",
      subtitle: "",
      readMoreLabel: DEFAULT_HOME_TESTIMONIAL_READ_MORE,
      readMoreLink: "",
      featured: false,
      order: "1",
      backgroundImageUrl: "",
      avatarImageUrl: "",
    });
    setDialogOpen(true);
  };

  const openEdit = (item: HomeTestimonial) => {
    setEditingItem(item);
    setBackgroundImage(
      item.backgroundImageUrl
        ? { url: item.backgroundImageUrl }
        : null,
    );
    setBackgroundPendingPreview(null);
    setAvatarImage(
      item.avatarImageUrl ? { url: item.avatarImageUrl } : null,
    );
    setAvatarPendingPreview(null);
    form.reset({
      quote: item.quote,
      name: item.name,
      subtitle: item.subtitle,
      readMoreLabel: item.readMoreLabel || DEFAULT_HOME_TESTIMONIAL_READ_MORE,
      readMoreLink: item.readMoreLink,
      featured: item.featured,
      order: String(item.order || 1),
      backgroundImageUrl: item.backgroundImageUrl,
      avatarImageUrl: item.avatarImageUrl,
    });
    setDialogOpen(true);
  };

  const onSubmit = async (values: TestimonialFormValues) => {
    const order = Number(values.order);
    if (!backgroundImage?.url) {
      toast.error("Please upload a background image");
      return;
    }

    const featuredCheck = await validateFeaturedHomeTestimonialsLimit(
      values.featured,
      editingItem?.id,
    );
    if (!featuredCheck.ok) {
      toast.error(featuredCheck.message);
      return;
    }

    const placementCheck = await validateHomeTestimonialPlacement(
      order,
      values.featured,
      editingItem?.id,
    );
    if (!placementCheck.ok) {
      toast.error(placementCheck.message);
      return;
    }

    setSaving(true);
    try {
      const payload = {
        quote: values.quote.trim(),
        name: values.name.trim(),
        subtitle: values.subtitle.trim(),
        readMoreLabel:
          values.readMoreLabel?.trim() || DEFAULT_HOME_TESTIMONIAL_READ_MORE,
        readMoreLink: values.readMoreLink?.trim() ?? "",
        featured: values.featured,
        order: values.featured ? order : 0,
        backgroundImageUrl: backgroundImage.url,
        avatarImageUrl: avatarImage?.url?.trim() ?? "",
      };

      if (editingItem) {
        await updateHomeTestimonial(editingItem.id, payload);
        toast.success("Testimonial updated");
      } else {
        await createHomeTestimonial(payload);
        toast.success("Testimonial created");
      }

      setDialogOpen(false);
      await loadItems();
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to save testimonial";
      toast.error(message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteHomeTestimonial(deleteTarget.id);
      toast.success("Testimonial deleted");
      setDeleteTarget(null);
      await loadItems();
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to delete testimonial";
      toast.error(message);
    }
  };

  return (
    <section>
      <header className="mb-8">
        <Button variant="ghost" size="sm" className="mb-4 -ml-2" asChild>
          <Link href="/admin/home-content">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Home page content
          </Link>
        </Button>
        <HomeSectionPublishToggle sectionKey="testimonials" className="mb-6" />
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-heading font-bold text-foreground">
              Student testimonials
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Feature up to 3 testimonials on the homepage. Placement order
              controls which section each band appears after.
            </p>
          </div>
          <Button onClick={openCreate}>
            <Plus className="w-4 h-4 mr-2" />
            Add testimonial
          </Button>
        </div>
      </header>

      <section className="bg-card rounded-lg border border-border shadow-sm overflow-hidden">
        {loading ? (
          <section className="p-8 space-y-3">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </section>
        ) : items.length === 0 ? (
          <p className="p-8 text-sm text-muted-foreground text-center">
            No testimonials yet. Click &quot;Add testimonial&quot; to create one.
          </p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead>Name</TableHead>
                <TableHead className="hidden md:table-cell">Quote</TableHead>
                <TableHead className="w-20">Featured</TableHead>
                <TableHead className="w-36">Placement</TableHead>
                <TableHead className="hidden sm:table-cell w-32">
                  Updated
                </TableHead>
                <TableHead className="w-24 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium max-w-[180px]">
                    <span className="line-clamp-2">{item.name || "—"}</span>
                  </TableCell>
                  <TableCell className="hidden md:table-cell text-muted-foreground max-w-xs">
                    <span className="line-clamp-2 text-sm">{item.quote}</span>
                  </TableCell>
                  <TableCell>
                    {item.featured ? (
                      <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {item.featured
                      ? getHomeTestimonialPlacementLabel(item.order)
                      : "—"}
                  </TableCell>
                  <TableCell className="hidden sm:table-cell text-sm text-muted-foreground">
                    {formatUpdatedAt(item.updatedAt)}
                  </TableCell>
                  <TableCell className="text-right">
                    <section className="flex justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEdit(item)}
                        aria-label="Edit"
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteTarget(item)}
                        aria-label="Delete"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </section>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </section>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-background">
          <DialogHeader>
            <DialogTitle className="font-heading text-xl">
              {editingItem ? "Edit testimonial" : "New testimonial"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <CmsImageUploadField
              label="Background image"
              preset="testimonialBackground"
              folder="cms/home-testimonials"
              storageFileName={`${editingItem?.id ?? "new"}-background`}
              value={backgroundImage}
              onChange={setBackgroundImage}
              pendingPreviewUrl={backgroundPendingPreview}
              onPendingPreviewChange={setBackgroundPendingPreview}
              required
            />

            <CmsImageUploadField
              label="Avatar image"
              preset="avatarSquare"
              folder="cms/home-testimonials"
              storageFileName={`${editingItem?.id ?? "new"}-avatar`}
              value={avatarImage}
              onChange={setAvatarImage}
              pendingPreviewUrl={avatarPendingPreview}
              onPendingPreviewChange={setAvatarPendingPreview}
            />

            <section className="space-y-2">
              <Label htmlFor="quote">
                Quote <span className="text-destructive">*</span>
              </Label>
              <Textarea id="quote" rows={4} {...form.register("quote")} />
              {form.formState.errors.quote && (
                <p className="text-sm text-destructive">
                  {form.formState.errors.quote.message}
                </p>
              )}
            </section>

            <section className="space-y-2">
              <Label htmlFor="name">
                Name <span className="text-destructive">*</span>
              </Label>
              <Input
                id="name"
                placeholder="Priya Sharma, '25"
                {...form.register("name")}
              />
              {form.formState.errors.name && (
                <p className="text-sm text-destructive">
                  {form.formState.errors.name.message}
                </p>
              )}
            </section>

            <section className="space-y-2">
              <Label htmlFor="subtitle">
                Subtitle <span className="text-destructive">*</span>
              </Label>
              <Input
                id="subtitle"
                placeholder="Design major and three-time NCAA gymnastics champion"
                {...form.register("subtitle")}
              />
              {form.formState.errors.subtitle && (
                <p className="text-sm text-destructive">
                  {form.formState.errors.subtitle.message}
                </p>
              )}
            </section>

            <section className="grid sm:grid-cols-2 gap-4">
              <section className="space-y-2">
                <Label htmlFor="readMoreLabel">Read more label</Label>
                <Input id="readMoreLabel" {...form.register("readMoreLabel")} />
              </section>
              <section className="space-y-2">
                <Label htmlFor="readMoreLink">Read more link</Label>
                <Input
                  id="readMoreLink"
                  placeholder="https://www.alizon.in/alizon-testimonials"
                  {...form.register("readMoreLink")}
                />
              </section>
            </section>

            <section className="flex items-start gap-3 rounded-lg border border-border p-4 bg-muted/30">
              <Checkbox
                id="featured"
                checked={featured}
                onCheckedChange={(checked) =>
                  form.setValue("featured", checked === true)
                }
              />
              <section className="space-y-0.5">
                <Label htmlFor="featured" className="cursor-pointer font-medium">
                  Feature on homepage
                </Label>
                <p className="text-xs text-muted-foreground">
                  Up to 3 featured testimonials appear on the home page.
                </p>
              </section>
            </section>

            {featured ? (
              <section className="space-y-2">
                <Label htmlFor="order">
                  Home placement <span className="text-destructive">*</span>
                </Label>
                <Select
                  value={orderValue}
                  onValueChange={(value) => form.setValue("order", value)}
                >
                  <SelectTrigger id="order">
                    <SelectValue placeholder="Select placement" />
                  </SelectTrigger>
                  <SelectContent>
                    {HOME_TESTIMONIAL_PLACEMENTS.map((placement) => (
                      <SelectItem
                        key={placement.order}
                        value={String(placement.order)}
                      >
                        {placement.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </section>
            ) : null}

            <DialogFooter className="gap-2 sm:gap-0 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving}>
                {saving ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete testimonial?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
