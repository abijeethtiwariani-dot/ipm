"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { format, parseISO } from "date-fns";
import { CheckCircle2, Eye } from "lucide-react";
import { toast } from "sonner";
import { apiFetchGrievanceStudents } from "@/lib/admin-grievances-api";
import { statusBadgeVariant } from "@/lib/grievance-status";
import type { AdminGrievanceListRow } from "@/types/admin-grievance";
import type { GrievanceAdminStatus } from "@/types/grievance";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";

const PAGE_SIZE = 10;

function ListStatusCell({ row }: { row: AdminGrievanceListRow }) {
  if (row.allResolved) {
    return (
      <span className="inline-flex items-center gap-1.5 text-sm font-medium text-success">
        <CheckCircle2 className="h-4 w-4 shrink-0" />
        Resolved
      </span>
    );
  }

  if (row.listStatus === "In progress") {
    return (
      <span className="text-sm text-muted-foreground">
        In progress ({row.resolvedCount}/{row.grievanceCount} resolved)
      </span>
    );
  }

  const status = row.listStatus as GrievanceAdminStatus;
  return <Badge variant={statusBadgeVariant(status)}>{status}</Badge>;
}

function formatLatestDate(iso: string | null): string {
  if (!iso) return "—";
  try {
    return format(parseISO(iso), "MMM d, yyyy");
  } catch {
    return "—";
  }
}

export function GrievancesManager() {
  const [rows, setRows] = useState<AdminGrievanceListRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await apiFetchGrievanceStudents();
      setRows(data);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load grievances",
      );
      setRows([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    if (!q) return rows;
    return rows.filter(
      (row) =>
        row.studentName.toLowerCase().includes(q) ||
        row.studentEmail.toLowerCase().includes(q) ||
        row.registrationId.toLowerCase().includes(q),
    );
  }, [rows, search]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  useEffect(() => {
    setPage(1);
  }, [search]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-heading font-bold">Grievances</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Review student grievances for assignments and evaluations
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <Input
          placeholder="Search by name, email, or registration ID…"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-md"
        />
      </div>

      {loading ? (
        <div className="space-y-2">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
        </div>
      ) : filtered.length === 0 ? (
        <p className="text-muted-foreground text-sm py-8 text-center">
          {rows.length === 0
            ? "No student grievances have been submitted yet."
            : "No students match your search."}
        </p>
      ) : (
        <>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Reg. ID</TableHead>
                <TableHead>Student</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Count</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Latest submitted</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginated.map((row) => (
                <TableRow key={row.studentId}>
                  <TableCell className="font-mono text-sm">
                    {row.registrationId || "—"}
                  </TableCell>
                  <TableCell>
                    <Link
                      href={`/admin/grievances/${row.studentId}`}
                      className="font-medium text-primary hover:underline"
                    >
                      {row.studentName || "—"}
                    </Link>
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {row.studentEmail || "—"}
                  </TableCell>
                  <TableCell>{row.grievanceCount}</TableCell>
                  <TableCell>
                    <ListStatusCell row={row} />
                  </TableCell>
                  <TableCell className="text-sm">
                    {formatLatestDate(row.latestSubmittedAt)}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="outline" size="sm" asChild>
                      <Link href={`/admin/grievances/${row.studentId}`}>
                        <Eye className="w-4 h-4 mr-1" />
                        View grievances
                      </Link>
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {totalPages > 1 && (
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      setPage((p) => Math.max(1, p - 1));
                    }}
                    className={
                      page <= 1 ? "pointer-events-none opacity-50" : undefined
                    }
                  />
                </PaginationItem>
                {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                  (p) => (
                    <PaginationItem key={p}>
                      <PaginationLink
                        href="#"
                        isActive={p === page}
                        onClick={(e) => {
                          e.preventDefault();
                          setPage(p);
                        }}
                      >
                        {p}
                      </PaginationLink>
                    </PaginationItem>
                  ),
                )}
                <PaginationItem>
                  <PaginationNext
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      setPage((p) => Math.min(totalPages, p + 1));
                    }}
                    className={
                      page >= totalPages
                        ? "pointer-events-none opacity-50"
                        : undefined
                    }
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}
        </>
      )}
    </div>
  );
}
