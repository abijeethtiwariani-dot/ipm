"use client";

import Link from "next/link";
import {
  BarChart3,
  ChevronRight,
  Heart,
  MessageSquareQuote,
  Search,
  Sparkles,
  Star,
  Users,
} from "lucide-react";
import { Card } from "@/components/ui/card";

const sections = [
  {
    title: "Hero",
    description: "Full-screen banner, headline, and job search.",
    href: "/admin/careers-page-content/hero",
    icon: Sparkles,
  },
  {
    title: "SEO",
    description: "Meta title, description, and Open Graph image.",
    href: "/admin/careers-page-content/seo",
    icon: Search,
  },
  {
    title: "Why Work At Alizon",
    description: "Section heading and feature cards.",
    href: "/admin/careers-page-content/why-work",
    icon: Star,
  },
  {
    title: "Career Stories",
    description: "Employee testimonials carousel.",
    href: "/admin/careers-page-content/stories",
    icon: MessageSquareQuote,
  },
  {
    title: "Why People Love Working Here",
    description: "Background image, title, and statistics.",
    href: "/admin/careers-page-content/love-working",
    icon: Heart,
  },
  {
    title: "Benefits & Culture",
    description: "Benefits and culture feature cards.",
    href: "/admin/careers-page-content/benefits",
    icon: Users,
  },
  {
    title: "Open Positions",
    description: "Featured jobs section heading and count.",
    href: "/admin/careers-page-content/open-positions",
    icon: BarChart3,
  },
];

export function CareersPageContentHub() {
  return (
    <section>
      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold">Careers Page Content</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Manage all sections of the public careers page.
        </p>
      </header>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {sections.map((section) => (
          <Link key={section.href} href={section.href}>
            <Card className="group h-full border p-6 transition-shadow hover:shadow-md">
              <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <section.icon className="h-5 w-5" />
              </div>
              <h2 className="text-lg font-semibold group-hover:text-primary">
                {section.title}
              </h2>
              <p className="mt-2 text-sm text-muted-foreground">{section.description}</p>
              <span className="mt-4 inline-flex items-center text-sm font-medium text-primary">
                Open
                <ChevronRight className="ml-1 h-4 w-4" />
              </span>
            </Card>
          </Link>
        ))}
      </div>
    </section>
  );
}
