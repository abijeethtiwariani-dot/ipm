"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { ArrowLeft, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { HomePartnerLogo } from "@/types/cms";
import {
  createHomePartnerLogoAdmin,
  deleteHomePartnerLogoAdmin,
  fetchHomePartnerLogosAdmin,
  fetchHomePartnersContent,
  saveHomePartnersContent,
  updateHomePartnerLogoAdmin,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import { unoptimizedForImageSrc } from "@/lib/cms-image-url";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { HomeSectionPublishToggle } from "@/components/admin/HomeSectionPublishToggle";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const sectionFormSchema = z.object({
  sectionEyebrow: z.string(),
  sectionHeading: z.string().min(1, "Section heading is required"),
  sectionIntro: z.string().min(1, "Section intro is required"),
});

const logoFormSchema = z.object({
  name: z.string().min(1, "Partner name is required"),
  order: z.string().min(1, "Sort order is required"),
});

type SectionFormValues = z.infer<typeof sectionFormSchema>;
type LogoFormValues = z.infer<typeof logoFormSchema>;

function formatUpdatedAt(updatedAt: HomePartnerLogo["updatedAt"]): string {
  if (!updatedAt) return "—";
  if (
    typeof updatedAt === "object" &&
    updatedAt !== null &&
    "toDate" in updatedAt &&
    typeof (updatedAt as { toDate: () => Date }).toDate === "function"
  ) {
    return format((updatedAt as { toDate: () => Date }).toDate(), "MMM d, yyyy");
  }
  if (updatedAt instanceof Date) {
    return format(updatedAt, "MMM d, yyyy");
  }
  return "—";
}

function nextOrder(logos: HomePartnerLogo[]): number {
  if (logos.length === 0) return 1;
  return Math.max(...logos.map((logo) => logo.order ?? 0)) + 1;
}

export function HomePartnersManager() {
  const [logos, setLogos] = useState<HomePartnerLogo[]>([]);
  const [loadingSection, setLoadingSection] = useState(true);
  const [loadingLogos, setLoadingLogos] = useState(true);
  const [savingSection, setSavingSection] = useState(false);
  const [savingLogo, setSavingLogo] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingLogo, setEditingLogo] = useState<HomePartnerLogo | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<HomePartnerLogo | null>(null);
  const [logoImage, setLogoImage] = useState<CmsImageUploadValue | null>(null);
  const [logoPendingPreview, setLogoPendingPreview] = useState<string | null>(
    null,
  );
  const submittingLogoRef = useRef(false);

  const sectionForm = useForm<SectionFormValues>({
    resolver: zodResolver(sectionFormSchema),
    defaultValues: {
      sectionEyebrow: "",
      sectionHeading: "",
      sectionIntro: "",
    },
  });

  const logoForm = useForm<LogoFormValues>({
    resolver: zodResolver(logoFormSchema),
    defaultValues: {
      name: "",
      order: "1",
    },
  });

  const loadSection = useCallback(async () => {
    setLoadingSection(true);
    try {
      const data = await fetchHomePartnersContent();
      sectionForm.reset({
        sectionEyebrow: data.sectionEyebrow,
        sectionHeading: data.sectionHeading,
        sectionIntro: data.sectionIntro,
      });
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load section",
      );
    } finally {
      setLoadingSection(false);
    }
  }, [sectionForm]);

  const loadLogos = useCallback(async () => {
    setLoadingLogos(true);
    try {
      setLogos(await fetchHomePartnerLogosAdmin());
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load partner logos",
      );
    } finally {
      setLoadingLogos(false);
    }
  }, []);

  useEffect(() => {
    void loadSection();
    void loadLogos();
  }, [loadSection, loadLogos]);

  const onSaveSection = async (values: SectionFormValues) => {
    setSavingSection(true);
    try {
      await saveHomePartnersContent({
        sectionEyebrow: values.sectionEyebrow.trim(),
        sectionHeading: values.sectionHeading.trim(),
        sectionIntro: values.sectionIntro.trim(),
      });
      toast.success("Partners section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save section",
      );
    } finally {
      setSavingSection(false);
    }
  };

  const openCreateLogo = () => {
    setEditingLogo(null);
    setLogoImage(null);
    setLogoPendingPreview(null);
    logoForm.reset({
      name: "",
      order: String(nextOrder(logos)),
    });
    setDialogOpen(true);
  };

  const openEditLogo = (logo: HomePartnerLogo) => {
    setEditingLogo(logo);
    setLogoImage(logo.logoUrl ? { url: logo.logoUrl } : null);
    setLogoPendingPreview(null);
    logoForm.reset({
      name: logo.name,
      order: String(logo.order || 1),
    });
    setDialogOpen(true);
  };

  const onSubmitLogo = async (values: LogoFormValues) => {
    if (submittingLogoRef.current) return;
    if (!logoImage?.url) {
      toast.error("Please upload a partner logo");
      return;
    }

    submittingLogoRef.current = true;
    setSavingLogo(true);

    try {
      const payload = {
        name: values.name.trim(),
        logoUrl: logoImage.url,
        order: Number(values.order),
      };

      if (editingLogo) {
        await updateHomePartnerLogoAdmin(editingLogo.id, payload);
        toast.success("Partner logo updated");
      } else {
        await createHomePartnerLogoAdmin(payload);
        toast.success("Partner logo created");
      }

      setDialogOpen(false);
      await loadLogos();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save partner logo",
      );
    } finally {
      submittingLogoRef.current = false;
      setSavingLogo(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteHomePartnerLogoAdmin(deleteTarget.id);
      toast.success("Partner logo deleted");
      setDeleteTarget(null);
      await loadLogos();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete partner logo",
      );
    }
  };

  return (
    <section className="space-y-10">
      <Button variant="ghost" size="sm" className="-ml-2" asChild>
        <Link href="/admin/home-content">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Home page content
        </Link>
      </Button>

      <HomeSectionPublishToggle sectionKey="partners" />

      <header>
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Our Trusted Partners
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Homepage partners marquee: section copy and partner logos shown in a
          single scrolling row after Upcoming Events.
        </p>
      </header>

      <form
        onSubmit={sectionForm.handleSubmit(onSaveSection)}
        className="max-w-2xl space-y-5 rounded-lg border border-border p-6"
      >
        <h2 className="text-lg font-heading font-semibold">Section settings</h2>

        {loadingSection ? (
          <div className="space-y-3">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-24 w-full" />
          </div>
        ) : (
          <>
            <div className="space-y-2">
              <Label htmlFor="sectionEyebrow">Eyebrow label</Label>
              <Input
                id="sectionEyebrow"
                placeholder="— EST. PARTNERSHIPS —"
                {...sectionForm.register("sectionEyebrow")}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="sectionHeading">
                Section heading <span className="text-destructive">*</span>
              </Label>
              <Input
                id="sectionHeading"
                {...sectionForm.register("sectionHeading")}
              />
              {sectionForm.formState.errors.sectionHeading ? (
                <p className="text-sm text-destructive">
                  {sectionForm.formState.errors.sectionHeading.message}
                </p>
              ) : null}
            </div>

            <div className="space-y-2">
              <Label htmlFor="sectionIntro">
                Section intro <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="sectionIntro"
                rows={3}
                {...sectionForm.register("sectionIntro")}
              />
              {sectionForm.formState.errors.sectionIntro ? (
                <p className="text-sm text-destructive">
                  {sectionForm.formState.errors.sectionIntro.message}
                </p>
              ) : null}
            </div>

            <Button type="submit" disabled={savingSection}>
              {savingSection ? "Saving..." : "Save section"}
            </Button>
          </>
        )}
      </form>

      <section className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-heading font-semibold">Partner logos</h2>
            <p className="text-sm text-muted-foreground mt-1">
              Add as many partner logos as needed. Lower sort order appears
              first in the marquee.
            </p>
          </div>
          <Button onClick={openCreateLogo}>
            <Plus className="w-4 h-4 mr-2" />
            New partner
          </Button>
        </div>

        {loadingLogos ? (
          <div className="space-y-3">
            <Skeleton className="h-12 w-full" />
            <Skeleton className="h-12 w-full" />
          </div>
        ) : logos.length === 0 ? (
          <div className="rounded-lg border border-dashed border-border p-10 text-center text-muted-foreground">
            No partner logos yet. The section stays hidden on the homepage until
            you add at least one logo.
          </div>
        ) : (
          <div className="rounded-lg border border-border overflow-hidden">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[120px]">Logo</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead className="w-[80px]">Order</TableHead>
                  <TableHead className="w-[120px]">Updated</TableHead>
                  <TableHead className="w-[100px] text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logos.map((logo) => (
                  <TableRow key={logo.id}>
                    <TableCell>
                      {logo.logoUrl ? (
                        <Image
                          src={logo.logoUrl}
                          alt={logo.name}
                          width={80}
                          height={40}
                          unoptimized={unoptimizedForImageSrc(logo.logoUrl)}
                          className="h-10 max-w-[80px] object-contain"
                        />
                      ) : (
                        "—"
                      )}
                    </TableCell>
                    <TableCell className="font-medium">{logo.name}</TableCell>
                    <TableCell>{logo.order}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {formatUpdatedAt(logo.updatedAt)}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEditLogo(logo)}
                        aria-label={`Edit ${logo.name}`}
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteTarget(logo)}
                        aria-label={`Delete ${logo.name}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </section>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto bg-background">
          <DialogHeader>
            <DialogTitle className="font-heading text-xl">
              {editingLogo ? "Edit partner" : "New partner"}
            </DialogTitle>
          </DialogHeader>
          <form
            onSubmit={logoForm.handleSubmit(onSubmitLogo)}
            className="space-y-5"
          >
            <CmsImageUploadField
              label="Partner logo"
              preset="partnerLogo"
              folder="cms/home-partners"
              storageFileName={editingLogo?.id ?? `new-${Date.now()}`}
              value={logoImage}
              onChange={setLogoImage}
              pendingPreviewUrl={logoPendingPreview}
              onPendingPreviewChange={setLogoPendingPreview}
              required
            />

            <div className="space-y-2">
              <Label htmlFor="name">
                Partner name <span className="text-destructive">*</span>
              </Label>
              <Input
                id="name"
                placeholder="Company name"
                {...logoForm.register("name")}
              />
              <p className="text-xs text-muted-foreground">
                Used for logo alt text on the website.
              </p>
              {logoForm.formState.errors.name ? (
                <p className="text-sm text-destructive">
                  {logoForm.formState.errors.name.message}
                </p>
              ) : null}
            </div>

            <div className="space-y-2">
              <Label htmlFor="order">
                Sort order <span className="text-destructive">*</span>
              </Label>
              <Input
                id="order"
                type="number"
                min={1}
                {...logoForm.register("order")}
              />
              {logoForm.formState.errors.order ? (
                <p className="text-sm text-destructive">
                  {logoForm.formState.errors.order.message}
                </p>
              ) : null}
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={savingLogo}>
                {savingLogo ? "Saving..." : editingLogo ? "Update" : "Create"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={Boolean(deleteTarget)}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete partner logo?</AlertDialogTitle>
            <AlertDialogDescription>
              This removes &quot;{deleteTarget?.name}&quot; from the homepage
              marquee. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
