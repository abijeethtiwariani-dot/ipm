"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { ArrowLeft, ExternalLink, FileUser, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  apiDeleteStudent,
  apiFetchStudent,
  apiUpdateStudentProfile,
} from "@/lib/admin-students-api";
import { apiFetchStudentFeeDetail } from "@/lib/admin-fees-api";
import { getEffectiveProfile } from "@/lib/student-mapper";
import { getProfileCompletionPercent } from "@/lib/student-profile-completion";
import { decodeStudentsListReturn } from "@/lib/admin-students-list-query";
import { toDateString } from "@/lib/students";
import { StudentIdCardSection } from "@/components/admin/StudentIdCardSection";
import { ProfileDetailsDisplay } from "@/components/profile/ProfileFieldDisplay";
import type { PaymentStatus } from "@/types/fees";
import type { Student, StudentAccountStatus } from "@/types/student";
import { PaymentStatusBadge } from "@/components/fees/PaymentStatusBadge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export function StudentDetailsView({ studentId }: { studentId: string }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const listReturnPath = decodeStudentsListReturn(searchParams.get("return"));
  const [student, setStudent] = useState<Student | null>(null);
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [savingStatus, setSavingStatus] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [accountStatus, setAccountStatus] = useState<StudentAccountStatus>("Pending");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await apiFetchStudent(studentId);
      setStudent(data);
      if (data) {
        setAccountStatus(data.accountStatus);
        try {
          const feeData = await apiFetchStudentFeeDetail(studentId);
          setPaymentStatus(feeData.summary.paymentStatus);
        } catch {
          setPaymentStatus("Pending");
        }
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to load student");
    } finally {
      setLoading(false);
    }
  }, [studentId]);

  useEffect(() => {
    void load();
  }, [load]);

  const handleStatusChange = async (status: StudentAccountStatus) => {
    if (!student) return;
    setSavingStatus(true);
    try {
      await apiUpdateStudentProfile(student.uid, { accountStatus: status });
      setAccountStatus(status);
      setStudent({ ...student, accountStatus: status });
      toast.success("Account status updated");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to update status");
    } finally {
      setSavingStatus(false);
    }
  };

  const handleDelete = async () => {
    if (!student) return;
    setDeleting(true);
    try {
      await apiDeleteStudent(student.uid);
      toast.success("Student deleted");
      router.push(listReturnPath);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to delete student");
    } finally {
      setDeleting(false);
      setDeleteOpen(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-48" />
        <div className="grid gap-4 md:grid-cols-2">
          <Skeleton className="h-48" />
          <Skeleton className="h-48" />
        </div>
      </div>
    );
  }

  if (!student) {
    return (
      <p className="text-muted-foreground">Student not found.</p>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" asChild>
            <Link href={listReturnPath}>
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <div>
            <h1 className="text-2xl font-heading font-bold">{student.name}</h1>
            <p className="text-sm text-muted-foreground">
              {student.registrationId} · {student.course || "No course assigned"}
            </p>
          </div>
          <Badge
            variant={
              student.accountStatus === "Approved"
                ? "default"
                : student.accountStatus === "Rejected"
                  ? "destructive"
                  : "secondary"
            }
          >
            {student.accountStatus}
          </Badge>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" asChild>
            <Link href={`/admin/students/${studentId}/profile/edit`}>
              <FileUser className="mr-2 h-4 w-4" />
              Edit full profile
            </Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href={`/admin/students/${studentId}/edit`}>
              <Pencil className="mr-2 h-4 w-4" />
              Edit account
            </Link>
          </Button>
          <Button variant="destructive" onClick={() => setDeleteOpen(true)}>
            <Trash2 className="mr-2 h-4 w-4" />
            Delete
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Personal Information</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3 text-sm">
            <div>
              <span className="text-muted-foreground">Registration ID: </span>
              <span className="font-mono">{student.registrationId}</span>
            </div>
            <div>
              <span className="text-muted-foreground">Name: </span>
              {student.name}
            </div>
            <div>
              <span className="text-muted-foreground">Email: </span>
              {student.email}
            </div>
            <div>
              <span className="text-muted-foreground">Phone: </span>
              {student.phone}
            </div>
            <div>
              <span className="text-muted-foreground">Course: </span>
              {student.course || "Not assigned"}
            </div>
            <div>
              <span className="text-muted-foreground">Joined: </span>
              {toDateString(student.createdAt)}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Account</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Account status</Label>
              <Select
                value={accountStatus}
                onValueChange={(v) => handleStatusChange(v as StudentAccountStatus)}
                disabled={savingStatus}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Pending">Pending</SelectItem>
                  <SelectItem value="Approved">Approved</SelectItem>
                  <SelectItem value="Rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Reference By</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3 text-sm">
            <div>
              <span className="text-muted-foreground">Type: </span>
              {student.referenceByType || "Not provided"}
            </div>
            {student.referenceByType ? (
              <div>
                <span className="text-muted-foreground">
                  {student.referenceByType === "College"
                    ? "College name: "
                    : "Organization name: "}
                </span>
                {student.referenceByName || "—"}
              </div>
            ) : null}
          </CardContent>
        </Card>

        <StudentIdCardSection
          studentId={studentId}
          student={student}
          onUpdated={setStudent}
        />

        <Card className="md:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between space-y-0">
            <CardTitle className="text-base">Fees</CardTitle>
            <Button variant="outline" size="sm" asChild>
              <Link href={`/admin/fees/students/${studentId}`}>
                <ExternalLink className="mr-2 h-4 w-4" />
                View fee details
              </Link>
            </Button>
          </CardHeader>
          <CardContent className="grid gap-3 text-sm sm:grid-cols-3">
            <div>
              <span className="text-muted-foreground">Scholarship: </span>
              {student.scholarshipPercentage ?? 0}%
            </div>
            <div>
              <span className="text-muted-foreground">Payment status: </span>
              {paymentStatus ? (
                <PaymentStatusBadge status={paymentStatus} />
              ) : (
                "—"
              )}
            </div>
            {student.feeNotes ? (
              <div className="sm:col-span-3">
                <span className="text-muted-foreground">Fee notes: </span>
                {student.feeNotes}
              </div>
            ) : null}
          </CardContent>
        </Card>
      </div>

      <div className="space-y-2">
        <h2 className="text-lg font-semibold">Extended profile</h2>
        <p className="text-sm text-muted-foreground">
          Profile completion: {getProfileCompletionPercent(getEffectiveProfile(student))}%
        </p>
        <ProfileDetailsDisplay
          profile={getEffectiveProfile(student)}
          photoUrl={student.profilePhotoUrl}
          assignedBatch={student.assignedBatch}
          registrationId={student.registrationId}
        />
      </div>

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete student?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete {student.name}&apos;s account,
              assignments, and uploaded files. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
