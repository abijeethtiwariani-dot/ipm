"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import {
  fetchAboutPageOurStoryContentAdmin,
  saveAboutPageOurStoryContentAdmin,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import {
  AboutPageAdminBackLink,
  AboutPageAdminHeader,
  AboutPageFormFooter,
} from "@/components/admin/about-page/AboutPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z.object({
  eyebrow: z.string().min(1, "Eyebrow is required"),
  heading: z.string().min(1, "Heading is required"),
  body: z.string().min(1, "Body is required"),
  ctaText: z.string().min(1, "CTA text is required"),
  ctaHref: z.string().min(1, "CTA link is required"),
  imageAlt: z.string(),
});

type FormValues = z.infer<typeof formSchema>;

export function AboutPageOurStoryManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [image, setImage] = useState<CmsImageUploadValue | null>(null);
  const [pendingPreview, setPendingPreview] = useState<string | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      eyebrow: "",
      heading: "",
      body: "",
      ctaText: "",
      ctaHref: "",
      imageAlt: "",
    },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchAboutPageOurStoryContentAdmin();
      if (data) {
        setImage(data.imageUrl ? { url: data.imageUrl } : null);
        form.reset({
          eyebrow: data.eyebrow,
          heading: data.heading,
          body: data.body,
          ctaText: data.ctaText,
          ctaHref: data.ctaHref,
          imageAlt: data.imageAlt,
        });
      } else {
        setImage(null);
        form.reset({
          eyebrow: "",
          heading: "",
          body: "",
          ctaText: "",
          ctaHref: "",
          imageAlt: "",
        });
      }
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load our story content",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    try {
      await saveAboutPageOurStoryContentAdmin({
        eyebrow: values.eyebrow.trim(),
        heading: values.heading.trim(),
        body: values.body.trim(),
        ctaText: values.ctaText.trim(),
        ctaHref: values.ctaHref.trim(),
        imageUrl: image?.url?.trim() ?? "",
        imageAlt: values.imageAlt.trim(),
      });
      toast.success("Our Story section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save our story section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-3xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-24 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-3xl">
      <AboutPageAdminBackLink />
      <AboutPageAdminHeader
        title="Our Story"
        description="Story section with image, heading, body copy, and call-to-action."
      />

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="eyebrow">Eyebrow</Label>
          <Input id="eyebrow" {...form.register("eyebrow")} />
        </div>

        <div className="space-y-2">
          <Label htmlFor="heading">Heading</Label>
          <Input id="heading" {...form.register("heading")} />
        </div>

        <div className="space-y-2">
          <Label htmlFor="body">Body</Label>
          <Textarea id="body" rows={6} {...form.register("body")} />
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="ctaText">CTA text</Label>
            <Input id="ctaText" {...form.register("ctaText")} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="ctaHref">CTA link</Label>
            <Input id="ctaHref" placeholder="/admissions" {...form.register("ctaHref")} />
          </div>
        </div>

        <CmsImageUploadField
          label="Section image"
          preset="card4x3"
          value={image}
          onChange={setImage}
          folder="cms/about-page/our-story"
          storageFileName="story"
          pendingPreviewUrl={pendingPreview}
          onPendingPreviewChange={setPendingPreview}
        />

        <div className="space-y-2">
          <Label htmlFor="imageAlt">Image alt text</Label>
          <Input id="imageAlt" {...form.register("imageAlt")} />
        </div>

        <AboutPageFormFooter
          end={
            <Button type="submit" disabled={saving} className="w-full sm:w-auto">
              {saving ? "Saving…" : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
