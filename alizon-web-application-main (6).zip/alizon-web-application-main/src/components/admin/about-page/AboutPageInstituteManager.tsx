"use client";

import { useCallback, useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type {
  AboutPageIconKey,
  AboutPageInstituteMetaItem,
} from "@/types/cms";
import { ABOUT_PAGE_ICONS } from "@/types/cms";
import {
  fetchAboutPageInstituteContentAdmin,
  saveAboutPageInstituteContentAdmin,
} from "@/lib/admin-cms-api";
import { ABOUT_ICON_LABELS } from "@/lib/about-icon-map";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import {
  AboutPageAdminBackLink,
  AboutPageAdminHeader,
  AboutPageFormFooter,
} from "@/components/admin/about-page/AboutPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const emptyMeta = (): AboutPageInstituteMetaItem => ({
  icon: "graduation-cap",
  label: "",
});

export function AboutPageInstituteManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [eyebrow, setEyebrow] = useState("");
  const [heading, setHeading] = useState("");
  const [programTitle, setProgramTitle] = useState("");
  const [aboutHeading, setAboutHeading] = useState("");
  const [aboutBody, setAboutBody] = useState("");
  const [meta, setMeta] = useState<AboutPageInstituteMetaItem[]>([]);
  const [image, setImage] = useState<CmsImageUploadValue | null>(null);
  const [pendingPreview, setPendingPreview] = useState<string | null>(null);
  const [imageAlt, setImageAlt] = useState("");

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchAboutPageInstituteContentAdmin();
      if (data) {
        setEyebrow(data.eyebrow);
        setHeading(data.heading);
        setProgramTitle(data.programTitle);
        setAboutHeading(data.aboutHeading);
        setAboutBody(data.aboutBody);
        setMeta(data.meta?.length ? data.meta : [emptyMeta()]);
        setImage(data.imageUrl ? { url: data.imageUrl } : null);
        setImageAlt(data.imageAlt);
      } else {
        setEyebrow("");
        setHeading("");
        setProgramTitle("");
        setAboutHeading("");
        setAboutBody("");
        setMeta([emptyMeta()]);
        setImage(null);
        setImageAlt("");
      }
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load institute content",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const updateMeta = (
    index: number,
    patch: Partial<AboutPageInstituteMetaItem>,
  ) => {
    setMeta((prev) =>
      prev.map((item, i) => (i === index ? { ...item, ...patch } : item)),
    );
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (
      !eyebrow.trim() ||
      !heading.trim() ||
      !programTitle.trim() ||
      !aboutHeading.trim() ||
      !aboutBody.trim()
    ) {
      toast.error("All text fields are required");
      return;
    }

    const validMeta = meta.filter((m) => m.label.trim());
    if (validMeta.length === 0) {
      toast.error("Add at least one meta row");
      return;
    }

    setSaving(true);
    try {
      await saveAboutPageInstituteContentAdmin({
        eyebrow: eyebrow.trim(),
        heading: heading.trim(),
        programTitle: programTitle.trim(),
        aboutHeading: aboutHeading.trim(),
        aboutBody: aboutBody.trim(),
        imageUrl: image?.url?.trim() ?? "",
        imageAlt: imageAlt.trim(),
        meta: validMeta.map((m) => ({
          icon: m.icon,
          label: m.label.trim(),
        })),
      });
      toast.success("Institute section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save institute section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-3xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-24 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-3xl">
      <AboutPageAdminBackLink />
      <AboutPageAdminHeader
        title="Our Institute"
        description="Program showcase with image, meta details, and about copy."
      />

      <form onSubmit={onSubmit} className="space-y-6">
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="eyebrow">Eyebrow</Label>
            <Input
              id="eyebrow"
              value={eyebrow}
              onChange={(e) => setEyebrow(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="heading">Heading</Label>
            <Input
              id="heading"
              value={heading}
              onChange={(e) => setHeading(e.target.value)}
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="programTitle">Program title</Label>
          <Input
            id="programTitle"
            value={programTitle}
            onChange={(e) => setProgramTitle(e.target.value)}
          />
        </div>

        <CmsImageUploadField
          label="Institute image"
          preset="card4x3"
          value={image}
          onChange={setImage}
          folder="cms/about-page/institute"
          storageFileName="institute"
          pendingPreviewUrl={pendingPreview}
          onPendingPreviewChange={setPendingPreview}
        />

        <div className="space-y-2">
          <Label htmlFor="imageAlt">Image alt text</Label>
          <Input
            id="imageAlt"
            value={imageAlt}
            onChange={(e) => setImageAlt(e.target.value)}
          />
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label>Meta rows</Label>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setMeta((prev) => [...prev, emptyMeta()])}
            >
              <Plus className="w-4 h-4 mr-1" />
              Add row
            </Button>
          </div>

          {meta.map((item, index) => (
            <div
              key={index}
              className="rounded-lg border border-border p-4 space-y-3"
            >
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">Row {index + 1}</p>
                {meta.length > 1 ? (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() =>
                      setMeta((prev) => prev.filter((_, i) => i !== index))
                    }
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                ) : null}
              </div>
              <Select
                value={item.icon}
                onValueChange={(value) =>
                  updateMeta(index, { icon: value as AboutPageIconKey })
                }
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select icon" />
                </SelectTrigger>
                <SelectContent>
                  {ABOUT_PAGE_ICONS.map((key) => (
                    <SelectItem key={key} value={key}>
                      {ABOUT_ICON_LABELS[key]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                placeholder="Label"
                value={item.label}
                onChange={(e) => updateMeta(index, { label: e.target.value })}
              />
            </div>
          ))}
        </div>

        <div className="space-y-2">
          <Label htmlFor="aboutHeading">About heading</Label>
          <Input
            id="aboutHeading"
            value={aboutHeading}
            onChange={(e) => setAboutHeading(e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="aboutBody">About body</Label>
          <Textarea
            id="aboutBody"
            rows={6}
            value={aboutBody}
            onChange={(e) => setAboutBody(e.target.value)}
          />
        </div>

        <AboutPageFormFooter
          end={
            <Button type="submit" disabled={saving} className="w-full sm:w-auto">
              {saving ? "Saving…" : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
