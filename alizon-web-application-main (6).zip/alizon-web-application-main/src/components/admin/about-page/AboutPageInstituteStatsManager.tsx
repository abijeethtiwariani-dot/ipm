"use client";

import { useCallback, useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { AboutPageIconKey, AboutPageInstituteStat } from "@/types/cms";
import { ABOUT_PAGE_ICONS } from "@/types/cms";
import {
  fetchAboutPageInstituteStatsContentAdmin,
  saveAboutPageInstituteStatsContentAdmin,
} from "@/lib/admin-cms-api";
import { ABOUT_ICON_LABELS } from "@/lib/about-icon-map";
import {
  AboutPageAdminBackLink,
  AboutPageAdminHeader,
  AboutPageFormFooter,
} from "@/components/admin/about-page/AboutPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const emptyStat = (): AboutPageInstituteStat => ({
  animateValue: 0,
  label: "",
  icon: "book-open",
});

export function AboutPageInstituteStatsManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [sectionHeading, setSectionHeading] = useState("");
  const [stats, setStats] = useState<AboutPageInstituteStat[]>([]);

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchAboutPageInstituteStatsContentAdmin();
      if (data) {
        setSectionHeading(data.sectionHeading ?? "");
        setStats(data.stats?.length ? data.stats : [emptyStat()]);
      } else {
        setSectionHeading("");
        setStats([emptyStat()]);
      }
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load institute stats",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const updateStat = (index: number, patch: Partial<AboutPageInstituteStat>) => {
    setStats((prev) =>
      prev.map((s, i) => (i === index ? { ...s, ...patch } : s)),
    );
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!sectionHeading.trim()) {
      toast.error("Section heading is required");
      return;
    }

    const valid = stats.filter(
      (s) => s.label.trim() && Number.isFinite(s.animateValue),
    );
    if (valid.length === 0) {
      toast.error("Add at least one stat with value and label");
      return;
    }

    setSaving(true);
    try {
      await saveAboutPageInstituteStatsContentAdmin({
        sectionHeading: sectionHeading.trim(),
        stats: valid.map((s) => ({
          animateValue: Number(s.animateValue),
          label: s.label.trim(),
          icon: s.icon,
        })),
      });
      toast.success("Institute stats saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save institute stats",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-3xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-3xl">
      <AboutPageAdminBackLink />
      <AboutPageAdminHeader
        title="Institute Stats"
        description="Animated statistics shown at the bottom of the about page."
      />

      <form onSubmit={onSubmit} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="sectionHeading">Section heading</Label>
          <Input
            id="sectionHeading"
            value={sectionHeading}
            onChange={(e) => setSectionHeading(e.target.value)}
            placeholder="Institute Highlights"
          />
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label>Statistics</Label>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setStats((prev) => [...prev, emptyStat()])}
            >
              <Plus className="w-4 h-4 mr-1" />
              Add stat
            </Button>
          </div>

          {stats.map((stat, index) => (
            <div
              key={index}
              className="rounded-lg border border-border p-4 space-y-3"
            >
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">Stat {index + 1}</p>
                {stats.length > 1 ? (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() =>
                      setStats((prev) => prev.filter((_, i) => i !== index))
                    }
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                ) : null}
              </div>

              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-2">
                  <Label>Value</Label>
                  <Input
                    type="number"
                    value={stat.animateValue}
                    onChange={(e) =>
                      updateStat(index, {
                        animateValue: Number(e.target.value),
                      })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Label</Label>
                  <Input
                    value={stat.label}
                    onChange={(e) =>
                      updateStat(index, { label: e.target.value })
                    }
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Icon</Label>
                <Select
                  value={stat.icon}
                  onValueChange={(value) =>
                    updateStat(index, { icon: value as AboutPageIconKey })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select icon" />
                  </SelectTrigger>
                  <SelectContent>
                    {ABOUT_PAGE_ICONS.map((key) => (
                      <SelectItem key={key} value={key}>
                        {ABOUT_ICON_LABELS[key]}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          ))}
        </div>

        <AboutPageFormFooter
          end={
            <Button type="submit" disabled={saving} className="w-full sm:w-auto">
              {saving ? "Saving…" : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
