import type { ReactNode } from "react";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export function AboutPageAdminBackLink() {
  return (
    <Link
      href="/admin/about-page-content"
      className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6"
    >
      <ArrowLeft className="w-4 h-4" />
      Back to About Us page content
    </Link>
  );
}

export function AboutPageAdminHeader({
  title,
  description,
}: {
  title: string;
  description: string;
}) {
  return (
    <header className="mb-8">
      <h1 className="text-3xl font-heading font-bold text-foreground">{title}</h1>
      <p className="text-sm text-muted-foreground mt-1">{description}</p>
      <p className="text-xs text-muted-foreground mt-2">
        Save to publish this section on the public about page. If not saved, default
        content is shown on the site.
      </p>
    </header>
  );
}

export function AboutPageFormFooter({
  start,
  end,
}: {
  start?: ReactNode;
  end: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between pt-2">
      {start ? <div>{start}</div> : <div />}
      <div className="flex flex-col gap-2 sm:flex-row sm:justify-end">{end}</div>
    </div>
  );
}
