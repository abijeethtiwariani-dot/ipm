"use client";

import { useCallback, useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { AboutPageAccreditationCard } from "@/types/cms";
import {
  fetchAboutPageAccreditationContentAdmin,
  saveAboutPageAccreditationContentAdmin,
} from "@/lib/admin-cms-api";
import {
  AboutPageAdminBackLink,
  AboutPageAdminHeader,
  AboutPageFormFooter,
} from "@/components/admin/about-page/AboutPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const emptyCard = (): AboutPageAccreditationCard => ({ title: "", body: "" });

export function AboutPageAccreditationManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [eyebrow, setEyebrow] = useState("");
  const [heading, setHeading] = useState("");
  const [cards, setCards] = useState<AboutPageAccreditationCard[]>([]);

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchAboutPageAccreditationContentAdmin();
      if (data) {
        setEyebrow(data.eyebrow);
        setHeading(data.heading);
        setCards(data.cards?.length ? data.cards : [emptyCard(), emptyCard()]);
      } else {
        setEyebrow("");
        setHeading("");
        setCards([emptyCard(), emptyCard()]);
      }
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : "Failed to load accreditation content",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const updateCard = (
    index: number,
    patch: Partial<AboutPageAccreditationCard>,
  ) => {
    setCards((prev) =>
      prev.map((card, i) => (i === index ? { ...card, ...patch } : card)),
    );
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!eyebrow.trim() || !heading.trim()) {
      toast.error("Eyebrow and heading are required");
      return;
    }

    const valid = cards.filter((c) => c.title.trim() && c.body.trim());
    if (valid.length < 2) {
      toast.error("Add at least two cards with title and body");
      return;
    }

    setSaving(true);
    try {
      await saveAboutPageAccreditationContentAdmin({
        eyebrow: eyebrow.trim(),
        heading: heading.trim(),
        cards: valid.map((c) => ({
          title: c.title.trim(),
          body: c.body.trim(),
        })),
      });
      toast.success("Accreditation section saved");
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : "Failed to save accreditation section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-3xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-24 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-3xl">
      <AboutPageAdminBackLink />
      <AboutPageAdminHeader
        title="Global Accreditation"
        description="Section heading and two accreditation glass cards."
      />

      <form onSubmit={onSubmit} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="eyebrow">Eyebrow</Label>
          <Input
            id="eyebrow"
            value={eyebrow}
            onChange={(e) => setEyebrow(e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="heading">Heading</Label>
          <Input
            id="heading"
            value={heading}
            onChange={(e) => setHeading(e.target.value)}
          />
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Label>Cards</Label>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setCards((prev) => [...prev, emptyCard()])}
            >
              <Plus className="w-4 h-4 mr-1" />
              Add card
            </Button>
          </div>

          {cards.map((card, index) => (
            <div
              key={index}
              className="rounded-lg border border-border p-4 space-y-3"
            >
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">Card {index + 1}</p>
                {cards.length > 2 ? (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() =>
                      setCards((prev) => prev.filter((_, i) => i !== index))
                    }
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                ) : null}
              </div>
              <Input
                placeholder="Card title"
                value={card.title}
                onChange={(e) => updateCard(index, { title: e.target.value })}
              />
              <Textarea
                placeholder="Card body"
                rows={5}
                value={card.body}
                onChange={(e) => updateCard(index, { body: e.target.value })}
              />
            </div>
          ))}
        </div>

        <AboutPageFormFooter
          end={
            <Button type="submit" disabled={saving} className="w-full sm:w-auto">
              {saving ? "Saving…" : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
