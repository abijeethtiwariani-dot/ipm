"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import {
  fetchAboutPageHeroContentAdmin,
  saveAboutPageHeroContentAdmin,
} from "@/lib/admin-cms-api";
import {
  CmsHeroImagePairField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import {
  AboutPageAdminBackLink,
  AboutPageAdminHeader,
  AboutPageFormFooter,
} from "@/components/admin/about-page/AboutPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z.object({
  title: z.string().min(1, "Title is required"),
  subtitle: z.string(),
  imageAlt: z.string(),
});

type FormValues = z.infer<typeof formSchema>;

export function AboutPageHeroManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [desktopImage, setDesktopImage] = useState<CmsImageUploadValue | null>(
    null,
  );
  const [mobileImage, setMobileImage] = useState<CmsImageUploadValue | null>(
    null,
  );
  const [desktopPendingPreview, setDesktopPendingPreview] = useState<
    string | null
  >(null);
  const [mobilePendingPreview, setMobilePendingPreview] = useState<
    string | null
  >(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: { title: "", subtitle: "", imageAlt: "" },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchAboutPageHeroContentAdmin();
      if (data) {
        setDesktopImage(
          data.heroImageUrl ? { url: data.heroImageUrl } : null,
        );
        setMobileImage(
          data.mobileHeroImageUrl ? { url: data.mobileHeroImageUrl } : null,
        );
        form.reset({
          title: data.title,
          subtitle: data.subtitle,
          imageAlt: data.imageAlt,
        });
      } else {
        setDesktopImage(null);
        setMobileImage(null);
        form.reset({ title: "", subtitle: "", imageAlt: "" });
      }
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load hero content",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    if (!desktopImage?.url) {
      toast.error("Please upload a desktop banner image");
      return;
    }

    setSaving(true);
    try {
      await saveAboutPageHeroContentAdmin({
        title: values.title.trim(),
        subtitle: values.subtitle.trim(),
        heroImageUrl: desktopImage.url,
        mobileHeroImageUrl: mobileImage?.url?.trim() ?? "",
        imageAlt: values.imageAlt.trim(),
      });
      toast.success("Hero section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save hero section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-3xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-40 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-3xl">
      <AboutPageAdminBackLink />
      <AboutPageAdminHeader
        title="Hero Banner"
        description="Top banner on the about page. Upload desktop and optional mobile images."
      />

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="title">Title</Label>
          <Input id="title" {...form.register("title")} />
          {form.formState.errors.title ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.title.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="subtitle">Subtitle</Label>
          <Textarea id="subtitle" rows={3} {...form.register("subtitle")} />
        </div>

        <CmsHeroImagePairField
          desktop={desktopImage}
          mobile={mobileImage}
          onDesktopChange={setDesktopImage}
          onMobileChange={setMobileImage}
          folder="cms/about-page/hero"
          fileBaseName="banner"
          desktopPendingPreview={desktopPendingPreview}
          mobilePendingPreview={mobilePendingPreview}
          onDesktopPendingPreviewChange={setDesktopPendingPreview}
          onMobilePendingPreviewChange={setMobilePendingPreview}
        />

        <div className="space-y-2">
          <Label htmlFor="imageAlt">Image alt text</Label>
          <Input id="imageAlt" {...form.register("imageAlt")} />
        </div>

        <AboutPageFormFooter
          end={
            <Button type="submit" disabled={saving} className="w-full sm:w-auto">
              {saving ? "Saving…" : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
