"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import type { NewsResearchMattersContent } from "@/types/cms";
import {
  fetchNewsResearchMattersContentAdmin,
  saveNewsResearchMattersContentAdmin,
  uploadCmsImageUrl,
} from "@/lib/admin-cms-api";
import { NewsSectionBackLink } from "@/components/admin/NewsSectionBackLink";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  buttonText: z.string().min(1, "Button text is required"),
  buttonLink: z.string().min(1, "Button link is required"),
});

type FormValues = z.infer<typeof formSchema>;

export function NewsResearchMattersManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [backgroundFile, setBackgroundFile] = useState<File | null>(null);
  const [backgroundPreview, setBackgroundPreview] = useState<string | null>(null);
  const [existingBackgroundUrl, setExistingBackgroundUrl] = useState("");

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      buttonText: "",
      buttonLink: "",
    },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchNewsResearchMattersContentAdmin();
      setExistingBackgroundUrl(data.backgroundImageUrl ?? "");
      setBackgroundPreview(data.backgroundImageUrl || null);
      form.reset({
        title: data.title,
        description: data.description,
        buttonText: data.buttonText,
        buttonLink: data.buttonLink,
      });
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load content",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onBackgroundFileChange = (file: File | null) => {
    setBackgroundFile(file);
    if (file) {
      setBackgroundPreview(URL.createObjectURL(file));
    } else {
      setBackgroundPreview(existingBackgroundUrl || null);
    }
  };

  const onSubmit = async (values: FormValues) => {
    const hasBackground =
      Boolean(existingBackgroundUrl) || Boolean(backgroundFile);
    if (!hasBackground) {
      toast.error("Please upload a background image");
      return;
    }

    setSaving(true);
    try {
      let backgroundImageUrl = existingBackgroundUrl;
      if (backgroundFile) {
        backgroundImageUrl = await uploadCmsImageUrl(
          `cms/news/research-matters/bg-${backgroundFile.name}`,
          backgroundFile,
        );
      }

      const payload: Omit<NewsResearchMattersContent, "updatedAt"> = {
        title: values.title.trim(),
        description: values.description.trim(),
        buttonText: values.buttonText.trim(),
        buttonLink: values.buttonLink.trim(),
        backgroundImageUrl,
      };

      await saveNewsResearchMattersContentAdmin(payload);
      setExistingBackgroundUrl(backgroundImageUrl);
      setBackgroundFile(null);
      toast.success("Research Matters section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-2xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-24 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-2xl">
      <NewsSectionBackLink />

      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Research Matters
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Full-width banner with background image, copy, and CTA button.
        </p>
      </header>

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="title">Title</Label>
          <Input id="title" {...form.register("title")} />
          {form.formState.errors.title ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.title.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description</Label>
          <Textarea id="description" rows={4} {...form.register("description")} />
          {form.formState.errors.description ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.description.message}
            </p>
          ) : null}
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="buttonText">Button text</Label>
            <Input id="buttonText" {...form.register("buttonText")} />
            {form.formState.errors.buttonText ? (
              <p className="text-sm text-destructive">
                {form.formState.errors.buttonText.message}
              </p>
            ) : null}
          </div>
          <div className="space-y-2">
            <Label htmlFor="buttonLink">Button link</Label>
            <Input id="buttonLink" {...form.register("buttonLink")} />
            {form.formState.errors.buttonLink ? (
              <p className="text-sm text-destructive">
                {form.formState.errors.buttonLink.message}
              </p>
            ) : null}
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="backgroundImage">Background image</Label>
          {backgroundPreview ? (
            <div className="relative aspect-[21/9] w-full max-w-xl overflow-hidden rounded-md border border-border mb-2">
              <Image
                src={backgroundPreview}
                alt="Background preview"
                fill
                className="object-cover"
                unoptimized={backgroundPreview.startsWith("blob:")}
              />
            </div>
          ) : null}
          <Input
            id="backgroundImage"
            type="file"
            accept="image/*"
            onChange={(e) => onBackgroundFileChange(e.target.files?.[0] ?? null)}
          />
        </div>

        <Button type="submit" disabled={saving}>
          {saving ? "Saving…" : "Save changes"}
        </Button>
      </form>
    </section>
  );
}
