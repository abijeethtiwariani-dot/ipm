"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { ArrowLeft, Pencil, Plus, Star, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { HomeCampusLifeCard, HomeSectionContent } from "@/types/cms";
import {
  HOME_THREE_COLUMN_CARD_ORDERS,
  getHomeThreeColumnCardOrderLabel,
} from "@/types/cms";
import {
  DEFAULT_HOME_ATHLETICS_LINK,
  createHomeAthleticsCard,
  deleteHomeAthleticsCard,
  fetchHomeAthleticsCards,
  fetchHomeAthleticsContent,
  saveHomeAthleticsContent,
  updateHomeAthleticsCard,
  validateFeaturedHomeAthleticsLimit,
  validateHomeAthleticsCardOrder,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { HomeSectionPublishToggle } from "@/components/admin/HomeSectionPublishToggle";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const sectionFormSchema = z.object({
  sectionHeading: z.string().min(1, "Section heading is required"),
  sectionSubContent: z.string().min(1, "Sub content is required"),
  buttonText: z.string().min(1, "Button text is required"),
  buttonLink: z.string().min(1, "Button link is required"),
});

const cardFormSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  imageUrl: z.string().optional(),
  link: z.string().min(1, "Link is required"),
  linkText: z.string().optional(),
  featured: z.boolean(),
  order: z.string(),
});

type SectionFormValues = z.infer<typeof sectionFormSchema>;
type CardFormValues = z.infer<typeof cardFormSchema>;

function formatUpdatedAt(updatedAt: HomeCampusLifeCard["updatedAt"]): string {
  if (!updatedAt) return "—";
  if (
    typeof updatedAt === "object" &&
    updatedAt !== null &&
    "toDate" in updatedAt &&
    typeof (updatedAt as { toDate: () => Date }).toDate === "function"
  ) {
    return format((updatedAt as { toDate: () => Date }).toDate(), "MMM d, yyyy");
  }
  if (updatedAt instanceof Date) {
    return format(updatedAt, "MMM d, yyyy");
  }
  return "—";
}

export function HomeAthleticsManager() {
  const [cards, setCards] = useState<HomeCampusLifeCard[]>([]);
  const [loadingSection, setLoadingSection] = useState(true);
  const [loadingCards, setLoadingCards] = useState(true);
  const [savingSection, setSavingSection] = useState(false);
  const [savingCard, setSavingCard] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingCard, setEditingCard] = useState<HomeCampusLifeCard | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<HomeCampusLifeCard | null>(null);
  const [cardImage, setCardImage] = useState<CmsImageUploadValue | null>(null);
  const [imagePendingPreview, setImagePendingPreview] = useState<string | null>(
    null,
  );

  const sectionForm = useForm<SectionFormValues>({
    resolver: zodResolver(sectionFormSchema),
    defaultValues: {
      sectionHeading: "Athletics",
      sectionSubContent: "",
      buttonText: "More about athletics",
      buttonLink: DEFAULT_HOME_ATHLETICS_LINK,
    },
  });

  const cardForm = useForm<CardFormValues>({
    resolver: zodResolver(cardFormSchema),
    defaultValues: {
      title: "",
      description: "",
      imageUrl: "",
      link: DEFAULT_HOME_ATHLETICS_LINK,
      linkText: "",
      featured: false,
      order: "1",
    },
  });

  const featured = cardForm.watch("featured");
  const orderValue = cardForm.watch("order");

  const loadSection = useCallback(async () => {
    setLoadingSection(true);
    try {
      const data = await fetchHomeAthleticsContent();
      sectionForm.reset({
        sectionHeading: data.sectionHeading,
        sectionSubContent: data.sectionSubContent,
        buttonText: data.buttonText,
        buttonLink: data.buttonLink,
      });
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load section",
      );
    } finally {
      setLoadingSection(false);
    }
  }, [sectionForm]);

  const loadCards = useCallback(async () => {
    setLoadingCards(true);
    try {
      setCards(await fetchHomeAthleticsCards());
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load cards",
      );
    } finally {
      setLoadingCards(false);
    }
  }, []);

  useEffect(() => {
    loadSection();
    loadCards();
  }, [loadSection, loadCards]);

  const onSaveSection = async (values: SectionFormValues) => {
    setSavingSection(true);
    try {
      await saveHomeAthleticsContent(
        values as Omit<HomeSectionContent, "updatedAt">,
      );
      toast.success("Section settings saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save section",
      );
    } finally {
      setSavingSection(false);
    }
  };

  const openCreate = () => {
    setEditingCard(null);
    setCardImage(null);
    setImagePendingPreview(null);
    cardForm.reset({
      title: "",
      description: "",
      imageUrl: "",
      link: DEFAULT_HOME_ATHLETICS_LINK,
      linkText: "",
      featured: false,
      order: "1",
    });
    setDialogOpen(true);
  };

  const openEdit = (card: HomeCampusLifeCard) => {
    setEditingCard(card);
    setCardImage(card.imageUrl ? { url: card.imageUrl } : null);
    setImagePendingPreview(null);
    cardForm.reset({
      title: card.title,
      description: card.description,
      imageUrl: card.imageUrl,
      link: card.link,
      linkText: card.linkText,
      featured: card.featured,
      order: String(card.order || 1),
    });
    setDialogOpen(true);
  };

  const onSubmitCard = async (values: CardFormValues) => {
    const order = Number(values.order);
    if (!cardImage?.url) {
      toast.error("Please upload an image");
      return;
    }

    const featuredCheck = await validateFeaturedHomeAthleticsLimit(
      values.featured,
      editingCard?.id,
    );
    if (!featuredCheck.ok) {
      toast.error(featuredCheck.message);
      return;
    }

    const orderCheck = await validateHomeAthleticsCardOrder(
      order,
      values.featured,
      editingCard?.id,
    );
    if (!orderCheck.ok) {
      toast.error(orderCheck.message);
      return;
    }

    setSavingCard(true);
    try {
      const payload = {
        title: values.title,
        description: values.description,
        imageUrl: cardImage.url,
        link: values.link.trim() || DEFAULT_HOME_ATHLETICS_LINK,
        linkText: values.linkText?.trim() ?? "",
        featured: values.featured,
        order: values.featured ? order : 0,
      };

      if (editingCard) {
        await updateHomeAthleticsCard(editingCard.id, payload);
        toast.success("Card updated");
      } else {
        await createHomeAthleticsCard(payload);
        toast.success("Card created");
      }

      setDialogOpen(false);
      await loadCards();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save card",
      );
    } finally {
      setSavingCard(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteHomeAthleticsCard(deleteTarget.id);
      toast.success("Card deleted");
      setDeleteTarget(null);
      await loadCards();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete card",
      );
    }
  };

  return (
    <section className="space-y-10">
      <header>
        <Button variant="ghost" size="sm" className="mb-4 -ml-2" asChild>
          <Link href="/admin/home-content">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Home page content
          </Link>
        </Button>
        <HomeSectionPublishToggle sectionKey="athletics" className="mb-6" />
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Athletics
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Manage the homepage Athletics section. Up to 3 featured cards appear
          on the home page.
        </p>
      </header>

      <section className="bg-card rounded-lg border border-border shadow-sm p-6 md:p-8">
        <h2 className="text-xl font-heading font-semibold text-foreground mb-6">
          Section settings
        </h2>
        {loadingSection ? (
          <div className="space-y-4">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-24 w-full" />
          </div>
        ) : (
          <form
            onSubmit={sectionForm.handleSubmit(onSaveSection)}
            className="space-y-5 max-w-2xl"
          >
            <div className="space-y-2">
              <Label htmlFor="sectionHeading">Section heading</Label>
              <Input
                id="sectionHeading"
                {...sectionForm.register("sectionHeading")}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="sectionSubContent">Sub content</Label>
              <Textarea
                id="sectionSubContent"
                rows={3}
                {...sectionForm.register("sectionSubContent")}
              />
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="buttonText">Button text</Label>
                <Input id="buttonText" {...sectionForm.register("buttonText")} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="buttonLink">Button link</Label>
                <Input
                  id="buttonLink"
                  {...sectionForm.register("buttonLink")}
                />
              </div>
            </div>
            <Button type="submit" disabled={savingSection}>
              {savingSection ? "Saving..." : "Save section"}
            </Button>
          </form>
        )}
      </section>

      <section>
        <header className="flex flex-wrap items-center justify-between gap-4 mb-6">
          <h2 className="text-xl font-heading font-semibold text-foreground">
            Cards
          </h2>
          <Button onClick={openCreate}>
            <Plus className="w-4 h-4 mr-2" />
            Add card
          </Button>
        </header>

        <section className="bg-card rounded-lg border border-border shadow-sm overflow-hidden">
          {loadingCards ? (
            <section className="p-8 space-y-3">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </section>
          ) : cards.length === 0 ? (
            <p className="p-8 text-sm text-muted-foreground text-center">
              No cards yet. Add featured cards for the homepage.
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead>Title</TableHead>
                  <TableHead className="w-20">Featured</TableHead>
                  <TableHead className="w-36">Position</TableHead>
                  <TableHead className="hidden sm:table-cell w-32">
                    Updated
                  </TableHead>
                  <TableHead className="w-24 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {cards.map((card) => (
                  <TableRow key={card.id}>
                    <TableCell className="font-medium max-w-[200px]">
                      <span className="line-clamp-2">{card.title}</span>
                    </TableCell>
                    <TableCell>
                      {card.featured ? (
                        <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {card.featured
                        ? getHomeThreeColumnCardOrderLabel(card.order)
                        : "—"}
                    </TableCell>
                    <TableCell className="hidden sm:table-cell text-sm text-muted-foreground">
                      {formatUpdatedAt(card.updatedAt)}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => openEdit(card)}
                          aria-label="Edit"
                        >
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setDeleteTarget(card)}
                          aria-label="Delete"
                        >
                          <Trash2 className="w-4 h-4 text-destructive" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </section>
      </section>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-background">
          <DialogHeader>
            <DialogTitle className="font-heading text-xl">
              {editingCard ? "Edit card" : "New card"}
            </DialogTitle>
          </DialogHeader>
          <form
            onSubmit={cardForm.handleSubmit(onSubmitCard)}
            className="space-y-5"
          >
            <CmsImageUploadField
              label="Card image"
              preset="card4x3"
              folder="cms/home-athletics"
              storageFileName={editingCard?.id ?? `new-${Date.now()}`}
              value={cardImage}
              onChange={setCardImage}
              pendingPreviewUrl={imagePendingPreview}
              onPendingPreviewChange={setImagePendingPreview}
              required
            />

            <div className="space-y-2">
              <Label htmlFor="title">
                Title <span className="text-destructive">*</span>
              </Label>
              <Input id="title" {...cardForm.register("title")} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">
                Description <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="description"
                rows={4}
                {...cardForm.register("description")}
              />
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="link">
                  Link <span className="text-destructive">*</span>
                </Label>
                <Input id="link" {...cardForm.register("link")} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="linkText">Link text</Label>
                <Input
                  id="linkText"
                  placeholder="Student Affairs"
                  {...cardForm.register("linkText")}
                />
              </div>
            </div>

            <section className="flex items-start gap-3 rounded-lg border border-border p-4 bg-muted/30">
              <Checkbox
                id="featured"
                checked={featured}
                onCheckedChange={(checked) =>
                  cardForm.setValue("featured", checked === true)
                }
              />
              <div className="space-y-0.5">
                <Label htmlFor="featured" className="cursor-pointer font-medium">
                  Feature on homepage
                </Label>
                <p className="text-xs text-muted-foreground">
                  Up to 3 featured cards appear on the home page.
                </p>
              </div>
            </section>

            {featured ? (
              <div className="space-y-2">
                <Label htmlFor="order">
                  Card position <span className="text-destructive">*</span>
                </Label>
                <Select
                  value={orderValue}
                  onValueChange={(value) => cardForm.setValue("order", value)}
                >
                  <SelectTrigger id="order">
                    <SelectValue placeholder="Select position" />
                  </SelectTrigger>
                  <SelectContent>
                    {HOME_THREE_COLUMN_CARD_ORDERS.map((placement) => (
                      <SelectItem
                        key={placement.order}
                        value={String(placement.order)}
                      >
                        {placement.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            ) : null}

            <DialogFooter className="gap-2 sm:gap-0 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={savingCard}>
                {savingCard ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete card?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
