"use client";

import Link from "next/link";
import {
  BarChart3,
  Bell,
  ChevronRight,
  MessageCircle,
  Sparkles,
  Star,
  Users,
} from "lucide-react";
import { Card } from "@/components/ui/card";

const sections = [
  {
    title: "Alumni Banner",
    description: "Page banner title, subtitle, background image, and optional CTA.",
    href: "/admin/alumni-page-content/hero",
    icon: Sparkles,
  },
  {
    title: "Alumni Leadership",
    description: "Section header, leadership profiles, photos, bios, and LinkedIn links.",
    href: "/admin/alumni-page-content/leadership",
    icon: Users,
  },
  {
    title: "Alumni Notifications",
    description: "Section header, announcements, events, reunions, and community updates.",
    href: "/admin/alumni-page-content/notifications",
    icon: Bell,
  },
  {
    title: "Community Join Links",
    description: "WhatsApp and Telegram group names, descriptions, and links.",
    href: "/admin/alumni-page-content/community-links",
    icon: MessageCircle,
  },
  {
    title: "Alumni Impact Statistics",
    description: "Animated impact statistics with icons and display order.",
    href: "/admin/alumni-page-content/statistics",
    icon: BarChart3,
  },
  {
    title: "Alumni Testimonials",
    description: "Alumni testimonial carousel cards.",
    href: "/admin/alumni-page-content/testimonials",
    icon: Star,
  },
];

export function AlumniPageContentHub() {
  return (
    <section>
      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Alumni page content
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Manage sections on the public{" "}
          <code className="text-xs">/alumni</code> page. Content appears only
          after you save it here.
        </p>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {sections.map((section) => {
          const Icon = section.icon;
          return (
            <Link key={section.href} href={section.href}>
              <Card className="group h-full p-5 border border-border hover:border-primary/30 hover:shadow-md transition-all">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <Icon className="h-5 w-5" />
                  </div>
                  <ChevronRight className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors" />
                </div>
                <h2 className="font-heading font-semibold text-foreground mt-4">
                  {section.title}
                </h2>
                <p className="text-sm text-muted-foreground mt-1">
                  {section.description}
                </p>
              </Card>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
