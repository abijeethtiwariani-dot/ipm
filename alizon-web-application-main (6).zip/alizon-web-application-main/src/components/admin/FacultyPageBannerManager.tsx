"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import {
  fetchFacultyPageBannerAdmin,
  saveFacultyPageBannerAdmin,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z.object({
  pageTitle: z.string().min(1, "Page title is required"),
  pageSubtitle: z.string().min(1, "Page subtitle is required"),
});

type FormValues = z.infer<typeof formSchema>;

export function FacultyPageBannerManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [heroImage, setHeroImage] = useState<CmsImageUploadValue | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: { pageTitle: "", pageSubtitle: "" },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchFacultyPageBannerAdmin();
      form.reset({
        pageTitle: data.pageTitle,
        pageSubtitle: data.pageSubtitle,
      });
      setHeroImage(data.imageUrl ? { url: data.imageUrl } : null);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load banner",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    void loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    try {
      await saveFacultyPageBannerAdmin({
        pageTitle: values.pageTitle.trim(),
        pageSubtitle: values.pageSubtitle.trim(),
        imageUrl: heroImage?.url?.trim() ?? "",
      });
      toast.success("Page banner saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save banner",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-2xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-24 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-2xl">
      <Button variant="ghost" size="sm" className="mb-4 -ml-2" asChild>
        <Link href="/admin/faculties-staff">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Faculties & Staff page
        </Link>
      </Button>

      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Page banner
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Title, subtitle, and hero image for the top of the public Faculty &
          Staff page. Leave image empty to use the built-in placeholder.
        </p>
      </header>

      <form
        onSubmit={form.handleSubmit(onSubmit)}
        className="space-y-6 bg-card rounded-lg border border-border shadow-sm p-6 md:p-8"
      >
        <div className="space-y-2">
          <Label htmlFor="pageTitle">Page title</Label>
          <Input id="pageTitle" {...form.register("pageTitle")} />
          {form.formState.errors.pageTitle ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.pageTitle.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="pageSubtitle">Page subtitle</Label>
          <Textarea
            id="pageSubtitle"
            rows={4}
            {...form.register("pageSubtitle")}
          />
          {form.formState.errors.pageSubtitle ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.pageSubtitle.message}
            </p>
          ) : null}
        </div>

        <CmsImageUploadField
          label="Page banner image"
          preset="facultyPageBanner"
          folder="cms/faculty-page/banner"
          storageFileName="hero"
          value={heroImage}
          onChange={setHeroImage}
        />

        <Button type="submit" disabled={saving}>
          {saving ? "Saving…" : "Save banner"}
        </Button>
      </form>
    </section>
  );
}
