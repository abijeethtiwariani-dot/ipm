"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import type { NewsRecentStoriesContent } from "@/types/cms";
import {
  fetchNewsRecentStoriesContentAdmin,
  saveNewsRecentStoriesContentAdmin,
  uploadCmsImageUrl,
} from "@/lib/admin-cms-api";
import { NewsSectionBackLink } from "@/components/admin/NewsSectionBackLink";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";

const storySchema = z.object({
  category: z.string().min(1, "Category is required"),
  title: z.string().min(1, "Title is required"),
  link: z.string().optional(),
});

const formSchema = z.object({
  sectionHeading: z.string().min(1, "Section heading is required"),
  stories: z.array(storySchema).length(3),
});

type FormValues = z.infer<typeof formSchema>;

const STORY_LABELS = ["Story 1", "Story 2", "Story 3"];

export function NewsRecentStoriesManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [storyFiles, setStoryFiles] = useState<(File | null)[]>([
    null,
    null,
    null,
  ]);
  const [storyPreviews, setStoryPreviews] = useState<(string | null)[]>([
    null,
    null,
    null,
  ]);
  const [existingStoryUrls, setExistingStoryUrls] = useState<string[]>([
    "",
    "",
    "",
  ]);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      sectionHeading: "",
      stories: [
        { category: "", title: "", link: "" },
        { category: "", title: "", link: "" },
        { category: "", title: "", link: "" },
      ],
    },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchNewsRecentStoriesContentAdmin();
      setExistingStoryUrls(data.stories.map((item) => item.imageUrl ?? ""));
      setStoryPreviews(data.stories.map((item) => item.imageUrl || null));
      form.reset({
        sectionHeading: data.sectionHeading,
        stories: data.stories.map((item) => ({
          category: item.category,
          title: item.title,
          link: item.link ?? "",
        })) as FormValues["stories"],
      });
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load content",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onStoryFileChange = (index: number, file: File | null) => {
    setStoryFiles((prev) => {
      const next = [...prev];
      next[index] = file;
      return next;
    });
    setStoryPreviews((prev) => {
      const next = [...prev];
      next[index] = file
        ? URL.createObjectURL(file)
        : existingStoryUrls[index] || null;
      return next;
    });
  };

  const onSubmit = async (values: FormValues) => {
    for (let i = 0; i < 3; i++) {
      const hasImage = Boolean(existingStoryUrls[i]) || Boolean(storyFiles[i]);
      if (!hasImage) {
        toast.error(`Please upload an image for ${STORY_LABELS[i]}`);
        return;
      }
    }

    setSaving(true);
    try {
      const stories = await Promise.all(
        values.stories.map(async (item, index) => {
          let imageUrl = existingStoryUrls[index] ?? "";
          const file = storyFiles[index];
          if (file) {
            imageUrl = await uploadCmsImageUrl(
              `cms/news/recent-stories/story-${index + 1}-${file.name}`,
              file,
            );
          }
          return {
            category: item.category.trim(),
            title: item.title.trim(),
            imageUrl,
            ...(item.link?.trim() ? { link: item.link.trim() } : {}),
          };
        }),
      );

      const payload: Omit<NewsRecentStoriesContent, "updatedAt"> = {
        sectionHeading: values.sectionHeading.trim(),
        stories,
      };

      await saveNewsRecentStoriesContentAdmin(payload);
      setExistingStoryUrls(stories.map((item) => item.imageUrl));
      setStoryFiles([null, null, null]);
      toast.success("Recent Stories section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-2xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-24 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-2xl">
      <NewsSectionBackLink />

      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Recent Stories
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Section heading and three recent story cards.
        </p>
      </header>

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <div className="space-y-2">
          <Label htmlFor="sectionHeading">Section heading</Label>
          <Input id="sectionHeading" {...form.register("sectionHeading")} />
          {form.formState.errors.sectionHeading ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.sectionHeading.message}
            </p>
          ) : null}
        </div>

        {STORY_LABELS.map((label, index) => (
          <section
            key={label}
            className="space-y-4 rounded-lg border border-border bg-card p-6"
          >
            <h2 className="text-lg font-heading font-semibold text-foreground">
              {label}
            </h2>

            <div className="space-y-2">
              <Label htmlFor={`story-${index}-category`}>Category</Label>
              <Input
                id={`story-${index}-category`}
                {...form.register(`stories.${index}.category`)}
              />
              {form.formState.errors.stories?.[index]?.category ? (
                <p className="text-sm text-destructive">
                  {form.formState.errors.stories[index]?.category?.message}
                </p>
              ) : null}
            </div>

            <div className="space-y-2">
              <Label htmlFor={`story-${index}-title`}>Title</Label>
              <Input
                id={`story-${index}-title`}
                {...form.register(`stories.${index}.title`)}
              />
              {form.formState.errors.stories?.[index]?.title ? (
                <p className="text-sm text-destructive">
                  {form.formState.errors.stories[index]?.title?.message}
                </p>
              ) : null}
            </div>

            <div className="space-y-2">
              <Label htmlFor={`story-${index}-link`}>Link (optional)</Label>
              <Input
                id={`story-${index}-link`}
                placeholder="/news/example"
                {...form.register(`stories.${index}.link`)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor={`story-${index}-image`}>Image</Label>
              {storyPreviews[index] ? (
                <div className="relative aspect-[4/3] w-full max-w-xs overflow-hidden rounded-md border border-border mb-2">
                  <Image
                    src={storyPreviews[index]!}
                    alt={`${label} preview`}
                    fill
                    className="object-cover"
                    unoptimized={storyPreviews[index]!.startsWith("blob:")}
                  />
                </div>
              ) : null}
              <Input
                id={`story-${index}-image`}
                type="file"
                accept="image/*"
                onChange={(e) =>
                  onStoryFileChange(index, e.target.files?.[0] ?? null)
                }
              />
            </div>
          </section>
        ))}

        <Button type="submit" disabled={saving}>
          {saving ? "Saving…" : "Save changes"}
        </Button>
      </form>
    </section>
  );
}
