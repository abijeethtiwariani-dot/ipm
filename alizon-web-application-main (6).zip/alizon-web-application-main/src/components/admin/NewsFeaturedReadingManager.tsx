"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Image from "next/image";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { NewsFeaturedReadingCard } from "@/types/cms";
import {
  NEWS_FEATURED_READING_ORDERS,
  getNewsFeaturedReadingOrderLabel,
} from "@/types/cms";
import {
  createNewsFeaturedReadingCardAdmin,
  deleteNewsFeaturedReadingCardAdmin,
  fetchNewsFeaturedReadingCardsAdmin,
  updateNewsFeaturedReadingCardAdmin,
  uploadCmsImageUrl,
  validateNewsFeaturedReadingLimitAdmin,
  validateNewsFeaturedReadingOrderAdmin,
} from "@/lib/admin-cms-api";
import { NewsSectionBackLink } from "@/components/admin/NewsSectionBackLink";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const cardFormSchema = z.object({
  label: z.string().min(1, "Label is required"),
  title: z.string().min(1, "Title is required"),
  author: z.string().min(1, "Author is required"),
  type: z.string().min(1, "Type is required"),
  description: z
    .string()
    .min(10, "Description must be at least 10 characters")
    .max(350, "Description must be 350 characters or less"),
  coverImageUrl: z.string().optional(),
  order: z.string(),
});

type CardFormValues = z.infer<typeof cardFormSchema>;

function formatUpdatedAt(updatedAt: NewsFeaturedReadingCard["updatedAt"]): string {
  if (!updatedAt) return "—";
  if (
    typeof updatedAt === "object" &&
    updatedAt !== null &&
    "toDate" in updatedAt &&
    typeof (updatedAt as { toDate: () => Date }).toDate === "function"
  ) {
    return format((updatedAt as { toDate: () => Date }).toDate(), "MMM d, yyyy");
  }
  if (updatedAt instanceof Date) {
    return format(updatedAt, "MMM d, yyyy");
  }
  return "—";
}

export function NewsFeaturedReadingManager() {
  const [cards, setCards] = useState<NewsFeaturedReadingCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingCard, setEditingCard] = useState<NewsFeaturedReadingCard | null>(
    null,
  );
  const [deleteTarget, setDeleteTarget] = useState<NewsFeaturedReadingCard | null>(
    null,
  );
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const submittingRef = useRef(false);

  const form = useForm<CardFormValues>({
    resolver: zodResolver(cardFormSchema),
    defaultValues: {
      label: "",
      title: "",
      author: "",
      type: "",
      description: "",
      coverImageUrl: "",
      order: "1",
    },
  });

  const orderValue = form.watch("order");
  const descriptionValue = form.watch("description") ?? "";
  const descriptionOverLimit = descriptionValue.length > 350;

  const loadCards = useCallback(async () => {
    setLoading(true);
    try {
      setCards(await fetchNewsFeaturedReadingCardsAdmin());
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load cards",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadCards();
  }, [loadCards]);

  const openCreate = async () => {
    const limitCheck = await validateNewsFeaturedReadingLimitAdmin();
    if (!limitCheck.ok) {
      toast.error(limitCheck.message);
      return;
    }

    setEditingCard(null);
    setImageFile(null);
    setImagePreview(null);
    form.reset({
      label: "Featured reading",
      title: "",
      author: "",
      type: "Book",
      description: "",
      coverImageUrl: "",
      order: "1",
    });
    setDialogOpen(true);
  };

  const openEdit = (card: NewsFeaturedReadingCard) => {
    setEditingCard(card);
    setImageFile(null);
    setImagePreview(card.coverImageUrl || null);
    form.reset({
      label: card.label,
      title: card.title,
      author: card.author,
      type: card.type,
      description: card.description,
      coverImageUrl: card.coverImageUrl,
      order: String(card.order || 1),
    });
    setDialogOpen(true);
  };

  const onSubmit = async (values: CardFormValues) => {
    if (submittingRef.current) return;
    submittingRef.current = true;
    setSaving(true);

    try {
      const order = Number(values.order);
      const hasImage = Boolean(editingCard?.coverImageUrl) || Boolean(imageFile);
      if (!hasImage) {
        toast.error("Please upload a cover image");
        return;
      }

      const orderCheck = await validateNewsFeaturedReadingOrderAdmin(
        order,
        editingCard?.id,
      );
      if (!orderCheck.ok) {
        toast.error(orderCheck.message);
        return;
      }

      if (!editingCard) {
        const limitCheck = await validateNewsFeaturedReadingLimitAdmin();
        if (!limitCheck.ok) {
          toast.error(limitCheck.message);
          return;
        }
      }
      const cardId = editingCard?.id ?? `new-${Date.now()}`;
      let coverImageUrl = values.coverImageUrl ?? editingCard?.coverImageUrl ?? "";

      if (imageFile) {
        coverImageUrl = await uploadCmsImageUrl(
          `cms/news/featured-reading/${cardId}/${imageFile.name}`,
          imageFile,
        );
      }

      const payload = {
        label: values.label.trim(),
        title: values.title.trim(),
        author: values.author.trim(),
        type: values.type.trim(),
        description: values.description.trim(),
        coverImageUrl,
        order,
      };

      if (editingCard) {
        await updateNewsFeaturedReadingCardAdmin(editingCard.id, payload);
        toast.success("Slide updated");
      } else {
        await createNewsFeaturedReadingCardAdmin(payload);
        toast.success("Slide created");
      }

      setDialogOpen(false);
      await loadCards();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save slide",
      );
    } finally {
      submittingRef.current = false;
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteNewsFeaturedReadingCardAdmin(deleteTarget.id);
      toast.success("Slide deleted");
      setDeleteTarget(null);
      await loadCards();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete slide",
      );
    }
  };

  return (
    <section>
      <NewsSectionBackLink />

      <header className="flex flex-wrap items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">
            Featured Reading
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Up to 3 carousel slides with book cover and reading details.
          </p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="w-4 h-4 mr-2" />
          Add slide
        </Button>
      </header>

      <section className="bg-card rounded-lg border border-border shadow-sm overflow-hidden">
        {loading ? (
          <section className="p-8 space-y-3">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </section>
        ) : cards.length === 0 ? (
          <p className="p-8 text-sm text-muted-foreground text-center">
            No slides yet. Add up to 3 featured reading slides.
          </p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead>Title</TableHead>
                <TableHead className="hidden md:table-cell">Author</TableHead>
                <TableHead className="w-28">Slide</TableHead>
                <TableHead className="hidden sm:table-cell w-32">
                  Updated
                </TableHead>
                <TableHead className="w-24 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {cards.map((card) => (
                <TableRow key={card.id}>
                  <TableCell className="font-medium max-w-[240px]">
                    <span className="line-clamp-2">{card.title}</span>
                  </TableCell>
                  <TableCell className="hidden md:table-cell text-muted-foreground">
                    {card.author}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {getNewsFeaturedReadingOrderLabel(card.order)}
                  </TableCell>
                  <TableCell className="hidden sm:table-cell text-sm text-muted-foreground">
                    {formatUpdatedAt(card.updatedAt)}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEdit(card)}
                        aria-label="Edit"
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteTarget(card)}
                        aria-label="Delete"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </section>

      <Dialog
        open={dialogOpen}
        onOpenChange={(open) => {
          if (!open && saving) return;
          setDialogOpen(open);
        }}
      >
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-background">
          <DialogHeader>
            <DialogTitle className="font-heading text-xl">
              {editingCard ? "Edit slide" : "New slide"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="coverImage">
                Cover image <span className="text-destructive">*</span>
              </Label>
              <Input
                id="coverImage"
                type="file"
                accept="image/*"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  setImageFile(file);
                  setImagePreview(URL.createObjectURL(file));
                }}
              />
              {imagePreview ? (
                <div className="relative w-32 h-44 rounded-lg overflow-hidden bg-muted border border-border mt-2">
                  <Image
                    src={imagePreview}
                    alt="Cover preview"
                    fill
                    className="object-cover"
                    unoptimized
                  />
                </div>
              ) : null}
            </div>

            <div className="space-y-2">
              <Label htmlFor="order">
                Slide position <span className="text-destructive">*</span>
              </Label>
              <Select
                value={orderValue}
                onValueChange={(value) => form.setValue("order", value)}
              >
                <SelectTrigger id="order">
                  <SelectValue placeholder="Select slide" />
                </SelectTrigger>
                <SelectContent>
                  {NEWS_FEATURED_READING_ORDERS.map((placement) => (
                    <SelectItem
                      key={placement.order}
                      value={String(placement.order)}
                    >
                      {placement.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="label">
                Label <span className="text-destructive">*</span>
              </Label>
              <Input id="label" {...form.register("label")} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="title">
                Title <span className="text-destructive">*</span>
              </Label>
              <Input id="title" {...form.register("title")} />
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="author">
                  Author <span className="text-destructive">*</span>
                </Label>
                <Input id="author" {...form.register("author")} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="type">
                  Type <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="type"
                  placeholder="Book, Article, etc."
                  {...form.register("type")}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">
                Description <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="description"
                rows={4}
                maxLength={350}
                {...form.register("description")}
              />
              <p
                className={`text-xs ${descriptionOverLimit ? "text-destructive" : "text-muted-foreground"}`}
              >
                {descriptionValue.length} / 350
              </p>
              {form.formState.errors.description ? (
                <p className="text-sm text-destructive">
                  {form.formState.errors.description.message}
                </p>
              ) : null}
            </div>

            <DialogFooter className="gap-2 sm:gap-0 pt-2">
              <Button
                type="button"
                variant="outline"
                disabled={saving}
                onClick={() => setDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={saving || descriptionOverLimit}
                aria-busy={saving}
              >
                {saving ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete slide?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
