"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";
import { Eye, Filter, MoreHorizontal, Pencil, Plus, Search, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { apiDeleteProgram, apiFetchAdminPrograms } from "@/lib/admin-programs-api";
import type { Program } from "@/types/program";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { OptimizedImage } from "@/components/shared/OptimizedImage";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export function ProgramsManager() {
  const [loading, setLoading] = useState(true);
  const [programs, setPrograms] = useState<Program[]>([]);
  const [query, setQuery] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [openMenu, setOpenMenu] = useState<string | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Program | null>(null);

  const loadPrograms = useCallback(async () => {
    setLoading(true);
    try {
      setPrograms(await apiFetchAdminPrograms());
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to load programs.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadPrograms();
  }, [loadPrograms]);

  const categories = useMemo(() => {
    return [...new Set(programs.map((program) => program.category).filter(Boolean))].sort();
  }, [programs]);

  const filtered = useMemo(() => {
    return programs.filter((program) => {
      const matchesSearch =
        !query ||
        program.name.toLowerCase().includes(query.toLowerCase()) ||
        program.category.toLowerCase().includes(query.toLowerCase());
      const matchesCategory =
        categoryFilter === "all" || program.category === categoryFilter;
      const matchesStatus =
        statusFilter === "all" || program.status === statusFilter;
      return matchesSearch && matchesCategory && matchesStatus;
    });
  }, [categoryFilter, programs, query, statusFilter]);

  const onDelete = async () => {
    if (!deleteTarget) return;
    try {
      await apiDeleteProgram(deleteTarget.id);
      toast.success("Program deleted.");
      setDeleteTarget(null);
      await loadPrograms();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Delete failed.");
    }
  };

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-heading font-bold">Programs</h1>
          <p className="text-sm text-muted-foreground">
            Manage academic programs offered through Alizon.
          </p>
        </div>
        <Button asChild className="shadow-sm">
          <Link href="/admin/programs/new">
            <Plus className="mr-2 h-4 w-4" />
            Add Program
          </Link>
        </Button>
      </div>

      <div className="overflow-hidden rounded-2xl border border-border bg-card">
        <div className="flex flex-col gap-3 border-b border-border p-4 md:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search programs..."
              className="pl-9"
            />
          </div>
          <div className="grid gap-3 md:grid-cols-2">
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="min-w-[180px]">
                <Filter className="mr-2 h-4 w-4" />
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="min-w-[160px]">
                <SelectValue placeholder="All Statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="hidden overflow-x-auto lg:block">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50">
              <TableHead>Program</TableHead>
              <TableHead>Category</TableHead>
              <TableHead>Duration</TableHead>
              <TableHead>Modules</TableHead>
              <TableHead>Students</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading
              ? Array.from({ length: 5 }).map((_, idx) => (
                  <TableRow key={idx}>
                    <TableCell colSpan={7}>
                      <Skeleton className="h-10 w-full" />
                    </TableCell>
                  </TableRow>
                ))
              : filtered.map((program) => (
                  <TableRow key={program.id} className="group transition hover:bg-muted/40">
                    <TableCell>
                      <Link href={`/admin/programs/${program.id}`} className="flex items-center gap-3">
                        <OptimizedImage
                          image={program.thumbnail}
                          alt={program.name}
                          variant="thumbnail"
                          width={52}
                          height={52}
                          className="h-12 w-12 rounded-md object-cover"
                        />
                        <div>
                          <div className="font-medium transition group-hover:text-primary">{program.name}</div>
                          <div className="text-xs text-muted-foreground">/{program.slug || "program"}</div>
                        </div>
                      </Link>
                    </TableCell>
                    <TableCell>{program.category || "—"}</TableCell>
                    <TableCell>{program.duration || "—"}</TableCell>
                    <TableCell>{program.moduleCount}</TableCell>
                    <TableCell>{program.studentCount ?? 0}</TableCell>
                    <TableCell>
                      <Badge variant={program.status === "active" ? "default" : "secondary"}>
                        {program.status === "active" ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="relative">
                        <Button
                          size="icon"
                          variant="ghost"
                          onClick={() =>
                            setOpenMenu(openMenu === program.id ? null : program.id)
                          }
                        >
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                        {openMenu === program.id ? (
                          <div className="absolute right-0 top-10 z-20 w-44 rounded-lg border border-border bg-popover py-1 shadow-lg">
                            <Link href={`/admin/programs/${program.id}`} className="flex items-center gap-2 px-3 py-2 text-sm hover:bg-muted">
                              <Eye className="h-4 w-4" /> View Details
                            </Link>
                            <Link href={`/admin/programs/${program.id}/edit`} className="flex items-center gap-2 px-3 py-2 text-sm hover:bg-muted">
                              <Pencil className="h-4 w-4" /> Edit
                            </Link>
                            <button
                              className="flex w-full items-center gap-2 px-3 py-2 text-sm text-destructive hover:bg-muted"
                              onClick={() => setDeleteTarget(program)}
                            >
                              <Trash2 className="h-4 w-4" /> Delete
                            </button>
                          </div>
                        ) : null}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
          </TableBody>
        </Table>
        </div>

        <div className="divide-y divide-border lg:hidden">
        {filtered.map((program) => (
          <Link
            key={program.id}
            href={`/admin/programs/${program.id}`}
            className="block p-4 transition hover:bg-muted/40"
          >
            <div className="flex items-start gap-3">
              <OptimizedImage
                image={program.thumbnail}
                alt={program.name}
                variant="thumbnail"
                width={52}
                height={52}
                className="h-12 w-12 rounded-md object-cover"
              />
              <div className="min-w-0 flex-1">
                <div className="mb-1 flex items-center justify-between gap-2">
                  <p className="truncate font-medium">{program.name}</p>
                  <Badge variant={program.status === "active" ? "default" : "secondary"}>
                    {program.status}
                  </Badge>
                </div>
                <p className="text-xs text-muted-foreground">
                  {program.category || "General"} · {program.duration || "N/A"}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {program.moduleCount} modules · {program.studentCount ?? 0} students
                </p>
              </div>
            </div>
          </Link>
        ))}
        </div>
      </div>

      <AlertDialog open={Boolean(deleteTarget)} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete program?</AlertDialogTitle>
            <AlertDialogDescription>
              This action removes the selected program record.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={onDelete} className="bg-destructive text-destructive-foreground">
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
