"use client";

import Link from "next/link";
import { ChevronRight, ImageIcon, LayoutGrid, MapPin } from "lucide-react";
import { Card } from "@/components/ui/card";

const sections = [
  {
    title: "Page banner",
    description:
      "Page title, intro, hero images, and stat tiles at the top of the Campus Life page.",
    href: "/admin/campus-life/banner",
    icon: ImageIcon,
  },
  {
    title: "Card sections",
    description:
      "Manage Student Life, Arts & Culture, and Athletics cards using the category dropdown.",
    href: "/admin/campus-life/cards",
    icon: LayoutGrid,
  },
  {
    title: "Getting Around",
    description:
      "Section heading, intro, image, and quick links for the Getting Around block.",
    href: "/admin/campus-life/getting-around",
    icon: MapPin,
  },
];

export function CampusLifeHub() {
  return (
    <section>
      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Campus Life page
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Manage content on the public Campus Life page.
        </p>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 max-w-5xl">
        {sections.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href}>
              <Card className="p-6 h-full border border-border shadow-sm hover:shadow-md transition-shadow card-hover">
                <div className="flex items-start justify-between gap-4">
                  <div className="w-11 h-11 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-1" />
                </div>
                <h2 className="text-lg font-heading font-semibold text-foreground mt-4">
                  {item.title}
                </h2>
                <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                  {item.description}
                </p>
              </Card>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
