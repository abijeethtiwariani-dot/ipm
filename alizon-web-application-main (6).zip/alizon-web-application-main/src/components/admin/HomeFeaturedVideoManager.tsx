"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowLeft, Loader2, Upload } from "lucide-react";
import { toast } from "sonner";
import type { HomeFeaturedVideoContent } from "@/types/cms";
import {
  fetchHomeFeaturedVideoContentAdmin,
  saveHomeFeaturedVideoContentAdmin,
  uploadCmsVideoUrl,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import { HomeSectionPublishToggle } from "@/components/admin/HomeSectionPublishToggle";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Skeleton } from "@/components/ui/skeleton";
import { isValidYoutubeUrl, isDirectVideoFileUrl } from "@/lib/youtube";

function normalizeHttpUrl(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed) return "";
  if (/^https?:\/\//i.test(trimmed)) return trimmed;
  return `https://${trimmed}`;
}

const formSchema = z
  .object({
    videoSource: z.enum(["youtube", "upload", "url"]),
    youtubeUrl: z.string().optional(),
    videoUrl: z.string().optional(),
    mobileVideoSource: z.enum(["youtube", "upload", "url"]),
    mobileYoutubeUrl: z.string().optional(),
    mobileVideoUrl: z.string().optional(),
  })
  .superRefine((values, ctx) => {
    if (values.videoSource === "youtube") {
      const url = values.youtubeUrl?.trim() ?? "";
      if (!url) return;
      if (isDirectVideoFileUrl(url) || isDirectVideoFileUrl(normalizeHttpUrl(url))) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message:
            "This looks like a video file URL — switch source to Video URL.",
          path: ["youtubeUrl"],
        });
        return;
      }
      if (!isValidYoutubeUrl(url)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Enter a valid YouTube URL",
          path: ["youtubeUrl"],
        });
      }
    }
    if (values.videoSource === "url") {
      const raw = values.videoUrl?.trim() ?? "";
      if (!raw) return;
      const url = normalizeHttpUrl(raw);
      try {
        // eslint-disable-next-line no-new
        new URL(url);
      } catch {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Enter a valid video URL",
          path: ["videoUrl"],
        });
        return;
      }
      if (isValidYoutubeUrl(url)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "This looks like a YouTube link — switch source to YouTube URL.",
          path: ["videoUrl"],
        });
      }
    }
    if (values.mobileVideoSource === "youtube") {
      const url = values.mobileYoutubeUrl?.trim() ?? "";
      if (!url) return;
      if (isDirectVideoFileUrl(url) || isDirectVideoFileUrl(normalizeHttpUrl(url))) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message:
            "This looks like a video file — switch mobile source to Video URL.",
          path: ["mobileYoutubeUrl"],
        });
        return;
      }
      if (!isValidYoutubeUrl(url)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Enter a valid YouTube URL",
          path: ["mobileYoutubeUrl"],
        });
      }
    }
    if (values.mobileVideoSource === "url") {
      const raw = values.mobileVideoUrl?.trim() ?? "";
      if (!raw) return;
      const url = normalizeHttpUrl(raw);
      try {
        // eslint-disable-next-line no-new
        new URL(url);
      } catch {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Enter a valid video URL",
          path: ["mobileVideoUrl"],
        });
        return;
      }
      if (isValidYoutubeUrl(url)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message:
            "This looks like a YouTube link — switch mobile source to YouTube URL.",
          path: ["mobileVideoUrl"],
        });
      }
    }
  });

type FormValues = z.infer<typeof formSchema>;

export function HomeFeaturedVideoManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploadingVideo, setUploadingVideo] = useState(false);
  const [uploadingMobileVideo, setUploadingMobileVideo] = useState(false);
  const [videoFileUrl, setVideoFileUrl] = useState("");
  const [mobileVideoFileUrl, setMobileVideoFileUrl] = useState("");
  const [posterImage, setPosterImage] =
    useState<CmsImageUploadValue | null>(null);
  const [posterPending, setPosterPending] = useState<string | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      videoSource: "youtube",
      youtubeUrl: "",
      videoUrl: "",
      mobileVideoSource: "youtube",
      mobileYoutubeUrl: "",
      mobileVideoUrl: "",
    },
  });

  const videoSource = form.watch("videoSource");
  const mobileVideoSource = form.watch("mobileVideoSource");

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchHomeFeaturedVideoContentAdmin();
      form.reset({
        videoSource: data.videoSource,
        youtubeUrl: data.youtubeUrl,
        videoUrl: data.videoUrl,
        mobileVideoSource: data.mobileVideoSource ?? "youtube",
        mobileYoutubeUrl: data.mobileYoutubeUrl ?? "",
        mobileVideoUrl: data.mobileVideoUrl ?? "",
      });
      setVideoFileUrl(data.videoFileUrl ?? "");
      setMobileVideoFileUrl(data.mobileVideoFileUrl ?? "");
      setPosterImage(
        data.posterImageUrl ? { url: data.posterImageUrl } : null,
      );
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load content",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    void loadContent();
  }, [loadContent]);

  const onUploadVideo = async (file?: File) => {
    if (!file) return;
    setUploadingVideo(true);
    try {
      const url = await uploadCmsVideoUrl(
        "cms/home-featured-video/video",
        file,
      );
      setVideoFileUrl(url);
      toast.success("Video uploaded");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to upload video",
      );
    } finally {
      setUploadingVideo(false);
    }
  };

  const onUploadMobileVideo = async (file?: File) => {
    if (!file) return;
    setUploadingMobileVideo(true);
    try {
      const url = await uploadCmsVideoUrl(
        "cms/home-featured-video/mobile-video",
        file,
      );
      setMobileVideoFileUrl(url);
      toast.success("Mobile video uploaded");
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : "Failed to upload mobile video",
      );
    } finally {
      setUploadingMobileVideo(false);
    }
  };

  const onSave = async (values: FormValues) => {
    if (values.videoSource === "upload" && !videoFileUrl.trim()) {
      toast.error("Upload a video file or switch source");
      return;
    }
    if (values.videoSource === "youtube" && !values.youtubeUrl?.trim()) {
      toast.error("Enter a YouTube URL");
      return;
    }
    if (values.videoSource === "url" && !values.videoUrl?.trim()) {
      toast.error("Enter a video URL");
      return;
    }

    setSaving(true);
    try {
      const payload: Omit<HomeFeaturedVideoContent, "updatedAt"> = {
        videoSource: values.videoSource,
        youtubeUrl: values.youtubeUrl?.trim() ?? "",
        videoFileUrl: videoFileUrl.trim(),
        videoUrl:
          values.videoSource === "url"
            ? normalizeHttpUrl(values.videoUrl?.trim() ?? "")
            : values.videoUrl?.trim() ?? "",
        mobileVideoSource: values.mobileVideoSource,
        mobileYoutubeUrl: values.mobileYoutubeUrl?.trim() ?? "",
        mobileVideoFileUrl: mobileVideoFileUrl.trim(),
        mobileVideoUrl:
          values.mobileVideoSource === "url"
            ? normalizeHttpUrl(values.mobileVideoUrl?.trim() ?? "")
            : values.mobileVideoUrl?.trim() ?? "",
        posterImageUrl: posterImage?.url?.trim() ?? "",
      };
      await saveHomeFeaturedVideoContentAdmin(payload);
      toast.success("Featured video section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl space-y-8">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/admin/home-content" aria-label="Back to home content">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-2xl font-heading font-bold text-foreground">
            Featured Video
          </h1>
          <p className="text-sm text-muted-foreground">
            Full-width video shown on the homepage after Campus News.
          </p>
        </div>
      </div>

      <HomeSectionPublishToggle sectionKey="featuredVideo" />

      <form onSubmit={form.handleSubmit(onSave)} className="space-y-6">
        <div className="space-y-4 rounded-xl border border-border bg-card p-6">
          <h2 className="text-lg font-heading font-semibold">
            Desktop video source
          </h2>
          <RadioGroup
            value={videoSource}
            onValueChange={(value) =>
              form.setValue(
                "videoSource",
                value as "youtube" | "upload" | "url",
                { shouldDirty: true },
              )
            }
            className="flex flex-wrap gap-x-6 gap-y-3"
          >
            <div className="flex items-center gap-2">
              <RadioGroupItem value="youtube" id="featured-video-youtube" />
              <Label
                htmlFor="featured-video-youtube"
                className="cursor-pointer font-normal"
              >
                YouTube URL
              </Label>
            </div>
            <div className="flex items-center gap-2">
              <RadioGroupItem value="upload" id="featured-video-upload" />
              <Label
                htmlFor="featured-video-upload"
                className="cursor-pointer font-normal"
              >
                Upload video
              </Label>
            </div>
            <div className="flex items-center gap-2">
              <RadioGroupItem value="url" id="featured-video-url" />
              <Label
                htmlFor="featured-video-url"
                className="cursor-pointer font-normal"
              >
                Video URL
              </Label>
            </div>
          </RadioGroup>

          {videoSource === "youtube" ? (
            <div className="space-y-2">
              <Label htmlFor="youtubeUrl">YouTube URL</Label>
              <Input
                id="youtubeUrl"
                placeholder="https://www.youtube.com/watch?v=..."
                {...form.register("youtubeUrl")}
              />
              {form.formState.errors.youtubeUrl ? (
                <p className="text-sm text-destructive">
                  {form.formState.errors.youtubeUrl.message}
                </p>
              ) : null}
            </div>
          ) : null}

          {videoSource === "upload" ? (
            <div className="space-y-2">
              <Label>Upload video file</Label>
              <Input
                type="file"
                accept="video/mp4,video/webm,video/quicktime,.mp4,.webm,.mov"
                disabled={uploadingVideo}
                onChange={(e) => void onUploadVideo(e.target.files?.[0])}
              />
              {uploadingVideo ? (
                <p className="inline-flex items-center gap-2 text-xs text-muted-foreground">
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  Uploading…
                </p>
              ) : null}
              {videoFileUrl ? (
                <div className="flex flex-wrap items-center gap-3">
                  <p className="max-w-full truncate text-xs text-muted-foreground">
                    Video saved
                  </p>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setVideoFileUrl("")}
                  >
                    Remove video
                  </Button>
                </div>
              ) : null}
            </div>
          ) : null}

          {videoSource === "url" ? (
            <div className="space-y-2">
              <Label htmlFor="videoUrl">Direct video URL</Label>
              <Input
                id="videoUrl"
                placeholder="https://example.com/video.mp4"
                {...form.register("videoUrl")}
              />
              {form.formState.errors.videoUrl ? (
                <p className="text-sm text-destructive">
                  {form.formState.errors.videoUrl.message}
                </p>
              ) : null}
            </div>
          ) : null}

          {videoSource !== "youtube" ? (
            <CmsImageUploadField
              label="Poster image (optional)"
              preset="heroDesktop"
              folder="cms/home-featured-video/poster"
              storageFileName="poster"
              value={posterImage}
              onChange={setPosterImage}
              pendingPreviewUrl={posterPending}
              onPendingPreviewChange={setPosterPending}
            />
          ) : null}
        </div>

        <div className="space-y-4 rounded-xl border border-border bg-card p-6">
          <div>
            <h2 className="text-lg font-heading font-semibold">
              Mobile video source (9:16)
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Optional. Used on phones. Leave empty to fall back to the desktop
              video.
            </p>
          </div>
          <RadioGroup
            value={mobileVideoSource}
            onValueChange={(value) =>
              form.setValue(
                "mobileVideoSource",
                value as "youtube" | "upload" | "url",
                { shouldDirty: true },
              )
            }
            className="flex flex-wrap gap-x-6 gap-y-3"
          >
            <div className="flex items-center gap-2">
              <RadioGroupItem
                value="youtube"
                id="featured-mobile-video-youtube"
              />
              <Label
                htmlFor="featured-mobile-video-youtube"
                className="cursor-pointer font-normal"
              >
                YouTube URL
              </Label>
            </div>
            <div className="flex items-center gap-2">
              <RadioGroupItem
                value="upload"
                id="featured-mobile-video-upload"
              />
              <Label
                htmlFor="featured-mobile-video-upload"
                className="cursor-pointer font-normal"
              >
                Upload video
              </Label>
            </div>
            <div className="flex items-center gap-2">
              <RadioGroupItem value="url" id="featured-mobile-video-url" />
              <Label
                htmlFor="featured-mobile-video-url"
                className="cursor-pointer font-normal"
              >
                Video URL
              </Label>
            </div>
          </RadioGroup>

          {mobileVideoSource === "youtube" ? (
            <div className="space-y-2">
              <Label htmlFor="mobileYoutubeUrl">Mobile YouTube URL</Label>
              <Input
                id="mobileYoutubeUrl"
                placeholder="https://www.youtube.com/watch?v=..."
                {...form.register("mobileYoutubeUrl")}
              />
              {form.formState.errors.mobileYoutubeUrl ? (
                <p className="text-sm text-destructive">
                  {form.formState.errors.mobileYoutubeUrl.message}
                </p>
              ) : null}
            </div>
          ) : null}

          {mobileVideoSource === "upload" ? (
            <div className="space-y-2">
              <Label>Upload 9:16 video</Label>
              <Input
                type="file"
                accept="video/mp4,video/webm,video/quicktime,.mp4,.webm,.mov"
                disabled={uploadingMobileVideo}
                onChange={(e) => void onUploadMobileVideo(e.target.files?.[0])}
              />
              {uploadingMobileVideo ? (
                <p className="inline-flex items-center gap-2 text-xs text-muted-foreground">
                  <Loader2 className="h-3.5 w-3.5 animate-spin" />
                  Uploading…
                </p>
              ) : null}
              {mobileVideoFileUrl ? (
                <div className="flex flex-wrap items-center gap-3">
                  <p className="max-w-full truncate text-xs text-muted-foreground">
                    Mobile video saved
                  </p>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setMobileVideoFileUrl("")}
                  >
                    Remove mobile video
                  </Button>
                </div>
              ) : null}
            </div>
          ) : null}

          {mobileVideoSource === "url" ? (
            <div className="space-y-2">
              <Label htmlFor="mobileVideoUrl">Mobile direct video URL</Label>
              <Input
                id="mobileVideoUrl"
                placeholder="https://example.com/video-9x16.mp4"
                {...form.register("mobileVideoUrl")}
              />
              {form.formState.errors.mobileVideoUrl ? (
                <p className="text-sm text-destructive">
                  {form.formState.errors.mobileVideoUrl.message}
                </p>
              ) : null}
            </div>
          ) : null}
        </div>

        <Button
          type="submit"
          disabled={saving || uploadingVideo || uploadingMobileVideo}
        >
          {saving ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Saving…
            </>
          ) : (
            <>
              <Upload className="mr-2 h-4 w-4" />
              Save section
            </>
          )}
        </Button>
      </form>
    </div>
  );
}
