"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { FacultyLeader } from "@/types/cms";
import {
  createFacultyLeaderAdmin,
  deleteFacultyLeaderAdmin,
  fetchFacultyLeadersAdmin,
  updateFacultyLeaderAdmin,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import { StringListField } from "@/components/admin/faculty/StringListField";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { shouldUnoptimizeCmsSrc } from "@/lib/cms-image-url";

const leaderSchema = z.object({
  name: z.string().min(1, "Name is required"),
  position: z.string().min(1, "Position is required"),
  department: z.string().min(1, "Department is required"),
  bio: z.string().min(10, "Bio must be at least 10 characters"),
  order: z.coerce.number().min(0),
  published: z.boolean(),
});

type LeaderFormValues = z.infer<typeof leaderSchema>;

export function FacultyLeadersTab() {
  const [leaders, setLeaders] = useState<FacultyLeader[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<FacultyLeader | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<FacultyLeader | null>(null);
  const [leaderImage, setLeaderImage] = useState<CmsImageUploadValue | null>(
    null,
  );
  const [achievements, setAchievements] = useState<string[]>([]);

  const form = useForm<LeaderFormValues>({
    resolver: zodResolver(leaderSchema),
    defaultValues: {
      name: "",
      position: "",
      department: "Academic Leadership",
      bio: "",
      order: 0,
      published: true,
    },
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setLeaders(await fetchFacultyLeadersAdmin());
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load leadership",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const openCreate = () => {
    setEditing(null);
    setLeaderImage(null);
    setAchievements([""]);
    form.reset({
      name: "",
      position: "",
      department: "Academic Leadership",
      bio: "",
      order:
        leaders.length > 0 ? Math.max(...leaders.map((l) => l.order)) + 1 : 0,
      published: true,
    });
    setDialogOpen(true);
  };

  const openEdit = (leader: FacultyLeader) => {
    setEditing(leader);
    setLeaderImage(leader.imageUrl ? { url: leader.imageUrl } : null);
    setAchievements(
      leader.achievements.length > 0 ? leader.achievements : [""],
    );
    form.reset({
      name: leader.name,
      position: leader.position,
      department: leader.department,
      bio: leader.bio,
      order: leader.order,
      published: leader.published,
    });
    setDialogOpen(true);
  };

  const onSubmit = async (values: LeaderFormValues) => {
    const imageUrl = leaderImage?.url?.trim() ?? editing?.imageUrl ?? "";
    if (!imageUrl) {
      toast.error("Please upload a leadership photo");
      return;
    }

    setSaving(true);
    try {
      const payload = {
        name: values.name.trim(),
        position: values.position.trim(),
        department: values.department.trim(),
        imageUrl,
        bio: values.bio.trim(),
        achievements: achievements.map((s) => s.trim()).filter(Boolean),
        order: values.order,
        published: values.published,
      };

      if (editing) {
        await updateFacultyLeaderAdmin(editing.id, payload);
        toast.success("Leader updated");
      } else {
        await createFacultyLeaderAdmin(payload);
        toast.success("Leader created");
      }
      setDialogOpen(false);
      await load();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save leader",
      );
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteFacultyLeaderAdmin(deleteTarget.id);
      toast.success("Leader deleted");
      setDeleteTarget(null);
      await load();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete",
      );
    }
  };

  return (
    <section>
      <header className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-xl font-heading font-semibold text-foreground">
            Academic leadership
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            Leadership cards on the public Faculty & Staff page.
          </p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="w-4 h-4 mr-2" />
          Add leader
        </Button>
      </header>

      <section className="bg-card rounded-lg border border-border shadow-sm overflow-hidden">
        {loading ? (
          <section className="p-8 space-y-3">
            <Skeleton className="h-10 w-full" />
          </section>
        ) : leaders.length === 0 ? (
          <p className="p-8 text-sm text-muted-foreground text-center">
            No leadership entries yet.
          </p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-14">Photo</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Position</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {leaders.map((leader) => (
                <TableRow key={leader.id}>
                  <TableCell>
                    {leader.imageUrl ? (
                      <div className="relative w-12 h-9 rounded overflow-hidden border border-border">
                        <Image
                          src={leader.imageUrl}
                          alt=""
                          fill
                          className="object-cover"
                          sizes="48px"
                          unoptimized={shouldUnoptimizeCmsSrc(leader.imageUrl)}
                        />
                      </div>
                    ) : (
                      "—"
                    )}
                  </TableCell>
                  <TableCell className="font-medium">{leader.name}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {leader.position}
                  </TableCell>
                  <TableCell className="text-sm">
                    {leader.published ? "Published" : "Draft"}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openEdit(leader)}
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setDeleteTarget(leader)}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </section>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editing ? "Edit leader" : "Add leader"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <CmsImageUploadField
              label="Leadership photo"
              preset="facultyLeadership"
              folder={`cms/faculty-leadership/${editing?.id ?? "new"}`}
              storageFileName="photo"
              value={leaderImage}
              onChange={setLeaderImage}
              required
            />

            <div className="space-y-2">
              <Label htmlFor="leader-name">Name</Label>
              <Input id="leader-name" {...form.register("name")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="position">Position</Label>
              <Input id="position" {...form.register("position")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="leader-dept">Department</Label>
              <Input id="leader-dept" {...form.register("department")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="leader-bio">Bio</Label>
              <Textarea id="leader-bio" rows={4} {...form.register("bio")} />
            </div>
            <StringListField
              label="Achievements"
              values={achievements}
              onChange={setAchievements}
            />
            <div className="space-y-2">
              <Label htmlFor="leader-order">Display order</Label>
              <Input
                id="leader-order"
                type="number"
                min={0}
                {...form.register("order")}
              />
            </div>
            <label className="flex items-center gap-2 text-sm">
              <Checkbox
                checked={form.watch("published")}
                onCheckedChange={(c) => form.setValue("published", c === true)}
              />
              Published on public page
            </label>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving}>
                {saving ? "Saving…" : editing ? "Update" : "Create"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={Boolean(deleteTarget)}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete leader?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove {deleteTarget?.name} from the leadership section.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => void handleDelete()}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
