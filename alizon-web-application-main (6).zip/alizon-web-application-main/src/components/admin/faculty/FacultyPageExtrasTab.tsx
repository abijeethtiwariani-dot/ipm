"use client";

import { useCallback, useEffect, useState } from "react";
import { toast } from "sonner";
import type { FacultyPageExtras, FacultyPageStat } from "@/types/cms";
import {
  fetchFacultyPageExtrasAdmin,
  saveFacultyPageExtrasAdmin,
} from "@/lib/admin-cms-api";
import { DEFAULT_FACULTY_PAGE_EXTRAS } from "@/lib/cms";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import { StringListField } from "@/components/admin/faculty/StringListField";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const STAT_ICONS = ["Users", "BookOpen", "GraduationCap", "Star"];
const FEATURE_ICONS = [
  "Briefcase",
  "FlaskConical",
  "Globe",
  "Award",
  "Lightbulb",
  "Users",
];

export function FacultyPageExtrasTab() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [stats, setStats] = useState<FacultyPageStat[]>(
    DEFAULT_FACULTY_PAGE_EXTRAS.stats,
  );
  const [features, setFeatures] = useState(
    DEFAULT_FACULTY_PAGE_EXTRAS.whyLearnFeatures,
  );
  const [cta, setCta] = useState(DEFAULT_FACULTY_PAGE_EXTRAS.cta);
  const [ctaBackground, setCtaBackground] = useState<CmsImageUploadValue | null>(
    null,
  );
  const [trustIndicators, setTrustIndicators] = useState<string[]>(
    DEFAULT_FACULTY_PAGE_EXTRAS.cta.trustIndicators,
  );

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchFacultyPageExtrasAdmin();
      setStats(data.stats);
      setFeatures(data.whyLearnFeatures);
      setCta(data.cta);
      setTrustIndicators(data.cta.trustIndicators);
      setCtaBackground(
        data.cta.backgroundImageUrl
          ? { url: data.cta.backgroundImageUrl }
          : null,
      );
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load page sections",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const updateStat = (
    index: number,
    field: keyof FacultyPageStat,
    value: string | number,
  ) => {
    setStats((prev) => {
      const next = [...prev];
      next[index] = { ...next[index], [field]: value };
      return next;
    });
  };

  const updateFeature = (
    index: number,
    field: "icon" | "title" | "description",
    value: string,
  ) => {
    setFeatures((prev) => {
      const next = [...prev];
      next[index] = { ...next[index], [field]: value };
      return next;
    });
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const extras: Omit<FacultyPageExtras, "updatedAt"> = {
        stats,
        whyLearnFeatures: features,
        cta: {
          ...cta,
          backgroundImageUrl: ctaBackground?.url?.trim() ?? "",
          trustIndicators: trustIndicators.map((s) => s.trim()).filter(Boolean),
        },
      };
      await saveFacultyPageExtrasAdmin(extras);
      toast.success("Page sections saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="space-y-4 max-w-2xl">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-32 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-2xl space-y-10">
      <div>
        <h2 className="text-xl font-heading font-semibold text-foreground mb-1">
          Statistics strip
        </h2>
        <p className="text-sm text-muted-foreground mb-4">
          Four animated stat cards below the page banner.
        </p>
        <div className="space-y-4 bg-card border border-border rounded-lg p-6">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="grid sm:grid-cols-4 gap-3 pb-4 border-b border-border last:border-0 last:pb-0"
            >
              <div className="space-y-1">
                <Label>Value</Label>
                <Input
                  type="text"
                  value={String(stat.value)}
                  onChange={(e) => {
                    const raw = e.target.value;
                    const num = Number(raw);
                    updateStat(
                      index,
                      "value",
                      raw !== "" && !Number.isNaN(num) ? num : raw,
                    );
                  }}
                />
              </div>
              <div className="space-y-1">
                <Label>Suffix</Label>
                <Input
                  value={stat.suffix ?? ""}
                  onChange={(e) => updateStat(index, "suffix", e.target.value)}
                  placeholder="+"
                />
              </div>
              <div className="space-y-1 sm:col-span-2">
                <Label>Label</Label>
                <Input
                  value={stat.label}
                  onChange={(e) => updateStat(index, "label", e.target.value)}
                />
              </div>
              <div className="space-y-1 sm:col-span-4">
                <Label>Icon</Label>
                <select
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  value={stat.icon}
                  onChange={(e) => updateStat(index, "icon", e.target.value)}
                >
                  {STAT_ICONS.map((icon) => (
                    <option key={icon} value={icon}>
                      {icon}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-xl font-heading font-semibold text-foreground mb-1">
          Why learn from our faculty
        </h2>
        <div className="space-y-4 bg-card border border-border rounded-lg p-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="space-y-3 pb-4 border-b border-border last:border-0"
            >
              <div className="space-y-1">
                <Label>Icon</Label>
                <select
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                  value={feature.icon}
                  onChange={(e) =>
                    updateFeature(index, "icon", e.target.value)
                  }
                >
                  {FEATURE_ICONS.map((icon) => (
                    <option key={icon} value={icon}>
                      {icon}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-1">
                <Label>Title</Label>
                <Input
                  value={feature.title}
                  onChange={(e) =>
                    updateFeature(index, "title", e.target.value)
                  }
                />
              </div>
              <div className="space-y-1">
                <Label>Description</Label>
                <Textarea
                  rows={2}
                  value={feature.description}
                  onChange={(e) =>
                    updateFeature(index, "description", e.target.value)
                  }
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div>
        <h2 className="text-xl font-heading font-semibold text-foreground mb-1">
          Bottom CTA
        </h2>
        <div className="space-y-4 bg-card border border-border rounded-lg p-6">
          <CmsImageUploadField
            label="CTA background image"
            preset="facultyCtaBackground"
            folder="cms/faculty-page/cta"
            storageFileName="background"
            value={ctaBackground}
            onChange={setCtaBackground}
          />
          <div className="space-y-2">
            <Label>Badge text</Label>
            <Input
              value={cta.badge}
              onChange={(e) => setCta({ ...cta, badge: e.target.value })}
            />
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Title (before highlight)</Label>
              <Input
                value={cta.title}
                onChange={(e) => setCta({ ...cta, title: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label>Title highlight (italic)</Label>
              <Input
                value={cta.titleHighlight}
                onChange={(e) =>
                  setCta({ ...cta, titleHighlight: e.target.value })
                }
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Subtitle</Label>
            <Textarea
              rows={3}
              value={cta.subtitle}
              onChange={(e) => setCta({ ...cta, subtitle: e.target.value })}
            />
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Primary button label</Label>
              <Input
                value={cta.primaryLabel}
                onChange={(e) =>
                  setCta({ ...cta, primaryLabel: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <Label>Primary button link</Label>
              <Input
                value={cta.primaryHref}
                onChange={(e) =>
                  setCta({ ...cta, primaryHref: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <Label>Secondary button label</Label>
              <Input
                value={cta.secondaryLabel}
                onChange={(e) =>
                  setCta({ ...cta, secondaryLabel: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <Label>Secondary button link</Label>
              <Input
                value={cta.secondaryHref}
                onChange={(e) =>
                  setCta({ ...cta, secondaryHref: e.target.value })
                }
              />
            </div>
          </div>
          <StringListField
            label="Trust indicators"
            values={trustIndicators}
            onChange={setTrustIndicators}
          />
        </div>
      </div>

      <Button onClick={() => void handleSave()} disabled={saving}>
        {saving ? "Saving…" : "Save page sections"}
      </Button>
    </section>
  );
}
