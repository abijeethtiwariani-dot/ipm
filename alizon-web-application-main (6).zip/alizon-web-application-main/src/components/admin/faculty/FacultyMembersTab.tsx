"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { FacultyMember } from "@/types/cms";
import { FACULTY_DESIGNATIONS } from "@/types/cms";
import {
  createFacultyMemberAdmin,
  deleteFacultyMemberAdmin,
  fetchFacultyMembersAdmin,
  updateFacultyMemberAdmin,
} from "@/lib/admin-cms-api";
import { apiFetchAdminPrograms } from "@/lib/admin-programs-api";
import type { Program } from "@/types/program";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import { StringListField } from "@/components/admin/faculty/StringListField";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { shouldUnoptimizeCmsSrc } from "@/lib/cms-image-url";

const memberSchema = z.object({
  name: z.string().min(1, "Name is required"),
  designation: z.string().min(1, "Designation is required"),
  department: z.string().min(1, "Department is required"),
  qualification: z.string().min(1, "Qualification is required"),
  specialization: z.string().min(1, "Specialization is required"),
  experience: z.coerce.number().min(0),
  email: z.string().email("Valid email required"),
  bio: z.string().min(10, "Bio must be at least 10 characters"),
  order: z.coerce.number().min(0),
  published: z.boolean(),
});

type MemberFormValues = z.infer<typeof memberSchema>;

export function FacultyMembersTab() {
  const [members, setMembers] = useState<FacultyMember[]>([]);
  const [programs, setPrograms] = useState<Program[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<FacultyMember | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<FacultyMember | null>(null);
  const [profileImage, setProfileImage] = useState<CmsImageUploadValue | null>(
    null,
  );
  const [programIds, setProgramIds] = useState<string[]>([]);
  const [expertise, setExpertise] = useState<string[]>([]);
  const [researchInterests, setResearchInterests] = useState<string[]>([]);
  const [publications, setPublications] = useState<string[]>([]);
  const [awards, setAwards] = useState<string[]>([]);

  const form = useForm<MemberFormValues>({
    resolver: zodResolver(memberSchema),
    defaultValues: {
      name: "",
      designation: "Professor",
      department: "",
      qualification: "",
      specialization: "",
      experience: 0,
      email: "",
      bio: "",
      order: 0,
      published: true,
    },
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [memberData, programData] = await Promise.all([
        fetchFacultyMembersAdmin(),
        apiFetchAdminPrograms(),
      ]);
      setMembers(memberData);
      setPrograms(programData.filter((p) => p.status === "active" || p.active));
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load faculty",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const openCreate = () => {
    setEditing(null);
    setProfileImage(null);
    setProgramIds([]);
    setExpertise([""]);
    setResearchInterests([""]);
    setPublications([""]);
    setAwards([""]);
    form.reset({
      name: "",
      designation: "Professor",
      department: "",
      qualification: "",
      specialization: "",
      experience: 0,
      email: "",
      bio: "",
      order: members.length > 0 ? Math.max(...members.map((m) => m.order)) + 1 : 0,
      published: true,
    });
    setDialogOpen(true);
  };

  const openEdit = (member: FacultyMember) => {
    setEditing(member);
    setProfileImage(member.imageUrl ? { url: member.imageUrl } : null);
    setProgramIds(member.programIds);
    setExpertise(member.expertise.length > 0 ? member.expertise : [""]);
    setResearchInterests(
      member.researchInterests.length > 0 ? member.researchInterests : [""],
    );
    setPublications(member.publications.length > 0 ? member.publications : [""]);
    setAwards(member.awards.length > 0 ? member.awards : [""]);
    form.reset({
      name: member.name,
      designation: member.designation,
      department: member.department,
      qualification: member.qualification,
      specialization: member.specialization,
      experience: member.experience,
      email: member.email,
      bio: member.bio,
      order: member.order,
      published: member.published,
    });
    setDialogOpen(true);
  };

  const toggleProgram = (id: string, checked: boolean) => {
    setProgramIds((prev) =>
      checked ? [...prev, id] : prev.filter((p) => p !== id),
    );
  };

  const filterList = (items: string[]) =>
    items.map((s) => s.trim()).filter(Boolean);

  const onSubmit = async (values: MemberFormValues) => {
    const imageUrl = profileImage?.url?.trim() ?? editing?.imageUrl ?? "";
    if (!imageUrl) {
      toast.error("Please upload a faculty profile photo");
      return;
    }
    if (programIds.length === 0) {
      toast.error("Select at least one program");
      return;
    }

    setSaving(true);
    try {
      const payload = {
        name: values.name.trim(),
        designation: values.designation,
        department: values.department.trim(),
        qualification: values.qualification.trim(),
        specialization: values.specialization.trim(),
        experience: values.experience,
        email: values.email.trim(),
        imageUrl,
        bio: values.bio.trim(),
        expertise: filterList(expertise),
        researchInterests: filterList(researchInterests),
        publications: filterList(publications),
        awards: filterList(awards),
        programIds,
        order: values.order,
        published: values.published,
      };

      if (editing) {
        await updateFacultyMemberAdmin(editing.id, payload);
        toast.success("Faculty member updated");
      } else {
        await createFacultyMemberAdmin(payload);
        toast.success("Faculty member created");
      }
      setDialogOpen(false);
      await load();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save faculty member",
      );
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteFacultyMemberAdmin(deleteTarget.id);
      toast.success("Faculty member deleted");
      setDeleteTarget(null);
      await load();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete",
      );
    }
  };

  return (
    <section>
      <header className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-xl font-heading font-semibold text-foreground">
            Faculty members
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            Directory cards and profile modal on the public page.
          </p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="w-4 h-4 mr-2" />
          Add faculty
        </Button>
      </header>

      <section className="bg-card rounded-lg border border-border shadow-sm overflow-hidden">
        {loading ? (
          <section className="p-8 space-y-3">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </section>
        ) : members.length === 0 ? (
          <p className="p-8 text-sm text-muted-foreground text-center">
            No faculty members yet. Click &quot;Add faculty&quot; to create one.
          </p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-14">Photo</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Designation</TableHead>
                <TableHead>Programs</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {members.map((member) => (
                <TableRow key={member.id}>
                  <TableCell>
                    {member.imageUrl ? (
                      <div className="relative w-10 h-12 rounded overflow-hidden border border-border">
                        <Image
                          src={member.imageUrl}
                          alt=""
                          fill
                          className="object-cover object-top"
                          sizes="40px"
                          unoptimized={shouldUnoptimizeCmsSrc(member.imageUrl)}
                        />
                      </div>
                    ) : (
                      <span className="text-xs text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell className="font-medium">{member.name}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {member.designation}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground max-w-[160px] truncate">
                    {member.programIds.length} program
                    {member.programIds.length !== 1 ? "s" : ""}
                  </TableCell>
                  <TableCell className="text-sm">
                    {member.published ? "Published" : "Draft"}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openEdit(member)}
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setDeleteTarget(member)}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </section>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editing ? "Edit faculty member" : "Add faculty member"}
            </DialogTitle>
          </DialogHeader>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="space-y-4"
          >
            <CmsImageUploadField
              label="Profile photo"
              preset="facultyProfile"
              folder={`cms/faculty-members/${editing?.id ?? "new"}`}
              storageFileName="profile"
              value={profileImage}
              onChange={setProfileImage}
              required
            />

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input id="name" {...form.register("name")} />
              </div>
              <div className="space-y-2">
                <Label>Designation</Label>
                <Select
                  value={form.watch("designation")}
                  onValueChange={(v) => form.setValue("designation", v)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {FACULTY_DESIGNATIONS.map((d) => (
                      <SelectItem key={d} value={d}>
                        {d}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="department">Department</Label>
                <Input id="department" {...form.register("department")} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" {...form.register("email")} />
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="qualification">Qualification</Label>
                <Input id="qualification" {...form.register("qualification")} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="specialization">Specialization</Label>
                <Input
                  id="specialization"
                  {...form.register("specialization")}
                />
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="experience">Experience (years)</Label>
                <Input
                  id="experience"
                  type="number"
                  min={0}
                  {...form.register("experience")}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="order">Display order</Label>
                <Input
                  id="order"
                  type="number"
                  min={0}
                  {...form.register("order")}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="bio">Biography</Label>
              <Textarea id="bio" rows={4} {...form.register("bio")} />
            </div>

            <StringListField
              label="Areas of expertise"
              values={expertise}
              onChange={setExpertise}
            />
            <StringListField
              label="Research interests"
              values={researchInterests}
              onChange={setResearchInterests}
            />
            <StringListField
              label="Publications"
              values={publications}
              onChange={setPublications}
            />
            <StringListField
              label="Awards & achievements"
              values={awards}
              onChange={setAwards}
            />

            <div className="space-y-2">
              <Label>Programs (public listing)</Label>
              <div className="rounded-md border border-border p-3 max-h-40 overflow-y-auto space-y-2">
                {programs.length === 0 ? (
                  <p className="text-sm text-muted-foreground">
                    No active programs. Add programs first.
                  </p>
                ) : (
                  programs.map((program) => (
                    <label
                      key={program.id}
                      className="flex items-center gap-2 text-sm cursor-pointer"
                    >
                      <Checkbox
                        checked={programIds.includes(program.id)}
                        onCheckedChange={(c) =>
                          toggleProgram(program.id, c === true)
                        }
                      />
                      {program.name}
                    </label>
                  ))
                )}
              </div>
            </div>

            <label className="flex items-center gap-2 text-sm">
              <Checkbox
                checked={form.watch("published")}
                onCheckedChange={(c) =>
                  form.setValue("published", c === true)
                }
              />
              Published on public page
            </label>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving}>
                {saving ? "Saving…" : editing ? "Update" : "Create"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={Boolean(deleteTarget)}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete faculty member?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove {deleteTarget?.name} from the public directory.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => void handleDelete()}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
