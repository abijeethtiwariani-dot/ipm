"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import type { NewsReportSignupContent } from "@/types/cms";
import {
  fetchNewsReportSignupContentAdmin,
  saveNewsReportSignupContentAdmin,
} from "@/lib/admin-cms-api";
import { NewsSectionBackLink } from "@/components/admin/NewsSectionBackLink";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  linkText: z.string().min(1, "Link text is required"),
  linkHref: z.string().min(1, "Link URL is required"),
});

type FormValues = z.infer<typeof formSchema>;

export function NewsReportSignupManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      linkText: "",
      linkHref: "",
    },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchNewsReportSignupContentAdmin();
      form.reset({
        title: data.title,
        description: data.description,
        linkText: data.linkText,
        linkHref: data.linkHref,
      });
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load content",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    try {
      const payload: Omit<NewsReportSignupContent, "updatedAt"> = {
        title: values.title.trim(),
        description: values.description.trim(),
        linkText: values.linkText.trim(),
        linkHref: values.linkHref.trim(),
      };

      await saveNewsReportSignupContentAdmin(payload);
      toast.success("Alizon Report section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-2xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-24 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-2xl">
      <NewsSectionBackLink />

      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Alizon Report
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Newsletter signup copy and link at the bottom of the news page.
        </p>
      </header>

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="title">Title</Label>
          <Input id="title" {...form.register("title")} />
          {form.formState.errors.title ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.title.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description</Label>
          <Textarea id="description" rows={4} {...form.register("description")} />
          {form.formState.errors.description ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.description.message}
            </p>
          ) : null}
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="linkText">Link text</Label>
            <Input id="linkText" {...form.register("linkText")} />
            {form.formState.errors.linkText ? (
              <p className="text-sm text-destructive">
                {form.formState.errors.linkText.message}
              </p>
            ) : null}
          </div>
          <div className="space-y-2">
            <Label htmlFor="linkHref">Link URL</Label>
            <Input id="linkHref" {...form.register("linkHref")} />
            {form.formState.errors.linkHref ? (
              <p className="text-sm text-destructive">
                {form.formState.errors.linkHref.message}
              </p>
            ) : null}
          </div>
        </div>

        <Button type="submit" disabled={saving}>
          {saving ? "Saving…" : "Save changes"}
        </Button>
      </form>
    </section>
  );
}
