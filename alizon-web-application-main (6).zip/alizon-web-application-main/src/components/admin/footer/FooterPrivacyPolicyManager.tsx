"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import {
  fetchFooterPrivacyPolicyAdmin,
  saveFooterPrivacyPolicyAdmin,
} from "@/lib/admin-cms-api";
import { HtmlPolicyEditor } from "@/components/admin/footer/HtmlPolicyEditor";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export function FooterPrivacyPolicyManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [htmlContent, setHtmlContent] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchFooterPrivacyPolicyAdmin();
      setHtmlContent(data.htmlContent ?? "");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load privacy policy.",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const onSave = async () => {
    if (saving) return;
    if (!htmlContent.trim()) {
      toast.error("Policy content cannot be empty.");
      return;
    }

    setSaving(true);
    try {
      await saveFooterPrivacyPolicyAdmin({ htmlContent: htmlContent.trim() });
      toast.success("Privacy policy saved.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to save.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mx-auto max-w-4xl space-y-8">
      <Link
        href="/admin/footer"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Footer
      </Link>

      <header>
        <h1 className="text-3xl font-heading font-bold">Privacy Policy</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Edit the public privacy policy page at /privacy. Use HTML for headings,
          lists, and styled content.
        </p>
      </header>

      {loading ? (
        <Skeleton className="h-80 w-full" />
      ) : (
        <section className="space-y-6 rounded-lg border border-border bg-card p-6 shadow-sm">
          <HtmlPolicyEditor
            id="footer-privacy-html"
            value={htmlContent}
            onChange={setHtmlContent}
          />
          <Button type="button" onClick={() => void onSave()} disabled={saving}>
            {saving ? "Saving..." : "Save Changes"}
          </Button>
        </section>
      )}
    </div>
  );
}
