"use client";

import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowLeft, ExternalLink, FileText, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  fetchFooterRefundPolicyAdmin,
  saveFooterRefundPolicyAdmin,
  uploadFooterRefundDocument,
} from "@/lib/admin-cms-api";
import { isValidDriveOrLinkUrl } from "@/lib/module-resource-utils";
import type { FooterRefundPolicyContent } from "@/types/cms";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Skeleton } from "@/components/ui/skeleton";

export function FooterRefundPolicyManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [sourceType, setSourceType] = useState<"document" | "url">("url");
  const [documentUrl, setDocumentUrl] = useState("");
  const [documentFileName, setDocumentFileName] = useState("");
  const [externalUrl, setExternalUrl] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchFooterRefundPolicyAdmin();
      setSourceType(data.sourceType);
      setDocumentUrl(data.documentUrl ?? "");
      setDocumentFileName(data.documentFileName ?? "");
      setExternalUrl(data.externalUrl ?? "");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load refund policy.",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const onUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;

    setUploading(true);
    try {
      const uploaded = await uploadFooterRefundDocument(file);
      setSourceType("document");
      setDocumentUrl(uploaded.url);
      setDocumentFileName(uploaded.fileName);
      toast.success("Document uploaded. Save to publish.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Upload failed.");
    } finally {
      setUploading(false);
    }
  };

  const onSave = async () => {
    if (saving) return;

    if (sourceType === "url") {
      const trimmed = externalUrl.trim();
      if (trimmed && !isValidDriveOrLinkUrl(trimmed)) {
        toast.error("Enter a valid http or https URL.");
        return;
      }
    } else if (!documentUrl.trim()) {
      toast.error("Upload a document or switch to External URL.");
      return;
    }

    setSaving(true);
    try {
      const payload: Omit<FooterRefundPolicyContent, "updatedAt"> = {
        sourceType,
        documentUrl: sourceType === "document" ? documentUrl.trim() : "",
        documentFileName: sourceType === "document" ? documentFileName.trim() : "",
        externalUrl: sourceType === "url" ? externalUrl.trim() : "",
      };
      await saveFooterRefundPolicyAdmin(payload);
      toast.success("Refund policy saved.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to save.");
    } finally {
      setSaving(false);
    }
  };

  const onClear = async () => {
    if (saving) return;
    setSaving(true);
    try {
      await saveFooterRefundPolicyAdmin({
        sourceType: "url",
        documentUrl: "",
        documentFileName: "",
        externalUrl: "",
      });
      setSourceType("url");
      setDocumentUrl("");
      setDocumentFileName("");
      setExternalUrl("");
      toast.success("Refund policy cleared.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to clear.");
    } finally {
      setSaving(false);
    }
  };

  const activeHref =
    sourceType === "document" ? documentUrl.trim() : externalUrl.trim();

  return (
    <div className="mx-auto max-w-3xl space-y-8">
      <Link
        href="/admin/footer"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to Footer
      </Link>

      <header>
        <h1 className="text-3xl font-heading font-bold">Refund Policy</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Upload a policy document or link to Google Drive. The footer Refund Policy
          link opens this URL in a new tab.
        </p>
      </header>

      {loading ? (
        <div className="space-y-4">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-32 w-full" />
        </div>
      ) : (
        <section className="space-y-6 rounded-lg border border-border bg-card p-6 shadow-sm">
          <RadioGroup
            value={sourceType}
            onValueChange={(value) => setSourceType(value as "document" | "url")}
            className="space-y-3"
          >
            <div className="flex items-center gap-2">
              <RadioGroupItem value="document" id="refund-source-document" />
              <Label htmlFor="refund-source-document">Upload document</Label>
            </div>
            <div className="flex items-center gap-2">
              <RadioGroupItem value="url" id="refund-source-url" />
              <Label htmlFor="refund-source-url">External URL (Google Drive, etc.)</Label>
            </div>
          </RadioGroup>

          {sourceType === "document" ? (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Policy document (PDF, DOC, DOCX — max 10 MB)</Label>
                <div className="flex flex-wrap items-center gap-3">
                  <Button
                    type="button"
                    variant="outline"
                    disabled={uploading}
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <FileText className="mr-2 h-4 w-4" />
                    {uploading ? "Uploading..." : "Choose file"}
                  </Button>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf,.doc,.docx"
                    className="hidden"
                    onChange={(e) => void onUpload(e)}
                  />
                  {documentFileName ? (
                    <span className="text-sm text-muted-foreground">
                      {documentFileName}
                    </span>
                  ) : null}
                </div>
              </div>
              {documentUrl ? (
                <a
                  href={documentUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-sm text-primary hover:underline"
                >
                  View uploaded document
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              ) : null}
            </div>
          ) : (
            <div className="space-y-2">
              <Label htmlFor="refund-external-url">Policy URL</Label>
              <Input
                id="refund-external-url"
                value={externalUrl}
                onChange={(e) => setExternalUrl(e.target.value)}
                placeholder="https://drive.google.com/..."
              />
              {externalUrl.trim() && isValidDriveOrLinkUrl(externalUrl.trim()) ? (
                <a
                  href={externalUrl.trim()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-sm text-primary hover:underline"
                >
                  Preview link
                  <ExternalLink className="h-3.5 w-3.5" />
                </a>
              ) : null}
            </div>
          )}

          <div className="flex flex-wrap gap-3 pt-2">
            <Button type="button" onClick={() => void onSave()} disabled={saving}>
              {saving ? "Saving..." : "Save Changes"}
            </Button>
            {activeHref ? (
              <Button
                type="button"
                variant="outline"
                onClick={() => void onClear()}
                disabled={saving}
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Clear policy
              </Button>
            ) : null}
          </div>
        </section>
      )}
    </div>
  );
}
