"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  arrayMove,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { GripVertical, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { FooterLinkItem, FooterLinkItemInput } from "@/types/cms";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const linkFormSchema = z.object({
  title: z.string().min(1, "Link title is required"),
  url: z.string().min(1, "URL is required"),
  displayOrder: z.coerce.number().int().min(1, "Order must be at least 1"),
  isActive: z.boolean(),
});

type LinkFormValues = z.infer<typeof linkFormSchema>;

export type FooterLinksSectionProps = {
  title: string;
  description: string;
  fetchLinks: () => Promise<FooterLinkItem[]>;
  createLink: (payload: FooterLinkItemInput) => Promise<void>;
  updateLink: (id: string, payload: Partial<FooterLinkItemInput>) => Promise<void>;
  deleteLink: (id: string) => Promise<void>;
  reorderLinks: (orderedIds: string[]) => Promise<void>;
};

function getNextDisplayOrder(items: FooterLinkItem[]): number {
  if (items.length === 0) return 1;
  return Math.max(...items.map((item) => item.displayOrder ?? 0)) + 1;
}

function SortableLinkRow({
  item,
  onEdit,
  onDelete,
  dragDisabled,
}: {
  item: FooterLinkItem;
  onEdit: (item: FooterLinkItem) => void;
  onDelete: (item: FooterLinkItem) => void;
  dragDisabled?: boolean;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } =
    useSortable({ id: item.id, disabled: dragDisabled });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <TableRow ref={setNodeRef} style={style}>
      <TableCell className="w-10">
        <button
          type="button"
          className={`touch-none rounded p-1 text-muted-foreground ${
            dragDisabled
              ? "cursor-not-allowed opacity-40"
              : "cursor-grab hover:text-foreground active:cursor-grabbing"
          }`}
          aria-label={`Reorder ${item.title}`}
          disabled={dragDisabled}
          {...(dragDisabled ? {} : { ...attributes, ...listeners })}
        >
          <GripVertical className="h-4 w-4" />
        </button>
      </TableCell>
      <TableCell className="font-medium">{item.title}</TableCell>
      <TableCell className="max-w-[200px] truncate text-muted-foreground">
        {item.url}
      </TableCell>
      <TableCell>{item.displayOrder}</TableCell>
      <TableCell>
        <Badge variant={item.isActive ? "default" : "secondary"}>
          {item.isActive ? "Active" : "Inactive"}
        </Badge>
      </TableCell>
      <TableCell className="text-right">
        <div className="flex justify-end gap-1">
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={() => onEdit(item)}
            aria-label={`Edit ${item.title}`}
          >
            <Pencil className="h-4 w-4" />
          </Button>
          <Button
            type="button"
            variant="ghost"
            size="icon"
            onClick={() => onDelete(item)}
            aria-label={`Delete ${item.title}`}
          >
            <Trash2 className="h-4 w-4 text-destructive" />
          </Button>
        </div>
      </TableCell>
    </TableRow>
  );
}

export function FooterLinksSection({
  title,
  description,
  fetchLinks,
  createLink,
  updateLink,
  deleteLink,
  reorderLinks,
}: FooterLinksSectionProps) {
  const [items, setItems] = useState<FooterLinkItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [reordering, setReordering] = useState(false);
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<FooterLinkItem | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<FooterLinkItem | null>(null);

  const form = useForm<LinkFormValues>({
    resolver: zodResolver(linkFormSchema),
    defaultValues: {
      title: "",
      url: "/",
      displayOrder: 1,
      isActive: true,
    },
  });

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    }),
  );

  const loadItems = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchLinks();
      setItems(
        [...data].sort((a, b) => a.displayOrder - b.displayOrder),
      );
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : `Failed to load ${title}`,
      );
    } finally {
      setLoading(false);
    }
  }, [fetchLinks, title]);

  useEffect(() => {
    void loadItems();
  }, [loadItems]);

  const isSearchActive = search.trim().length > 0;

  const filteredItems = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return items;
    return items.filter(
      (item) =>
        item.title.toLowerCase().includes(q) ||
        item.url.toLowerCase().includes(q),
    );
  }, [items, search]);

  const openCreate = () => {
    setEditingItem(null);
    form.reset({
      title: "",
      url: "/",
      displayOrder: getNextDisplayOrder(items),
      isActive: true,
    });
    setDialogOpen(true);
  };

  const openEdit = (item: FooterLinkItem) => {
    setEditingItem(item);
    form.reset({
      title: item.title,
      url: item.url,
      displayOrder: item.displayOrder,
      isActive: item.isActive,
    });
    setDialogOpen(true);
  };

  const onSubmit = form.handleSubmit(async (values) => {
    if (saving) return;
    setSaving(true);
    try {
      const payload: FooterLinkItemInput = {
        title: values.title,
        url: values.url,
        displayOrder: values.displayOrder,
        isActive: values.isActive,
      };
      if (editingItem) {
        await updateLink(editingItem.id, payload);
        toast.success("Link updated.");
      } else {
        await createLink(payload);
        toast.success("Link created.");
      }
      setDialogOpen(false);
      await loadItems();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Save failed.");
    } finally {
      setSaving(false);
    }
  });

  const onDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteLink(deleteTarget.id);
      toast.success("Link deleted.");
      setDeleteTarget(null);
      await loadItems();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Delete failed.");
    }
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;

    const oldIndex = items.findIndex((item) => item.id === active.id);
    const newIndex = items.findIndex((item) => item.id === over.id);
    if (oldIndex < 0 || newIndex < 0) return;

    const reordered = arrayMove(items, oldIndex, newIndex).map((item, index) => ({
      ...item,
      displayOrder: index + 1,
    }));

    setItems(reordered);
    setReordering(true);
    try {
      await reorderLinks(reordered.map((item) => item.id));
      toast.success("Link order updated.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Reorder failed.");
      await loadItems();
    } finally {
      setReordering(false);
    }
  };

  return (
    <section className="bg-card rounded-lg border border-border shadow-sm p-6 space-y-4">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h2 className="text-xl font-heading font-semibold">{title}</h2>
          <p className="text-sm text-muted-foreground mt-1">{description}</p>
        </div>
        <Button type="button" onClick={openCreate} className="shrink-0">
          <Plus className="h-4 w-4 mr-2" />
          Add Link
        </Button>
      </div>

      <div className="space-y-1">
        <Input
          placeholder="Search links by title or URL..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-sm"
        />
        {isSearchActive && (
          <p className="text-xs text-muted-foreground">
            Clear search to reorder links via drag and drop.
          </p>
        )}
      </div>

      {loading ? (
        <div className="space-y-2">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
        </div>
      ) : filteredItems.length === 0 ? (
        <p className="text-sm text-muted-foreground py-4">
          {search.trim() ? "No links match your search." : "No links yet. Add your first link."}
        </p>
      ) : (
        <DndContext
          sensors={sensors}
          collisionDetection={closestCenter}
          onDragEnd={(event) => void handleDragEnd(event)}
        >
          <div className="rounded-md border overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-10" />
                  <TableHead>Title</TableHead>
                  <TableHead>URL</TableHead>
                  <TableHead>Order</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <SortableContext
                  items={filteredItems.map((item) => item.id)}
                  strategy={verticalListSortingStrategy}
                >
                  {filteredItems.map((item) => (
                    <SortableLinkRow
                      key={item.id}
                      item={item}
                      onEdit={openEdit}
                      onDelete={setDeleteTarget}
                      dragDisabled={isSearchActive}
                    />
                  ))}
                </SortableContext>
              </TableBody>
            </Table>
          </div>
        </DndContext>
      )}

      {reordering && (
        <p className="text-xs text-muted-foreground">Saving new order...</p>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingItem ? "Edit Link" : "Add Link"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor={`${title}-link-title`}>Link Title</Label>
              <Input id={`${title}-link-title`} {...form.register("title")} />
              {form.formState.errors.title && (
                <p className="text-sm text-destructive">
                  {form.formState.errors.title.message}
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor={`${title}-link-url`}>Link URL / Route</Label>
              <Input id={`${title}-link-url`} {...form.register("url")} />
              {form.formState.errors.url && (
                <p className="text-sm text-destructive">
                  {form.formState.errors.url.message}
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor={`${title}-link-order`}>Display Order</Label>
              <Input
                id={`${title}-link-order`}
                type="number"
                min={1}
                {...form.register("displayOrder")}
              />
              {form.formState.errors.displayOrder && (
                <p className="text-sm text-destructive">
                  {form.formState.errors.displayOrder.message}
                </p>
              )}
            </div>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <Label htmlFor={`${title}-link-active`}>Active</Label>
                <p className="text-xs text-muted-foreground">
                  Inactive links are hidden on the public footer.
                </p>
              </div>
              <Switch
                id={`${title}-link-active`}
                checked={form.watch("isActive")}
                onCheckedChange={(checked) => form.setValue("isActive", checked)}
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={saving}>
                {saving ? "Saving..." : editingItem ? "Update Link" : "Add Link"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={deleteTarget !== null}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete link?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove &quot;{deleteTarget?.title}&quot; from the footer.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => void onDelete()}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
