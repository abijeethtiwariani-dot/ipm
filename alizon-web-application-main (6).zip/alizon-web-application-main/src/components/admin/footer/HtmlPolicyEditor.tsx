"use client";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

type HtmlPolicyEditorProps = {
  id?: string;
  value: string;
  onChange: (value: string) => void;
  rows?: number;
};

export function HtmlPolicyEditor({
  id = "policy-html",
  value,
  onChange,
  rows = 18,
}: HtmlPolicyEditorProps) {
  return (
    <Tabs defaultValue="edit" className="w-full">
      <TabsList>
        <TabsTrigger value="edit">Edit</TabsTrigger>
        <TabsTrigger value="preview">Preview</TabsTrigger>
      </TabsList>
      <TabsContent value="edit" className="mt-4 space-y-2">
        <Label htmlFor={id}>HTML content</Label>
        <Textarea
          id={id}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          rows={rows}
          className="font-mono text-sm"
          placeholder="<h2>Section title</h2><p>Policy text...</p>"
        />
        <p className="text-xs text-muted-foreground">
          Paste HTML directly. Use the Preview tab to check formatting before saving.
        </p>
      </TabsContent>
      <TabsContent value="preview" className="mt-4">
        <div className="min-h-[280px] rounded-lg border border-border bg-background p-6">
          {value.trim() ? (
            <div
              className="prose prose-neutral max-w-none dark:prose-invert"
              dangerouslySetInnerHTML={{ __html: value }}
            />
          ) : (
            <p className="text-sm text-muted-foreground">Nothing to preview yet.</p>
          )}
        </div>
      </TabsContent>
    </Tabs>
  );
}
