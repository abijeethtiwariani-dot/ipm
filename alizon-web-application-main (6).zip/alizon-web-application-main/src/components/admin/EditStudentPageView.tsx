"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { apiFetchStudent } from "@/lib/admin-students-api";
import type { Student } from "@/types/student";
import { StudentEditForm } from "@/components/admin/StudentEditForm";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export function EditStudentPageView({ studentId }: { studentId: string }) {
  const [student, setStudent] = useState<Student | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    void apiFetchStudent(studentId)
      .then((data) => {
        if (!active) return;
        setStudent(data);
        setLoading(false);
        if (!data) setError("Student not found.");
      })
      .catch((loadError) => {
        if (!active) return;
        setError(loadError instanceof Error ? loadError.message : "Failed to load student.");
        setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [studentId]);

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-64 w-full max-w-lg" />
      </div>
    );
  }

  if (error || !student) {
    return (
      <div className="rounded-xl border border-destructive/30 bg-destructive/5 p-6 text-sm text-destructive">
        {error ?? "Student not found."}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" asChild>
          <Link href={`/admin/students/${studentId}`}>
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <h1 className="text-2xl font-heading font-bold">Edit Student</h1>
      </div>
      <p className="text-sm text-muted-foreground">
        {student.name} — {student.registrationId}
      </p>
      <div className="max-w-lg">
        <StudentEditForm
          student={student}
          redirectTo={`/admin/students/${studentId}`}
          showCancel
          cancelHref={`/admin/students/${studentId}`}
        />
      </div>
    </div>
  );
}
