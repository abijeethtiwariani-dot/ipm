"use client";

import { useCallback, useRef, useState } from "react";
import Image from "next/image";
import { Loader2, UploadCloud, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";
import {
  formatMaxFileSize,
  getCmsImagePresetConfig,
  type CmsImagePreset,
} from "@/lib/cms-image-presets";
import { uploadCmsImage } from "@/lib/admin-cms-api";
import type { OptimizedImageSet } from "@/types/program";

export type CmsImageUploadValue = {
  url: string;
  image?: OptimizedImageSet | null;
};

type FileMeta = {
  width: number;
  height: number;
  format: string;
  fileSize: number;
};

type UploadMeta = FileMeta & {
  optimizedFormat: string;
};

function formatFileSize(bytes: number): string {
  if (bytes >= 1024 * 1024) {
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  }
  return `${Math.round(bytes / 1024)} KB`;
}

function formatFromFile(file: File): string {
  const ext = file.name.split(".").pop()?.toUpperCase();
  if (ext) return ext;
  return file.type.replace("image/", "").toUpperCase() || "Unknown";
}

async function readFileDimensions(file: File): Promise<FileMeta> {
  if (typeof createImageBitmap === "function") {
    const bitmap = await createImageBitmap(file);
    const meta = {
      width: bitmap.width,
      height: bitmap.height,
      format: formatFromFile(file),
      fileSize: file.size,
    };
    bitmap.close();
    return meta;
  }
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new window.Image();
    img.onload = () => {
      resolve({
        width: img.naturalWidth,
        height: img.naturalHeight,
        format: formatFromFile(file),
        fileSize: file.size,
      });
      URL.revokeObjectURL(url);
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error("Could not read image dimensions."));
    };
    img.src = url;
  });
}

interface CmsImageUploadFieldProps {
  label: string;
  preset: CmsImagePreset;
  folder: string;
  storageFileName: string;
  value?: CmsImageUploadValue | null;
  onChange: (value: CmsImageUploadValue | null) => void;
  /** Local blob preview before upload completes */
  pendingPreviewUrl?: string | null;
  onPendingPreviewChange?: (url: string | null) => void;
  required?: boolean;
  className?: string;
}

export function CmsImageUploadField({
  label,
  preset,
  folder,
  storageFileName,
  value,
  onChange,
  pendingPreviewUrl,
  onPendingPreviewChange,
  required = false,
  className,
}: CmsImageUploadFieldProps) {
  const config = getCmsImagePresetConfig(preset);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [fileMeta, setFileMeta] = useState<FileMeta | null>(null);
  const [uploadMeta, setUploadMeta] = useState<UploadMeta | null>(null);

  const displayUrl =
    pendingPreviewUrl ?? value?.url ?? value?.image?.largeUrl ?? null;

  const handlePick = useCallback(
    async (file?: File) => {
      if (!file) return;
      setLoading(true);
      setProgress(15);
      try {
        const meta = await readFileDimensions(file);
        setFileMeta(meta);
        const blobUrl = URL.createObjectURL(file);
        onPendingPreviewChange?.(blobUrl);
        setProgress(40);

        const storagePath = `${folder}/${storageFileName}`;
        const result = await uploadCmsImage(storagePath, file, { preset });
        setProgress(90);
        onChange({ url: result.primaryUrl, image: result.image });
        setUploadMeta({
          ...meta,
          optimizedFormat: "WEBP",
        });
        onPendingPreviewChange?.(null);
        setProgress(100);
        toast.success(`${label} uploaded.`);
      } catch (error) {
        const message =
          error instanceof Error ? error.message : "Upload failed.";
        toast.error(message);
        onPendingPreviewChange?.(null);
        setFileMeta(null);
        setUploadMeta(null);
      } finally {
        setLoading(false);
        setTimeout(() => setProgress(0), 400);
      }
    },
    [folder, label, onChange, onPendingPreviewChange, preset, storageFileName],
  );

  const handleRemove = () => {
    onChange(null);
    setFileMeta(null);
    setUploadMeta(null);
    onPendingPreviewChange?.(null);
    if (inputRef.current) inputRef.current.value = "";
  };

  const meta = uploadMeta ?? fileMeta;

  return (
    <div className={cn("space-y-2", className)}>
      <div className="text-sm font-medium">
        {label}
        {required ? <span className="text-destructive ml-1">*</span> : null}
      </div>

      <p className="text-xs text-muted-foreground">
        Recommended size: {config.recommendedSizeLabel}
      </p>
      <p className="text-xs text-muted-foreground">
        Supported formats: {config.supportedFormatsLabel} · Max file size:{" "}
        {formatMaxFileSize(config.maxBytes)}
      </p>

      {displayUrl ? (
        <div
          className={cn(
            "relative w-full max-w-xl overflow-hidden rounded-md border border-border bg-muted",
            config.adminPreviewAspectClass,
          )}
        >
          <Image
            src={displayUrl}
            alt={`${label} preview`}
            fill
            className="object-cover"
            unoptimized={displayUrl.startsWith("blob:")}
          />
        </div>
      ) : null}

      {value?.url && !pendingPreviewUrl ? (
        <p className="text-xs text-muted-foreground truncate max-w-xl">
          Current image saved
        </p>
      ) : null}

      <div className="flex flex-wrap gap-2">
        <Button
          type="button"
          variant="outline"
          size="sm"
          disabled={loading}
          onClick={() => inputRef.current?.click()}
        >
          {loading ? (
            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
          ) : (
            <UploadCloud className="h-4 w-4 mr-2" />
          )}
          {value?.url || pendingPreviewUrl ? "Replace image" : "Upload image"}
        </Button>
        {(value?.url || pendingPreviewUrl) && !loading ? (
          <Button type="button" variant="ghost" size="sm" onClick={handleRemove}>
            <X className="h-4 w-4 mr-1" />
            Remove
          </Button>
        ) : null}
      </div>

      {progress > 0 ? <Progress value={progress} className="h-2 max-w-xl" /> : null}

      {meta ? (
        <div className="rounded-md border border-border bg-muted/30 p-3 text-xs space-y-1 max-w-xl">
          <p className="font-medium text-foreground">Image details</p>
          <p>
            Resolution: {meta.width} × {meta.height}
          </p>
          <p>Format: {meta.format}</p>
          <p>File size: {formatFileSize(meta.fileSize)}</p>
          {uploadMeta ? (
            <p>Optimized output: {uploadMeta.optimizedFormat}</p>
          ) : null}
        </div>
      ) : null}

      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp,image/avif,.jpg,.jpeg,.png,.webp,.avif"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          void handlePick(file);
          e.target.value = "";
        }}
      />
    </div>
  );
}

/** Dual desktop + mobile hero uploads with side-by-side previews */
interface CmsHeroImagePairFieldProps {
  desktop: CmsImageUploadValue | null;
  mobile: CmsImageUploadValue | null;
  onDesktopChange: (value: CmsImageUploadValue | null) => void;
  onMobileChange: (value: CmsImageUploadValue | null) => void;
  folder: string;
  fileBaseName: string;
  desktopPendingPreview?: string | null;
  mobilePendingPreview?: string | null;
  onDesktopPendingPreviewChange?: (url: string | null) => void;
  onMobilePendingPreviewChange?: (url: string | null) => void;
}

export function CmsHeroImagePairField({
  desktop,
  mobile,
  onDesktopChange,
  onMobileChange,
  folder,
  fileBaseName,
  desktopPendingPreview,
  mobilePendingPreview,
  onDesktopPendingPreviewChange,
  onMobilePendingPreviewChange,
}: CmsHeroImagePairFieldProps) {
  return (
    <div className="space-y-6">
      <div className="grid gap-6 lg:grid-cols-2">
        <CmsImageUploadField
          label="Desktop banner image"
          preset="heroDesktop"
          folder={folder}
          storageFileName={`${fileBaseName}-desktop`}
          value={desktop}
          onChange={onDesktopChange}
          pendingPreviewUrl={desktopPendingPreview}
          onPendingPreviewChange={onDesktopPendingPreviewChange}
          required
        />
        <CmsImageUploadField
          label="Mobile banner image"
          preset="heroMobile"
          folder={folder}
          storageFileName={`${fileBaseName}-mobile`}
          value={mobile}
          onChange={onMobileChange}
          pendingPreviewUrl={mobilePendingPreview}
          onPendingPreviewChange={onMobilePendingPreviewChange}
        />
      </div>
      <p className="text-xs text-muted-foreground max-w-3xl">
        Tablet and desktop use the desktop banner. On phones, the mobile banner is
        used when uploaded; otherwise the desktop image is shown.
      </p>
      {(desktop?.url ||
        mobile?.url ||
        desktopPendingPreview ||
        mobilePendingPreview) && (
        <div className="space-y-2">
          <p className="text-sm font-medium">Preview before saving</p>
          <div className="grid gap-4 md:grid-cols-2 max-w-4xl">
            <div>
              <p className="text-xs text-muted-foreground mb-1">Desktop preview</p>
              <div className="relative aspect-[21/9] w-full overflow-hidden rounded-md border bg-muted">
                {(desktopPendingPreview ?? desktop?.url) ? (
                  <Image
                    src={desktopPendingPreview ?? desktop!.url}
                    alt="Desktop preview"
                    fill
                    className="object-cover"
                    unoptimized={
                      (desktopPendingPreview ?? desktop!.url).startsWith("blob:")
                    }
                  />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center text-xs text-muted-foreground">
                    No desktop image
                  </div>
                )}
              </div>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">Mobile preview</p>
              <div className="relative aspect-[9/16] max-h-80 w-full max-w-[200px] overflow-hidden rounded-md border bg-muted mx-auto md:mx-0">
                {(mobilePendingPreview ?? mobile?.url ?? desktopPendingPreview ?? desktop?.url) ? (
                  <Image
                    src={
                      mobilePendingPreview ??
                      mobile?.url ??
                      desktopPendingPreview ??
                      desktop!.url
                    }
                    alt="Mobile preview"
                    fill
                    className="object-cover"
                    unoptimized={(
                      mobilePendingPreview ??
                      mobile?.url ??
                      desktopPendingPreview ??
                      desktop!.url
                    ).startsWith("blob:")}
                  />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center text-xs text-muted-foreground px-2 text-center">
                    No image
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
