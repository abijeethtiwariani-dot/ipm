"use client";

import Link from "next/link";
import { ChevronRight, ClipboardList, FolderOpen, Plus, Sparkles, Trophy } from "lucide-react";
import { Card } from "@/components/ui/card";

const sections = [
  {
    title: "Hero",
    description: "Page banner title, subtitle, and hero image.",
    href: "/admin/allotment/hero",
    icon: Sparkles,
  },
  {
    title: "All Allotments",
    description: "Search, filter, export, and manage program allotment announcements.",
    href: "/admin/allotment/list",
    icon: ClipboardList,
  },
  {
    title: "Results",
    description: "Manage published allotment result lists with documents and Google Drive links.",
    href: "/admin/allotment/results",
    icon: Trophy,
  },
  {
    title: "Categories",
    description: "Manage allotment categories such as undergraduate and postgraduate programs.",
    href: "/admin/allotment/categories",
    icon: FolderOpen,
  },
  {
    title: "Create Allotment",
    description: "Publish a new allotment notice with documents and optional Google Drive link.",
    href: "/admin/allotment/new",
    icon: Plus,
  },
];

export function AllotmentContentHub() {
  return (
    <section>
      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold">Allotment</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Manage program allotments, categories, and published seat allocation notices.
        </p>
      </header>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {sections.map((section) => (
          <Link key={section.href} href={section.href}>
            <Card className="group h-full border p-6 transition-shadow hover:shadow-md">
              <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <section.icon className="h-5 w-5" />
              </div>
              <h2 className="text-lg font-semibold group-hover:text-primary">
                {section.title}
              </h2>
              <p className="mt-2 text-sm text-muted-foreground">{section.description}</p>
              <span className="mt-4 inline-flex items-center text-sm font-medium text-primary">
                Open
                <ChevronRight className="ml-1 h-4 w-4" />
              </span>
            </Card>
          </Link>
        ))}
      </div>
    </section>
  );
}
