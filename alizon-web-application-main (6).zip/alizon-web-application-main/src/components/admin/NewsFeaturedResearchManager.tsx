"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format, parseISO } from "date-fns";
import { CalendarIcon, Pencil, Plus, Star, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { NewsCard, HomeNewsSectionContent } from "@/types/cms";
import {
  createNewsCard,
  deleteNewsCard,
  fetchHomeNewsSectionContentAdmin,
  fetchNewsCards,
  saveHomeNewsSectionContentAdmin,
  updateNewsCard,
  uploadCmsImageUrl,
  validateFeaturedLimit,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { formatNewsPublishedDate } from "@/lib/news-utils";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { NewsSectionBackLink } from "@/components/admin/NewsSectionBackLink";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const newsFormSchema = z.object({
  title: z.string().min(3, "Title must be at least 3 characters"),
  content: z.string().min(10, "Content must be at least 10 characters"),
  subContent: z
    .string()
    .min(1, "Sub content is required")
    .max(300, "Sub content must be 300 characters or less"),
  imageUrl: z.string().optional(),
  category: z.string().max(40, "Category must be 40 characters or less").optional(),
  featured: z.boolean(),
});

type NewsFormValues = z.infer<typeof newsFormSchema>;

const sectionFormSchema = z.object({
  sectionHeading: z.string().min(1, "Section heading is required"),
  sectionSubContent: z.string().min(1, "Section subheading is required"),
  buttonText: z.string().min(1, "Button text is required"),
  buttonLink: z.string().min(1, "Button link is required"),
});

type SectionFormValues = z.infer<typeof sectionFormSchema>;

function formatPublishedDateForTable(publishedDate: string): string {
  return formatNewsPublishedDate(publishedDate) ?? "—";
}

export function NewsFeaturedResearchManager() {
  const [cards, setCards] = useState<NewsCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingSection, setLoadingSection] = useState(true);
  const [saving, setSaving] = useState(false);
  const [savingSection, setSavingSection] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingCard, setEditingCard] = useState<NewsCard | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<NewsCard | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [panelImage, setPanelImage] = useState<CmsImageUploadValue | null>(null);
  const [panelImagePendingPreview, setPanelImagePendingPreview] = useState<
    string | null
  >(null);
  const [panelImageAlt, setPanelImageAlt] = useState("");
  const [publishedDate, setPublishedDate] = useState<Date | undefined>(undefined);
  const [datePickerOpen, setDatePickerOpen] = useState(false);

  const form = useForm<NewsFormValues>({
    resolver: zodResolver(newsFormSchema),
    defaultValues: {
      title: "",
      content: "",
      subContent: "",
      imageUrl: "",
      category: "",
      featured: false,
    },
  });

  const sectionForm = useForm<SectionFormValues>({
    resolver: zodResolver(sectionFormSchema),
    defaultValues: {
      sectionHeading: "",
      sectionSubContent: "",
      buttonText: "",
      buttonLink: "/news",
    },
  });

  const subContent = form.watch("subContent") ?? "";
  const featured = form.watch("featured");
  const subContentOverLimit = subContent.length > 300;

  const loadCards = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchNewsCards();
      setCards(data);
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to load news";
      toast.error(message);
    } finally {
      setLoading(false);
    }
  }, []);

  const loadSection = useCallback(async () => {
    setLoadingSection(true);
    try {
      const data = await fetchHomeNewsSectionContentAdmin();
      sectionForm.reset({
        sectionHeading: data.sectionHeading,
        sectionSubContent: data.sectionSubContent,
        buttonText: data.buttonText,
        buttonLink: data.buttonLink,
      });
      setPanelImage(data.panelImageUrl ? { url: data.panelImageUrl } : null);
      setPanelImageAlt(data.panelImageAlt ?? "");
      setPanelImagePendingPreview(null);
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "Failed to load homepage section settings";
      toast.error(message);
    } finally {
      setLoadingSection(false);
    }
  }, [sectionForm]);

  useEffect(() => {
    loadCards();
    void loadSection();
  }, [loadCards, loadSection]);

  const onSaveSection = async (values: SectionFormValues) => {
    setSavingSection(true);
    try {
      const payload: Omit<HomeNewsSectionContent, "updatedAt"> = {
        sectionHeading: values.sectionHeading.trim(),
        sectionSubContent: values.sectionSubContent.trim(),
        buttonText: values.buttonText.trim(),
        buttonLink: values.buttonLink.trim(),
        panelImageUrl: panelImage?.url?.trim() ?? "",
        panelImageAlt: panelImageAlt.trim(),
      };
      await saveHomeNewsSectionContentAdmin(payload);
      toast.success("Homepage section settings saved");
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "Failed to save homepage section settings";
      toast.error(message);
    } finally {
      setSavingSection(false);
    }
  };

  const openCreate = () => {
    setEditingCard(null);
    setImageFile(null);
    setImagePreview(null);
    setPublishedDate(new Date());
    form.reset({
      title: "",
      content: "",
      subContent: "",
      imageUrl: "",
      category: "",
      featured: false,
    });
    setDialogOpen(true);
  };

  const openEdit = (card: NewsCard) => {
    setEditingCard(card);
    setImageFile(null);
    setImagePreview(card.imageUrl || null);
    try {
      setPublishedDate(
        card.publishedDate ? parseISO(card.publishedDate) : undefined,
      );
    } catch {
      setPublishedDate(undefined);
    }
    form.reset({
      title: card.title,
      content: card.content,
      subContent: card.subContent,
      imageUrl: card.imageUrl,
      category: card.category ?? "",
      featured: card.featured,
    });
    setDialogOpen(true);
  };

  const onSubmit = async (values: NewsFormValues) => {
    if (subContentOverLimit) return;

    if (!publishedDate) {
      toast.error("Please select a publish date");
      return;
    }

    const needsImage = !editingCard?.imageUrl && !imageFile;
    if (needsImage) {
      toast.error("Please upload an image");
      return;
    }

    const featuredCheck = await validateFeaturedLimit(
      values.featured,
      editingCard?.id,
    );
    if (!featuredCheck.ok) {
      toast.error(featuredCheck.message);
      return;
    }

    setSaving(true);
    try {
      let imageUrl = values.imageUrl ?? editingCard?.imageUrl ?? "";

      if (imageFile) {
        const cardId = editingCard?.id ?? `new-${Date.now()}`;
        imageUrl = await uploadCmsImageUrl(
          `cms/news/${cardId}/${imageFile.name}`,
          imageFile,
        );
      }

      const payload = {
        title: values.title,
        content: values.content,
        subContent: values.subContent,
        imageUrl,
        category: values.category?.trim() ?? "",
        publishedDate: format(publishedDate, "yyyy-MM-dd"),
        featured: values.featured,
      };

      if (editingCard) {
        await updateNewsCard(editingCard.id, payload);
        toast.success("News updated");
      } else {
        const nextOrder =
          cards.length > 0 ? Math.max(...cards.map((c) => c.order)) + 1 : 0;
        await createNewsCard({ ...payload, order: nextOrder });
        toast.success("News created");
      }

      setDialogOpen(false);
      await loadCards();
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to save news";
      toast.error(message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteNewsCard(deleteTarget.id);
      toast.success("News deleted");
      setDeleteTarget(null);
      await loadCards();
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to delete news";
      toast.error(message);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  };

  return (
    <section>
      <NewsSectionBackLink />
      <header className="flex flex-wrap items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">
            Featured Research
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Manage news cards for the news page and homepage. Section settings
            control the Campus News heading, intro, and CTA; the table controls
            which cards appear on the homepage when marked Featured.
          </p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="w-4 h-4 mr-2" />
          Add News
        </Button>
      </header>

      <form
        onSubmit={sectionForm.handleSubmit(onSaveSection)}
        className="space-y-6 bg-card rounded-lg border border-border shadow-sm p-6 md:p-8 mb-8 max-w-2xl"
      >
        <div>
          <h2 className="text-lg font-heading font-semibold">
            Homepage section settings
          </h2>
          <p className="text-sm text-muted-foreground mt-1">
            Heading, intro, panel image, and button shown in the Campus News
            block on the home page.
          </p>
        </div>
        {loadingSection ? (
          <section className="space-y-3">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-24 w-full" />
          </section>
        ) : (
          <>
            <section className="space-y-2">
              <Label htmlFor="sectionHeading">Section heading</Label>
              <Input
                id="sectionHeading"
                {...sectionForm.register("sectionHeading")}
              />
              {sectionForm.formState.errors.sectionHeading ? (
                <p className="text-sm text-destructive">
                  {sectionForm.formState.errors.sectionHeading.message}
                </p>
              ) : null}
            </section>
            <section className="space-y-2">
              <Label htmlFor="sectionSubContent">Section subheading</Label>
              <Textarea
                id="sectionSubContent"
                rows={3}
                {...sectionForm.register("sectionSubContent")}
              />
              {sectionForm.formState.errors.sectionSubContent ? (
                <p className="text-sm text-destructive">
                  {sectionForm.formState.errors.sectionSubContent.message}
                </p>
              ) : null}
            </section>
            <CmsImageUploadField
              label="Panel image"
              preset="card4x3"
              folder="cms/home-news/panel"
              storageFileName="panel"
              value={panelImage}
              onChange={setPanelImage}
              pendingPreviewUrl={panelImagePendingPreview}
              onPendingPreviewChange={setPanelImagePendingPreview}
            />
            <section className="space-y-2">
              <Label htmlFor="panelImageAlt">Image alt text</Label>
              <Input
                id="panelImageAlt"
                value={panelImageAlt}
                onChange={(e) => setPanelImageAlt(e.target.value)}
                placeholder="Describe the panel image"
              />
            </section>
            <section className="space-y-2">
              <Label htmlFor="buttonText">Button text</Label>
              <Input id="buttonText" {...sectionForm.register("buttonText")} />
              {sectionForm.formState.errors.buttonText ? (
                <p className="text-sm text-destructive">
                  {sectionForm.formState.errors.buttonText.message}
                </p>
              ) : null}
            </section>
            <section className="space-y-2">
              <Label htmlFor="buttonLink">Button link</Label>
              <Input
                id="buttonLink"
                placeholder="/news"
                {...sectionForm.register("buttonLink")}
              />
              {sectionForm.formState.errors.buttonLink ? (
                <p className="text-sm text-destructive">
                  {sectionForm.formState.errors.buttonLink.message}
                </p>
              ) : null}
            </section>
            <Button type="submit" disabled={savingSection}>
              {savingSection ? "Saving..." : "Save section settings"}
            </Button>
          </>
        )}
      </form>

      <section className="bg-card rounded-lg border border-border shadow-sm overflow-hidden">
        {loading ? (
          <section className="p-8 space-y-3">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </section>
        ) : cards.length === 0 ? (
          <p className="p-8 text-sm text-muted-foreground text-center">
            No news items yet. Click &quot;Add News&quot; to create one.
          </p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead>Title</TableHead>
                <TableHead className="w-20">Featured</TableHead>
                <TableHead className="hidden md:table-cell">
                  Sub content
                </TableHead>
                <TableHead className="hidden sm:table-cell w-32">
                  Published
                </TableHead>
                <TableHead className="w-24 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {cards.map((card) => (
                <TableRow key={card.id}>
                  <TableCell className="font-medium max-w-[240px]">
                    <span className="line-clamp-2">{card.title}</span>
                  </TableCell>
                  <TableCell>
                    {card.featured ? (
                      <Star className="w-4 h-4 fill-amber-400 text-amber-500" />
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell className="hidden md:table-cell text-muted-foreground max-w-xs">
                    <span className="line-clamp-2 text-sm">
                      {card.subContent}
                    </span>
                  </TableCell>
                  <TableCell className="hidden sm:table-cell text-sm text-muted-foreground">
                    {formatPublishedDateForTable(card.publishedDate)}
                  </TableCell>
                  <TableCell className="text-right">
                    <section className="flex justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEdit(card)}
                        aria-label="Edit"
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteTarget(card)}
                        aria-label="Delete"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </section>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </section>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-background">
          <DialogHeader>
            <DialogTitle className="font-heading text-xl">
              {editingCard ? "Edit News" : "New News"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <section className="space-y-2">
              <Label htmlFor="image">
                Image <span className="text-destructive">*</span>
              </Label>
              <Input
                id="image"
                type="file"
                accept="image/*"
                onChange={handleImageChange}
              />
              {imagePreview && (
                <section className="relative w-full h-44 rounded-lg overflow-hidden bg-muted border border-border mt-2">
                  <Image
                    src={imagePreview}
                    alt="Preview"
                    fill
                    className="object-cover"
                    unoptimized
                  />
                </section>
              )}
            </section>

            <section className="space-y-2">
              <Label htmlFor="title">
                Title <span className="text-destructive">*</span>
              </Label>
              <Input id="title" {...form.register("title")} />
              {form.formState.errors.title && (
                <p className="text-sm text-destructive">
                  {form.formState.errors.title.message}
                </p>
              )}
            </section>

            <section className="space-y-2">
              <Label htmlFor="content">
                Content <span className="text-destructive">*</span>
              </Label>
              <Textarea id="content" rows={6} {...form.register("content")} />
              {form.formState.errors.content && (
                <p className="text-sm text-destructive">
                  {form.formState.errors.content.message}
                </p>
              )}
            </section>

            <section className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Input
                id="category"
                placeholder="Health & Medicine"
                {...form.register("category")}
              />
              <p className="text-xs text-muted-foreground">
                Optional. Shown in uppercase on the homepage Campus News section.
              </p>
              {form.formState.errors.category && (
                <p className="text-sm text-destructive">
                  {form.formState.errors.category.message}
                </p>
              )}
            </section>

            <section className="space-y-2">
              <Label htmlFor="subContent">
                Sub content <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="subContent"
                rows={3}
                {...form.register("subContent")}
              />
              <p
                className={`text-xs ${subContentOverLimit ? "text-destructive" : "text-muted-foreground"}`}
              >
                {subContent.length} / 300
              </p>
            </section>

            <section className="space-y-2">
              <Label>
                Publish date <span className="text-destructive">*</span>
              </Label>
              <Popover
                open={datePickerOpen}
                onOpenChange={setDatePickerOpen}
                modal
              >
                <PopoverTrigger asChild>
                  <Button
                    type="button"
                    variant="outline"
                    className={cn(
                      "w-full justify-start text-left font-normal",
                      !publishedDate && "text-muted-foreground",
                    )}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {publishedDate
                      ? format(publishedDate, "PPP")
                      : "Pick a date"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent
                  className="z-[100] w-auto p-0"
                  align="start"
                  onOpenAutoFocus={(e) => e.preventDefault()}
                >
                  <Calendar
                    mode="single"
                    selected={publishedDate}
                    defaultMonth={publishedDate}
                    onSelect={(date) => {
                      setPublishedDate(date);
                      if (date) {
                        setDatePickerOpen(false);
                      }
                    }}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
              <p className="text-xs text-muted-foreground">
                Shown on homepage news cards and the article page.
              </p>
            </section>

            <section className="flex items-start gap-3 rounded-lg border border-border p-4 bg-muted/30">
              <Checkbox
                id="featured"
                checked={featured}
                onCheckedChange={(checked) =>
                  form.setValue("featured", checked === true)
                }
              />
              <section className="space-y-0.5">
                <Label htmlFor="featured" className="cursor-pointer font-medium">
                  Show on homepage (Campus News)
                </Label>
                <p className="text-xs text-muted-foreground">
                  Up to 6 featured items appear on the home page.
                </p>
              </section>
            </section>

            <DialogFooter className="gap-2 sm:gap-0 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving || subContentOverLimit}>
                {saving ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete news item?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
