"use client";

import Link from "next/link";
import {
  Award,
  BarChart3,
  BookOpen,
  Building2,
  ChevronRight,
  Sparkles,
} from "lucide-react";
import { Card } from "@/components/ui/card";

const sections = [
  {
    title: "Hero Banner",
    description:
      "Page banner title, subtitle, and desktop + mobile hero images.",
    href: "/admin/about-page-content/hero",
    icon: Sparkles,
  },
  {
    title: "Our Story",
    description: "Eyebrow, heading, body copy, CTA button, and section image.",
    href: "/admin/about-page-content/our-story",
    icon: BookOpen,
  },
  {
    title: "Global Accreditation",
    description: "Section heading and two accreditation glass cards.",
    href: "/admin/about-page-content/accreditation",
    icon: Award,
  },
  {
    title: "Our Institute",
    description:
      "Program details, meta rows, about copy, and institute image.",
    href: "/admin/about-page-content/institute",
    icon: Building2,
  },
  {
    title: "Institute Stats",
    description: "Animated statistics for courses and active students.",
    href: "/admin/about-page-content/institute-stats",
    icon: BarChart3,
  },
];

export function AboutPageContentHub() {
  return (
    <section>
      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          About Us page content
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Manage sections on the public <code className="text-xs">/about</code>{" "}
          page. Unsaved sections fall back to default content on the site.
        </p>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 max-w-5xl">
        {sections.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href}>
              <Card className="p-6 h-full border border-border shadow-sm hover:shadow-md transition-shadow card-hover">
                <div className="flex items-start justify-between gap-4">
                  <div className="w-11 h-11 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-1" />
                </div>
                <h2 className="text-lg font-heading font-semibold text-foreground mt-4">
                  {item.title}
                </h2>
                <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                  {item.description}
                </p>
              </Card>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
