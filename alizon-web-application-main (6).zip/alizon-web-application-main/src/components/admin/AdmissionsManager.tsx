"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Eye } from "lucide-react";
import { toast } from "sonner";
import {
  fetchAllAdmissions,
  formatGenderLabel,
  toAdmissionDateString,
} from "@/lib/admissions";
import type { AdmissionApplication } from "@/types/admission";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";

const PAGE_SIZE = 10;

export function AdmissionsManager() {
  const [applications, setApplications] = useState<AdmissionApplication[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [viewTarget, setViewTarget] = useState<AdmissionApplication | null>(
    null,
  );

  const loadApplications = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchAllAdmissions();
      setApplications(data);
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to load applications";
      const hint =
        message.includes("permission") || message.includes("Permission")
          ? " Ensure Firestore rules are deployed and you have an admins/{uid} document."
          : "";
      toast.error(message + hint);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadApplications();
  }, [loadApplications]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    return applications.filter((a) => {
      if (!q) return true;
      return (
        a.name.toLowerCase().includes(q) ||
        a.email.toLowerCase().includes(q) ||
        a.phone.toLowerCase().includes(q) ||
        a.courseInterested.toLowerCase().includes(q) ||
        a.address.toLowerCase().includes(q) ||
        formatGenderLabel(a.gender).toLowerCase().includes(q)
      );
    });
  }, [applications, search]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  useEffect(() => {
    setPage(1);
  }, [search]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-heading font-bold">Admissions</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Review admission applications submitted from the website
        </p>
      </div>

      <Input
        placeholder="Search by name, email, phone, course, address..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="max-w-md"
      />

      {loading ? (
        <div className="space-y-2">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
        </div>
      ) : filtered.length === 0 ? (
        <p className="text-muted-foreground text-sm py-8 text-center">
          No admission applications found.
        </p>
      ) : (
        <>
          <div className="overflow-x-auto rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Course</TableHead>
                  <TableHead>DOB</TableHead>
                  <TableHead>Gender</TableHead>
                  <TableHead>WhatsApp</TableHead>
                  <TableHead>Submitted</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginated.map((a) => (
                  <TableRow key={a.id}>
                    <TableCell className="font-medium">{a.name}</TableCell>
                    <TableCell>{a.email}</TableCell>
                    <TableCell>{a.phone}</TableCell>
                    <TableCell>{a.courseInterested || "—"}</TableCell>
                    <TableCell>{a.dateOfBirth || "—"}</TableCell>
                    <TableCell>{formatGenderLabel(a.gender)}</TableCell>
                    <TableCell>
                      <Badge
                        variant={a.whatsappConsent ? "default" : "secondary"}
                      >
                        {a.whatsappConsent ? "Yes" : "No"}
                      </Badge>
                    </TableCell>
                    <TableCell className="whitespace-nowrap text-sm">
                      {toAdmissionDateString(a.createdAt)}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setViewTarget(a)}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {totalPages > 1 && (
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      setPage((p) => Math.max(1, p - 1));
                    }}
                    className={
                      page <= 1 ? "pointer-events-none opacity-50" : ""
                    }
                  />
                </PaginationItem>
                {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                  (p) => (
                    <PaginationItem key={p}>
                      <PaginationLink
                        href="#"
                        isActive={p === page}
                        onClick={(e) => {
                          e.preventDefault();
                          setPage(p);
                        }}
                      >
                        {p}
                      </PaginationLink>
                    </PaginationItem>
                  ),
                )}
                <PaginationItem>
                  <PaginationNext
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      setPage((p) => Math.min(totalPages, p + 1));
                    }}
                    className={
                      page >= totalPages
                        ? "pointer-events-none opacity-50"
                        : ""
                    }
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}
        </>
      )}

      <Dialog open={!!viewTarget} onOpenChange={() => setViewTarget(null)}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Application Details</DialogTitle>
          </DialogHeader>
          {viewTarget && (
            <div className="grid gap-3 text-sm">
              <p>
                <span className="text-muted-foreground">Name: </span>
                {viewTarget.name}
              </p>
              <p>
                <span className="text-muted-foreground">Email: </span>
                {viewTarget.email}
              </p>
              <p>
                <span className="text-muted-foreground">Phone: </span>
                {viewTarget.phone}
              </p>
              <p>
                <span className="text-muted-foreground">Course Interested In: </span>
                {viewTarget.courseInterested || "—"}
              </p>
              <p>
                <span className="text-muted-foreground">Date of Birth: </span>
                {viewTarget.dateOfBirth || "—"}
              </p>
              <p>
                <span className="text-muted-foreground">Gender: </span>
                {formatGenderLabel(viewTarget.gender)}
              </p>
              <p>
                <span className="text-muted-foreground">Address: </span>
                {viewTarget.address || "—"}
              </p>
              <p>
                <span className="text-muted-foreground">Message / Notes: </span>
                {viewTarget.message || "—"}
              </p>
              <p>
                <span className="text-muted-foreground">WhatsApp consent: </span>
                {viewTarget.whatsappConsent ? "Yes" : "No"}
              </p>
              <p>
                <span className="text-muted-foreground">Submitted: </span>
                {toAdmissionDateString(viewTarget.createdAt)}
              </p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
