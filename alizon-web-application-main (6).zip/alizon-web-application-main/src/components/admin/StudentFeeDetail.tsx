"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { ArrowLeft, Plus } from "lucide-react";
import { toast } from "sonner";
import {
  apiDeleteFeePayment,
  apiFetchStudentFeeDetail,
} from "@/lib/admin-fees-api";
import { calculateFeeCompletionPercent, formatCurrency } from "@/lib/fees";
import type { FeePayment, StudentFeeSummary } from "@/types/fees";
import { FeeStatCard } from "@/components/fees/FeeStatCard";
import { FeeProgressBar } from "@/components/fees/FeeProgressBar";
import { PaymentTimeline } from "@/components/fees/PaymentTimeline";
import { AddPaymentDialog } from "@/components/fees/AddPaymentDialog";
import { EditPaymentDialog } from "@/components/fees/EditPaymentDialog";
import { ReceiptDialog } from "@/components/fees/ReceiptDialog";
import { PaymentStatusBadge } from "@/components/fees/PaymentStatusBadge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { IndianRupee, Percent, Wallet } from "lucide-react";

export function StudentFeeDetail({ studentId }: { studentId: string }) {
  const [summary, setSummary] = useState<StudentFeeSummary | null>(null);
  const [payments, setPayments] = useState<FeePayment[]>([]);
  const [loading, setLoading] = useState(true);
  const [addOpen, setAddOpen] = useState(false);
  const [editPayment, setEditPayment] = useState<FeePayment | null>(null);
  const [receiptId, setReceiptId] = useState<string | null>(null);
  const [deletePayment, setDeletePayment] = useState<FeePayment | null>(null);
  const [deleting, setDeleting] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await apiFetchStudentFeeDetail(studentId);
      setSummary(data.summary);
      setPayments(data.payments);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to load fee profile");
    } finally {
      setLoading(false);
    }
  }, [studentId]);

  useEffect(() => {
    void load();
  }, [load]);

  const handleDelete = async () => {
    if (!deletePayment) return;
    setDeleting(true);
    try {
      await apiDeleteFeePayment(deletePayment.id);
      toast.success("Payment deleted.");
      setDeletePayment(null);
      await load();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Delete failed.");
    } finally {
      setDeleting(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-48" />
        <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-28" />
          ))}
        </div>
      </div>
    );
  }

  if (!summary) {
    return (
      <p className="text-muted-foreground">Student fee profile not found.</p>
    );
  }

  const percent = calculateFeeCompletionPercent(summary.finalPayableFee, summary.totalPaid);

  return (
    <div className="space-y-8">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" asChild>
            <Link href="/admin/fees/students">
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </Button>
          <div>
            <h1 className="text-2xl font-heading font-bold">{summary.studentName}</h1>
            <p className="text-sm text-muted-foreground">
              {summary.registrationId} · {summary.programName}
            </p>
          </div>
          <PaymentStatusBadge status={summary.paymentStatus} />
        </div>
        <Button onClick={() => setAddOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Add Payment
        </Button>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <FeeStatCard
          label="Course Fee"
          value={formatCurrency(summary.courseFee)}
          icon={<IndianRupee className="h-5 w-5" />}
        />
        <FeeStatCard
          label="Scholarship %"
          value={`${summary.scholarshipPercentage}%`}
          icon={<Percent className="h-5 w-5" />}
        />
        <FeeStatCard
          label="Discount Amount"
          value={formatCurrency(summary.discountAmount)}
          icon={<IndianRupee className="h-5 w-5" />}
        />
        <FeeStatCard
          label="Final Payable Fee"
          value={formatCurrency(summary.finalPayableFee)}
          icon={<Wallet className="h-5 w-5" />}
          accent
        />
        <FeeStatCard
          label="Total Paid"
          value={formatCurrency(summary.totalPaid)}
          icon={<IndianRupee className="h-5 w-5" />}
        />
        <FeeStatCard
          label="Due Amount"
          value={formatCurrency(summary.dueAmount)}
          icon={<IndianRupee className="h-5 w-5" />}
        />
      </div>

      <Card className="border-0 shadow-soft">
        <CardHeader>
          <CardTitle className="font-heading text-base">Fee Payment Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <FeeProgressBar
            percent={percent}
            totalPaid={summary.totalPaid}
            finalPayableFee={summary.finalPayableFee}
          />
        </CardContent>
      </Card>

      {summary.feeNotes ? (
        <Card className="border-0 shadow-soft">
          <CardContent className="p-4 text-sm">
            <span className="font-medium">Fee notes: </span>
            {summary.feeNotes}
          </CardContent>
        </Card>
      ) : null}

      <div>
        <h2 className="mb-4 text-lg font-heading font-semibold">Payment History</h2>
        <PaymentTimeline
          payments={payments}
          onEdit={setEditPayment}
          onDelete={setDeletePayment}
          onReceipt={(p) => setReceiptId(p.id)}
        />
      </div>

      <AddPaymentDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        defaultStudentId={studentId}
        onSuccess={load}
      />
      <EditPaymentDialog
        payment={editPayment}
        open={!!editPayment}
        onOpenChange={(o) => !o && setEditPayment(null)}
        onSuccess={load}
      />
      <ReceiptDialog
        paymentId={receiptId}
        open={!!receiptId}
        onOpenChange={(o) => !o && setReceiptId(null)}
      />

      <AlertDialog open={!!deletePayment} onOpenChange={() => setDeletePayment(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete payment?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove this payment record. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
