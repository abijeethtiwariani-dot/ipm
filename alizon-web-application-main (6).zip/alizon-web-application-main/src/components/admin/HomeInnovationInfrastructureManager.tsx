"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import {
  ArrowLeft,
  ArrowDown,
  ArrowUp,
  Loader2,
  Pencil,
  Plus,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import type { HomeInnovationCard } from "@/types/cms";
import {
  fetchHomeInnovationInfrastructureContentAdmin,
  saveHomeInnovationInfrastructureContentAdmin,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import { HomeSectionPublishToggle } from "@/components/admin/HomeSectionPublishToggle";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { shouldUnoptimizeCmsSrc } from "@/lib/cms-image-url";

const sectionFormSchema = z.object({
  sectionHeading: z.string().min(1, "Section heading is required"),
  sectionDescription: z.string().min(1, "Section description is required"),
  mapImageAlt: z.string().optional(),
});

const cardFormSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  imageAlt: z.string().optional(),
  link: z.string().optional(),
});

type SectionFormValues = z.infer<typeof sectionFormSchema>;
type CardFormValues = z.infer<typeof cardFormSchema>;

function createCardId() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) {
    return crypto.randomUUID();
  }
  return `card-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

function renumberOrders(cards: HomeInnovationCard[]): HomeInnovationCard[] {
  return cards.map((card, index) => ({ ...card, order: index + 1 }));
}

export function HomeInnovationInfrastructureManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [cards, setCards] = useState<HomeInnovationCard[]>([]);
  const [mapImage, setMapImage] = useState<CmsImageUploadValue | null>(null);
  const [mapPending, setMapPending] = useState<string | null>(null);
  const [mapMobileImage, setMapMobileImage] =
    useState<CmsImageUploadValue | null>(null);
  const [mapMobilePending, setMapMobilePending] = useState<string | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingCard, setEditingCard] = useState<HomeInnovationCard | null>(
    null,
  );
  const [deleteTarget, setDeleteTarget] = useState<HomeInnovationCard | null>(
    null,
  );
  const [cardImage, setCardImage] = useState<CmsImageUploadValue | null>(null);
  const [cardPending, setCardPending] = useState<string | null>(null);

  const sectionForm = useForm<SectionFormValues>({
    resolver: zodResolver(sectionFormSchema),
    defaultValues: {
      sectionHeading: "An Infrastructure for Innovation",
      sectionDescription: "",
      mapImageAlt: "",
    },
  });

  const cardForm = useForm<CardFormValues>({
    resolver: zodResolver(cardFormSchema),
    defaultValues: {
      title: "",
      description: "",
      imageAlt: "",
      link: "",
    },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchHomeInnovationInfrastructureContentAdmin();
      sectionForm.reset({
        sectionHeading: data.sectionHeading,
        sectionDescription: data.sectionDescription,
        mapImageAlt: data.mapImageAlt ?? "",
      });
      setMapImage(data.mapImageUrl ? { url: data.mapImageUrl } : null);
      setMapMobileImage(
        data.mapImageMobileUrl ? { url: data.mapImageMobileUrl } : null,
      );
      setCards(
        [...data.cards].sort((a, b) => a.order - b.order).map((card, i) => ({
          ...card,
          order: i + 1,
        })),
      );
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load content",
      );
    } finally {
      setLoading(false);
    }
  }, [sectionForm]);

  useEffect(() => {
    void loadContent();
  }, [loadContent]);

  const openCreateCard = () => {
    setEditingCard(null);
    setCardImage(null);
    setCardPending(null);
    cardForm.reset({
      title: "",
      description: "",
      imageAlt: "",
      link: "",
    });
    setDialogOpen(true);
  };

  const openEditCard = (card: HomeInnovationCard) => {
    setEditingCard(card);
    setCardImage(card.imageUrl ? { url: card.imageUrl } : null);
    setCardPending(null);
    cardForm.reset({
      title: card.title,
      description: card.description,
      imageAlt: card.imageAlt ?? "",
      link: card.link ?? "",
    });
    setDialogOpen(true);
  };

  const saveCardDialog = (values: CardFormValues) => {
    const nextCard: HomeInnovationCard = {
      id: editingCard?.id ?? createCardId(),
      title: values.title.trim(),
      description: values.description.trim(),
      imageUrl: cardImage?.url?.trim() ?? "",
      imageAlt: values.imageAlt?.trim() ?? "",
      link: values.link?.trim() ?? "",
      order: editingCard?.order ?? cards.length + 1,
    };

    setCards((prev) => {
      if (editingCard) {
        return renumberOrders(
          prev.map((card) => (card.id === editingCard.id ? nextCard : card)),
        );
      }
      return renumberOrders([...prev, nextCard]);
    });
    setDialogOpen(false);
    toast.success(editingCard ? "Card updated" : "Card added");
  };

  const moveCard = (id: string, direction: -1 | 1) => {
    setCards((prev) => {
      const index = prev.findIndex((card) => card.id === id);
      if (index < 0) return prev;
      const nextIndex = index + direction;
      if (nextIndex < 0 || nextIndex >= prev.length) return prev;
      const copy = [...prev];
      const [item] = copy.splice(index, 1);
      copy.splice(nextIndex, 0, item);
      return renumberOrders(copy);
    });
  };

  const confirmDeleteCard = () => {
    if (!deleteTarget) return;
    setCards((prev) =>
      renumberOrders(prev.filter((card) => card.id !== deleteTarget.id)),
    );
    setDeleteTarget(null);
    toast.success("Card removed");
  };

  const onSaveSection = async (values: SectionFormValues) => {
    setSaving(true);
    try {
      await saveHomeInnovationInfrastructureContentAdmin({
        sectionHeading: values.sectionHeading.trim(),
        sectionDescription: values.sectionDescription.trim(),
        mapImageUrl: mapImage?.url?.trim() ?? "",
        mapImageAlt: values.mapImageAlt?.trim() ?? "",
        mapImageMobileUrl: mapMobileImage?.url?.trim() ?? "",
        imageObjectPosition: "center",
        cards: renumberOrders(cards),
      });
      toast.success("Infrastructure for Innovation section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-40 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl space-y-8">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" asChild>
          <Link href="/admin/home-content" aria-label="Back to home content">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-2xl font-heading font-bold text-foreground">
            Infrastructure for Innovation
          </h1>
          <p className="text-sm text-muted-foreground">
            Intro copy, background image, and auto-scrolling institute cards.
          </p>
        </div>
      </div>

      <HomeSectionPublishToggle sectionKey="innovationInfrastructure" />

      <form
        onSubmit={sectionForm.handleSubmit(onSaveSection)}
        className="space-y-8"
      >
        <div className="space-y-4 rounded-xl border border-border bg-card p-6">
          <h2 className="text-lg font-heading font-semibold">Section intro</h2>
          <div className="space-y-2">
            <Label htmlFor="sectionHeading">Heading</Label>
            <Input
              id="sectionHeading"
              {...sectionForm.register("sectionHeading")}
            />
            {sectionForm.formState.errors.sectionHeading ? (
              <p className="text-sm text-destructive">
                {sectionForm.formState.errors.sectionHeading.message}
              </p>
            ) : null}
          </div>
          <div className="space-y-2">
            <Label htmlFor="sectionDescription">Description</Label>
            <Textarea
              id="sectionDescription"
              rows={4}
              {...sectionForm.register("sectionDescription")}
            />
            {sectionForm.formState.errors.sectionDescription ? (
              <p className="text-sm text-destructive">
                {sectionForm.formState.errors.sectionDescription.message}
              </p>
            ) : null}
          </div>
        </div>

        <div className="space-y-4 rounded-xl border border-border bg-card p-6">
          <h2 className="text-lg font-heading font-semibold">
            Background image
          </h2>
          <CmsImageUploadField
            label="Desktop / primary image"
            preset="heroDesktop"
            folder="cms/home-innovation-infrastructure/map"
            storageFileName="background"
            value={mapImage}
            onChange={setMapImage}
            pendingPreviewUrl={mapPending}
            onPendingPreviewChange={setMapPending}
          />
          <CmsImageUploadField
            label="Mobile image (optional)"
            preset="heroMobile"
            folder="cms/home-innovation-infrastructure/map"
            storageFileName="background-mobile"
            value={mapMobileImage}
            onChange={setMapMobileImage}
            pendingPreviewUrl={mapMobilePending}
            onPendingPreviewChange={setMapMobilePending}
          />
          <div className="space-y-2">
            <Label htmlFor="mapImageAlt">Image alt text</Label>
            <Input
              id="mapImageAlt"
              placeholder="Alizon medical and digital intelligence research environment"
              {...sectionForm.register("mapImageAlt")}
            />
            <p className="text-xs text-muted-foreground">
              Describe the research / innovation scene for accessibility.
            </p>
          </div>
        </div>

        <div className="space-y-4 rounded-xl border border-border bg-card p-6">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-lg font-heading font-semibold">
              Carousel cards
            </h2>
            <Button type="button" variant="outline" onClick={openCreateCard}>
              <Plus className="mr-2 h-4 w-4" />
              Add card
            </Button>
          </div>
          <p className="text-sm text-muted-foreground">
            Reorder with the arrows. Changes are saved when you click Save
            section below.
          </p>
          {cards.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">
              No cards yet. Add at least one card for the carousel.
            </p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-16">Order</TableHead>
                  <TableHead className="w-20">Image</TableHead>
                  <TableHead>Title</TableHead>
                  <TableHead className="hidden md:table-cell">
                    Description
                  </TableHead>
                  <TableHead className="w-36 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {cards.map((card, index) => (
                  <TableRow key={card.id}>
                    <TableCell>
                      <div className="flex flex-col gap-1">
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          disabled={index === 0}
                          onClick={() => moveCard(card.id, -1)}
                          aria-label="Move up"
                        >
                          <ArrowUp className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          disabled={index === cards.length - 1}
                          onClick={() => moveCard(card.id, 1)}
                          aria-label="Move down"
                        >
                          <ArrowDown className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                    <TableCell>
                      {card.imageUrl ? (
                        <div className="relative h-12 w-16 overflow-hidden rounded-md border bg-muted">
                          <Image
                            src={card.imageUrl}
                            alt=""
                            fill
                            className="object-cover"
                            sizes="64px"
                            unoptimized={shouldUnoptimizeCmsSrc(card.imageUrl)}
                          />
                        </div>
                      ) : (
                        <div className="h-12 w-16 rounded-md bg-muted" />
                      )}
                    </TableCell>
                    <TableCell className="font-medium">{card.title}</TableCell>
                    <TableCell className="hidden max-w-xs truncate text-muted-foreground md:table-cell">
                      {card.description}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => openEditCard(card)}
                        aria-label="Edit card"
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteTarget(card)}
                        aria-label="Delete card"
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </div>

        <Button type="submit" disabled={saving}>
          {saving ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Saving…
            </>
          ) : (
            "Save section"
          )}
        </Button>
      </form>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingCard ? "Edit card" : "Add card"}
            </DialogTitle>
          </DialogHeader>
          <form
            onSubmit={cardForm.handleSubmit(saveCardDialog)}
            className="space-y-4"
          >
            <CmsImageUploadField
              label="Card image"
              preset="card4x3"
              folder="cms/home-innovation-infrastructure/cards"
              storageFileName={editingCard?.id ?? `new-${Date.now()}`}
              value={cardImage}
              onChange={setCardImage}
              pendingPreviewUrl={cardPending}
              onPendingPreviewChange={setCardPending}
            />
            <div className="space-y-2">
              <Label htmlFor="cardTitle">Title</Label>
              <Input id="cardTitle" {...cardForm.register("title")} />
              {cardForm.formState.errors.title ? (
                <p className="text-sm text-destructive">
                  {cardForm.formState.errors.title.message}
                </p>
              ) : null}
            </div>
            <div className="space-y-2">
              <Label htmlFor="cardDescription">Description</Label>
              <Textarea
                id="cardDescription"
                rows={3}
                {...cardForm.register("description")}
              />
              {cardForm.formState.errors.description ? (
                <p className="text-sm text-destructive">
                  {cardForm.formState.errors.description.message}
                </p>
              ) : null}
            </div>
            <div className="space-y-2">
              <Label htmlFor="cardImageAlt">Image alt text</Label>
              <Input id="cardImageAlt" {...cardForm.register("imageAlt")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="cardLink">Link (optional)</Label>
              <Input
                id="cardLink"
                placeholder="/research"
                {...cardForm.register("link")}
              />
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit">
                {editingCard ? "Update card" : "Add card"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={Boolean(deleteTarget)}
        onOpenChange={(open) => {
          if (!open) setDeleteTarget(null);
        }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this card?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleteTarget
                ? `“${deleteTarget.title}” will be removed when you save the section.`
                : null}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteCard}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
