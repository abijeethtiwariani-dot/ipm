"use client";

import Link from "next/link";
import {
  BookOpen,
  ChevronRight,
  Clapperboard,
  FlaskConical,
  LayoutGrid,
  Mail,
  Megaphone,
  Newspaper,
  Quote,
  Users,
} from "lucide-react";
import { Card } from "@/components/ui/card";

const sections = [
  {
    title: "Hero",
    description:
      "Featured story and three sidebar items at the top of the news page.",
    href: "/admin/news/hero",
    icon: LayoutGrid,
  },
  {
    title: "Featured Research",
    description:
      "Research cards grid on the news page. Featured items also appear on the homepage.",
    href: "/admin/news/featured-research",
    icon: FlaskConical,
  },
  {
    title: "In the News",
    description: "Quote block and two story cards in the In the news section.",
    href: "/admin/news/in-the-news",
    icon: Quote,
  },
  {
    title: "Research Matters",
    description: "Full-width banner with background image, copy, and CTA button.",
    href: "/admin/news/research-matters",
    icon: Megaphone,
  },
  {
    title: "Featured Reading",
    description: "Up to 3 carousel slides with book cover and reading details.",
    href: "/admin/news/featured-reading",
    icon: BookOpen,
  },
  {
    title: "Alizon in the community",
    description: "Section heading and three community story cards.",
    href: "/admin/news/community",
    icon: Users,
  },
  {
    title: "Stories in Motion",
    description: "Video feature block with image, title, and description.",
    href: "/admin/news/stories-in-motion",
    icon: Clapperboard,
  },
  {
    title: "Recent Stories",
    description: "Section heading and three recent story cards.",
    href: "/admin/news/recent-stories",
    icon: Newspaper,
  },
  {
    title: "Alizon Report",
    description: "Newsletter signup copy and link at the bottom of the page.",
    href: "/admin/news/report-signup",
    icon: Mail,
  },
];

export function NewsContentHub() {
  return (
    <section>
      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">News</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Manage sections that appear on the public news page.
        </p>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 max-w-5xl">
        {sections.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href}>
              <Card className="p-6 h-full border border-border shadow-sm hover:shadow-md transition-shadow card-hover">
                <div className="flex items-start justify-between gap-4">
                  <div className="w-11 h-11 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-1" />
                </div>
                <h2 className="text-lg font-heading font-semibold text-foreground mt-4">
                  {item.title}
                </h2>
                <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                  {item.description}
                </p>
              </Card>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
