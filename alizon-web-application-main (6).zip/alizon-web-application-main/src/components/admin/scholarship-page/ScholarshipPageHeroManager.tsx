"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import {
  fetchScholarshipPageHeroContentAdmin,
  saveScholarshipPageHeroContentAdmin,
} from "@/lib/admin-cms-api";
import { DEFAULT_SCHOLARSHIP_PAGE_HERO } from "@/lib/scholarship-page-cms";
import {
  CmsHeroImagePairField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import {
  ScholarshipPageAdminBackLink,
  ScholarshipPageAdminHeader,
  ScholarshipPageFormFooter,
} from "@/components/admin/scholarship-page/ScholarshipPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z.object({
  title: z.string().min(1, "Title is required"),
  subtitle: z.string(),
  imageAlt: z.string(),
});

type FormValues = z.infer<typeof formSchema>;

export function ScholarshipPageHeroManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [desktopImage, setDesktopImage] = useState<CmsImageUploadValue | null>(
    null,
  );
  const [mobileImage, setMobileImage] = useState<CmsImageUploadValue | null>(
    null,
  );
  const [desktopPendingPreview, setDesktopPendingPreview] = useState<
    string | null
  >(null);
  const [mobilePendingPreview, setMobilePendingPreview] = useState<
    string | null
  >(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: DEFAULT_SCHOLARSHIP_PAGE_HERO.title,
      subtitle: DEFAULT_SCHOLARSHIP_PAGE_HERO.subtitle,
      imageAlt: DEFAULT_SCHOLARSHIP_PAGE_HERO.imageAlt,
    },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchScholarshipPageHeroContentAdmin();
      const content = data ?? DEFAULT_SCHOLARSHIP_PAGE_HERO;
      setDesktopImage(
        content.heroImageUrl ? { url: content.heroImageUrl } : null,
      );
      setMobileImage(
        content.mobileHeroImageUrl ? { url: content.mobileHeroImageUrl } : null,
      );
      form.reset({
        title: content.title,
        subtitle: content.subtitle,
        imageAlt: content.imageAlt,
      });
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load hero content",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    try {
      await saveScholarshipPageHeroContentAdmin({
        title: values.title.trim(),
        subtitle: values.subtitle.trim(),
        heroImageUrl: desktopImage?.url?.trim() ?? "",
        mobileHeroImageUrl: mobileImage?.url?.trim() ?? "",
        imageAlt: values.imageAlt.trim(),
      });
      toast.success("Hero banner saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save hero banner",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-3xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-40 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-3xl">
      <ScholarshipPageAdminBackLink />
      <ScholarshipPageAdminHeader
        title="Hero Banner"
        description="Title, subtitle, and banner images for the scholarships page."
      />

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <section className="space-y-2">
          <Label htmlFor="title">Title</Label>
          <Input id="title" {...form.register("title")} />
        </section>

        <section className="space-y-2">
          <Label htmlFor="subtitle">Subtitle</Label>
          <Textarea id="subtitle" rows={3} {...form.register("subtitle")} />
        </section>

        <section className="space-y-2">
          <Label htmlFor="imageAlt">Image alt text</Label>
          <Input id="imageAlt" {...form.register("imageAlt")} />
        </section>

        <CmsHeroImagePairField
          desktop={desktopImage}
          mobile={mobileImage}
          onDesktopChange={setDesktopImage}
          onMobileChange={setMobileImage}
          folder="cms/scholarship-page/hero"
          fileBaseName="banner"
          desktopPendingPreview={desktopPendingPreview}
          mobilePendingPreview={mobilePendingPreview}
          onDesktopPendingPreviewChange={setDesktopPendingPreview}
          onMobilePendingPreviewChange={setMobilePendingPreview}
        />

        <ScholarshipPageFormFooter
          end={
            <Button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
