"use client";

import { useCallback, useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type {
  ScholarshipPageIconKey,
  ScholarshipPageStatCms,
} from "@/types/cms";
import { SCHOLARSHIP_PAGE_ICONS } from "@/types/cms";
import {
  fetchScholarshipPageStatsContentAdmin,
  saveScholarshipPageStatsContentAdmin,
} from "@/lib/admin-cms-api";
import { DEFAULT_SCHOLARSHIP_PAGE_STATS } from "@/lib/scholarship-page-cms";
import {
  ScholarshipPageAdminBackLink,
  ScholarshipPageAdminHeader,
  ScholarshipPageFormFooter,
} from "@/components/admin/scholarship-page/ScholarshipPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export function ScholarshipPageImpactStatsManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [eyebrow, setEyebrow] = useState(DEFAULT_SCHOLARSHIP_PAGE_STATS.eyebrow);
  const [heading, setHeading] = useState(DEFAULT_SCHOLARSHIP_PAGE_STATS.heading);
  const [intro, setIntro] = useState(DEFAULT_SCHOLARSHIP_PAGE_STATS.intro);
  const [stats, setStats] = useState<ScholarshipPageStatCms[]>(
    DEFAULT_SCHOLARSHIP_PAGE_STATS.stats,
  );

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchScholarshipPageStatsContentAdmin();
      const content = data ?? DEFAULT_SCHOLARSHIP_PAGE_STATS;
      setEyebrow(content.eyebrow);
      setHeading(content.heading);
      setIntro(content.intro);
      setStats(content.stats);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load stats",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const updateStat = (index: number, patch: Partial<ScholarshipPageStatCms>) => {
    setStats((prev) =>
      prev.map((s, i) => (i === index ? { ...s, ...patch } : s)),
    );
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await saveScholarshipPageStatsContentAdmin({
        eyebrow: eyebrow.trim(),
        heading: heading.trim(),
        intro: intro.trim(),
        stats: stats
          .filter((s) => s.label.trim())
          .map((s) => ({
            label: s.label.trim(),
            value: s.value.trim(),
            icon: s.icon,
            counterEnd:
              s.counterEnd !== undefined ? Number(s.counterEnd) : undefined,
            counterSuffix: s.counterSuffix?.trim() || undefined,
          })),
      });
      toast.success("Impact stats saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save stats",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-3xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-32 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-3xl">
      <ScholarshipPageAdminBackLink />
      <ScholarshipPageAdminHeader
        title="Impact Stats"
        description="Each stat can use an animated counter or a static text value."
      />

      <form onSubmit={onSubmit} className="space-y-6">
        <section className="space-y-2">
          <Label>Eyebrow</Label>
          <Input value={eyebrow} onChange={(e) => setEyebrow(e.target.value)} />
        </section>
        <section className="space-y-2">
          <Label>Heading</Label>
          <Input value={heading} onChange={(e) => setHeading(e.target.value)} />
        </section>
        <section className="space-y-2">
          <Label>Intro</Label>
          <Textarea rows={2} value={intro} onChange={(e) => setIntro(e.target.value)} />
        </section>

        {stats.map((stat, index) => (
          <div
            key={index}
            className="space-y-4 rounded-lg border border-border p-4"
          >
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium">Stat {index + 1}</p>
              {stats.length > 1 ? (
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() =>
                    setStats((prev) => prev.filter((_, i) => i !== index))
                  }
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              ) : null}
            </div>

            <div className="space-y-2">
              <Label htmlFor={`stat-${index}-label`}>Stat label</Label>
              <Input
                id={`stat-${index}-label`}
                placeholder="e.g. Students Receive Financial Aid"
                value={stat.label}
                onChange={(e) => updateStat(index, { label: e.target.value })}
              />
              <p className="text-xs text-muted-foreground">
                Text shown below the number on the website.
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor={`stat-${index}-value`}>Static display value</Label>
              <Input
                id={`stat-${index}-value`}
                placeholder="e.g. 150+ or $2M"
                value={stat.value}
                onChange={(e) => updateStat(index, { value: e.target.value })}
              />
              <p className="text-xs text-muted-foreground">
                Shown on the site when animated count target is empty. Use for
                plain text or non-numeric values.
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor={`stat-${index}-counter-end`}>
                Animated count target
              </Label>
              <Input
                id={`stat-${index}-counter-end`}
                placeholder="e.g. 69"
                type="number"
                value={stat.counterEnd ?? ""}
                onChange={(e) =>
                  updateStat(index, {
                    counterEnd: e.target.value
                      ? Number(e.target.value)
                      : undefined,
                  })
                }
              />
              <p className="text-xs text-muted-foreground">
                Number the counter animates up to. Leave empty to use static
                display value instead.
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor={`stat-${index}-counter-suffix`}>Count suffix</Label>
              <Input
                id={`stat-${index}-counter-suffix`}
                placeholder="e.g. % or +"
                value={stat.counterSuffix ?? ""}
                onChange={(e) =>
                  updateStat(index, { counterSuffix: e.target.value })
                }
              />
              <p className="text-xs text-muted-foreground">
                Optional characters added after the animated number (only used
                with animated count target).
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor={`stat-${index}-icon`}>Icon</Label>
              <Select
                value={stat.icon}
                onValueChange={(v) =>
                  updateStat(index, { icon: v as ScholarshipPageIconKey })
                }
              >
                <SelectTrigger id={`stat-${index}-icon`}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SCHOLARSHIP_PAGE_ICONS.map((icon) => (
                    <SelectItem key={icon} value={icon}>
                      {icon}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        ))}

        <Button
          type="button"
          variant="outline"
          onClick={() =>
            setStats((prev) => [
              ...prev,
              {
                label: "",
                value: "",
                icon: "graduation",
                counterEnd: 0,
                counterSuffix: "",
              },
            ])
          }
        >
          <Plus className="h-4 w-4 mr-2" />
          Add stat
        </Button>

        <ScholarshipPageFormFooter
          end={
            <Button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
