"use client";

import { useCallback, useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type {
  ScholarshipPageBenefitCms,
  ScholarshipPageIconKey,
} from "@/types/cms";
import { SCHOLARSHIP_PAGE_ICONS } from "@/types/cms";
import {
  fetchScholarshipPageBenefitsContentAdmin,
  saveScholarshipPageBenefitsContentAdmin,
} from "@/lib/admin-cms-api";
import { DEFAULT_SCHOLARSHIP_PAGE_BENEFITS } from "@/lib/scholarship-page-cms";
import {
  ScholarshipPageAdminBackLink,
  ScholarshipPageAdminHeader,
  ScholarshipPageFormFooter,
} from "@/components/admin/scholarship-page/ScholarshipPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export function ScholarshipPageBenefitsManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [eyebrow, setEyebrow] = useState(DEFAULT_SCHOLARSHIP_PAGE_BENEFITS.eyebrow);
  const [heading, setHeading] = useState(DEFAULT_SCHOLARSHIP_PAGE_BENEFITS.heading);
  const [intro, setIntro] = useState(DEFAULT_SCHOLARSHIP_PAGE_BENEFITS.intro);
  const [benefits, setBenefits] = useState<ScholarshipPageBenefitCms[]>(
    DEFAULT_SCHOLARSHIP_PAGE_BENEFITS.benefits,
  );

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchScholarshipPageBenefitsContentAdmin();
      const content = data ?? DEFAULT_SCHOLARSHIP_PAGE_BENEFITS;
      setEyebrow(content.eyebrow);
      setHeading(content.heading);
      setIntro(content.intro);
      setBenefits(content.benefits);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load benefits",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const updateBenefit = (
    index: number,
    patch: Partial<ScholarshipPageBenefitCms>,
  ) => {
    setBenefits((prev) =>
      prev.map((b, i) => (i === index ? { ...b, ...patch } : b)),
    );
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await saveScholarshipPageBenefitsContentAdmin({
        eyebrow: eyebrow.trim(),
        heading: heading.trim(),
        intro: intro.trim(),
        benefits: benefits
          .filter((b) => b.title.trim())
          .map((b) => ({
            title: b.title.trim(),
            description: b.description.trim(),
            icon: b.icon,
          })),
      });
      toast.success("Benefits section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save benefits",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-3xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-32 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-3xl">
      <ScholarshipPageAdminBackLink />
      <ScholarshipPageAdminHeader
        title="Benefits"
        description="Icon benefit cards in the benefits grid."
      />

      <form onSubmit={onSubmit} className="space-y-6">
        <section className="space-y-2">
          <Label>Eyebrow</Label>
          <Input value={eyebrow} onChange={(e) => setEyebrow(e.target.value)} />
        </section>
        <section className="space-y-2">
          <Label>Heading</Label>
          <Input value={heading} onChange={(e) => setHeading(e.target.value)} />
        </section>
        <section className="space-y-2">
          <Label>Intro</Label>
          <Textarea rows={2} value={intro} onChange={(e) => setIntro(e.target.value)} />
        </section>

        {benefits.map((benefit, index) => (
          <div
            key={index}
            className="space-y-3 rounded-lg border border-border p-4"
          >
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium">Benefit {index + 1}</p>
              {benefits.length > 1 ? (
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() =>
                    setBenefits((prev) => prev.filter((_, i) => i !== index))
                  }
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              ) : null}
            </div>
            <Input
              placeholder="Title"
              value={benefit.title}
              onChange={(e) =>
                updateBenefit(index, { title: e.target.value })
              }
            />
            <Textarea
              placeholder="Description"
              rows={2}
              value={benefit.description}
              onChange={(e) =>
                updateBenefit(index, { description: e.target.value })
              }
            />
            <Select
              value={benefit.icon}
              onValueChange={(v) =>
                updateBenefit(index, { icon: v as ScholarshipPageIconKey })
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {SCHOLARSHIP_PAGE_ICONS.map((icon) => (
                  <SelectItem key={icon} value={icon}>
                    {icon}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        ))}

        <Button
          type="button"
          variant="outline"
          onClick={() =>
            setBenefits((prev) => [
              ...prev,
              { title: "", description: "", icon: "star" },
            ])
          }
        >
          <Plus className="h-4 w-4 mr-2" />
          Add benefit
        </Button>

        <ScholarshipPageFormFooter
          end={
            <Button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
