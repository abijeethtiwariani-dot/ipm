"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import {
  fetchScholarshipPageFeaturedScholarContentAdmin,
  saveScholarshipPageFeaturedScholarContentAdmin,
} from "@/lib/admin-cms-api";
import { DEFAULT_SCHOLARSHIP_PAGE_FEATURED_SCHOLAR } from "@/lib/scholarship-page-cms";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import {
  ScholarshipPageAdminBackLink,
  ScholarshipPageAdminHeader,
  ScholarshipPageFormFooter,
} from "@/components/admin/scholarship-page/ScholarshipPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z.object({
  eyebrow: z.string().min(1),
  heading: z.string().min(1),
  intro: z.string().min(1),
  name: z.string().min(1),
  scholarship: z.string().min(1),
  program: z.string().min(1),
  amount: z.string().min(1),
  story: z.string().min(1),
  fullStory: z.string().min(1),
  avatar: z.string().min(1),
});

type FormValues = z.infer<typeof formSchema>;

export function ScholarshipPageFeaturedScholarManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [photo, setPhoto] = useState<CmsImageUploadValue | null>(null);
  const [pendingPreview, setPendingPreview] = useState<string | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      eyebrow: DEFAULT_SCHOLARSHIP_PAGE_FEATURED_SCHOLAR.eyebrow,
      heading: DEFAULT_SCHOLARSHIP_PAGE_FEATURED_SCHOLAR.heading,
      intro: DEFAULT_SCHOLARSHIP_PAGE_FEATURED_SCHOLAR.intro,
      name: DEFAULT_SCHOLARSHIP_PAGE_FEATURED_SCHOLAR.name,
      scholarship: DEFAULT_SCHOLARSHIP_PAGE_FEATURED_SCHOLAR.scholarship,
      program: DEFAULT_SCHOLARSHIP_PAGE_FEATURED_SCHOLAR.program,
      amount: DEFAULT_SCHOLARSHIP_PAGE_FEATURED_SCHOLAR.amount,
      story: DEFAULT_SCHOLARSHIP_PAGE_FEATURED_SCHOLAR.story,
      fullStory: DEFAULT_SCHOLARSHIP_PAGE_FEATURED_SCHOLAR.fullStory,
      avatar: DEFAULT_SCHOLARSHIP_PAGE_FEATURED_SCHOLAR.avatar,
    },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchScholarshipPageFeaturedScholarContentAdmin();
      const content = data ?? DEFAULT_SCHOLARSHIP_PAGE_FEATURED_SCHOLAR;
      setPhoto(content.photoUrl ? { url: content.photoUrl } : null);
      form.reset({
        eyebrow: content.eyebrow,
        heading: content.heading,
        intro: content.intro,
        name: content.name,
        scholarship: content.scholarship,
        program: content.program,
        amount: content.amount,
        story: content.story,
        fullStory: content.fullStory,
        avatar: content.avatar,
      });
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load spotlight",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    try {
      await saveScholarshipPageFeaturedScholarContentAdmin({
        eyebrow: values.eyebrow.trim(),
        heading: values.heading.trim(),
        intro: values.intro.trim(),
        name: values.name.trim(),
        scholarship: values.scholarship.trim(),
        program: values.program.trim(),
        amount: values.amount.trim(),
        story: values.story.trim(),
        fullStory: values.fullStory.trim(),
        avatar: values.avatar.trim(),
        photoUrl: photo?.url?.trim() ?? "",
      });
      toast.success("Featured scholar spotlight saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save spotlight",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-3xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-3xl">
      <ScholarshipPageAdminBackLink />
      <ScholarshipPageAdminHeader
        title="Featured Scholar Spotlight"
        description="Spotlight card with scholar profile, testimonial, and person photo."
      />

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <section className="space-y-2">
          <Label htmlFor="eyebrow">Section eyebrow</Label>
          <Input id="eyebrow" {...form.register("eyebrow")} />
        </section>
        <section className="space-y-2">
          <Label htmlFor="heading">Section heading</Label>
          <Input id="heading" {...form.register("heading")} />
        </section>
        <section className="space-y-2">
          <Label htmlFor="intro">Section intro</Label>
          <Textarea id="intro" rows={2} {...form.register("intro")} />
        </section>

        <CmsImageUploadField
          label="Scholar photo"
          preset="avatarSquare"
          folder="cms/scholarship-page/featured-scholar"
          storageFileName="featured-scholar-photo"
          value={photo}
          onChange={setPhoto}
          pendingPreviewUrl={pendingPreview}
          onPendingPreviewChange={setPendingPreview}
        />

        <section className="space-y-2">
          <Label htmlFor="avatar">Initials fallback (e.g. AK)</Label>
          <Input id="avatar" maxLength={3} {...form.register("avatar")} />
          <p className="text-xs text-muted-foreground">
            Shown when no photo is uploaded.
          </p>
        </section>
        <section className="space-y-2">
          <Label htmlFor="name">Name</Label>
          <Input id="name" {...form.register("name")} />
        </section>
        <section className="space-y-2">
          <Label htmlFor="scholarship">Scholarship</Label>
          <Input id="scholarship" {...form.register("scholarship")} />
        </section>
        <section className="space-y-2">
          <Label htmlFor="program">Program</Label>
          <Input id="program" {...form.register("program")} />
        </section>
        <section className="space-y-2">
          <Label htmlFor="amount">Award amount</Label>
          <Input id="amount" {...form.register("amount")} />
        </section>
        <section className="space-y-2">
          <Label htmlFor="story">Short testimonial</Label>
          <Textarea id="story" rows={3} {...form.register("story")} />
        </section>
        <section className="space-y-2">
          <Label htmlFor="fullStory">Full story (modal)</Label>
          <Textarea id="fullStory" rows={5} {...form.register("fullStory")} />
        </section>

        <ScholarshipPageFormFooter
          end={
            <Button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
