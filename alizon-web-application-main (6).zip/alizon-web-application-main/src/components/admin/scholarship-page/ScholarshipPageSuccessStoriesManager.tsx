"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { ScholarshipSuccessStoryCard } from "@/types/cms";
import {
  createScholarshipSuccessStoryCardAdmin,
  deleteScholarshipSuccessStoryCardAdmin,
  fetchScholarshipPageSuccessStoriesHeaderContentAdmin,
  fetchScholarshipSuccessStoryCardsAdmin,
  saveScholarshipPageSuccessStoriesHeaderContentAdmin,
  updateScholarshipSuccessStoryCardAdmin,
} from "@/lib/admin-cms-api";
import { DEFAULT_SCHOLARSHIP_PAGE_SUCCESS_STORIES_HEADER } from "@/lib/scholarship-page-cms";
import {
  ScholarshipPageAdminBackLink,
  ScholarshipPageAdminHeader,
} from "@/components/admin/scholarship-page/ScholarshipPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const headerSchema = z.object({
  eyebrow: z.string().min(1),
  heading: z.string().min(1),
  intro: z.string().min(1),
});

const cardSchema = z.object({
  name: z.string().min(1),
  scholarship: z.string().min(1),
  program: z.string().min(1),
  amount: z.string().min(1),
  story: z.string().min(1),
  fullStory: z.string().min(1),
  avatar: z.string().min(1),
  order: z.string(),
});

type HeaderValues = z.infer<typeof headerSchema>;
type CardFormValues = z.infer<typeof cardSchema>;

export function ScholarshipPageSuccessStoriesManager() {
  const [loading, setLoading] = useState(true);
  const [savingHeader, setSavingHeader] = useState(false);
  const [savingCard, setSavingCard] = useState(false);
  const [items, setItems] = useState<ScholarshipSuccessStoryCard[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ScholarshipSuccessStoryCard | null>(
    null,
  );
  const [deleteTarget, setDeleteTarget] = useState<ScholarshipSuccessStoryCard | null>(
    null,
  );

  const headerForm = useForm<HeaderValues>({
    resolver: zodResolver(headerSchema),
    defaultValues: DEFAULT_SCHOLARSHIP_PAGE_SUCCESS_STORIES_HEADER,
  });

  const cardForm = useForm<CardFormValues>({
    resolver: zodResolver(cardSchema),
    defaultValues: {
      name: "",
      scholarship: "",
      program: "",
      amount: "",
      story: "",
      fullStory: "",
      avatar: "",
      order: "0",
    },
  });

  const loadItems = useCallback(async () => {
    setLoading(true);
    try {
      const [header, cards] = await Promise.all([
        fetchScholarshipPageSuccessStoriesHeaderContentAdmin(),
        fetchScholarshipSuccessStoryCardsAdmin(),
      ]);
      headerForm.reset(header ?? DEFAULT_SCHOLARSHIP_PAGE_SUCCESS_STORIES_HEADER);
      setItems(cards);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load success stories",
      );
    } finally {
      setLoading(false);
    }
  }, [headerForm]);

  useEffect(() => {
    loadItems();
  }, [loadItems]);

  const saveHeader = async (values: HeaderValues) => {
    setSavingHeader(true);
    try {
      await saveScholarshipPageSuccessStoriesHeaderContentAdmin({
        eyebrow: values.eyebrow.trim(),
        heading: values.heading.trim(),
        intro: values.intro.trim(),
      });
      toast.success("Section header saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save header",
      );
    } finally {
      setSavingHeader(false);
    }
  };

  const openCreate = () => {
    setEditingItem(null);
    cardForm.reset({
      name: "",
      scholarship: "",
      program: "",
      amount: "",
      story: "",
      fullStory: "",
      avatar: "",
      order: String(items.length),
    });
    setDialogOpen(true);
  };

  const openEdit = (item: ScholarshipSuccessStoryCard) => {
    setEditingItem(item);
    cardForm.reset({
      name: item.name,
      scholarship: item.scholarship,
      program: item.program,
      amount: item.amount,
      story: item.story,
      fullStory: item.fullStory,
      avatar: item.avatar,
      order: String(item.order),
    });
    setDialogOpen(true);
  };

  const onSubmitCard = async (values: CardFormValues) => {
    setSavingCard(true);
    try {
      const payload = {
        name: values.name.trim(),
        scholarship: values.scholarship.trim(),
        program: values.program.trim(),
        amount: values.amount.trim(),
        story: values.story.trim(),
        fullStory: values.fullStory.trim(),
        avatar: values.avatar.trim(),
        order: Number(values.order) || 0,
      };
      if (editingItem) {
        await updateScholarshipSuccessStoryCardAdmin(editingItem.id, payload);
        toast.success("Story updated");
      } else {
        await createScholarshipSuccessStoryCardAdmin(payload);
        toast.success("Story created");
      }
      setDialogOpen(false);
      await loadItems();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save story",
      );
    } finally {
      setSavingCard(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteScholarshipSuccessStoryCardAdmin(deleteTarget.id);
      toast.success("Story deleted");
      setDeleteTarget(null);
      await loadItems();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete story",
      );
    }
  };

  if (loading) {
    return (
      <section className="max-w-4xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-32 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-4xl">
      <ScholarshipPageAdminBackLink />
      <ScholarshipPageAdminHeader
        title="Success Stories"
        description="Carousel cards shown in the success stories section."
      />

      <form
        onSubmit={headerForm.handleSubmit(saveHeader)}
        className="mb-8 space-y-4 rounded-lg border border-border p-4"
      >
        <p className="text-sm font-medium">Section header</p>
        <section className="space-y-2">
          <Label htmlFor="eyebrow">Eyebrow</Label>
          <Input id="eyebrow" {...headerForm.register("eyebrow")} />
        </section>
        <section className="space-y-2">
          <Label htmlFor="heading">Heading</Label>
          <Input id="heading" {...headerForm.register("heading")} />
        </section>
        <section className="space-y-2">
          <Label htmlFor="intro">Intro</Label>
          <Textarea id="intro" rows={2} {...headerForm.register("intro")} />
        </section>
        <Button type="submit" disabled={savingHeader}>
          {savingHeader ? "Saving..." : "Save header"}
        </Button>
      </form>

      <div className="mb-4 flex justify-end">
        <Button type="button" onClick={openCreate}>
          <Plus className="h-4 w-4 mr-2" />
          Add story
        </Button>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Scholarship</TableHead>
            <TableHead>Order</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {items.map((item) => (
            <TableRow key={item.id}>
              <TableCell>{item.name}</TableCell>
              <TableCell>{item.scholarship}</TableCell>
              <TableCell>{item.order}</TableCell>
              <TableCell className="text-right">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => openEdit(item)}
                  aria-label={`Edit ${item.name}`}
                >
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => setDeleteTarget(item)}
                  aria-label={`Delete ${item.name}`}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingItem ? "Edit story" : "New story"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={cardForm.handleSubmit(onSubmitCard)} className="space-y-4">
            <section className="space-y-2">
              <Label>Name</Label>
              <Input {...cardForm.register("name")} />
            </section>
            <section className="space-y-2">
              <Label>Scholarship</Label>
              <Input {...cardForm.register("scholarship")} />
            </section>
            <section className="space-y-2">
              <Label>Program</Label>
              <Input {...cardForm.register("program")} />
            </section>
            <section className="space-y-2">
              <Label>Amount</Label>
              <Input {...cardForm.register("amount")} />
            </section>
            <section className="space-y-2">
              <Label>Avatar initials</Label>
              <Input maxLength={3} {...cardForm.register("avatar")} />
            </section>
            <section className="space-y-2">
              <Label>Short story</Label>
              <Textarea rows={3} {...cardForm.register("story")} />
            </section>
            <section className="space-y-2">
              <Label>Full story</Label>
              <Textarea rows={4} {...cardForm.register("fullStory")} />
            </section>
            <section className="space-y-2">
              <Label>Order</Label>
              <Input {...cardForm.register("order")} />
            </section>
            <DialogFooter>
              <Button type="submit" disabled={savingCard}>
                {savingCard ? "Saving..." : "Save story"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={Boolean(deleteTarget)}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete story?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove {deleteTarget?.name} from the carousel.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
