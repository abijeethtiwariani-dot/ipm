"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import {
  fetchScholarshipPageOverviewContentAdmin,
  saveScholarshipPageOverviewContentAdmin,
} from "@/lib/admin-cms-api";
import { DEFAULT_SCHOLARSHIP_PAGE_OVERVIEW } from "@/lib/scholarship-page-cms";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import {
  ScholarshipPageAdminBackLink,
  ScholarshipPageAdminHeader,
  ScholarshipPageFormFooter,
} from "@/components/admin/scholarship-page/ScholarshipPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z.object({
  eyebrow: z.string().min(1),
  title: z.string().min(1),
  intro: z.string().min(1),
  description: z.string().min(1),
  imageAlt: z.string(),
});

type FormValues = z.infer<typeof formSchema>;

export function ScholarshipPageOverviewManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [image, setImage] = useState<CmsImageUploadValue | null>(null);
  const [pendingPreview, setPendingPreview] = useState<string | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: DEFAULT_SCHOLARSHIP_PAGE_OVERVIEW,
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchScholarshipPageOverviewContentAdmin();
      const content = data ?? DEFAULT_SCHOLARSHIP_PAGE_OVERVIEW;
      setImage(content.imageUrl ? { url: content.imageUrl } : null);
      form.reset({
        eyebrow: content.eyebrow,
        title: content.title,
        intro: content.intro,
        description: content.description,
        imageAlt: content.imageAlt,
      });
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load overview",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    try {
      await saveScholarshipPageOverviewContentAdmin({
        eyebrow: values.eyebrow.trim(),
        title: values.title.trim(),
        intro: values.intro.trim(),
        description: values.description.trim(),
        imageUrl: image?.url?.trim() ?? "",
        imageAlt: values.imageAlt.trim(),
      });
      toast.success("Overview section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save overview",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-3xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-3xl">
      <ScholarshipPageAdminBackLink />
      <ScholarshipPageAdminHeader
        title="Overview"
        description="Introduction section below the hero banner."
      />

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <section className="space-y-2">
          <Label htmlFor="eyebrow">Eyebrow</Label>
          <Input id="eyebrow" {...form.register("eyebrow")} />
        </section>
        <section className="space-y-2">
          <Label htmlFor="title">Title</Label>
          <Input id="title" {...form.register("title")} />
        </section>
        <section className="space-y-2">
          <Label htmlFor="intro">Intro</Label>
          <Textarea id="intro" rows={2} {...form.register("intro")} />
        </section>
        <section className="space-y-2">
          <Label htmlFor="description">Description</Label>
          <Textarea id="description" rows={5} {...form.register("description")} />
        </section>
        <section className="space-y-2">
          <Label htmlFor="imageAlt">Image alt text</Label>
          <Input id="imageAlt" {...form.register("imageAlt")} />
        </section>
        <CmsImageUploadField
          label="Section image"
          preset="card4x3"
          folder="cms/scholarship-page/overview"
          storageFileName="overview"
          value={image}
          onChange={setImage}
          pendingPreviewUrl={pendingPreview}
          onPendingPreviewChange={setPendingPreview}
        />
        <ScholarshipPageFormFooter
          end={
            <Button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
