"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { ScholarshipFaqCard } from "@/types/cms";
import {
  createScholarshipFaqCardAdmin,
  deleteScholarshipFaqCardAdmin,
  fetchScholarshipFaqCardsAdmin,
  fetchScholarshipPageFaqHeaderContentAdmin,
  saveScholarshipPageFaqHeaderContentAdmin,
  updateScholarshipFaqCardAdmin,
} from "@/lib/admin-cms-api";
import { DEFAULT_SCHOLARSHIP_PAGE_FAQ_HEADER } from "@/lib/scholarship-page-cms";
import {
  ScholarshipPageAdminBackLink,
  ScholarshipPageAdminHeader,
} from "@/components/admin/scholarship-page/ScholarshipPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const headerSchema = z.object({
  heading: z.string().min(1),
});

const cardSchema = z.object({
  question: z.string().min(1),
  answer: z.string().min(1),
  order: z.string(),
});

type HeaderValues = z.infer<typeof headerSchema>;
type CardFormValues = z.infer<typeof cardSchema>;

export function ScholarshipPageFaqManager() {
  const [loading, setLoading] = useState(true);
  const [savingHeader, setSavingHeader] = useState(false);
  const [savingCard, setSavingCard] = useState(false);
  const [items, setItems] = useState<ScholarshipFaqCard[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ScholarshipFaqCard | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<ScholarshipFaqCard | null>(
    null,
  );

  const headerForm = useForm<HeaderValues>({
    resolver: zodResolver(headerSchema),
    defaultValues: DEFAULT_SCHOLARSHIP_PAGE_FAQ_HEADER,
  });

  const cardForm = useForm<CardFormValues>({
    resolver: zodResolver(cardSchema),
    defaultValues: { question: "", answer: "", order: "0" },
  });

  const loadItems = useCallback(async () => {
    setLoading(true);
    try {
      const [header, cards] = await Promise.all([
        fetchScholarshipPageFaqHeaderContentAdmin(),
        fetchScholarshipFaqCardsAdmin(),
      ]);
      headerForm.reset(header ?? DEFAULT_SCHOLARSHIP_PAGE_FAQ_HEADER);
      setItems(cards);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load FAQs",
      );
    } finally {
      setLoading(false);
    }
  }, [headerForm]);

  useEffect(() => {
    loadItems();
  }, [loadItems]);

  const saveHeader = async (values: HeaderValues) => {
    setSavingHeader(true);
    try {
      await saveScholarshipPageFaqHeaderContentAdmin({
        heading: values.heading.trim(),
      });
      toast.success("FAQ heading saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save heading",
      );
    } finally {
      setSavingHeader(false);
    }
  };

  const openCreate = () => {
    setEditingItem(null);
    cardForm.reset({ question: "", answer: "", order: String(items.length) });
    setDialogOpen(true);
  };

  const openEdit = (item: ScholarshipFaqCard) => {
    setEditingItem(item);
    cardForm.reset({
      question: item.question,
      answer: item.answer,
      order: String(item.order),
    });
    setDialogOpen(true);
  };

  const onSubmitCard = async (values: CardFormValues) => {
    setSavingCard(true);
    try {
      const payload = {
        question: values.question.trim(),
        answer: values.answer.trim(),
        order: Number(values.order) || 0,
      };
      if (editingItem) {
        await updateScholarshipFaqCardAdmin(editingItem.id, payload);
        toast.success("FAQ updated");
      } else {
        await createScholarshipFaqCardAdmin(payload);
        toast.success("FAQ created");
      }
      setDialogOpen(false);
      await loadItems();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save FAQ",
      );
    } finally {
      setSavingCard(false);
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteScholarshipFaqCardAdmin(deleteTarget.id);
      toast.success("FAQ deleted");
      setDeleteTarget(null);
      await loadItems();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete FAQ",
      );
    }
  };

  if (loading) {
    return (
      <section className="max-w-4xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-32 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-4xl">
      <ScholarshipPageAdminBackLink />
      <ScholarshipPageAdminHeader
        title="FAQ"
        description="Accordion questions and answers."
      />

      <form
        onSubmit={headerForm.handleSubmit(saveHeader)}
        className="mb-8 space-y-4 rounded-lg border border-border p-4"
      >
        <p className="text-sm font-medium">Section heading</p>
        <section className="space-y-2">
          <Label htmlFor="heading">Heading</Label>
          <Input id="heading" {...headerForm.register("heading")} />
        </section>
        <Button type="submit" disabled={savingHeader}>
          {savingHeader ? "Saving..." : "Save heading"}
        </Button>
      </form>

      <div className="mb-4 flex justify-end">
        <Button type="button" onClick={openCreate}>
          <Plus className="h-4 w-4 mr-2" />
          Add FAQ
        </Button>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Question</TableHead>
            <TableHead>Order</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {items.map((item) => (
            <TableRow key={item.id}>
              <TableCell className="max-w-md truncate">{item.question}</TableCell>
              <TableCell>{item.order}</TableCell>
              <TableCell className="text-right">
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => openEdit(item)}
                >
                  <Pencil className="h-4 w-4" />
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => setDeleteTarget(item)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingItem ? "Edit FAQ" : "New FAQ"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={cardForm.handleSubmit(onSubmitCard)} className="space-y-4">
            <section className="space-y-2">
              <Label>Question</Label>
              <Input {...cardForm.register("question")} />
            </section>
            <section className="space-y-2">
              <Label>Answer</Label>
              <Textarea rows={4} {...cardForm.register("answer")} />
            </section>
            <section className="space-y-2">
              <Label>Order</Label>
              <Input {...cardForm.register("order")} />
            </section>
            <DialogFooter>
              <Button type="submit" disabled={savingCard}>
                {savingCard ? "Saving..." : "Save FAQ"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={Boolean(deleteTarget)}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete FAQ?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the selected question from the page.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
