"use client";

import { useCallback, useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type {
  ScholarshipPageDetailBlockCms,
  ScholarshipPageIconKey,
} from "@/types/cms";
import { SCHOLARSHIP_PAGE_ICONS } from "@/types/cms";
import {
  fetchScholarshipPageDetailsContentAdmin,
  saveScholarshipPageDetailsContentAdmin,
} from "@/lib/admin-cms-api";
import { DEFAULT_SCHOLARSHIP_PAGE_DETAILS } from "@/lib/scholarship-page-cms";
import {
  ScholarshipPageAdminBackLink,
  ScholarshipPageAdminHeader,
  ScholarshipPageFormFooter,
} from "@/components/admin/scholarship-page/ScholarshipPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export function ScholarshipPageDetailsManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [eyebrow, setEyebrow] = useState(DEFAULT_SCHOLARSHIP_PAGE_DETAILS.eyebrow);
  const [heading, setHeading] = useState(DEFAULT_SCHOLARSHIP_PAGE_DETAILS.heading);
  const [intro, setIntro] = useState(DEFAULT_SCHOLARSHIP_PAGE_DETAILS.intro);
  const [blocks, setBlocks] = useState<ScholarshipPageDetailBlockCms[]>(
    DEFAULT_SCHOLARSHIP_PAGE_DETAILS.blocks,
  );

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchScholarshipPageDetailsContentAdmin();
      const content = data ?? DEFAULT_SCHOLARSHIP_PAGE_DETAILS;
      setEyebrow(content.eyebrow);
      setHeading(content.heading);
      setIntro(content.intro);
      setBlocks(content.blocks);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load details",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const updateBlock = (
    index: number,
    patch: Partial<ScholarshipPageDetailBlockCms>,
  ) => {
    setBlocks((prev) =>
      prev.map((block, i) => (i === index ? { ...block, ...patch } : block)),
    );
  };

  const updateBlockItem = (blockIndex: number, itemIndex: number, value: string) => {
    setBlocks((prev) =>
      prev.map((block, i) => {
        if (i !== blockIndex) return block;
        const items = [...block.items];
        items[itemIndex] = value;
        return { ...block, items };
      }),
    );
  };

  const addBlockItem = (blockIndex: number) => {
    setBlocks((prev) =>
      prev.map((block, i) =>
        i === blockIndex ? { ...block, items: [...block.items, ""] } : block,
      ),
    );
  };

  const removeBlockItem = (blockIndex: number, itemIndex: number) => {
    setBlocks((prev) =>
      prev.map((block, i) => {
        if (i !== blockIndex) return block;
        return {
          ...block,
          items: block.items.filter((_, j) => j !== itemIndex),
        };
      }),
    );
  };

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await saveScholarshipPageDetailsContentAdmin({
        eyebrow: eyebrow.trim(),
        heading: heading.trim(),
        intro: intro.trim(),
        blocks: blocks.map((block) => ({
          ...block,
          title: block.title.trim(),
          body: block.body.trim(),
          items: block.items.map((item) => item.trim()).filter(Boolean),
        })),
      });
      toast.success("Scholarship details saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save details",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-3xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-32 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-3xl">
      <ScholarshipPageAdminBackLink />
      <ScholarshipPageAdminHeader
        title="Scholarship Details"
        description="Alternating detail blocks for eligibility, benefits, and process."
      />

      <form onSubmit={onSubmit} className="space-y-6">
        <section className="space-y-2">
          <Label htmlFor="eyebrow">Section eyebrow</Label>
          <Input id="eyebrow" value={eyebrow} onChange={(e) => setEyebrow(e.target.value)} />
        </section>
        <section className="space-y-2">
          <Label htmlFor="heading">Section heading</Label>
          <Input id="heading" value={heading} onChange={(e) => setHeading(e.target.value)} />
        </section>
        <section className="space-y-2">
          <Label htmlFor="intro">Section intro</Label>
          <Textarea id="intro" rows={2} value={intro} onChange={(e) => setIntro(e.target.value)} />
        </section>

        {blocks.map((block, blockIndex) => (
          <div
            key={block.id}
            className="space-y-4 rounded-lg border border-border p-4"
          >
            <p className="text-sm font-medium">Block {blockIndex + 1}</p>
            <section className="space-y-2">
              <Label>Title</Label>
              <Input
                value={block.title}
                onChange={(e) =>
                  updateBlock(blockIndex, { title: e.target.value })
                }
              />
            </section>
            <section className="space-y-2">
              <Label>Icon</Label>
              <Select
                value={block.icon}
                onValueChange={(v) =>
                  updateBlock(blockIndex, { icon: v as ScholarshipPageIconKey })
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {SCHOLARSHIP_PAGE_ICONS.map((icon) => (
                    <SelectItem key={icon} value={icon}>
                      {icon}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </section>
            <section className="space-y-2">
              <Label>Body</Label>
              <Textarea
                rows={3}
                value={block.body}
                onChange={(e) =>
                  updateBlock(blockIndex, { body: e.target.value })
                }
              />
            </section>
            <section className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Bullet items</Label>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => addBlockItem(blockIndex)}
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add item
                </Button>
              </div>
              {block.items.map((item, itemIndex) => (
                <div key={itemIndex} className="flex gap-2">
                  <Input
                    value={item}
                    onChange={(e) =>
                      updateBlockItem(blockIndex, itemIndex, e.target.value)
                    }
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => removeBlockItem(blockIndex, itemIndex)}
                    aria-label="Remove item"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </section>
          </div>
        ))}

        <ScholarshipPageFormFooter
          end={
            <Button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
