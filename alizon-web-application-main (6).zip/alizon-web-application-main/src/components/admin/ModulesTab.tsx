"use client";

import { useEffect, useState } from "react";
import { MoreHorizontal, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  createProgramModule,
  deleteProgramModule,
  fetchProgramModules,
  syncProgramModuleCount,
} from "@/lib/modules";
import type { ProgramModule } from "@/types/program";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ModuleForm } from "@/components/admin/ModuleForm";
import { ModuleResourcesList } from "@/components/admin/ModuleResourcesList";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export function ModulesTab({ programId }: { programId: string }) {
  const [modules, setModules] = useState<ProgramModule[]>([]);
  const [openForm, setOpenForm] = useState(false);
  const [editTarget, setEditTarget] = useState<ProgramModule | null>(null);

  const load = async () => {
    setModules(await fetchProgramModules(programId));
    await syncProgramModuleCount(programId);
  };

  useEffect(() => {
    void load();
  }, [programId]);

  const onDelete = async (module: ProgramModule) => {
    try {
      await deleteProgramModule(programId, module.id);
      await load();
      toast.success("Module deleted.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Delete failed.");
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">Program Modules</h3>
        <Button onClick={() => { setEditTarget(null); setOpenForm(true); }}>
          <Plus className="mr-2 h-4 w-4" />
          Add Module
        </Button>
      </div>

      <div className="grid gap-3">
        {modules.map((module) => (
          <Card key={module.id}>
            <CardContent className="p-4">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="font-semibold">{module.name}</p>
                  <p className="text-xs text-muted-foreground">{module.code} • {module.lessonCount} lessons</p>
                  <div className="mt-2 flex flex-wrap gap-2">
                    <Badge variant="outline">{module.fileCount} files</Badge>
                    <Badge variant="outline">{module.videoCount} videos</Badge>
                    <Badge variant={module.status === "active" ? "default" : "secondary"}>
                      {module.status}
                    </Badge>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Button size="sm" variant="outline" onClick={() => { setEditTarget(module); setOpenForm(true); }}>
                    Edit
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => void onDelete(module)}>
                    <Trash2 className="mr-1 h-4 w-4" />
                    Delete
                  </Button>
                </div>
              </div>
              <div className="mt-4">
                <ModuleResourcesList programId={programId} module={module} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <ModuleForm
        open={openForm}
        onOpenChange={setOpenForm}
        programId={programId}
        module={editTarget}
        createModuleOverride={async (payload) => {
          const id = await createProgramModule(programId, payload);
          return id;
        }}
        onSaved={load}
      />
    </div>
  );
}
