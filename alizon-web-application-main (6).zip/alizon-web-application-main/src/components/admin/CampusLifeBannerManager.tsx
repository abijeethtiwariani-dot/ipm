"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import {
  fetchCampusLifePageBannerAdmin,
  saveCampusLifePageBannerAdmin,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const statSchema = z.object({
  value: z.string().min(1, "Value is required"),
  label: z.string().min(1, "Label is required"),
});

const formSchema = z.object({
  pageTitle: z.string().min(1, "Page title is required"),
  pageIntro: z.string().min(1, "Page intro is required"),
  stats: z.array(statSchema).length(3),
});

type FormValues = z.infer<typeof formSchema>;

export function CampusLifeBannerManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [primaryImage, setPrimaryImage] = useState<CmsImageUploadValue | null>(
    null,
  );
  const [secondaryImage, setSecondaryImage] =
    useState<CmsImageUploadValue | null>(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      pageTitle: "",
      pageIntro: "",
      stats: [
        { value: "", label: "" },
        { value: "", label: "" },
        { value: "", label: "" },
      ],
    },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchCampusLifePageBannerAdmin();
      form.reset({
        pageTitle: data.pageTitle,
        pageIntro: data.pageIntro,
        stats: [
          data.stats[0] ?? { value: "", label: "" },
          data.stats[1] ?? { value: "", label: "" },
          data.stats[2] ?? { value: "", label: "" },
        ],
      });
      setPrimaryImage(
        data.primaryImageUrl ? { url: data.primaryImageUrl } : null,
      );
      setSecondaryImage(
        data.secondaryImageUrl ? { url: data.secondaryImageUrl } : null,
      );
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load banner",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    void loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    try {
      await saveCampusLifePageBannerAdmin({
        pageTitle: values.pageTitle.trim(),
        pageIntro: values.pageIntro.trim(),
        primaryImageUrl: primaryImage?.url?.trim() ?? "",
        secondaryImageUrl: secondaryImage?.url?.trim() ?? "",
        stats: values.stats.map((s: { value: string; label: string }) => ({
          value: s.value.trim(),
          label: s.label.trim(),
        })),
      });
      toast.success("Page banner saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save banner",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-2xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-24 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-2xl">
      <Button variant="ghost" size="sm" className="mb-4 -ml-2" asChild>
        <Link href="/admin/campus-life">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Campus Life page
        </Link>
      </Button>

      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Page banner
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Title, intro, hero images, and stats shown at the top of the Campus
          Life page. Leave images empty to use built-in placeholders on the
          public site until you upload.
        </p>
      </header>

      <form
        onSubmit={form.handleSubmit(onSubmit)}
        className="space-y-6 bg-card rounded-lg border border-border shadow-sm p-6 md:p-8"
      >
        <div className="space-y-2">
          <Label htmlFor="pageTitle">Page title</Label>
          <Input id="pageTitle" {...form.register("pageTitle")} />
          {form.formState.errors.pageTitle ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.pageTitle.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="pageIntro">Page intro</Label>
          <Textarea id="pageIntro" rows={4} {...form.register("pageIntro")} />
          {form.formState.errors.pageIntro ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.pageIntro.message}
            </p>
          ) : null}
        </div>

        <CmsImageUploadField
          label="Primary hero image (large)"
          preset="heroDesktop"
          folder="cms/campus-life-page/banner"
          storageFileName="primary"
          value={primaryImage}
          onChange={setPrimaryImage}
        />

        <CmsImageUploadField
          label="Secondary hero image"
          preset="card4x3"
          folder="cms/campus-life-page/banner"
          storageFileName="secondary"
          value={secondaryImage}
          onChange={setSecondaryImage}
        />

        <div className="space-y-4">
          <p className="text-sm font-medium text-foreground">Stats (3)</p>
          {[0, 1, 2].map((index) => (
            <div
              key={index}
              className="grid sm:grid-cols-2 gap-4 p-4 rounded-lg border border-border bg-muted/30"
            >
              <div className="space-y-2">
                <Label htmlFor={`stats.${index}.value`}>Stat {index + 1} value</Label>
                <Input
                  id={`stats.${index}.value`}
                  {...form.register(`stats.${index}.value`)}
                />
                {form.formState.errors.stats?.[index]?.value ? (
                  <p className="text-sm text-destructive">
                    {form.formState.errors.stats[index]?.value?.message}
                  </p>
                ) : null}
              </div>
              <div className="space-y-2">
                <Label htmlFor={`stats.${index}.label`}>Stat {index + 1} label</Label>
                <Input
                  id={`stats.${index}.label`}
                  {...form.register(`stats.${index}.label`)}
                />
                {form.formState.errors.stats?.[index]?.label ? (
                  <p className="text-sm text-destructive">
                    {form.formState.errors.stats[index]?.label?.message}
                  </p>
                ) : null}
              </div>
            </div>
          ))}
        </div>

        <Button type="submit" disabled={saving}>
          {saving ? "Saving..." : "Save banner"}
        </Button>
      </form>
    </section>
  );
}
