"use client";

import Link from "next/link";
import { ChevronRight, ImageIcon, Users } from "lucide-react";
import { Card } from "@/components/ui/card";

const sections = [
  {
    title: "Page banner",
    description:
      "Page title, subtitle, and hero banner image at the top of the Faculty & Staff page.",
    href: "/admin/faculties-staff/banner",
    icon: ImageIcon,
  },
  {
    title: "Faculties information",
    description:
      "Faculty members, academic leadership, page statistics, why-learn features, and bottom CTA.",
    href: "/admin/faculties-staff/content",
    icon: Users,
  },
];

export function FacultyStaffHub() {
  return (
    <section>
      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Faculties & Staff page
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Manage content on the public Faculty & Staff page.
        </p>
      </header>

      <div className="grid gap-4 sm:grid-cols-2 max-w-3xl">
        {sections.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.href} href={item.href}>
              <Card className="p-6 h-full border border-border shadow-sm hover:shadow-md transition-shadow card-hover">
                <div className="flex items-start justify-between gap-4">
                  <div className="w-11 h-11 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-1" />
                </div>
                <h2 className="text-lg font-heading font-semibold text-foreground mt-4">
                  {item.title}
                </h2>
                <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                  {item.description}
                </p>
              </Card>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
