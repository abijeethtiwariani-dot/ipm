"use client";

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";
import { createProgramModule, updateProgramModule } from "@/lib/modules";
import {
  DEFAULT_ASSIGNMENT_TOTAL_MARKS,
  MAX_MARKS_CONFIG,
  MIN_MARKS_CONFIG,
} from "@/lib/student-constants";
import type { ProgramModule } from "@/types/program";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ModuleLearningMaterialsEditor,
  persistPendingLearningMaterials,
  type PendingLearningMaterial,
} from "@/components/admin/ModuleLearningMaterialsEditor";

const schema = z.object({
  name: z.string().min(2),
  code: z.string().min(1),
  description: z.string().optional(),
  order: z.coerce.number().min(1),
  status: z.enum(["active", "inactive"]),
  assignmentTotalMarks: z.coerce
    .number()
    .min(MIN_MARKS_CONFIG)
    .max(MAX_MARKS_CONFIG),
});

type Values = z.infer<typeof schema>;

export function ModuleForm({
  open,
  onOpenChange,
  programId,
  module,
  onSaved,
  createModuleOverride,
  updateModuleOverride,
}: {
  open: boolean;
  onOpenChange: (value: boolean) => void;
  programId: string;
  module?: ProgramModule | null;
  onSaved: () => Promise<void>;
  createModuleOverride?: (values: Values) => Promise<string>;
  updateModuleOverride?: (moduleId: string, values: Values) => Promise<void>;
}) {
  const [saving, setSaving] = useState(false);
  const [pendingMaterials, setPendingMaterials] = useState<PendingLearningMaterial[]>([]);

  const form = useForm<Values>({
    resolver: zodResolver(schema),
    defaultValues: {
      name: "",
      code: "",
      description: "",
      order: 1,
      status: "active",
      assignmentTotalMarks: DEFAULT_ASSIGNMENT_TOTAL_MARKS,
    },
  });

  useEffect(() => {
    if (!open) return;
    if (module) {
      form.reset({
        name: module.name,
        code: module.code,
        description: module.description ?? "",
        order: module.order || 1,
        status: module.status,
        assignmentTotalMarks: module.assignmentTotalMarks,
      });
    } else {
      form.reset({
        name: "",
        code: "",
        description: "",
        order: 1,
        status: "active",
        assignmentTotalMarks: DEFAULT_ASSIGNMENT_TOTAL_MARKS,
      });
      setPendingMaterials([]);
    }
  }, [form, module, open]);

  const submit = form.handleSubmit(async (values) => {
    if (saving) return;
    setSaving(true);
    try {
      let moduleId = module?.id ?? "";

      if (module) {
        if (updateModuleOverride) {
          await updateModuleOverride(module.id, values);
        } else {
          await updateProgramModule(programId, module.id, values);
        }
        moduleId = module.id;
      } else {
        if (createModuleOverride) {
          moduleId = await createModuleOverride(values);
        } else {
          moduleId = await createProgramModule(programId, values);
        }
      }

      if (moduleId && pendingMaterials.length > 0) {
        await persistPendingLearningMaterials(programId, moduleId, pendingMaterials);
        setPendingMaterials([]);
      }

      toast.success(module ? "Module updated." : "Module created.");
      onOpenChange(false);
      await onSaved();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Save failed.");
    } finally {
      setSaving(false);
    }
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] max-w-2xl overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{module ? "Edit Module" : "Add Module"}</DialogTitle>
          <DialogDescription className="sr-only">
            Create or update module details and learning materials.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-2">
            <Label>Module Name</Label>
            <Input {...form.register("name")} disabled={saving} />
          </div>
          <div className="space-y-2">
            <Label>Assignment Total Marks</Label>
            <Input
              type="number"
              min={MIN_MARKS_CONFIG}
              max={MAX_MARKS_CONFIG}
              {...form.register("assignmentTotalMarks")}
              disabled={saving}
            />
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label>Module Code</Label>
              <Input {...form.register("code")} disabled={saving} />
            </div>
            <div className="space-y-2">
              <Label>Module Order</Label>
              <Input type="number" min={1} {...form.register("order")} disabled={saving} />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea rows={3} {...form.register("description")} disabled={saving} />
          </div>
          <div className="space-y-2">
            <Label>Status</Label>
            <Select
              value={form.watch("status")}
              onValueChange={(value) => form.setValue("status", value as Values["status"])}
              disabled={saving}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <ModuleLearningMaterialsEditor
            programId={programId}
            moduleId={module?.id}
            pending={pendingMaterials}
            onPendingChange={setPendingMaterials}
            disabled={saving}
          />

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              disabled={saving}
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
