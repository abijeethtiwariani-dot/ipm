"use client";

import Link from "next/link";
import { ChevronRight, Briefcase, UserPlus } from "lucide-react";
import { Card } from "@/components/ui/card";

const sections = [
  {
    title: "Manage Jobs",
    description: "Create, edit, deactivate, and feature open positions.",
    href: "/admin/jobs-portal/jobs",
    icon: Briefcase,
  },
  {
    title: "View Applications",
    description: "Review job applications submitted for open positions.",
    href: "/admin/jobs-portal/applications",
    icon: UserPlus,
  },
];

export function JobsPortalHub() {
  return (
    <section>
      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold">Jobs Portal</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Manage career opportunities and review candidate applications.
        </p>
      </header>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {sections.map((section) => (
          <Link key={section.href} href={section.href}>
            <Card className="group h-full border p-6 transition-shadow hover:shadow-md">
              <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <section.icon className="h-5 w-5" />
              </div>
              <h2 className="text-lg font-semibold group-hover:text-primary">
                {section.title}
              </h2>
              <p className="mt-2 text-sm text-muted-foreground">{section.description}</p>
              <span className="mt-4 inline-flex items-center text-sm font-medium text-primary">
                Open
                <ChevronRight className="ml-1 h-4 w-4" />
              </span>
            </Card>
          </Link>
        ))}
      </div>
    </section>
  );
}
