"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useFieldArray, useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowLeft, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { MAX_CAMPUS_LIFE_GETTING_AROUND_LINKS } from "@/types/cms";
import {
  fetchCampusLifeGettingAroundAdmin,
  saveCampusLifeGettingAroundAdmin,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const linkSchema = z.object({
  label: z.string().min(1, "Label is required"),
  href: z.string().min(1, "Link is required"),
});

const formSchema = z.object({
  sectionHeading: z.string().min(1, "Section heading is required"),
  sectionIntro: z.string().min(1, "Section intro is required"),
  links: z
    .array(linkSchema)
    .min(1, "Add at least one link")
    .max(MAX_CAMPUS_LIFE_GETTING_AROUND_LINKS),
});

type FormValues = z.infer<typeof formSchema>;

export function CampusLifeGettingAroundManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [sectionImage, setSectionImage] = useState<CmsImageUploadValue | null>(
    null,
  );

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      sectionHeading: "",
      sectionIntro: "",
      links: [{ label: "", href: "" }],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "links",
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchCampusLifeGettingAroundAdmin();
      form.reset({
        sectionHeading: data.sectionHeading,
        sectionIntro: data.sectionIntro,
        links:
          data.links.length > 0
            ? data.links.map((l) => ({ label: l.label, href: l.href }))
            : [{ label: "", href: "" }],
      });
      setSectionImage(data.imageUrl ? { url: data.imageUrl } : null);
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : "Failed to load Getting Around section",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    void loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    try {
      await saveCampusLifeGettingAroundAdmin({
        sectionHeading: values.sectionHeading.trim(),
        sectionIntro: values.sectionIntro.trim(),
        imageUrl: sectionImage?.url?.trim() ?? "",
        links: values.links.map((l) => ({
          label: l.label.trim(),
          href: l.href.trim(),
        })),
      });
      toast.success("Getting Around section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save section",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-2xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-24 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-2xl">
      <Button variant="ghost" size="sm" className="mb-4 -ml-2" asChild>
        <Link href="/admin/campus-life">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Campus Life page
        </Link>
      </Button>

      <header className="mb-8">
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Getting Around
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Content for the Getting Around section at the bottom of the Campus Life
          page.
        </p>
      </header>

      <form
        onSubmit={form.handleSubmit(onSubmit)}
        className="space-y-6 bg-card rounded-lg border border-border shadow-sm p-6 md:p-8"
      >
        <div className="space-y-2">
          <Label htmlFor="sectionHeading">Section heading</Label>
          <Input id="sectionHeading" {...form.register("sectionHeading")} />
          {form.formState.errors.sectionHeading ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.sectionHeading.message}
            </p>
          ) : null}
        </div>

        <div className="space-y-2">
          <Label htmlFor="sectionIntro">Section intro</Label>
          <Textarea
            id="sectionIntro"
            rows={5}
            {...form.register("sectionIntro")}
          />
          {form.formState.errors.sectionIntro ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.sectionIntro.message}
            </p>
          ) : null}
        </div>

        <CmsImageUploadField
          label="Section image"
          preset="card4x3"
          folder="cms/campus-life-page/getting-around"
          storageFileName="section"
          value={sectionImage}
          onChange={setSectionImage}
        />

        <div className="space-y-4">
          <div className="flex items-center justify-between gap-4">
            <p className="text-sm font-medium text-foreground">Quick links</p>
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={fields.length >= MAX_CAMPUS_LIFE_GETTING_AROUND_LINKS}
              onClick={() => append({ label: "", href: "" })}
            >
              <Plus className="w-4 h-4 mr-1" />
              Add link
            </Button>
          </div>
          {form.formState.errors.links?.message ? (
            <p className="text-sm text-destructive">
              {form.formState.errors.links.message}
            </p>
          ) : null}
          {fields.map((field, index) => (
            <div
              key={field.id}
              className="grid sm:grid-cols-2 gap-4 p-4 rounded-lg border border-border bg-muted/30 relative"
            >
              <div className="space-y-2 sm:col-span-1">
                <Label htmlFor={`links.${index}.label`}>Link label</Label>
                <Input
                  id={`links.${index}.label`}
                  {...form.register(`links.${index}.label`)}
                />
              </div>
              <div className="space-y-2 sm:col-span-1">
                <Label htmlFor={`links.${index}.href`}>URL</Label>
                <Input
                  id={`links.${index}.href`}
                  placeholder="/about"
                  {...form.register(`links.${index}.href`)}
                />
              </div>
              {fields.length > 1 ? (
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2"
                  onClick={() => remove(index)}
                  aria-label="Remove link"
                >
                  <Trash2 className="w-4 h-4 text-destructive" />
                </Button>
              ) : null}
            </div>
          ))}
        </div>

        <Button type="submit" disabled={saving}>
          {saving ? "Saving..." : "Save section"}
        </Button>
      </form>
    </section>
  );
}
