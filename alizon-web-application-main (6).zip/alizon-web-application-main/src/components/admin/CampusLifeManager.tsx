"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import Image from "next/image";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format } from "date-fns";
import Link from "next/link";
import { ArrowLeft, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { CampusLifeCard, CampusSectionKey } from "@/types/cms";
import {
  CAMPUS_SECTIONS,
  getCampusSectionTitle,
} from "@/types/cms";
import {
  createCampusLifeCard,
  deleteCampusLifeCard,
  ensureCampusLifeCardsMigrated,
  fetchCampusLifeCards,
  updateCampusLifeCard,
  uploadCmsImageUrl,
} from "@/lib/admin-cms-api";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const campusFormSchema = z.object({
  section: z.enum(["studentLife", "artsCulture", "athletics"]),
  title: z.string().min(1, "Title is required"),
  description: z.string().min(10, "Description must be at least 10 characters"),
  link: z.string().min(1, "Link is required"),
  linkText: z.string().min(1, "Link text is required"),
  imageUrl: z.string().optional(),
});

type CampusFormValues = z.infer<typeof campusFormSchema>;

const FILTER_ALL = "all";

function formatUpdatedAt(updatedAt: CampusLifeCard["updatedAt"]): string {
  if (!updatedAt) return "—";
  if (
    typeof updatedAt === "object" &&
    updatedAt !== null &&
    "toDate" in updatedAt &&
    typeof (updatedAt as { toDate: () => Date }).toDate === "function"
  ) {
    return format((updatedAt as { toDate: () => Date }).toDate(), "MMM d, yyyy");
  }
  if (updatedAt instanceof Date) {
    return format(updatedAt, "MMM d, yyyy");
  }
  return "—";
}

export function CampusLifeManager() {
  const [cards, setCards] = useState<CampusLifeCard[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingCard, setEditingCard] = useState<CampusLifeCard | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<CampusLifeCard | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [categoryFilter, setCategoryFilter] = useState<string>(FILTER_ALL);

  const form = useForm<CampusFormValues>({
    resolver: zodResolver(campusFormSchema),
    defaultValues: {
      section: "studentLife",
      title: "",
      description: "",
      link: "/student-login",
      linkText: "",
      imageUrl: "",
    },
  });

  const loadCards = useCallback(async () => {
    setLoading(true);
    try {
      await ensureCampusLifeCardsMigrated();
      const data = await fetchCampusLifeCards();
      setCards(data);
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to load campus life";
      toast.error(message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadCards();
  }, [loadCards]);

  const filteredCards = useMemo(() => {
    if (categoryFilter === FILTER_ALL) return cards;
    return cards.filter((c) => c.section === categoryFilter);
  }, [cards, categoryFilter]);

  const openCreate = () => {
    setEditingCard(null);
    setImageFile(null);
    setImagePreview(null);
    form.reset({
      section:
        categoryFilter !== FILTER_ALL
          ? (categoryFilter as CampusSectionKey)
          : "studentLife",
      title: "",
      description: "",
      link: "/student-login",
      linkText: "",
      imageUrl: "",
    });
    setDialogOpen(true);
  };

  const openEdit = (card: CampusLifeCard) => {
    setEditingCard(card);
    setImageFile(null);
    setImagePreview(card.imageUrl || null);
    form.reset({
      section: card.section,
      title: card.title,
      description: card.description,
      link: card.link,
      linkText: card.linkText,
      imageUrl: card.imageUrl,
    });
    setDialogOpen(true);
  };

  const onSubmit = async (values: CampusFormValues) => {
    const needsImage = !editingCard?.imageUrl && !imageFile;
    if (needsImage) {
      toast.error("Please upload an image");
      return;
    }

    setSaving(true);
    try {
      let imageUrl = values.imageUrl ?? editingCard?.imageUrl ?? "";

      if (imageFile) {
        const cardId = editingCard?.id ?? `new-${Date.now()}`;
        imageUrl = await uploadCmsImageUrl(
          `cms/campus-life/${values.section}/${cardId}/${imageFile.name}`,
          imageFile,
        );
      }

      const payload = {
        section: values.section,
        title: values.title,
        description: values.description,
        link: values.link,
        linkText: values.linkText,
        imageUrl,
      };

      if (editingCard) {
        await updateCampusLifeCard(editingCard.id, payload);
        toast.success("Card updated");
      } else {
        const nextOrder =
          cards.length > 0 ? Math.max(...cards.map((c) => c.order)) + 1 : 0;
        await createCampusLifeCard({ ...payload, order: nextOrder });
        toast.success("Card created");
      }

      setDialogOpen(false);
      await loadCards();
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to save card";
      toast.error(message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteCampusLifeCard(deleteTarget.id);
      toast.success("Card deleted");
      setDeleteTarget(null);
      await loadCards();
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to delete card";
      toast.error(message);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  };

  return (
    <section>
      <Button variant="ghost" size="sm" className="mb-4 -ml-2" asChild>
        <Link href="/admin/campus-life">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Campus Life page
        </Link>
      </Button>
      <header className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-heading font-bold text-foreground">
            Card sections
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Student Life, Arts &amp; Culture, and Athletics cards on the Campus
            Life page.
          </p>
        </div>
        <Button onClick={openCreate}>
          <Plus className="w-4 h-4 mr-2" />
          Add Card
        </Button>
      </header>

      <section className="flex flex-wrap items-end gap-4 mb-6">
        <section className="space-y-2 min-w-[200px]">
          <Label htmlFor="category-filter">Category</Label>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger id="category-filter" className="bg-background">
              <SelectValue placeholder="All categories" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={FILTER_ALL}>All categories</SelectItem>
              {CAMPUS_SECTIONS.map((section) => (
                <SelectItem key={section.key} value={section.key}>
                  {section.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </section>
      </section>

      <section className="bg-card rounded-lg border border-border shadow-sm overflow-hidden">
        {loading ? (
          <section className="p-8 space-y-3">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </section>
        ) : filteredCards.length === 0 ? (
          <p className="p-8 text-sm text-muted-foreground text-center">
            {cards.length === 0
              ? 'No campus life cards yet. Click "Add Card" to create one.'
              : "No cards in this category."}
          </p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead>Title</TableHead>
                <TableHead>Category</TableHead>
                <TableHead className="hidden md:table-cell">
                  Description
                </TableHead>
                <TableHead className="hidden sm:table-cell w-32">
                  Updated
                </TableHead>
                <TableHead className="w-24 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredCards.map((card) => (
                <TableRow key={card.id}>
                  <TableCell className="font-medium max-w-[200px]">
                    <span className="line-clamp-2">{card.title}</span>
                  </TableCell>
                  <TableCell className="text-sm">
                    {getCampusSectionTitle(card.section)}
                  </TableCell>
                  <TableCell className="hidden md:table-cell text-muted-foreground max-w-xs">
                    <span className="line-clamp-2 text-sm">
                      {card.description}
                    </span>
                  </TableCell>
                  <TableCell className="hidden sm:table-cell text-sm text-muted-foreground">
                    {formatUpdatedAt(card.updatedAt)}
                  </TableCell>
                  <TableCell className="text-right">
                    <section className="flex justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEdit(card)}
                        aria-label="Edit"
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteTarget(card)}
                        aria-label="Delete"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </section>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </section>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-background">
          <DialogHeader>
            <DialogTitle className="font-heading text-xl">
              {editingCard ? "Edit Card" : "New Card"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <section className="space-y-2">
              <Label htmlFor="section">
                Category <span className="text-destructive">*</span>
              </Label>
              <Select
                value={form.watch("section")}
                onValueChange={(value) =>
                  form.setValue("section", value as CampusSectionKey)
                }
              >
                <SelectTrigger id="section" className="bg-background">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {CAMPUS_SECTIONS.map((section) => (
                    <SelectItem key={section.key} value={section.key}>
                      {section.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </section>

            <section className="space-y-2">
              <Label htmlFor="image">
                Image <span className="text-destructive">*</span>
              </Label>
              <Input
                id="image"
                type="file"
                accept="image/*"
                onChange={handleImageChange}
              />
              {imagePreview && (
                <section className="relative w-full h-44 rounded-lg overflow-hidden bg-muted border border-border mt-2">
                  <Image
                    src={imagePreview}
                    alt="Preview"
                    fill
                    className="object-cover"
                    unoptimized
                  />
                </section>
              )}
            </section>

            <section className="space-y-2">
              <Label htmlFor="title">
                Title <span className="text-destructive">*</span>
              </Label>
              <Input id="title" {...form.register("title")} />
            </section>

            <section className="space-y-2">
              <Label htmlFor="description">
                Description <span className="text-destructive">*</span>
              </Label>
              <Textarea
                id="description"
                rows={4}
                {...form.register("description")}
              />
            </section>

            <section className="grid sm:grid-cols-2 gap-4">
              <section className="space-y-2">
                <Label htmlFor="link">
                  Link <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="link"
                  {...form.register("link")}
                  placeholder="/student-login"
                />
              </section>
              <section className="space-y-2">
                <Label htmlFor="linkText">
                  Link text <span className="text-destructive">*</span>
                </Label>
                <Input id="linkText" {...form.register("linkText")} />
              </section>
            </section>

            <DialogFooter className="gap-2 sm:gap-0 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving}>
                {saving ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete card?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
