"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import {
  fetchAlumniPageHeroContentAdmin,
  saveAlumniPageHeroContentAdmin,
} from "@/lib/admin-cms-api";
import {
  CmsHeroImagePairField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import {
  AlumniPageAdminBackLink,
  AlumniPageAdminHeader,
  AlumniPageFormFooter,
} from "@/components/admin/alumni-page/AlumniPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z.object({
  title: z.string().min(1, "Title is required"),
  subtitle: z.string(),
  imageAlt: z.string(),
  ctaText: z.string(),
  ctaLink: z.string(),
});

type FormValues = z.infer<typeof formSchema>;

export function AlumniPageHeroManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [desktopImage, setDesktopImage] = useState<CmsImageUploadValue | null>(
    null,
  );
  const [mobileImage, setMobileImage] = useState<CmsImageUploadValue | null>(
    null,
  );
  const [desktopPendingPreview, setDesktopPendingPreview] = useState<
    string | null
  >(null);
  const [mobilePendingPreview, setMobilePendingPreview] = useState<
    string | null
  >(null);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      subtitle: "",
      imageAlt: "",
      ctaText: "",
      ctaLink: "",
    },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchAlumniPageHeroContentAdmin();
      setDesktopImage(
        data?.heroImageUrl ? { url: data.heroImageUrl } : null,
      );
      setMobileImage(
        data?.mobileHeroImageUrl ? { url: data.mobileHeroImageUrl } : null,
      );
      form.reset({
        title: data?.title ?? "",
        subtitle: data?.subtitle ?? "",
        imageAlt: data?.imageAlt ?? "",
        ctaText: data?.ctaText ?? "",
        ctaLink: data?.ctaLink ?? "",
      });
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load hero content",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    try {
      const ctaText = values.ctaText.trim();
      const ctaLink = values.ctaLink.trim();
      await saveAlumniPageHeroContentAdmin({
        title: values.title.trim(),
        subtitle: values.subtitle.trim(),
        heroImageUrl: desktopImage?.url?.trim() ?? "",
        mobileHeroImageUrl: mobileImage?.url?.trim() ?? "",
        imageAlt: values.imageAlt.trim(),
        ctaText: ctaText || undefined,
        ctaLink: ctaLink || undefined,
      });
      toast.success("Hero banner saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save hero banner",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-3xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-40 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-3xl">
      <AlumniPageAdminBackLink />
      <AlumniPageAdminHeader
        title="Alumni Banner"
        description="Title, subtitle, background image, and optional CTA for the alumni page."
      />

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <section className="space-y-2">
          <Label htmlFor="title">Banner title</Label>
          <Input id="title" {...form.register("title")} />
        </section>

        <section className="space-y-2">
          <Label htmlFor="subtitle">Banner subtitle</Label>
          <Textarea id="subtitle" rows={3} {...form.register("subtitle")} />
        </section>

        <section className="space-y-2">
          <Label htmlFor="imageAlt">Image alt text</Label>
          <Input id="imageAlt" {...form.register("imageAlt")} />
        </section>

        <section className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="ctaText">CTA text (optional)</Label>
            <Input id="ctaText" {...form.register("ctaText")} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="ctaLink">CTA link (optional)</Label>
            <Input id="ctaLink" {...form.register("ctaLink")} />
          </div>
        </section>

        <CmsHeroImagePairField
          desktop={desktopImage}
          mobile={mobileImage}
          onDesktopChange={setDesktopImage}
          onMobileChange={setMobileImage}
          folder="cms/alumni-page/hero"
          fileBaseName="banner"
          desktopPendingPreview={desktopPendingPreview}
          mobilePendingPreview={mobilePendingPreview}
          onDesktopPendingPreviewChange={setDesktopPendingPreview}
          onMobilePendingPreviewChange={setMobilePendingPreview}
        />

        <AlumniPageFormFooter
          end={
            <Button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
