"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { AlumniLeader } from "@/types/cms";
import {
  createAlumniLeaderAdmin,
  deleteAlumniLeaderAdmin,
  fetchAlumniLeadershipHeaderContentAdmin,
  fetchAlumniLeadersAdmin,
  saveAlumniLeadershipHeaderContentAdmin,
  updateAlumniLeaderAdmin,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import {
  AlumniPageAdminBackLink,
  AlumniPageAdminHeader,
  AlumniPageFormFooter,
} from "@/components/admin/alumni-page/AlumniPageAdminLayout";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { shouldUnoptimizeCmsSrc } from "@/lib/cms-image-url";

const leaderSchema = z.object({
  name: z.string().min(1, "Name is required"),
  designation: z.string().min(1, "Designation is required"),
  graduationYear: z.string().min(1, "Graduation year is required"),
  department: z.string().min(1, "Department is required"),
  bio: z.string().min(10, "Bio must be at least 10 characters"),
  linkedInUrl: z.string(),
  order: z.coerce.number().min(0),
  published: z.boolean(),
});

const headerSchema = z.object({
  eyebrow: z.string().min(1, "Eyebrow is required"),
  heading: z.string().min(1, "Heading is required"),
  intro: z.string().min(1, "Intro is required"),
});

type LeaderFormValues = z.infer<typeof leaderSchema>;
type HeaderFormValues = z.infer<typeof headerSchema>;

export function AlumniLeadershipManager() {
  const [leaders, setLeaders] = useState<AlumniLeader[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [savingHeader, setSavingHeader] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<AlumniLeader | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<AlumniLeader | null>(null);
  const [leaderImage, setLeaderImage] = useState<CmsImageUploadValue | null>(
    null,
  );

  const form = useForm<LeaderFormValues>({
    resolver: zodResolver(leaderSchema),
    defaultValues: {
      name: "",
      designation: "",
      graduationYear: "",
      department: "",
      bio: "",
      linkedInUrl: "",
      order: 0,
      published: true,
    },
  });

  const headerForm = useForm<HeaderFormValues>({
    resolver: zodResolver(headerSchema),
    defaultValues: {
      eyebrow: "",
      heading: "",
      intro: "",
    },
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [header, leadersData] = await Promise.all([
        fetchAlumniLeadershipHeaderContentAdmin(),
        fetchAlumniLeadersAdmin(),
      ]);
      headerForm.reset({
        eyebrow: header?.eyebrow ?? "",
        heading: header?.heading ?? "",
        intro: header?.intro ?? "",
      });
      setLeaders(leadersData);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load leadership",
      );
    } finally {
      setLoading(false);
    }
  }, [headerForm]);

  useEffect(() => {
    void load();
  }, [load]);

  const saveHeader = async (values: HeaderFormValues) => {
    setSavingHeader(true);
    try {
      await saveAlumniLeadershipHeaderContentAdmin({
        eyebrow: values.eyebrow.trim(),
        heading: values.heading.trim(),
        intro: values.intro.trim(),
      });
      toast.success("Section header saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save section header",
      );
    } finally {
      setSavingHeader(false);
    }
  };

  const openCreate = () => {
    setEditing(null);
    setLeaderImage(null);
    form.reset({
      name: "",
      designation: "",
      graduationYear: "",
      department: "",
      bio: "",
      linkedInUrl: "",
      order:
        leaders.length > 0 ? Math.max(...leaders.map((l) => l.order)) + 1 : 0,
      published: true,
    });
    setDialogOpen(true);
  };

  const openEdit = (leader: AlumniLeader) => {
    setEditing(leader);
    setLeaderImage(leader.imageUrl ? { url: leader.imageUrl } : null);
    form.reset({
      name: leader.name,
      designation: leader.designation,
      graduationYear: leader.graduationYear,
      department: leader.department,
      bio: leader.bio,
      linkedInUrl: leader.linkedInUrl ?? "",
      order: leader.order,
      published: leader.published,
    });
    setDialogOpen(true);
  };

  const onSubmit = async (values: LeaderFormValues) => {
    const imageUrl = leaderImage?.url?.trim() ?? editing?.imageUrl ?? "";
    if (!imageUrl) {
      toast.error("Please upload a profile photo");
      return;
    }

    setSaving(true);
    try {
      const linkedInUrl = values.linkedInUrl.trim();
      const payload = {
        name: values.name.trim(),
        designation: values.designation.trim(),
        graduationYear: values.graduationYear.trim(),
        department: values.department.trim(),
        imageUrl,
        bio: values.bio.trim(),
        linkedInUrl: linkedInUrl || undefined,
        order: values.order,
        published: values.published,
      };

      if (editing) {
        await updateAlumniLeaderAdmin(editing.id, payload);
        toast.success("Leader updated");
      } else {
        await createAlumniLeaderAdmin(payload);
        toast.success("Leader created");
      }
      setDialogOpen(false);
      await load();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save leader",
      );
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteAlumniLeaderAdmin(deleteTarget.id);
      toast.success("Leader deleted");
      setDeleteTarget(null);
      await load();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete",
      );
    }
  };

  return (
    <section>
      <AlumniPageAdminBackLink />
      <AlumniPageAdminHeader
        title="Alumni Leadership"
        description="Manage the leadership section header and profile cards on the public alumni page."
      />

      {loading ? (
        <section className="space-y-4 mb-8">
          <Skeleton className="h-32 w-full" />
        </section>
      ) : (
        <form
          onSubmit={headerForm.handleSubmit(saveHeader)}
          className="mb-8 max-w-3xl space-y-4 rounded-lg border border-border p-5"
        >
          <p className="text-sm font-medium text-foreground">Section header</p>
          <section className="space-y-2">
            <Label htmlFor="eyebrow">Eyebrow label</Label>
            <Input
              id="eyebrow"
              placeholder="e.g. Alumni Network"
              {...headerForm.register("eyebrow")}
            />
          </section>
          <section className="space-y-2">
            <Label htmlFor="heading">Section heading</Label>
            <Input
              id="heading"
              placeholder="e.g. Alumni Leadership"
              {...headerForm.register("heading")}
            />
          </section>
          <section className="space-y-2">
            <Label htmlFor="intro">Section description</Label>
            <Textarea
              id="intro"
              rows={3}
              placeholder="Short supporting text for the leadership section"
              {...headerForm.register("intro")}
            />
          </section>
          <AlumniPageFormFooter
            end={
              <Button type="submit" disabled={savingHeader}>
                {savingHeader ? "Saving..." : "Save header"}
              </Button>
            }
          />
        </form>
      )}

      <header className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <p className="text-sm text-muted-foreground">
          {leaders.length} profile{leaders.length === 1 ? "" : "s"}
        </p>
        <Button onClick={openCreate}>
          <Plus className="w-4 h-4 mr-2" />
          Add leadership member
        </Button>
      </header>

      <section className="bg-card rounded-lg border border-border shadow-sm overflow-hidden">
        {loading ? (
          <section className="p-8 space-y-3">
            <Skeleton className="h-10 w-full" />
          </section>
        ) : leaders.length === 0 ? (
          <p className="p-8 text-sm text-muted-foreground text-center">
            No leadership profiles yet.
          </p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-14">Photo</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Designation</TableHead>
                <TableHead>Order</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {leaders.map((leader) => (
                <TableRow key={leader.id}>
                  <TableCell>
                    {leader.imageUrl ? (
                      <div className="relative w-12 h-9 rounded overflow-hidden border border-border">
                        <Image
                          src={leader.imageUrl}
                          alt=""
                          fill
                          className="object-cover"
                          sizes="48px"
                          unoptimized={shouldUnoptimizeCmsSrc(leader.imageUrl)}
                        />
                      </div>
                    ) : (
                      "—"
                    )}
                  </TableCell>
                  <TableCell className="font-medium">{leader.name}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {leader.designation}
                  </TableCell>
                  <TableCell className="text-sm">{leader.order}</TableCell>
                  <TableCell className="text-sm">
                    {leader.published ? "Published" : "Draft"}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openEdit(leader)}
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setDeleteTarget(leader)}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </section>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editing ? "Edit leadership member" : "Add leadership member"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <CmsImageUploadField
              label="Profile photo"
              preset="alumniLeadership"
              folder={`cms/alumni-leadership/${editing?.id ?? "new"}`}
              storageFileName="photo"
              value={leaderImage}
              onChange={setLeaderImage}
              required
            />

            <div className="space-y-2">
              <Label htmlFor="leader-name">Name</Label>
              <Input id="leader-name" {...form.register("name")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="designation">Designation</Label>
              <Input id="designation" {...form.register("designation")} />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="graduationYear">Graduation year</Label>
                <Input id="graduationYear" {...form.register("graduationYear")} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="leader-dept">Department / program</Label>
                <Input id="leader-dept" {...form.register("department")} />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="leader-bio">Biography</Label>
              <Textarea id="leader-bio" rows={4} {...form.register("bio")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="linkedInUrl">LinkedIn URL (optional)</Label>
              <Input id="linkedInUrl" {...form.register("linkedInUrl")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="leader-order">Display order</Label>
              <Input
                id="leader-order"
                type="number"
                min={0}
                {...form.register("order")}
              />
            </div>
            <label className="flex items-center gap-2 text-sm">
              <Checkbox
                checked={form.watch("published")}
                onCheckedChange={(c) => form.setValue("published", c === true)}
              />
              Published on public page
            </label>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving}>
                {saving ? "Saving…" : editing ? "Update" : "Create"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={Boolean(deleteTarget)}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete leadership profile?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove {deleteTarget?.name} from the alumni leadership
              section.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => void handleDelete()}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
