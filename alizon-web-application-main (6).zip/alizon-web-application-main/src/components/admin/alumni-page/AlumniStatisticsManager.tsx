"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { AlumniPageIconKey, AlumniStatistic } from "@/types/cms";
import { SCHOLARSHIP_PAGE_ICONS } from "@/types/cms";
import {
  createAlumniStatisticAdmin,
  deleteAlumniStatisticAdmin,
  fetchAlumniStatisticsAdmin,
  updateAlumniStatisticAdmin,
} from "@/lib/admin-cms-api";
import {
  AlumniPageAdminBackLink,
  AlumniPageAdminHeader,
} from "@/components/admin/alumni-page/AlumniPageAdminLayout";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const statSchema = z.object({
  title: z.string().min(1, "Title is required"),
  value: z.string().min(1, "Value is required"),
  icon: z.string(),
  counterEnd: z.string(),
  counterSuffix: z.string(),
  order: z.coerce.number().min(0),
});

type StatFormValues = z.infer<typeof statSchema>;

export function AlumniStatisticsManager() {
  const [stats, setStats] = useState<AlumniStatistic[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<AlumniStatistic | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<AlumniStatistic | null>(
    null,
  );

  const form = useForm<StatFormValues>({
    resolver: zodResolver(statSchema),
    defaultValues: {
      title: "",
      value: "",
      icon: "star",
      counterEnd: "",
      counterSuffix: "",
      order: 0,
    },
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setStats(await fetchAlumniStatisticsAdmin());
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load statistics",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const openCreate = () => {
    setEditing(null);
    form.reset({
      title: "",
      value: "",
      icon: "star",
      counterEnd: "",
      counterSuffix: "",
      order: stats.length > 0 ? Math.max(...stats.map((s) => s.order)) + 1 : 0,
    });
    setDialogOpen(true);
  };

  const openEdit = (stat: AlumniStatistic) => {
    setEditing(stat);
    form.reset({
      title: stat.title,
      value: stat.value,
      icon: stat.icon,
      counterEnd:
        stat.counterEnd !== undefined ? String(stat.counterEnd) : "",
      counterSuffix: stat.counterSuffix ?? "",
      order: stat.order,
    });
    setDialogOpen(true);
  };

  const onSubmit = async (values: StatFormValues) => {
    setSaving(true);
    try {
      const counterEndRaw = values.counterEnd.replace(/,/g, "").trim();
      const parsedCounterEnd =
        counterEndRaw !== "" ? Number(counterEndRaw) : Number.NaN;
      const counterEnd =
        Number.isFinite(parsedCounterEnd) && parsedCounterEnd > 0
          ? parsedCounterEnd
          : undefined;

      const payload = {
        title: values.title.trim(),
        value: values.value.trim(),
        icon: values.icon as AlumniPageIconKey,
        counterEnd,
        counterSuffix: values.counterSuffix.trim() || undefined,
        order: values.order,
      };

      if (editing) {
        await updateAlumniStatisticAdmin(editing.id, payload);
        toast.success("Statistic updated");
      } else {
        await createAlumniStatisticAdmin(payload);
        toast.success("Statistic created");
      }
      setDialogOpen(false);
      await load();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save statistic",
      );
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteAlumniStatisticAdmin(deleteTarget.id);
      toast.success("Statistic deleted");
      setDeleteTarget(null);
      await load();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete",
      );
    }
  };

  return (
    <section>
      <AlumniPageAdminBackLink />
      <AlumniPageAdminHeader
        title="Alumni Impact Statistics"
        description="Animated statistics for the Alumni Success & Impact section."
      />

      <header className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <p className="text-sm text-muted-foreground">
          {stats.length} statistic{stats.length === 1 ? "" : "s"}
        </p>
        <Button onClick={openCreate}>
          <Plus className="w-4 h-4 mr-2" />
          Add statistic
        </Button>
      </header>

      <section className="bg-card rounded-lg border border-border shadow-sm overflow-hidden">
        {loading ? (
          <section className="p-8 space-y-3">
            <Skeleton className="h-10 w-full" />
          </section>
        ) : stats.length === 0 ? (
          <p className="p-8 text-sm text-muted-foreground text-center">
            No statistics yet.
          </p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Value</TableHead>
                <TableHead>Icon</TableHead>
                <TableHead>Order</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {stats.map((stat) => (
                <TableRow key={stat.id}>
                  <TableCell className="font-medium">{stat.title}</TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {stat.value}
                  </TableCell>
                  <TableCell className="text-sm">{stat.icon}</TableCell>
                  <TableCell className="text-sm">{stat.order}</TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openEdit(stat)}
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setDeleteTarget(stat)}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </section>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editing ? "Edit statistic" : "Add statistic"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="stat-title">Title</Label>
              <Input id="stat-title" {...form.register("title")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="stat-value">Display value</Label>
              <Input
                id="stat-value"
                placeholder="e.g. 100,000+ (used when counter end is empty)"
                {...form.register("value")}
              />
            </div>
            <div className="space-y-2">
              <Label>Icon</Label>
              <Select
                value={form.watch("icon")}
                onValueChange={(value) => form.setValue("icon", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select icon" />
                </SelectTrigger>
                <SelectContent>
                  {SCHOLARSHIP_PAGE_ICONS.map((icon) => (
                    <SelectItem key={icon} value={icon}>
                      {icon}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="counterEnd">Counter end (optional)</Label>
                <Input
                  id="counterEnd"
                  placeholder="e.g. 100000 (numbers only, no commas)"
                  {...form.register("counterEnd")}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="counterSuffix">Counter suffix (optional)</Label>
                <Input id="counterSuffix" {...form.register("counterSuffix")} />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="stat-order">Display order</Label>
              <Input
                id="stat-order"
                type="number"
                min={0}
                {...form.register("order")}
              />
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving}>
                {saving ? "Saving…" : editing ? "Update" : "Create"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={Boolean(deleteTarget)}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete statistic?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove {deleteTarget?.title} from the alumni page.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => void handleDelete()}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
