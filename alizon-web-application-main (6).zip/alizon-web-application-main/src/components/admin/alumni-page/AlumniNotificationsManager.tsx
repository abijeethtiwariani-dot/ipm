"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { AlumniNotification } from "@/types/cms";
import {
  createAlumniNotificationAdmin,
  deleteAlumniNotificationAdmin,
  fetchAlumniNotificationsAdmin,
  fetchAlumniNotificationsHeaderContentAdmin,
  saveAlumniNotificationsHeaderContentAdmin,
  updateAlumniNotificationAdmin,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import {
  AlumniPageAdminBackLink,
  AlumniPageAdminHeader,
  AlumniPageFormFooter,
} from "@/components/admin/alumni-page/AlumniPageAdminLayout";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { shouldUnoptimizeCmsSrc } from "@/lib/cms-image-url";

const notificationSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  eventDate: z.string().min(1, "Event date is required"),
  linkUrl: z.string(),
  order: z.coerce.number().min(0),
  published: z.boolean(),
});

const headerSchema = z.object({
  heading: z.string().min(1, "Heading is required"),
  intro: z.string().min(1, "Intro is required"),
});

type NotificationFormValues = z.infer<typeof notificationSchema>;
type HeaderFormValues = z.infer<typeof headerSchema>;

export function AlumniNotificationsManager() {
  const [notifications, setNotifications] = useState<AlumniNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [savingHeader, setSavingHeader] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<AlumniNotification | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<AlumniNotification | null>(
    null,
  );
  const [notificationImage, setNotificationImage] =
    useState<CmsImageUploadValue | null>(null);

  const form = useForm<NotificationFormValues>({
    resolver: zodResolver(notificationSchema),
    defaultValues: {
      title: "",
      description: "",
      eventDate: "",
      linkUrl: "",
      order: 0,
      published: true,
    },
  });

  const headerForm = useForm<HeaderFormValues>({
    resolver: zodResolver(headerSchema),
    defaultValues: {
      heading: "",
      intro: "",
    },
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [header, notificationsData] = await Promise.all([
        fetchAlumniNotificationsHeaderContentAdmin(),
        fetchAlumniNotificationsAdmin(),
      ]);
      headerForm.reset({
        heading: header?.heading ?? "",
        intro: header?.intro ?? "",
      });
      setNotifications(notificationsData);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load notifications",
      );
    } finally {
      setLoading(false);
    }
  }, [headerForm]);

  useEffect(() => {
    void load();
  }, [load]);

  const saveHeader = async (values: HeaderFormValues) => {
    setSavingHeader(true);
    try {
      await saveAlumniNotificationsHeaderContentAdmin({
        heading: values.heading.trim(),
        intro: values.intro.trim(),
      });
      toast.success("Section header saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save section header",
      );
    } finally {
      setSavingHeader(false);
    }
  };

  const openCreate = () => {
    setEditing(null);
    setNotificationImage(null);
    form.reset({
      title: "",
      description: "",
      eventDate: "",
      linkUrl: "",
      order:
        notifications.length > 0
          ? Math.max(...notifications.map((n) => n.order)) + 1
          : 0,
      published: true,
    });
    setDialogOpen(true);
  };

  const openEdit = (notification: AlumniNotification) => {
    setEditing(notification);
    setNotificationImage(
      notification.imageUrl ? { url: notification.imageUrl } : null,
    );
    form.reset({
      title: notification.title,
      description: notification.description,
      eventDate: notification.eventDate,
      linkUrl: notification.linkUrl,
      order: notification.order,
      published: notification.published,
    });
    setDialogOpen(true);
  };

  const onSubmit = async (values: NotificationFormValues) => {
    const imageUrl =
      notificationImage?.url?.trim() ?? editing?.imageUrl ?? "";
    if (!imageUrl) {
      toast.error("Please upload a notification image");
      return;
    }

    setSaving(true);
    try {
      const payload = {
        title: values.title.trim(),
        description: values.description.trim(),
        imageUrl,
        eventDate: values.eventDate.trim(),
        linkUrl: values.linkUrl.trim(),
        order: values.order,
        published: values.published,
      };

      if (editing) {
        await updateAlumniNotificationAdmin(editing.id, payload);
        toast.success("Notification updated");
      } else {
        await createAlumniNotificationAdmin(payload);
        toast.success("Notification created");
      }
      setDialogOpen(false);
      await load();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save notification",
      );
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteAlumniNotificationAdmin(deleteTarget.id);
      toast.success("Notification deleted");
      setDeleteTarget(null);
      await load();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete",
      );
    }
  };

  return (
    <section>
      <AlumniPageAdminBackLink />
      <AlumniPageAdminHeader
        title="Alumni Notifications"
        description="Manage the notifications section header and announcement cards on the public alumni page."
      />

      {loading ? (
        <section className="space-y-4 mb-8">
          <Skeleton className="h-32 w-full" />
        </section>
      ) : (
        <form
          onSubmit={headerForm.handleSubmit(saveHeader)}
          className="mb-8 max-w-3xl space-y-4 rounded-lg border border-border p-5"
        >
          <p className="text-sm font-medium text-foreground">Section header</p>
          <section className="space-y-2">
            <Label htmlFor="notifications-heading">Section heading</Label>
            <Input
              id="notifications-heading"
              placeholder="e.g. Alumni Notifications"
              {...headerForm.register("heading")}
            />
          </section>
          <section className="space-y-2">
            <Label htmlFor="notifications-intro">Section description</Label>
            <Textarea
              id="notifications-intro"
              rows={3}
              placeholder="Short supporting text for the notifications section"
              {...headerForm.register("intro")}
            />
          </section>
          <AlumniPageFormFooter
            end={
              <Button type="submit" disabled={savingHeader}>
                {savingHeader ? "Saving..." : "Save header"}
              </Button>
            }
          />
        </form>
      )}

      <header className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <p className="text-sm text-muted-foreground">
          {notifications.length} notification
          {notifications.length === 1 ? "" : "s"}
        </p>
        <Button onClick={openCreate}>
          <Plus className="w-4 h-4 mr-2" />
          Add notification
        </Button>
      </header>

      <section className="bg-card rounded-lg border border-border shadow-sm overflow-hidden">
        {loading ? (
          <section className="p-8 space-y-3">
            <Skeleton className="h-10 w-full" />
          </section>
        ) : notifications.length === 0 ? (
          <p className="p-8 text-sm text-muted-foreground text-center">
            No notifications yet.
          </p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-14">Image</TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {notifications.map((notification) => (
                <TableRow key={notification.id}>
                  <TableCell>
                    {notification.imageUrl ? (
                      <div className="relative w-12 h-9 rounded overflow-hidden border border-border">
                        <Image
                          src={notification.imageUrl}
                          alt=""
                          fill
                          className="object-cover"
                          sizes="48px"
                          unoptimized={shouldUnoptimizeCmsSrc(
                            notification.imageUrl,
                          )}
                        />
                      </div>
                    ) : (
                      "—"
                    )}
                  </TableCell>
                  <TableCell className="font-medium">
                    {notification.title}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {notification.eventDate}
                  </TableCell>
                  <TableCell className="text-sm">
                    {notification.published ? "Published" : "Draft"}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openEdit(notification)}
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setDeleteTarget(notification)}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </section>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editing ? "Edit notification" : "Add notification"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <CmsImageUploadField
              label="Notification image"
              preset="alumniNotification"
              folder={`cms/alumni-notifications/${editing?.id ?? "new"}`}
              storageFileName="image"
              value={notificationImage}
              onChange={setNotificationImage}
              required
            />

            <div className="space-y-2">
              <Label htmlFor="notification-title">Title</Label>
              <Input id="notification-title" {...form.register("title")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="notification-description">Description</Label>
              <Textarea
                id="notification-description"
                rows={3}
                {...form.register("description")}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="eventDate">Event date</Label>
              <Input id="eventDate" {...form.register("eventDate")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="linkUrl">Read more link</Label>
              <Input id="linkUrl" {...form.register("linkUrl")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="notification-order">Display order</Label>
              <Input
                id="notification-order"
                type="number"
                min={0}
                {...form.register("order")}
              />
            </div>
            <label className="flex items-center gap-2 text-sm">
              <Checkbox
                checked={form.watch("published")}
                onCheckedChange={(c) => form.setValue("published", c === true)}
              />
              Published on public page
            </label>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving}>
                {saving ? "Saving…" : editing ? "Update" : "Create"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={Boolean(deleteTarget)}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete notification?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove {deleteTarget?.title} from the alumni page.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => void handleDelete()}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
