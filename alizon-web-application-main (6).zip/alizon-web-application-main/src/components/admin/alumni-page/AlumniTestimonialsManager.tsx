"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { AlumniTestimonial } from "@/types/cms";
import {
  createAlumniTestimonialAdmin,
  deleteAlumniTestimonialAdmin,
  fetchAlumniTestimonialsAdmin,
  updateAlumniTestimonialAdmin,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import {
  AlumniPageAdminBackLink,
  AlumniPageAdminHeader,
} from "@/components/admin/alumni-page/AlumniPageAdminLayout";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { shouldUnoptimizeCmsSrc } from "@/lib/cms-image-url";

const testimonialSchema = z.object({
  name: z.string().min(1, "Name is required"),
  graduationYear: z.string().min(1, "Graduation year is required"),
  currentRole: z.string().min(1, "Current role is required"),
  testimonial: z.string().min(10, "Testimonial must be at least 10 characters"),
  order: z.coerce.number().min(0),
});

type TestimonialFormValues = z.infer<typeof testimonialSchema>;

export function AlumniTestimonialsManager() {
  const [testimonials, setTestimonials] = useState<AlumniTestimonial[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<AlumniTestimonial | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<AlumniTestimonial | null>(
    null,
  );
  const [photo, setPhoto] = useState<CmsImageUploadValue | null>(null);

  const form = useForm<TestimonialFormValues>({
    resolver: zodResolver(testimonialSchema),
    defaultValues: {
      name: "",
      graduationYear: "",
      currentRole: "",
      testimonial: "",
      order: 0,
    },
  });

  const load = useCallback(async () => {
    setLoading(true);
    try {
      setTestimonials(await fetchAlumniTestimonialsAdmin());
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load testimonials",
      );
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  const openCreate = () => {
    setEditing(null);
    setPhoto(null);
    form.reset({
      name: "",
      graduationYear: "",
      currentRole: "",
      testimonial: "",
      order:
        testimonials.length > 0
          ? Math.max(...testimonials.map((t) => t.order)) + 1
          : 0,
    });
    setDialogOpen(true);
  };

  const openEdit = (testimonial: AlumniTestimonial) => {
    setEditing(testimonial);
    setPhoto(testimonial.photoUrl ? { url: testimonial.photoUrl } : null);
    form.reset({
      name: testimonial.name,
      graduationYear: testimonial.graduationYear,
      currentRole: testimonial.currentRole,
      testimonial: testimonial.testimonial,
      order: testimonial.order,
    });
    setDialogOpen(true);
  };

  const onSubmit = async (values: TestimonialFormValues) => {
    const photoUrl = photo?.url?.trim() ?? editing?.photoUrl ?? "";
    if (!photoUrl) {
      toast.error("Please upload an alumni photo");
      return;
    }

    setSaving(true);
    try {
      const payload = {
        name: values.name.trim(),
        photoUrl,
        graduationYear: values.graduationYear.trim(),
        currentRole: values.currentRole.trim(),
        testimonial: values.testimonial.trim(),
        order: values.order,
      };

      if (editing) {
        await updateAlumniTestimonialAdmin(editing.id, payload);
        toast.success("Testimonial updated");
      } else {
        await createAlumniTestimonialAdmin(payload);
        toast.success("Testimonial created");
      }
      setDialogOpen(false);
      await load();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save testimonial",
      );
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteAlumniTestimonialAdmin(deleteTarget.id);
      toast.success("Testimonial deleted");
      setDeleteTarget(null);
      await load();
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to delete",
      );
    }
  };

  return (
    <section>
      <AlumniPageAdminBackLink />
      <AlumniPageAdminHeader
        title="Alumni Testimonials"
        description="Manage testimonial cards for the alumni page carousel."
      />

      <header className="flex flex-wrap items-center justify-between gap-4 mb-6">
        <p className="text-sm text-muted-foreground">
          {testimonials.length} testimonial
          {testimonials.length === 1 ? "" : "s"}
        </p>
        <Button onClick={openCreate}>
          <Plus className="w-4 h-4 mr-2" />
          Add testimonial
        </Button>
      </header>

      <section className="bg-card rounded-lg border border-border shadow-sm overflow-hidden">
        {loading ? (
          <section className="p-8 space-y-3">
            <Skeleton className="h-10 w-full" />
          </section>
        ) : testimonials.length === 0 ? (
          <p className="p-8 text-sm text-muted-foreground text-center">
            No testimonials yet.
          </p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-14">Photo</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>Order</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {testimonials.map((testimonial) => (
                <TableRow key={testimonial.id}>
                  <TableCell>
                    {testimonial.photoUrl ? (
                      <div className="relative w-10 h-10 rounded-full overflow-hidden border border-border">
                        <Image
                          src={testimonial.photoUrl}
                          alt=""
                          fill
                          className="object-cover"
                          sizes="40px"
                          unoptimized={shouldUnoptimizeCmsSrc(
                            testimonial.photoUrl,
                          )}
                        />
                      </div>
                    ) : (
                      "—"
                    )}
                  </TableCell>
                  <TableCell className="font-medium">
                    {testimonial.name}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {testimonial.currentRole}
                  </TableCell>
                  <TableCell className="text-sm">{testimonial.order}</TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openEdit(testimonial)}
                    >
                      <Pencil className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setDeleteTarget(testimonial)}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </section>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editing ? "Edit testimonial" : "Add testimonial"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <CmsImageUploadField
              label="Alumni photo"
              preset="alumniTestimonial"
              folder={`cms/alumni-testimonials/${editing?.id ?? "new"}`}
              storageFileName="photo"
              value={photo}
              onChange={setPhoto}
              required
            />

            <div className="space-y-2">
              <Label htmlFor="testimonial-name">Name</Label>
              <Input id="testimonial-name" {...form.register("name")} />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="testimonial-year">Graduation year</Label>
                <Input
                  id="testimonial-year"
                  {...form.register("graduationYear")}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="currentRole">Current position</Label>
                <Input id="currentRole" {...form.register("currentRole")} />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="testimonial-text">Testimonial</Label>
              <Textarea
                id="testimonial-text"
                rows={4}
                {...form.register("testimonial")}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="testimonial-order">Display order</Label>
              <Input
                id="testimonial-order"
                type="number"
                min={0}
                {...form.register("order")}
              />
            </div>
            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving}>
                {saving ? "Saving…" : editing ? "Update" : "Create"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={Boolean(deleteTarget)}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete testimonial?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove {deleteTarget?.name} from the alumni page.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => void handleDelete()}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
