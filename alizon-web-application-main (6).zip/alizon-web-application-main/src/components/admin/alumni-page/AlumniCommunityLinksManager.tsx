"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import {
  fetchAlumniCommunityLinksContentAdmin,
  saveAlumniCommunityLinksContentAdmin,
} from "@/lib/admin-cms-api";
import {
  AlumniPageAdminBackLink,
  AlumniPageAdminHeader,
  AlumniPageFormFooter,
} from "@/components/admin/alumni-page/AlumniPageAdminLayout";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";

const formSchema = z.object({
  whatsappGroupName: z.string(),
  whatsappDescription: z.string(),
  whatsappGroupLink: z.string(),
  telegramGroupName: z.string(),
  telegramDescription: z.string(),
  telegramGroupLink: z.string(),
});

type FormValues = z.infer<typeof formSchema>;

export function AlumniCommunityLinksManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      whatsappGroupName: "",
      whatsappDescription: "",
      whatsappGroupLink: "",
      telegramGroupName: "",
      telegramDescription: "",
      telegramGroupLink: "",
    },
  });

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchAlumniCommunityLinksContentAdmin();
      form.reset({
        whatsappGroupName: data?.whatsapp.groupName ?? "",
        whatsappDescription: data?.whatsapp.description ?? "",
        whatsappGroupLink: data?.whatsapp.groupLink ?? "",
        telegramGroupName: data?.telegram.groupName ?? "",
        telegramDescription: data?.telegram.description ?? "",
        telegramGroupLink: data?.telegram.groupLink ?? "",
      });
    } catch (error) {
      toast.error(
        error instanceof Error
          ? error.message
          : "Failed to load community links",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    try {
      await saveAlumniCommunityLinksContentAdmin({
        whatsapp: {
          groupName: values.whatsappGroupName.trim(),
          description: values.whatsappDescription.trim(),
          groupLink: values.whatsappGroupLink.trim(),
        },
        telegram: {
          groupName: values.telegramGroupName.trim(),
          description: values.telegramDescription.trim(),
          groupLink: values.telegramGroupLink.trim(),
        },
      });
      toast.success("Community links saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save community links",
      );
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <section className="max-w-3xl space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-40 w-full" />
      </section>
    );
  }

  return (
    <section className="max-w-3xl">
      <AlumniPageAdminBackLink />
      <AlumniPageAdminHeader
        title="Community Join Links"
        description="WhatsApp and Telegram group details for the alumni community section."
      />

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
        <section className="space-y-4 rounded-lg border border-border p-5">
          <h2 className="font-heading font-semibold text-foreground">
            WhatsApp group
          </h2>
          <div className="space-y-2">
            <Label htmlFor="whatsappGroupName">Group name</Label>
            <Input id="whatsappGroupName" {...form.register("whatsappGroupName")} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="whatsappDescription">Description</Label>
            <Textarea
              id="whatsappDescription"
              rows={3}
              {...form.register("whatsappDescription")}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="whatsappGroupLink">Group link</Label>
            <Input id="whatsappGroupLink" {...form.register("whatsappGroupLink")} />
          </div>
        </section>

        <section className="space-y-4 rounded-lg border border-border p-5">
          <h2 className="font-heading font-semibold text-foreground">
            Telegram group
          </h2>
          <div className="space-y-2">
            <Label htmlFor="telegramGroupName">Group name</Label>
            <Input id="telegramGroupName" {...form.register("telegramGroupName")} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="telegramDescription">Description</Label>
            <Textarea
              id="telegramDescription"
              rows={3}
              {...form.register("telegramDescription")}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="telegramGroupLink">Group link</Label>
            <Input id="telegramGroupLink" {...form.register("telegramGroupLink")} />
          </div>
        </section>

        <AlumniPageFormFooter
          end={
            <Button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save changes"}
            </Button>
          }
        />
      </form>
    </section>
  );
}
