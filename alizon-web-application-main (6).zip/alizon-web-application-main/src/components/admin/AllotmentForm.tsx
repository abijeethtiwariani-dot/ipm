"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format, parseISO } from "date-fns";
import { ArrowLeft, CalendarIcon, Loader2, Trash2, Upload } from "lucide-react";
import { toast } from "sonner";
import {
  apiCreateAllotment,
  apiDeleteAllotmentFile,
  apiFetchAdminAllotment,
  apiFetchAllotmentCategories,
  apiUpdateAllotment,
  apiUploadAllotmentFile,
} from "@/lib/admin-allotment-api";
import { isLikelyGoogleDriveUrl, isValidHttpsUrl, slugifyAllotmentTitle } from "@/lib/allotments";
import type { AllotmentFile } from "@/types/allotment";
import { ALLOTMENT_STATUSES } from "@/types/allotment";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";

const schema = z.object({
  title: z.string().min(1, "Title is required"),
  slug: z.string().min(1, "Slug is required"),
  categoryId: z.string().min(1, "Category is required"),
  shortDescription: z.string().min(1, "Short description is required"),
  status: z.enum(["active", "upcoming", "closed"]),
  publishDate: z.string(),
  updatedDate: z.string(),
  featured: z.boolean(),
  sortOrder: z.coerce.number().int().min(0),
  googleDriveUrl: z.string(),
});

type FormValues = z.infer<typeof schema>;

function dateToIso(date: Date | undefined): string {
  if (!date) return "";
  return format(date, "yyyy-MM-dd");
}

function parseDateField(value: string): Date | undefined {
  if (!value) return undefined;
  try {
    return parseISO(value);
  } catch {
    return undefined;
  }
}

export function AllotmentForm({ allotmentId }: { allotmentId?: string }) {
  const router = useRouter();
  const isEdit = Boolean(allotmentId);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(isEdit);
  const [categories, setCategories] = useState<{ id: string; name: string }[]>([]);
  const [files, setFiles] = useState<AllotmentFile[]>([]);
  const [uploading, setUploading] = useState(false);
  const [driveWarning, setDriveWarning] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      title: "",
      slug: "",
      categoryId: "",
      shortDescription: "",
      status: "active",
      publishDate: dateToIso(new Date()),
      updatedDate: dateToIso(new Date()),
      featured: false,
      sortOrder: 0,
      googleDriveUrl: "",
    },
  });

  const title = form.watch("title");
  const googleDriveUrl = form.watch("googleDriveUrl");

  useEffect(() => {
    if (!isEdit && title) {
      form.setValue("slug", slugifyAllotmentTitle(title));
    }
  }, [title, isEdit, form]);

  useEffect(() => {
    const url = googleDriveUrl.trim();
    setDriveWarning(Boolean(url) && !isLikelyGoogleDriveUrl(url) && isValidHttpsUrl(url));
  }, [googleDriveUrl]);

  const loadCategories = useCallback(async () => {
    const cats = await apiFetchAllotmentCategories();
    setCategories(cats.map((c) => ({ id: c.id, name: c.name })));
  }, []);

  useEffect(() => {
    void loadCategories();
  }, [loadCategories]);

  useEffect(() => {
    if (!allotmentId) return;
    void (async () => {
      setLoading(true);
      try {
        const data = await apiFetchAdminAllotment(allotmentId);
        if (!data) {
          toast.error("Allotment not found.");
          router.replace("/admin/allotment/list");
          return;
        }
        form.reset({
          title: data.title,
          slug: data.slug,
          categoryId: data.categoryId,
          shortDescription: data.shortDescription,
          status: data.status,
          publishDate: data.publishDate,
          updatedDate: data.updatedDate,
          featured: data.featured,
          sortOrder: data.sortOrder,
          googleDriveUrl: data.googleDriveUrl ?? "",
        });
        setFiles(data.files ?? []);
      } catch (error) {
        toast.error(error instanceof Error ? error.message : "Failed to load.");
      } finally {
        setLoading(false);
      }
    })();
  }, [allotmentId, form, router]);

  const onSubmit = form.handleSubmit(async (values) => {
    const drive = values.googleDriveUrl.trim();
    if (drive && !isValidHttpsUrl(drive)) {
      toast.error("Google Drive URL must be a valid http(s) URL.");
      return;
    }

    if (saving) return;

    setSaving(true);
    try {
      const payload = {
        ...values,
        googleDriveUrl: drive || null,
      };

      if (isEdit && allotmentId) {
        await apiUpdateAllotment(allotmentId, payload);
        toast.success("Allotment saved.");
        setSaving(false);
      } else {
        const created = await apiCreateAllotment(payload);
        toast.success("Allotment created.");
        router.replace(`/admin/allotment/${created.id}/edit`);
      }
    } catch (error) {
      setSaving(false);
      toast.error(error instanceof Error ? error.message : "Save failed.");
    }
  });

  const onFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !allotmentId) {
      if (!allotmentId) toast.error("Save the allotment first, then upload files.");
      return;
    }
    setUploading(true);
    try {
      const uploaded = await apiUploadAllotmentFile(allotmentId, file);
      setFiles((prev) => [...prev, uploaded]);
      toast.success("File uploaded.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Upload failed.");
    } finally {
      setUploading(false);
      event.target.value = "";
    }
  };

  const onRemoveFile = async (fileId: string) => {
    if (!allotmentId) return;
    try {
      await apiDeleteAllotmentFile(allotmentId, fileId);
      setFiles((prev) => prev.filter((f) => f.id !== fileId));
      toast.success("File removed.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Remove failed.");
    }
  };

  if (loading) {
    return (
      <div className="flex min-h-[40vh] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl space-y-6 pb-12">
      <div>
        <Button variant="ghost" size="sm" asChild className="mb-2 -ml-2">
          <Link href="/admin/allotment">
            <ArrowLeft className="mr-1 h-4 w-4" />
            Allotment
          </Link>
        </Button>
        <h1 className="text-3xl font-heading font-bold">
          {isEdit ? "Edit allotment" : "Create allotment"}
        </h1>
      </div>

      <form onSubmit={onSubmit} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Basic information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Allotment title *</Label>
              <Input id="title" {...form.register("title")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="slug">Slug</Label>
              <Input id="slug" {...form.register("slug")} />
            </div>
            <div className="space-y-2">
              <Label>Category *</Label>
              <Select
                value={form.watch("categoryId")}
                onValueChange={(v) => form.setValue("categoryId", v)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="shortDescription">Short description *</Label>
              <Textarea id="shortDescription" rows={3} {...form.register("shortDescription")} />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Status & dates</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2 sm:col-span-2">
              <Label>Status</Label>
              <Select
                value={form.watch("status")}
                onValueChange={(v) =>
                  form.setValue("status", v as FormValues["status"])
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ALLOTMENT_STATUSES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {s}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <DateField
              label="Publish date"
              value={form.watch("publishDate")}
              onChange={(d) => form.setValue("publishDate", dateToIso(d))}
            />
            <DateField
              label="Last updated date"
              value={form.watch("updatedDate")}
              onChange={(d) => form.setValue("updatedDate", dateToIso(d))}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Links & attachments</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="googleDriveUrl">Google Drive URL</Label>
              <Input
                id="googleDriveUrl"
                placeholder="https://drive.google.com/..."
                {...form.register("googleDriveUrl")}
              />
              <p className="text-xs text-muted-foreground">
                Paste a shared Drive folder or file link. Visitors can open this directly from the
                allotment listing.
              </p>
              {driveWarning && (
                <p className="text-xs text-warning">
                  URL does not look like a standard Google Drive link, but it will still work if
                  valid.
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label>Upload documents (PDF, DOC, DOCX)</Label>
              <div className="flex items-center gap-3">
                <Button type="button" variant="outline" disabled={uploading || !isEdit} asChild>
                  <label className="cursor-pointer">
                    <Upload className="mr-2 h-4 w-4" />
                    {uploading ? "Uploading…" : "Choose file"}
                    <input
                      type="file"
                      className="sr-only"
                      accept=".pdf,.doc,.docx"
                      onChange={(e) => void onFileUpload(e)}
                      disabled={!isEdit}
                    />
                  </label>
                </Button>
                {!isEdit && (
                  <span className="text-xs text-muted-foreground">Save first to enable uploads.</span>
                )}
              </div>
              <ul className="space-y-2">
                {files.map((file) => (
                  <li
                    key={file.id}
                    className="flex items-center justify-between rounded-md border px-3 py-2 text-sm"
                  >
                    <a href={file.url} target="_blank" rel="noopener noreferrer" className="truncate hover:underline">
                      {file.fileName}
                    </a>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => void onRemoveFile(file.id)}
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Display</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <label className="flex items-center gap-2 text-sm">
              <Checkbox
                checked={form.watch("featured")}
                onCheckedChange={(v) => form.setValue("featured", Boolean(v))}
              />
              Featured allotment
            </label>
            <div className="space-y-2">
              <Label htmlFor="sortOrder">Sort order</Label>
              <Input id="sortOrder" type="number" {...form.register("sortOrder")} />
            </div>
          </CardContent>
        </Card>

        <div className="flex gap-3">
          <Button type="submit" disabled={saving}>
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {saving
              ? isEdit
                ? "Saving…"
                : "Creating…"
              : isEdit
                ? "Save changes"
                : "Create allotment"}
          </Button>
          {saving ? (
            <Button type="button" variant="outline" disabled>
              Cancel
            </Button>
          ) : (
            <Button type="button" variant="outline" asChild>
              <Link href="/admin/allotment/list">Cancel</Link>
            </Button>
          )}
        </div>
      </form>
    </div>
  );
}

function DateField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (date: Date | undefined) => void;
}) {
  const date = parseDateField(value);
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            className={cn("w-full justify-start text-left font-normal", !date && "text-muted-foreground")}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {date ? format(date, "PPP") : "Pick a date"}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar mode="single" selected={date} onSelect={onChange} initialFocus />
        </PopoverContent>
      </Popover>
    </div>
  );
}
