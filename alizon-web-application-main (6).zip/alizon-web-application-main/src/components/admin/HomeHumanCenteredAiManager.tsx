"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format, parseISO } from "date-fns";
import { ArrowLeft, CalendarIcon, Loader2, Upload } from "lucide-react";
import { toast } from "sonner";
import type { HomeHumanCenteredAiContent } from "@/types/cms";
import {
  fetchHomeHumanCenteredAiContentAdmin,
  saveHomeHumanCenteredAiContentAdmin,
  uploadCmsVideoUrl,
} from "@/lib/admin-cms-api";
import {
  CmsImageUploadField,
  type CmsImageUploadValue,
} from "@/components/admin/CmsImageUploadField";
import { HomeSectionPublishToggle } from "@/components/admin/HomeSectionPublishToggle";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { isValidYoutubeUrl } from "@/lib/youtube";

const formSchema = z
  .object({
    sectionHeading: z.string().min(1, "Section heading is required"),
    badgeText: z.string().min(1, "Badge text is required"),
    badgeLink: z.string().min(1, "Badge link is required"),
    panelImageAlt: z.string().optional(),
    introContent: z.string().optional(),
    quote: z.string().optional(),
    videoSource: z.enum(["youtube", "upload"]),
    videoYoutubeUrl: z.string().optional(),
    imageCardTitle: z.string().optional(),
    imageCardDescription: z.string().optional(),
    imageCardLink: z.string().optional(),
    textCard1Title: z.string().optional(),
    textCard1Body: z.string().optional(),
    textCard2Title: z.string().optional(),
    textCard2Body: z.string().optional(),
    footerYoutubeUrl: z.string().optional(),
    footerYoutubeLabel: z.string().optional(),
  })
  .superRefine((values, ctx) => {
    if (
      values.videoSource === "youtube" &&
      values.videoYoutubeUrl?.trim() &&
      !isValidYoutubeUrl(values.videoYoutubeUrl)
    ) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Enter a valid YouTube URL",
        path: ["videoYoutubeUrl"],
      });
    }
    if (
      values.footerYoutubeUrl?.trim() &&
      !isValidYoutubeUrl(values.footerYoutubeUrl)
    ) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Enter a valid YouTube URL",
        path: ["footerYoutubeUrl"],
      });
    }
  });

type FormValues = z.infer<typeof formSchema>;

function DateField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: Date | undefined;
  onChange: (date: Date | undefined) => void;
}) {
  const [open, setOpen] = useState(false);

  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <Popover open={open} onOpenChange={setOpen} modal>
        <PopoverTrigger asChild>
          <Button
            type="button"
            variant="outline"
            className={cn(
              "w-full justify-start text-left font-normal",
              !value && "text-muted-foreground",
            )}
          >
            <CalendarIcon className="mr-2 h-4 w-4" />
            {value ? format(value, "PPP") : "Pick a date"}
          </Button>
        </PopoverTrigger>
        <PopoverContent
          className="z-[100] w-auto p-0"
          align="start"
          onOpenAutoFocus={(e) => e.preventDefault()}
        >
          <Calendar
            mode="single"
            selected={value}
            defaultMonth={value}
            onSelect={(date) => {
              onChange(date);
              if (date) setOpen(false);
            }}
            initialFocus
          />
        </PopoverContent>
      </Popover>
    </div>
  );
}

export function HomeHumanCenteredAiManager() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploadingVideo, setUploadingVideo] = useState(false);
  const [panelImage, setPanelImage] = useState<CmsImageUploadValue | null>(null);
  const [panelImagePending, setPanelImagePending] = useState<string | null>(
    null,
  );
  const [imageCardImage, setImageCardImage] =
    useState<CmsImageUploadValue | null>(null);
  const [imageCardPending, setImageCardPending] = useState<string | null>(null);
  const [videoFileUrl, setVideoFileUrl] = useState("");
  const [imageCardDate, setImageCardDate] = useState<Date | undefined>();
  const [textCard1Date, setTextCard1Date] = useState<Date | undefined>();
  const [textCard2Date, setTextCard2Date] = useState<Date | undefined>();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      sectionHeading: "",
      badgeText: "Our impact",
      badgeLink: "/research",
      panelImageAlt: "",
      introContent: "",
      quote: "",
      videoSource: "youtube",
      videoYoutubeUrl: "",
      imageCardTitle: "",
      imageCardDescription: "",
      imageCardLink: "",
      textCard1Title: "",
      textCard1Body: "",
      textCard2Title: "",
      textCard2Body: "",
      footerYoutubeUrl: "",
      footerYoutubeLabel: "Watch on YouTube",
    },
  });

  const videoSource = form.watch("videoSource");

  const loadContent = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchHomeHumanCenteredAiContentAdmin();
      form.reset({
        sectionHeading: data.sectionHeading,
        badgeText: data.badgeText,
        badgeLink: data.badgeLink,
        panelImageAlt: data.panelImageAlt ?? "",
        introContent: data.introContent,
        quote: data.quote,
        videoSource: data.videoSource,
        videoYoutubeUrl: data.videoYoutubeUrl,
        imageCardTitle: data.imageCardTitle,
        imageCardDescription: data.imageCardDescription,
        imageCardLink: data.imageCardLink ?? "",
        textCard1Title: data.textCard1Title,
        textCard1Body: data.textCard1Body,
        textCard2Title: data.textCard2Title,
        textCard2Body: data.textCard2Body,
        footerYoutubeUrl: data.footerYoutubeUrl,
        footerYoutubeLabel: data.footerYoutubeLabel ?? "Watch on YouTube",
      });
      setPanelImage(data.panelImageUrl ? { url: data.panelImageUrl } : null);
      setImageCardImage(
        data.imageCardImageUrl ? { url: data.imageCardImageUrl } : null,
      );
      setVideoFileUrl(data.videoFileUrl ?? "");
      try {
        setImageCardDate(
          data.imageCardDate ? parseISO(data.imageCardDate) : undefined,
        );
      } catch {
        setImageCardDate(undefined);
      }
      try {
        setTextCard1Date(
          data.textCard1Date ? parseISO(data.textCard1Date) : undefined,
        );
      } catch {
        setTextCard1Date(undefined);
      }
      try {
        setTextCard2Date(
          data.textCard2Date ? parseISO(data.textCard2Date) : undefined,
        );
      } catch {
        setTextCard2Date(undefined);
      }
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load content",
      );
    } finally {
      setLoading(false);
    }
  }, [form]);

  useEffect(() => {
    void loadContent();
  }, [loadContent]);

  const onUploadVideo = async (file?: File) => {
    if (!file) return;
    setUploadingVideo(true);
    try {
      const url = await uploadCmsVideoUrl(
        "cms/home-human-centered-ai/video",
        file,
      );
      setVideoFileUrl(url);
      toast.success("Video uploaded");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to upload video",
      );
    } finally {
      setUploadingVideo(false);
    }
  };

  const onSave = async (values: FormValues) => {
    if (values.videoSource === "upload" && !videoFileUrl.trim()) {
      toast.error("Upload a video file or switch to YouTube");
      return;
    }

    setSaving(true);
    try {
      const payload: Omit<HomeHumanCenteredAiContent, "updatedAt"> = {
        sectionHeading: values.sectionHeading.trim(),
        badgeText: values.badgeText.trim(),
        badgeLink: values.badgeLink.trim(),
        panelImageUrl: panelImage?.url?.trim() ?? "",
        panelImageAlt: values.panelImageAlt?.trim() ?? "",
        introContent: values.introContent?.trim() ?? "",
        quote: values.quote?.trim() ?? "",
        videoSource: values.videoSource,
        videoYoutubeUrl: values.videoYoutubeUrl?.trim() ?? "",
        videoFileUrl: videoFileUrl.trim(),
        imageCardImageUrl: imageCardImage?.url?.trim() ?? "",
        imageCardTitle: values.imageCardTitle?.trim() ?? "",
        imageCardDescription: values.imageCardDescription?.trim() ?? "",
        imageCardDate: imageCardDate
          ? format(imageCardDate, "yyyy-MM-dd")
          : "",
        imageCardLink: values.imageCardLink?.trim() ?? "",
        textCard1Title: values.textCard1Title?.trim() ?? "",
        textCard1Body: values.textCard1Body?.trim() ?? "",
        textCard1Date: textCard1Date
          ? format(textCard1Date, "yyyy-MM-dd")
          : "",
        textCard2Title: values.textCard2Title?.trim() ?? "",
        textCard2Body: values.textCard2Body?.trim() ?? "",
        textCard2Date: textCard2Date
          ? format(textCard2Date, "yyyy-MM-dd")
          : "",
        footerYoutubeUrl: values.footerYoutubeUrl?.trim() ?? "",
        footerYoutubeLabel:
          values.footerYoutubeLabel?.trim() || "Watch on YouTube",
      };
      await saveHomeHumanCenteredAiContentAdmin(payload);
      toast.success("Human-Centered AI section saved");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save section",
      );
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className="space-y-10 max-w-3xl">
      <Button variant="ghost" size="sm" className="-ml-2" asChild>
        <Link href="/admin/home-content">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Home page content
        </Link>
      </Button>

      <HomeSectionPublishToggle sectionKey="humanCenteredAi" />

      <header>
        <h1 className="text-3xl font-heading font-bold text-foreground">
          Human-Centered AI
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Sticky left panel and scrolling right column on the homepage after
          Research. Default title: Achieving the promise of human-centered AI.
        </p>
      </header>

      {loading ? (
        <div className="space-y-3">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-24 w-full" />
          <Skeleton className="h-40 w-full" />
        </div>
      ) : (
        <form
          onSubmit={form.handleSubmit(onSave)}
          className="space-y-8 bg-card rounded-lg border border-border shadow-sm p-6 md:p-8"
        >
          <div className="space-y-4">
            <h2 className="text-lg font-heading font-semibold">Left panel</h2>
            <div className="space-y-2">
              <Label htmlFor="sectionHeading">Heading</Label>
              <Input
                id="sectionHeading"
                {...form.register("sectionHeading")}
              />
              {form.formState.errors.sectionHeading ? (
                <p className="text-sm text-destructive">
                  {form.formState.errors.sectionHeading.message}
                </p>
              ) : null}
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="badgeText">Badge text</Label>
                <Input id="badgeText" {...form.register("badgeText")} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="badgeLink">Badge link</Label>
                <Input id="badgeLink" {...form.register("badgeLink")} />
              </div>
            </div>
            <CmsImageUploadField
              label="Panel image"
              preset="card4x3"
              folder="cms/home-human-centered-ai/panel"
              storageFileName="panel"
              value={panelImage}
              onChange={setPanelImage}
              pendingPreviewUrl={panelImagePending}
              onPendingPreviewChange={setPanelImagePending}
            />
            <div className="space-y-2">
              <Label htmlFor="panelImageAlt">Panel image alt</Label>
              <Input id="panelImageAlt" {...form.register("panelImageAlt")} />
            </div>
          </div>

          <div className="space-y-4 border-t border-border pt-6">
            <h2 className="text-lg font-heading font-semibold">
              Intro and quote
            </h2>
            <div className="space-y-2">
              <Label htmlFor="introContent">Intro content</Label>
              <Textarea
                id="introContent"
                rows={4}
                {...form.register("introContent")}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="quote">Quote</Label>
              <Textarea id="quote" rows={3} {...form.register("quote")} />
            </div>
          </div>

          <div className="space-y-4 border-t border-border pt-6">
            <h2 className="text-lg font-heading font-semibold">Media row</h2>
            <div className="space-y-2">
              <Label>Video source</Label>
              <div className="flex flex-wrap gap-4">
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="radio"
                    value="youtube"
                    checked={videoSource === "youtube"}
                    onChange={() => form.setValue("videoSource", "youtube")}
                  />
                  YouTube URL
                </label>
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="radio"
                    value="upload"
                    checked={videoSource === "upload"}
                    onChange={() => form.setValue("videoSource", "upload")}
                  />
                  Upload video
                </label>
              </div>
            </div>
            {videoSource === "youtube" ? (
              <div className="space-y-2">
                <Label htmlFor="videoYoutubeUrl">YouTube URL</Label>
                <Input
                  id="videoYoutubeUrl"
                  placeholder="https://www.youtube.com/watch?v=..."
                  {...form.register("videoYoutubeUrl")}
                />
                {form.formState.errors.videoYoutubeUrl ? (
                  <p className="text-sm text-destructive">
                    {form.formState.errors.videoYoutubeUrl.message}
                  </p>
                ) : null}
              </div>
            ) : (
              <div className="space-y-2">
                <Label>Uploaded video</Label>
                <Input
                  type="file"
                  accept="video/mp4,video/webm,video/quicktime,.mp4,.webm,.mov"
                  disabled={uploadingVideo}
                  onChange={(e) => void onUploadVideo(e.target.files?.[0])}
                />
                {uploadingVideo ? (
                  <p className="text-xs text-muted-foreground inline-flex items-center gap-2">
                    <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    Uploading…
                  </p>
                ) : null}
                {videoFileUrl ? (
                  <p className="text-xs text-muted-foreground truncate">
                    Current video saved
                  </p>
                ) : null}
                {videoFileUrl ? (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => setVideoFileUrl("")}
                  >
                    Remove video
                  </Button>
                ) : null}
              </div>
            )}

            <CmsImageUploadField
              label="Image card image"
              preset="card4x3"
              folder="cms/home-human-centered-ai/image-card"
              storageFileName="card"
              value={imageCardImage}
              onChange={setImageCardImage}
              pendingPreviewUrl={imageCardPending}
              onPendingPreviewChange={setImageCardPending}
            />
            <div className="space-y-2">
              <Label htmlFor="imageCardTitle">Image card title</Label>
              <Input
                id="imageCardTitle"
                {...form.register("imageCardTitle")}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="imageCardDescription">
                Image card description
              </Label>
              <Textarea
                id="imageCardDescription"
                rows={3}
                {...form.register("imageCardDescription")}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="imageCardLink">Image card link (optional)</Label>
              <Input
                id="imageCardLink"
                {...form.register("imageCardLink")}
              />
            </div>
            <DateField
              label="Image card date"
              value={imageCardDate}
              onChange={setImageCardDate}
            />
          </div>

          <div className="space-y-4 border-t border-border pt-6">
            <h2 className="text-lg font-heading font-semibold">
              Text cards
            </h2>
            <div className="space-y-2">
              <Label htmlFor="textCard1Title">Card 1 title</Label>
              <Input
                id="textCard1Title"
                {...form.register("textCard1Title")}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="textCard1Body">Card 1 body</Label>
              <Textarea
                id="textCard1Body"
                rows={3}
                {...form.register("textCard1Body")}
              />
            </div>
            <DateField
              label="Card 1 date"
              value={textCard1Date}
              onChange={setTextCard1Date}
            />
            <div className="space-y-2">
              <Label htmlFor="textCard2Title">Card 2 title</Label>
              <Input
                id="textCard2Title"
                {...form.register("textCard2Title")}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="textCard2Body">Card 2 body</Label>
              <Textarea
                id="textCard2Body"
                rows={3}
                {...form.register("textCard2Body")}
              />
            </div>
            <DateField
              label="Card 2 date"
              value={textCard2Date}
              onChange={setTextCard2Date}
            />
          </div>

          <div className="space-y-4 border-t border-border pt-6">
            <h2 className="text-lg font-heading font-semibold">
              Footer YouTube
            </h2>
            <div className="space-y-2">
              <Label htmlFor="footerYoutubeUrl">YouTube URL</Label>
              <Input
                id="footerYoutubeUrl"
                placeholder="https://www.youtube.com/watch?v=..."
                {...form.register("footerYoutubeUrl")}
              />
              {form.formState.errors.footerYoutubeUrl ? (
                <p className="text-sm text-destructive">
                  {form.formState.errors.footerYoutubeUrl.message}
                </p>
              ) : null}
            </div>
            <div className="space-y-2">
              <Label htmlFor="footerYoutubeLabel">Watch label</Label>
              <Input
                id="footerYoutubeLabel"
                {...form.register("footerYoutubeLabel")}
              />
            </div>
          </div>

          <Button type="submit" disabled={saving || uploadingVideo}>
            {saving ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving…
              </>
            ) : (
              <>
                <Upload className="mr-2 h-4 w-4" />
                Save section
              </>
            )}
          </Button>
        </form>
      )}
    </section>
  );
}
