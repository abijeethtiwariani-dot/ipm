"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format, parseISO } from "date-fns";
import { CalendarIcon, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import type { NotificationItem, NotificationType } from "@/types/cms";
import { NOTIFICATION_ICONS, NOTIFICATION_TYPES } from "@/types/cms";
import {
  createNotificationItem,
  deleteNotificationItem,
  fetchNotificationItemsAdmin,
  updateNotificationItem,
} from "@/lib/admin-cms-api";
import { timestampToLocaleDateString } from "@/lib/firestore-timestamp";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const notificationIconValues = NOTIFICATION_ICONS.map((item) => item.value);

const notificationTypeValues = [...NOTIFICATION_TYPES] as [
  NotificationType,
  ...NotificationType[],
];

const notificationFormSchema = z.object({
  text: z.string().min(1, "Notification text is required"),
  link: z.string().min(1, "Link is required"),
  icon: z.enum(
    notificationIconValues as [
      (typeof notificationIconValues)[number],
      ...(typeof notificationIconValues)[number][],
    ],
  ),
  type: z.enum(notificationTypeValues),
  featured: z.boolean(),
  order: z.coerce.number().int().min(0, "Order must be 0 or greater"),
});

type NotificationFormValues = z.infer<typeof notificationFormSchema>;

function formatNotificationDate(date: string): string {
  try {
    return format(parseISO(date), "MMM d, yyyy");
  } catch {
    return date || "—";
  }
}

function getNextOrder(items: NotificationItem[]): number {
  if (items.length === 0) return 1;
  return Math.max(...items.map((item) => item.order ?? 0)) + 1;
}

export function NotificationsManager() {
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<NotificationItem | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<NotificationItem | null>(null);
  const [notificationDate, setNotificationDate] = useState<Date | undefined>();
  const [datePickerOpen, setDatePickerOpen] = useState(false);

  const form = useForm<NotificationFormValues>({
    resolver: zodResolver(notificationFormSchema),
    defaultValues: {
      text: "",
      link: "/news",
      icon: NOTIFICATION_ICONS[0].value,
      type: "Notice",
      featured: true,
      order: 1,
    },
  });

  const featured = form.watch("featured");
  const selectedIcon = form.watch("icon");

  const loadItems = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchNotificationItemsAdmin();
      setItems(data);
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to load notifications";
      toast.error(message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadItems();
  }, [loadItems]);

  const openCreate = () => {
    setEditingItem(null);
    setNotificationDate(new Date());
    form.reset({
      text: "",
      link: "/news",
      icon: NOTIFICATION_ICONS[0].value,
      type: "Notice",
      featured: true,
      order: getNextOrder(items),
    });
    setDialogOpen(true);
  };

  const openEdit = (item: NotificationItem) => {
    setEditingItem(item);
    try {
      setNotificationDate(parseISO(item.date));
    } catch {
      setNotificationDate(undefined);
    }
    form.reset({
      text: item.text,
      link: item.link,
      icon: item.icon,
      type: item.type,
      featured: item.featured,
      order: item.order,
    });
    setDialogOpen(true);
  };

  const onSubmit = async (values: NotificationFormValues) => {
    if (!notificationDate) {
      toast.error("Please select a notification date");
      return;
    }

    setSaving(true);
    try {
      const payload = {
        text: values.text,
        link: values.link,
        icon: values.icon,
        date: format(notificationDate, "yyyy-MM-dd"),
        type: values.type,
        featured: values.featured,
        order: values.order,
      };
      if (editingItem) {
        await updateNotificationItem(editingItem.id, payload);
        toast.success("Notification updated.");
      } else {
        await createNotificationItem(payload);
        toast.success("Notification created.");
      }
      setDialogOpen(false);
      await loadItems();
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to save notification";
      toast.error(message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      await deleteNotificationItem(deleteTarget.id);
      toast.success("Notification deleted.");
      setDeleteTarget(null);
      await loadItems();
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to delete notification";
      toast.error(message);
    }
  };

  return (
    <section>
      <header className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-8">
        <section>
          <h1 className="text-2xl font-heading font-bold text-foreground">
            Notifications
          </h1>
          <p className="text-sm text-muted-foreground mt-1 max-w-2xl">
            Manage campus notifications for the Latest ticker. Featured items
            scroll in the site header bar.
          </p>
        </section>
        <Button onClick={openCreate} className="gap-2 shrink-0">
          <Plus className="w-4 h-4" />
          Add Notification
        </Button>
      </header>

      <section className="bg-card rounded-lg border border-border shadow-sm overflow-hidden">
        {loading ? (
          <section className="p-8 space-y-3">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </section>
        ) : items.length === 0 ? (
          <p className="p-8 text-sm text-muted-foreground text-center">
            No notifications yet. Click &quot;Add Notification&quot; to create one.
          </p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="w-16">Icon</TableHead>
                <TableHead>Text</TableHead>
                <TableHead className="hidden lg:table-cell w-28">Date</TableHead>
                <TableHead className="hidden md:table-cell w-24">Type</TableHead>
                <TableHead className="hidden md:table-cell">Link</TableHead>
                <TableHead className="w-24">Featured</TableHead>
                <TableHead className="w-16">Order</TableHead>
                <TableHead className="hidden sm:table-cell w-32">Updated</TableHead>
                <TableHead className="w-24 text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="text-lg">{item.icon}</TableCell>
                  <TableCell className="font-medium max-w-[280px]">
                    <span className="line-clamp-2">{item.text}</span>
                  </TableCell>
                  <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                    {formatNotificationDate(item.date)}
                  </TableCell>
                  <TableCell className="hidden md:table-cell text-sm">
                    {item.type}
                  </TableCell>
                  <TableCell className="hidden md:table-cell text-sm text-muted-foreground max-w-[200px]">
                    <span className="line-clamp-1">{item.link}</span>
                  </TableCell>
                  <TableCell>
                    {item.featured ? (
                      <Badge variant="default">Featured</Badge>
                    ) : (
                      <Badge variant="secondary">Hidden</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-sm text-muted-foreground">
                    {item.order}
                  </TableCell>
                  <TableCell className="hidden sm:table-cell text-sm text-muted-foreground">
                    {timestampToLocaleDateString(item.updatedAt)}
                  </TableCell>
                  <TableCell className="text-right">
                    <section className="flex justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => openEdit(item)}
                        aria-label="Edit"
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteTarget(item)}
                        aria-label="Delete"
                      >
                        <Trash2 className="w-4 h-4 text-destructive" />
                      </Button>
                    </section>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </section>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto bg-background">
          <DialogHeader>
            <DialogTitle className="font-heading text-xl">
              {editingItem ? "Edit Notification" : "New Notification"}
            </DialogTitle>
          </DialogHeader>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
            <section className="space-y-2">
              <Label>
                Icon <span className="text-destructive">*</span>
              </Label>
              <section className="grid grid-cols-3 gap-2">
                {NOTIFICATION_ICONS.map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => form.setValue("icon", option.value)}
                    className={cn(
                      "flex flex-col items-center gap-1 rounded-lg border p-3 text-sm transition-colors",
                      selectedIcon === option.value
                        ? "border-primary bg-primary/5 ring-2 ring-primary ring-offset-2 ring-offset-background"
                        : "border-border hover:bg-muted/50",
                    )}
                  >
                    <span className="text-xl" aria-hidden>
                      {option.value}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {option.label}
                    </span>
                  </button>
                ))}
              </section>
            </section>

            <section className="space-y-2">
              <Label htmlFor="text">
                Notification text <span className="text-destructive">*</span>
              </Label>
              <Input
                id="text"
                placeholder="Spring Semester 2025 Registration Now Open"
                {...form.register("text")}
              />
            </section>

            <section className="grid sm:grid-cols-2 gap-4">
              <section className="space-y-2">
                <Label>
                  Date <span className="text-destructive">*</span>
                </Label>
                <Popover
                  open={datePickerOpen}
                  onOpenChange={setDatePickerOpen}
                  modal
                >
                  <PopoverTrigger asChild>
                    <Button
                      type="button"
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !notificationDate && "text-muted-foreground",
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {notificationDate
                        ? format(notificationDate, "PPP")
                        : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent
                    className="z-[100] w-auto p-0"
                    align="start"
                    onOpenAutoFocus={(e) => e.preventDefault()}
                  >
                    <Calendar
                      mode="single"
                      selected={notificationDate}
                      defaultMonth={notificationDate}
                      onSelect={(date) => {
                        setNotificationDate(date);
                        if (date) {
                          setDatePickerOpen(false);
                        }
                      }}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </section>

              <section className="space-y-2">
                <Label htmlFor="type">
                  Category <span className="text-destructive">*</span>
                </Label>
                <Select
                  value={form.watch("type")}
                  onValueChange={(value) =>
                    form.setValue("type", value as NotificationType)
                  }
                >
                  <SelectTrigger id="type" className="bg-background">
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {NOTIFICATION_TYPES.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </section>
            </section>

            <section className="space-y-2">
              <Label htmlFor="link">
                Link <span className="text-destructive">*</span>
              </Label>
              <Input
                id="link"
                placeholder="/news"
                {...form.register("link")}
              />
            </section>

            <section className="space-y-2">
              <Label htmlFor="order">
                Display order <span className="text-destructive">*</span>
              </Label>
              <Input
                id="order"
                type="number"
                min={0}
                {...form.register("order")}
              />
              <p className="text-xs text-muted-foreground">
                Lower numbers appear first in the ticker.
              </p>
            </section>

            <section className="flex items-start gap-3 rounded-lg border border-border p-4 bg-muted/30">
              <Checkbox
                id="featured"
                checked={featured}
                onCheckedChange={(checked) =>
                  form.setValue("featured", checked === true)
                }
              />
              <div className="space-y-0.5">
                <Label htmlFor="featured" className="cursor-pointer font-medium">
                  Show in Latest ticker
                </Label>
                <p className="text-xs text-muted-foreground">
                  Featured notifications scroll in the bar below the navigation.
                </p>
              </div>
            </section>

            <DialogFooter className="gap-2 sm:gap-0 pt-2">
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving}>
                {saving ? "Saving..." : "Save"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog
        open={Boolean(deleteTarget)}
        onOpenChange={(open) => !open && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete notification?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove &quot;{deleteTarget?.text}&quot; from the admin
              list and the public ticker if it was featured.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}
