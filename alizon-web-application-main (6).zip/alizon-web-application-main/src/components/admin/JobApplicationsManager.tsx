"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Eye, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  deleteJobApplication,
  fetchAllJobApplications,
  formatGenderLabel,
  toJobApplicationDateString,
  toJobApplicationTimestamp,
} from "@/lib/job-applications";
import type { JobApplication } from "@/types/job-application";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const PAGE_SIZE = 10;
const ALL_POSITIONS = "all";

function startOfDayMs(dateStr: string): number {
  return new Date(`${dateStr}T00:00:00`).getTime();
}

function endOfDayMs(dateStr: string): number {
  return new Date(`${dateStr}T23:59:59.999`).getTime();
}

export function JobApplicationsManager() {
  const [applications, setApplications] = useState<JobApplication[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [positionFilter, setPositionFilter] = useState(ALL_POSITIONS);
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [page, setPage] = useState(1);
  const [viewTarget, setViewTarget] = useState<JobApplication | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<JobApplication | null>(null);
  const [deleting, setDeleting] = useState(false);

  const loadApplications = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchAllJobApplications();
      setApplications(data);
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to load applications";
      const hint =
        message.includes("permission") || message.includes("Permission")
          ? " Ensure Firestore rules are deployed and you have an admins/{uid} document."
          : "";
      toast.error(message + hint);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadApplications();
  }, [loadApplications]);

  const positionOptions = useMemo(() => {
    const titles = new Set<string>();
    for (const app of applications) {
      if (app.positionAppliedFor) titles.add(app.positionAppliedFor);
    }
    return Array.from(titles).sort((a, b) => a.localeCompare(b));
  }, [applications]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    const fromMs = dateFrom ? startOfDayMs(dateFrom) : null;
    const toMs = dateTo ? endOfDayMs(dateTo) : null;

    return applications.filter((a) => {
      if (positionFilter !== ALL_POSITIONS && a.positionAppliedFor !== positionFilter) {
        return false;
      }

      const appliedMs = toJobApplicationTimestamp(a.createdAt);
      if (fromMs !== null && (appliedMs === null || appliedMs < fromMs)) {
        return false;
      }
      if (toMs !== null && (appliedMs === null || appliedMs > toMs)) {
        return false;
      }

      if (!q) return true;
      return (
        a.name.toLowerCase().includes(q) ||
        a.email.toLowerCase().includes(q) ||
        a.phone.toLowerCase().includes(q) ||
        a.positionAppliedFor.toLowerCase().includes(q) ||
        a.address.toLowerCase().includes(q) ||
        a.message.toLowerCase().includes(q) ||
        formatGenderLabel(a.gender).toLowerCase().includes(q)
      );
    });
  }, [applications, search, positionFilter, dateFrom, dateTo]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paginated = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const hasActiveFilters =
    search.trim() !== "" ||
    positionFilter !== ALL_POSITIONS ||
    dateFrom !== "" ||
    dateTo !== "";

  const clearFilters = () => {
    setSearch("");
    setPositionFilter(ALL_POSITIONS);
    setDateFrom("");
    setDateTo("");
    setPage(1);
  };

  useEffect(() => {
    setPage(1);
  }, [search, positionFilter, dateFrom, dateTo]);

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      await deleteJobApplication(deleteTarget.id);
      toast.success("Application deleted.");
      if (viewTarget?.id === deleteTarget.id) {
        setViewTarget(null);
      }
      setDeleteTarget(null);
      await loadApplications();
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to delete application";
      toast.error(message);
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-heading font-bold">Job Applications</h1>
        <p className="text-muted-foreground text-sm mt-1">
          Review job applications submitted from the careers pages
        </p>
      </div>

      <div className="flex flex-wrap items-end gap-3">
        <div className="space-y-1 min-w-[200px] flex-1">
          <label className="text-xs text-muted-foreground">Search</label>
          <Input
            placeholder="Name, email, phone, position..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="space-y-1 min-w-[180px]">
          <label className="text-xs text-muted-foreground">Job name</label>
          <Select value={positionFilter} onValueChange={setPositionFilter}>
            <SelectTrigger>
              <SelectValue placeholder="All positions" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={ALL_POSITIONS}>All positions</SelectItem>
              {positionOptions.map((title) => (
                <SelectItem key={title} value={title}>
                  {title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1">
          <label className="text-xs text-muted-foreground">Applied from</label>
          <Input
            type="date"
            value={dateFrom}
            onChange={(e) => setDateFrom(e.target.value)}
            className="w-[160px]"
          />
        </div>
        <div className="space-y-1">
          <label className="text-xs text-muted-foreground">Applied to</label>
          <Input
            type="date"
            value={dateTo}
            onChange={(e) => setDateTo(e.target.value)}
            className="w-[160px]"
          />
        </div>
        {hasActiveFilters && (
          <Button variant="outline" onClick={clearFilters}>
            Clear filters
          </Button>
        )}
      </div>

      {loading ? (
        <div className="space-y-2">
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
          <Skeleton className="h-10 w-full" />
        </div>
      ) : filtered.length === 0 ? (
        <p className="text-muted-foreground text-sm py-8 text-center">
          No job applications found.
        </p>
      ) : (
        <>
          <div className="overflow-x-auto rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Applied</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Position</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginated.map((a) => (
                  <TableRow key={a.id}>
                    <TableCell className="whitespace-nowrap text-sm">
                      {toJobApplicationDateString(a.createdAt)}
                    </TableCell>
                    <TableCell className="font-medium">{a.name}</TableCell>
                    <TableCell>{a.email}</TableCell>
                    <TableCell>{a.phone}</TableCell>
                    <TableCell>{a.positionAppliedFor || "—"}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setViewTarget(a)}
                          aria-label="View application"
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setDeleteTarget(a)}
                          aria-label="Delete application"
                          className="text-destructive hover:text-destructive"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          {totalPages > 1 && (
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      setPage((p) => Math.max(1, p - 1));
                    }}
                    className={
                      page <= 1 ? "pointer-events-none opacity-50" : ""
                    }
                  />
                </PaginationItem>
                {Array.from({ length: totalPages }, (_, i) => i + 1).map(
                  (p) => (
                    <PaginationItem key={p}>
                      <PaginationLink
                        href="#"
                        isActive={p === page}
                        onClick={(e) => {
                          e.preventDefault();
                          setPage(p);
                        }}
                      >
                        {p}
                      </PaginationLink>
                    </PaginationItem>
                  ),
                )}
                <PaginationItem>
                  <PaginationNext
                    href="#"
                    onClick={(e) => {
                      e.preventDefault();
                      setPage((p) => Math.min(totalPages, p + 1));
                    }}
                    className={
                      page >= totalPages
                        ? "pointer-events-none opacity-50"
                        : ""
                    }
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}
        </>
      )}

      <AlertDialog
        open={!!deleteTarget}
        onOpenChange={() => !deleting && setDeleteTarget(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete application?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the application from{" "}
              <span className="font-medium">{deleteTarget?.name}</span> for{" "}
              <span className="font-medium">
                {deleteTarget?.positionAppliedFor || "this position"}
              </span>
              . This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                void handleDelete();
              }}
              disabled={deleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={!!viewTarget} onOpenChange={() => setViewTarget(null)}>
        <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Application Details</DialogTitle>
          </DialogHeader>
          {viewTarget && (
            <div className="grid gap-3 text-sm">
              <p>
                <span className="text-muted-foreground">Apply Position For: </span>
                {viewTarget.positionAppliedFor || "—"}
              </p>
              <p>
                <span className="text-muted-foreground">Name: </span>
                {viewTarget.name}
              </p>
              <p>
                <span className="text-muted-foreground">Email: </span>
                {viewTarget.email}
              </p>
              <p>
                <span className="text-muted-foreground">Phone: </span>
                {viewTarget.phone}
              </p>
              <p>
                <span className="text-muted-foreground">Date of Birth: </span>
                {viewTarget.dateOfBirth || "—"}
              </p>
              <p>
                <span className="text-muted-foreground">Gender: </span>
                {formatGenderLabel(viewTarget.gender)}
              </p>
              <p>
                <span className="text-muted-foreground">Address: </span>
                {viewTarget.address || "—"}
              </p>
              <p>
                <span className="text-muted-foreground">Message / Notes: </span>
                {viewTarget.message || "—"}
              </p>
              <p>
                <span className="text-muted-foreground">CV: </span>
                {viewTarget.cvUrl ? (
                  <a
                    href={viewTarget.cvUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="font-medium text-primary underline-offset-2 hover:underline"
                  >
                    {viewTarget.cvFileName || "Download CV"}
                  </a>
                ) : (
                  "—"
                )}
              </p>
              <div className="flex items-center gap-2">
                <span className="text-muted-foreground">WhatsApp consent:</span>
                <Badge
                  variant={viewTarget.whatsappConsent ? "default" : "secondary"}
                >
                  {viewTarget.whatsappConsent ? "Yes" : "No"}
                </Badge>
              </div>
              <p>
                <span className="text-muted-foreground">Applied: </span>
                {toJobApplicationDateString(viewTarget.createdAt)}
              </p>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
