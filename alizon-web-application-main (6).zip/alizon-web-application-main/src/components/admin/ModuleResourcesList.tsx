"use client";

import { useEffect, useState } from "react";
import { Download, Eye, Pencil, Trash2 } from "lucide-react";
import { toast } from "sonner";
import {
  createModuleResource,
  deleteModuleResource,
  fetchModuleResources,
} from "@/lib/module-resources";
import type { ModuleResourceType, ProgramModule, ModuleResource } from "@/types/program";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export function ModuleResourcesList({
  programId,
  module,
}: {
  programId: string;
  module: ProgramModule;
}) {
  const [resources, setResources] = useState<ModuleResource[]>([]);
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  const [type, setType] = useState("link");

  const load = async () => {
    setResources(await fetchModuleResources(programId, module.id));
  };

  useEffect(() => {
    void load();
  }, [module.id, programId]);

  const addResource = async () => {
    if (!title.trim() || !url.trim()) return;
    try {
      await createModuleResource(programId, module.id, {
        title,
        url,
        type: type as ModuleResourceType,
      });
      setTitle("");
      setUrl("");
      await load();
      toast.success("Resource added.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to add resource.");
    }
  };

  const removeResource = async (resourceId: string) => {
    await deleteModuleResource(programId, module.id, resourceId);
    await load();
  };

  return (
    <div className="space-y-4">
      <div className="grid gap-3 rounded-lg border p-4 md:grid-cols-4">
        <div className="space-y-1 md:col-span-2">
          <Label>Resource Name</Label>
          <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Lecture notes" />
        </div>
        <div className="space-y-1">
          <Label>Type</Label>
          <Select value={type} onValueChange={setType}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pdf">PDF</SelectItem>
              <SelectItem value="doc">DOC</SelectItem>
              <SelectItem value="docx">DOCX</SelectItem>
              <SelectItem value="ppt">PPT</SelectItem>
              <SelectItem value="youtube">YouTube</SelectItem>
              <SelectItem value="video_file">Video</SelectItem>
              <SelectItem value="link">External Link</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1">
          <Label>Resource URL</Label>
          <Input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://..." />
        </div>
        <div className="md:col-span-4">
          <Button type="button" onClick={addResource}>Add Resource</Button>
        </div>
      </div>

      <div className="grid gap-3 md:grid-cols-2">
        {resources.map((resource) => (
          <Card key={resource.id} className="transition hover:-translate-y-0.5 hover:shadow-md">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-medium">{resource.title}</p>
                  <p className="text-xs text-muted-foreground uppercase">{resource.type}</p>
                </div>
                <div className="flex items-center gap-1">
                  <Button size="icon" variant="ghost" asChild>
                    <a href={resource.url} target="_blank" rel="noreferrer">
                      <Eye className="h-4 w-4" />
                    </a>
                  </Button>
                  <Button size="icon" variant="ghost" asChild>
                    <a href={resource.url} target="_blank" rel="noreferrer">
                      <Download className="h-4 w-4" />
                    </a>
                  </Button>
                  <Button size="icon" variant="ghost">
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button size="icon" variant="ghost" onClick={() => void removeResource(resource.id)}>
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
