"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { apiFetchStudent } from "@/lib/admin-students-api";
import { getEffectiveProfile } from "@/lib/student-mapper";
import type { Student } from "@/types/student";
import type { StudentProfileDetails } from "@/types/student-profile";
import {
  StudentProfileForm,
  StudentProfileFormSkeleton,
} from "@/components/student/StudentProfileForm";
import { Button } from "@/components/ui/button";

export function AdminStudentProfileEditView({ studentId }: { studentId: string }) {
  const router = useRouter();
  const [student, setStudent] = useState<Student | null>(null);
  const [profile, setProfile] = useState<StudentProfileDetails | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await apiFetchStudent(studentId);
      if (!data) {
        toast.error("Student not found");
        router.push("/admin/students");
        return;
      }
      setStudent(data);
      setProfile(getEffectiveProfile(data));
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to load student");
    } finally {
      setLoading(false);
    }
  }, [studentId, router]);

  useEffect(() => {
    void load();
  }, [load]);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" asChild>
          <Link href={`/admin/students/${studentId}`}>
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-2xl font-heading font-bold">Edit full profile</h1>
          <p className="text-sm text-muted-foreground">
            {student?.name ?? "Loading..."} · {student?.registrationId}
          </p>
        </div>
      </div>

      {loading || !student || !profile ? (
        <StudentProfileFormSkeleton />
      ) : (
        <StudentProfileForm
          mode="admin"
          student={student}
          initialProfile={profile}
          showCancel
          onCancel={() => router.push(`/admin/students/${studentId}`)}
          onSaved={() => router.push(`/admin/students/${studentId}`)}
        />
      )}
    </div>
  );
}
