"use client";

import { useCallback, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import {
  createFooterQuickLinkAdmin,
  createFooterResourceLinkAdmin,
  deleteFooterQuickLinkAdmin,
  deleteFooterResourceLinkAdmin,
  fetchFooterAboutAdmin,
  fetchFooterContactAdmin,
  fetchFooterQuickLinksAdmin,
  fetchFooterResourceLinksAdmin,
  fetchFooterSocialAdmin,
  reorderFooterQuickLinksAdmin,
  reorderFooterResourceLinksAdmin,
  saveFooterAboutAdmin,
  saveFooterContactAdmin,
  saveFooterSocialAdmin,
  updateFooterQuickLinkAdmin,
  updateFooterResourceLinkAdmin,
} from "@/lib/admin-cms-api";
import {
  FOOTER_SOCIAL_PLATFORM_LABELS,
} from "@/lib/footer-cms";
import { FOOTER_SOCIAL_PLATFORMS } from "@/types/cms";
import { FooterLinksSection } from "@/components/admin/footer/FooterLinksSection";
import Link from "next/link";
import { ChevronRight, FileText, Shield } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const aboutFormSchema = z.object({
  description: z.string().min(1, "Description is required"),
});

type AboutFormValues = z.infer<typeof aboutFormSchema>;

const contactFormSchema = z.object({
  email: z.string().email("Enter a valid email address"),
  phone: z.string().min(1, "Phone number is required"),
  addressLine1: z.string().min(1, "Address line 1 is required"),
  addressLine2: z.string(),
  mapUrl: z.string().optional(),
});

type ContactFormValues = z.infer<typeof contactFormSchema>;

type SocialFormValues = {
  platforms: {
    platform: (typeof FOOTER_SOCIAL_PLATFORMS)[number];
    url: string;
    isActive: boolean;
  }[];
};

const LEGAL_POLICY_SECTIONS = [
  {
    title: "Refund Policy",
    description:
      "Upload a document or link to Google Drive. Shown as a footer link that opens the policy URL.",
    href: "/admin/footer/refund-policy",
    icon: FileText,
  },
  {
    title: "Privacy Policy",
    description:
      "Edit HTML content for the public /privacy page using the built-in editor and preview.",
    href: "/admin/footer/privacy-policy",
    icon: Shield,
  },
] as const;

export function FooterManager() {
  const [aboutLoading, setAboutLoading] = useState(true);
  const [contactLoading, setContactLoading] = useState(true);
  const [socialLoading, setSocialLoading] = useState(true);
  const [aboutSaving, setAboutSaving] = useState(false);
  const [contactSaving, setContactSaving] = useState(false);
  const [socialSaving, setSocialSaving] = useState(false);

  const aboutForm = useForm<AboutFormValues>({
    resolver: zodResolver(aboutFormSchema),
    defaultValues: {
      description: "",
    },
  });

  const contactForm = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      email: "",
      phone: "",
      addressLine1: "",
      addressLine2: "",
      mapUrl: "",
    },
  });

  const [socialPlatforms, setSocialPlatforms] = useState<SocialFormValues["platforms"]>(
    FOOTER_SOCIAL_PLATFORMS.map((platform) => ({
      platform,
      url: "",
      isActive: true,
    })),
  );

  const loadAbout = useCallback(async () => {
    setAboutLoading(true);
    try {
      const data = await fetchFooterAboutAdmin();
      aboutForm.reset({
        description: data.description,
      });
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load footer description.",
      );
    } finally {
      setAboutLoading(false);
    }
  }, [aboutForm]);

  const loadContact = useCallback(async () => {
    setContactLoading(true);
    try {
      const data = await fetchFooterContactAdmin();
      contactForm.reset({
        email: data.email,
        phone: data.phone,
        addressLine1: data.addressLine1,
        addressLine2: data.addressLine2,
        mapUrl: data.mapUrl ?? "",
      });
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load contact information.",
      );
    } finally {
      setContactLoading(false);
    }
  }, [contactForm]);

  const loadSocial = useCallback(async () => {
    setSocialLoading(true);
    try {
      const data = await fetchFooterSocialAdmin();
      setSocialPlatforms(data.platforms);
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to load social media links.",
      );
    } finally {
      setSocialLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadAbout();
    void loadContact();
    void loadSocial();
  }, [loadAbout, loadContact, loadSocial]);

  const onSaveAbout = aboutForm.handleSubmit(async (values) => {
    if (aboutSaving) return;
    setAboutSaving(true);
    try {
      await saveFooterAboutAdmin({
        description: values.description.trim(),
      });
      toast.success("Footer description saved.");
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Failed to save footer description.",
      );
    } finally {
      setAboutSaving(false);
    }
  });

  const onSaveContact = contactForm.handleSubmit(async (values) => {
    if (contactSaving) return;
    setContactSaving(true);
    try {
      await saveFooterContactAdmin({
        email: values.email.trim(),
        phone: values.phone.trim(),
        addressLine1: values.addressLine1.trim(),
        addressLine2: values.addressLine2.trim(),
        mapUrl: values.mapUrl?.trim() ?? "",
      });
      toast.success("Contact information saved.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to save contact information.");
    } finally {
      setContactSaving(false);
    }
  });

  const onSaveSocial = async () => {
    if (socialSaving) return;
    setSocialSaving(true);
    try {
      await saveFooterSocialAdmin({
        platforms: socialPlatforms.map((item) => ({
          platform: item.platform,
          url: item.url.trim(),
          isActive: item.isActive,
        })),
      });
      toast.success("Social media links saved.");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Failed to save social media links.");
    } finally {
      setSocialSaving(false);
    }
  };

  const updateSocialPlatform = (
    platform: (typeof FOOTER_SOCIAL_PLATFORMS)[number],
    patch: Partial<{ url: string; isActive: boolean }>,
  ) => {
    setSocialPlatforms((prev) =>
      prev.map((item) =>
        item.platform === platform ? { ...item, ...patch } : item,
      ),
    );
  };

  return (
    <div className="mx-auto max-w-6xl space-y-8">
      <header>
        <h1 className="text-3xl font-heading font-bold">Footer</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Manage footer description, navigation links, contact details, and social media profiles.
        </p>
      </header>

      <section className="bg-card rounded-lg border border-border shadow-sm p-6 space-y-4">
        <div>
          <h2 className="text-xl font-heading font-semibold">About Description</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Short paragraph shown below the footer logo. The logo and institution name remain static.
          </p>
        </div>

        {aboutLoading ? (
          <div className="space-y-2">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-24 w-full" />
          </div>
        ) : (
          <form onSubmit={onSaveAbout} className="space-y-4 max-w-2xl">
            <div className="space-y-2">
              <Label htmlFor="footer-description">Description</Label>
              <Textarea
                id="footer-description"
                rows={4}
                {...aboutForm.register("description")}
              />
              {aboutForm.formState.errors.description && (
                <p className="text-sm text-destructive">
                  {aboutForm.formState.errors.description.message}
                </p>
              )}
            </div>
            <Button type="submit" disabled={aboutSaving}>
              {aboutSaving ? "Saving..." : "Save Changes"}
            </Button>
          </form>
        )}
      </section>

      <FooterLinksSection
        title="Quick Links"
        description="Links shown in the Quick Links column of the site footer."
        fetchLinks={fetchFooterQuickLinksAdmin}
        createLink={createFooterQuickLinkAdmin}
        updateLink={updateFooterQuickLinkAdmin}
        deleteLink={deleteFooterQuickLinkAdmin}
        reorderLinks={reorderFooterQuickLinksAdmin}
      />

      <FooterLinksSection
        title="Resources"
        description="Links shown in the Resources column of the site footer."
        fetchLinks={fetchFooterResourceLinksAdmin}
        createLink={createFooterResourceLinkAdmin}
        updateLink={updateFooterResourceLinkAdmin}
        deleteLink={deleteFooterResourceLinkAdmin}
        reorderLinks={reorderFooterResourceLinksAdmin}
      />

      <section className="bg-card rounded-lg border border-border shadow-sm p-6 space-y-4">
        <div>
          <h2 className="text-xl font-heading font-semibold">Contact Information</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Email, phone, and address displayed in the Get in Touch column.
          </p>
        </div>

        {contactLoading ? (
          <div className="space-y-2">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        ) : (
          <form onSubmit={onSaveContact} className="space-y-4 max-w-xl">
            <div className="space-y-2">
              <Label htmlFor="footer-email">Email Address</Label>
              <Input id="footer-email" type="email" {...contactForm.register("email")} />
              {contactForm.formState.errors.email && (
                <p className="text-sm text-destructive">
                  {contactForm.formState.errors.email.message}
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="footer-phone">Phone Number</Label>
              <Input id="footer-phone" {...contactForm.register("phone")} />
              {contactForm.formState.errors.phone && (
                <p className="text-sm text-destructive">
                  {contactForm.formState.errors.phone.message}
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="footer-address-1">Address Line 1</Label>
              <Input id="footer-address-1" {...contactForm.register("addressLine1")} />
              {contactForm.formState.errors.addressLine1 && (
                <p className="text-sm text-destructive">
                  {contactForm.formState.errors.addressLine1.message}
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="footer-address-2">Address Line 2</Label>
              <Input id="footer-address-2" {...contactForm.register("addressLine2")} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="footer-map-url">Google Map URL (optional)</Label>
              <Input
                id="footer-map-url"
                placeholder="https://maps.google.com/..."
                {...contactForm.register("mapUrl")}
              />
            </div>
            <Button type="submit" disabled={contactSaving}>
              {contactSaving ? "Saving..." : "Save Changes"}
            </Button>
          </form>
        )}
      </section>

      <section className="bg-card rounded-lg border border-border shadow-sm p-6 space-y-4">
        <div>
          <h2 className="text-xl font-heading font-semibold">Social Media</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Only active platforms with a URL appear in the footer.
          </p>
        </div>

        {socialLoading ? (
          <div className="space-y-2">
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        ) : (
          <>
            <div className="rounded-md border overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Platform</TableHead>
                    <TableHead>Profile URL</TableHead>
                    <TableHead>Active</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {socialPlatforms.map((item) => (
                    <TableRow key={item.platform}>
                      <TableCell className="font-medium">
                        {FOOTER_SOCIAL_PLATFORM_LABELS[item.platform]}
                      </TableCell>
                      <TableCell>
                        <Input
                          value={item.url}
                          onChange={(e) =>
                            updateSocialPlatform(item.platform, { url: e.target.value })
                          }
                          placeholder="https://..."
                        />
                      </TableCell>
                      <TableCell>
                        <Switch
                          checked={item.isActive}
                          onCheckedChange={(checked) =>
                            updateSocialPlatform(item.platform, { isActive: checked })
                          }
                          aria-label={`Toggle ${FOOTER_SOCIAL_PLATFORM_LABELS[item.platform]}`}
                        />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
            <Button type="button" onClick={() => void onSaveSocial()} disabled={socialSaving}>
              {socialSaving ? "Saving..." : "Save Changes"}
            </Button>
          </>
        )}
      </section>

      <section className="space-y-4">
        <div>
          <h2 className="text-xl font-heading font-semibold">Legal & Policies</h2>
          <p className="text-sm text-muted-foreground mt-1">
            Manage refund and privacy policy content shown on the public site footer.
          </p>
        </div>
        <div className="grid gap-4 md:grid-cols-2">
          {LEGAL_POLICY_SECTIONS.map((section) => (
            <Link key={section.href} href={section.href}>
              <Card className="group h-full border p-6 transition-shadow hover:shadow-md">
                <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  <section.icon className="h-5 w-5" />
                </div>
                <h3 className="text-lg font-semibold group-hover:text-primary">
                  {section.title}
                </h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  {section.description}
                </p>
                <span className="mt-4 inline-flex items-center text-sm font-medium text-primary">
                  Open
                  <ChevronRight className="ml-1 h-4 w-4" />
                </span>
              </Card>
            </Link>
          ))}
        </div>
      </section>
    </div>
  );
}
