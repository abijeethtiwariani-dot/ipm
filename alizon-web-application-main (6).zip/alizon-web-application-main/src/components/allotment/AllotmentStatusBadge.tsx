import { Badge } from "@/components/ui/badge";
import type { AllotmentStatus } from "@/types/allotment";
import { cn } from "@/lib/utils";

const labels: Record<AllotmentStatus, string> = {
  active: "Active",
  upcoming: "Upcoming",
  closed: "Closed",
};

const styles: Record<AllotmentStatus, string> = {
  active: "bg-success/10 text-success border-success/20",
  upcoming: "bg-warning/10 text-warning border-warning/20",
  closed: "bg-muted text-muted-foreground border-border",
};

export function AllotmentStatusBadge({
  status,
  className,
}: {
  status: AllotmentStatus;
  className?: string;
}) {
  return (
    <Badge variant="outline" className={cn(styles[status], className)}>
      {labels[status]}
    </Badge>
  );
}
