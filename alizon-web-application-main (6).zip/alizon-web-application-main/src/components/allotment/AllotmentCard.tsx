"use client";

import Link from "next/link";
import { format, parseISO } from "date-fns";
import { Calendar, ExternalLink, FileText } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ROUTES } from "@/lib/site-routes";
import type { Allotment } from "@/types/allotment";
import { AllotmentStatusBadge } from "./AllotmentStatusBadge";
import { AllotmentCategoryBadge } from "./AllotmentCategoryBadge";

function formatDate(value: string): string {
  if (!value) return "—";
  try {
    return format(parseISO(value), "MMM d, yyyy");
  } catch {
    return value;
  }
}

const OPEN_ALLOCATION_LABEL = "Open Allocation";

export function AllotmentCard({ allotment }: { allotment: Allotment }) {
  const hasDrive = Boolean(allotment.googleDriveUrl);
  const detailHref = `${ROUTES.allotment}/${allotment.slug}`;

  return (
    <Card className="flex h-full flex-col border-0 p-6 shadow-soft card-hover">
      <div className="mb-3 flex flex-wrap items-start justify-between gap-2">
        <AllotmentCategoryBadge name={allotment.categoryName ?? "Allotment"} />
        <AllotmentStatusBadge status={allotment.status} />
      </div>

      {hasDrive ? (
        <a
          href={allotment.googleDriveUrl!}
          target="_blank"
          rel="noopener noreferrer"
          className="group"
        >
          <h3 className="site-card-title text-foreground group-hover:text-primary transition-colors line-clamp-2">
            {allotment.title}
          </h3>
        </a>
      ) : (
        <Link href={detailHref}>
          <h3 className="site-card-title text-foreground hover:text-primary transition-colors line-clamp-2">
            {allotment.title}
          </h3>
        </Link>
      )}

      <div className="mt-3 flex flex-col gap-1 text-xs text-muted-foreground">
        <span className="flex items-center gap-1.5">
          <Calendar className="h-3.5 w-3.5" />
          Published {formatDate(allotment.publishDate)}
        </span>
        <span className="flex items-center gap-1.5">
          <Calendar className="h-3.5 w-3.5" />
          Updated {formatDate(allotment.updatedDate)}
        </span>
      </div>

      <p className="site-card-desc mt-4 flex-1 line-clamp-3">
        {allotment.shortDescription}
      </p>

      <div className="mt-6">
        {hasDrive ? (
          <Button asChild className="w-full sm:w-auto">
            <a
              href={allotment.googleDriveUrl!}
              target="_blank"
              rel="noopener noreferrer"
            >
              <ExternalLink className="mr-2 h-4 w-4" />
              {OPEN_ALLOCATION_LABEL}
            </a>
          </Button>
        ) : (
          <Button asChild variant="default" className="w-full sm:w-auto">
            <Link href={detailHref}>
              <FileText className="mr-2 h-4 w-4" />
              {OPEN_ALLOCATION_LABEL}
            </Link>
          </Button>
        )}
      </div>
    </Card>
  );
}
