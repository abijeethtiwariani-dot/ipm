import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export function AllotmentCategoryBadge({
  name,
  className,
}: {
  name: string;
  className?: string;
}) {
  return (
    <Badge
      variant="secondary"
      className={cn("bg-primary/10 text-primary border-0 font-medium", className)}
    >
      {name}
    </Badge>
  );
}
