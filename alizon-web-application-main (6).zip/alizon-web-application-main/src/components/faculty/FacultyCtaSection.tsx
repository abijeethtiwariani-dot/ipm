"use client";

import Link from "next/link";
import { ArrowRight, Phone } from "lucide-react";
import type { FacultyCtaContent } from "@/types/cms";
import { cn } from "@/lib/utils";
import { facultyContainer } from "@/components/faculty/faculty-layout";

type Props = {
  cta: FacultyCtaContent;
};

export function FacultyCtaSection({ cta }: Props) {
  const bgStyle = cta.backgroundImageUrl.trim()
    ? { backgroundImage: `url('${cta.backgroundImageUrl}')` }
    : undefined;

  return (
    <section className="relative py-12 md:py-16 lg:py-20 overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat bg-stone-900"
        style={bgStyle}
      />
      <div className="absolute inset-0 bg-gradient-to-br from-stone-950/95 via-stone-900/90 to-red-950/80" />

      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-700 via-red-500 to-transparent" />
      <div className="absolute top-8 right-8 sm:top-16 sm:right-16 w-40 h-40 sm:w-64 sm:h-64 border border-white/5 rounded-full max-sm:opacity-50" />
      <div className="absolute top-12 right-12 sm:top-24 sm:right-24 w-32 h-32 sm:w-48 sm:h-48 border border-white/5 rounded-full max-sm:opacity-50" />
      <div className="absolute bottom-8 left-8 sm:bottom-16 sm:left-16 w-32 h-32 sm:w-48 sm:h-48 border border-white/5 rounded-full max-sm:opacity-50" />

      <div
        className={cn(
          facultyContainer,
          "relative z-10 max-w-4xl text-center !px-6",
        )}
      >
        <div className="inline-flex items-center gap-2 bg-red-700/20 border border-red-500/30 text-red-400 text-xs font-semibold tracking-widest uppercase px-4 py-1.5 rounded-full mb-6 sm:mb-8">
          <span className="w-1.5 h-1.5 rounded-full bg-red-400 animate-pulse" />
          {cta.badge}
        </div>

        <h2 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-serif font-bold text-white leading-tight mb-4 sm:mb-6">
          {cta.title}{" "}
          <span className="text-red-400 italic">{cta.titleHighlight}</span>{" "}
          Educators
        </h2>

        <p className="text-stone-300 text-base sm:text-lg leading-relaxed max-w-2xl mx-auto mb-8 sm:mb-12 font-light">
          {cta.subtitle}
        </p>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-3 sm:gap-4">
          <Link
            href={cta.primaryHref}
            className="group inline-flex items-center justify-center gap-3 bg-red-700 hover:bg-red-600 text-white font-semibold px-8 py-4 rounded-xl transition-all duration-200 shadow-lg hover:shadow-red-700/30 text-sm w-full sm:w-auto"
          >
            {cta.primaryLabel}
            <ArrowRight
              size={16}
              className="group-hover:translate-x-1 transition-transform"
            />
          </Link>
          <Link
            href={cta.secondaryHref}
            className="group inline-flex items-center justify-center gap-3 bg-white/10 hover:bg-white/20 border border-white/20 text-white font-semibold px-8 py-4 rounded-xl transition-all duration-200 text-sm w-full sm:w-auto"
          >
            <Phone size={15} className="text-stone-300" />
            {cta.secondaryLabel}
          </Link>
        </div>

        {cta.trustIndicators.length > 0 ? (
          <div className="mt-10 sm:mt-14 pt-8 sm:pt-10 border-t border-white/10 flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-8 text-stone-400 text-xs tracking-widest uppercase font-medium">
            {cta.trustIndicators.map((item, index) => (
              <span key={item} className="flex items-center gap-4 sm:gap-8">
                {index > 0 ? (
                  <span
                    className="hidden sm:inline-block w-1 h-1 rounded-full bg-stone-600"
                    aria-hidden
                  />
                ) : null}
                {item}
              </span>
            ))}
          </div>
        ) : null}
      </div>
    </section>
  );
}
