"use client";

import { Search, X } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  facultyContainer,
  facultyStickyFilterTop,
} from "@/components/faculty/faculty-layout";

type Props = {
  categories: string[];
  activeCategory: string;
  searchQuery: string;
  onCategoryChange: (cat: string) => void;
  onSearchChange: (q: string) => void;
};

export function FacultyFilterSection({
  categories,
  activeCategory,
  searchQuery,
  onCategoryChange,
  onSearchChange,
}: Props) {
  return (
    <section
      className={cn(
        "sticky z-40 bg-white border-b border-stone-200 shadow-sm",
        facultyStickyFilterTop,
      )}
    >
      <div className={cn(facultyContainer, "py-3 md:py-4")}>
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <div className="flex flex-wrap gap-2 flex-1 min-w-0">
            {categories.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => onCategoryChange(cat)}
                className={cn(
                  "max-w-full px-3 sm:px-4 py-1.5 rounded-full text-xs sm:text-sm font-medium border transition-all duration-200",
                  activeCategory === cat
                    ? "bg-red-700 text-white border-red-700 shadow-sm"
                    : "bg-white text-stone-600 border-stone-200 hover:border-red-300 hover:text-red-700",
                )}
              >
                <span className="truncate block max-w-[14rem] sm:max-w-none">
                  {cat}
                </span>
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-64 lg:w-72 flex-shrink-0">
            <Search
              size={16}
              className="absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400"
            />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search faculty..."
              className="w-full pl-10 pr-10 py-2.5 text-sm bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-red-500/30 focus:border-red-400 transition-all placeholder:text-stone-400 text-stone-800"
            />
            {searchQuery ? (
              <button
                type="button"
                onClick={() => onSearchChange("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-600 transition-colors"
              >
                <X size={15} />
              </button>
            ) : null}
          </div>
        </div>
      </div>
    </section>
  );
}
