export const facultySectionPy = "py-12 md:py-14 lg:py-[72px]";

export const facultyContainer = "mx-auto max-w-7xl px-6 lg:px-8";

export const facultySectionTitleMb = "mb-8 md:mb-10";

export const facultyStickyFilterTop =
  "top-[var(--site-header-height-mobile)] lg:top-[var(--site-header-height)]";

/** Program section anchors: fixed header + sticky filter (~4rem) */
export const facultySectionScrollAnchor =
  "scroll-mt-[calc(var(--site-header-height-mobile)+4rem)] lg:scroll-mt-[calc(var(--site-header-height)+4rem)]";
