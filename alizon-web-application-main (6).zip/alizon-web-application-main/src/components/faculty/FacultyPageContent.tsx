"use client";

import { useEffect, useMemo, useState } from "react";
import type { FacultyDisplay } from "@/types/cms";
import { facultyMemberToDisplay } from "@/types/cms";
import {
  fetchFacultyPageExtras,
  fetchPublishedFacultyLeaders,
  fetchPublishedFacultyMembers,
} from "@/lib/cms";
import { DEFAULT_FACULTY_PAGE_EXTRAS } from "@/lib/cms";
import type { Program } from "@/types/program";
import { FacultyStatisticsSection } from "@/components/faculty/FacultyStatisticsSection";
import { FacultyFilterSection } from "@/components/faculty/FacultyFilterSection";
import {
  FacultyDirectory,
  type FacultyProgramSection,
} from "@/components/faculty/FacultyDirectory";
import { FacultyLeadershipSection } from "@/components/faculty/FacultyLeadershipSection";
import { FacultyWhyLearnSection } from "@/components/faculty/FacultyWhyLearnSection";
import { FacultyCtaSection } from "@/components/faculty/FacultyCtaSection";
import { FacultyModal } from "@/components/faculty/FacultyModal";
import type { FacultyLeader, FacultyPageExtras } from "@/types/cms";
import type { FacultyMember } from "@/types/cms";
import { FACULTY_CONTENT_SECTION_ID } from "@/lib/site-hero";

const ALL_FACULTIES = "All Faculties";

export function FacultyPageContent() {
  const [activeCategory, setActiveCategory] = useState(ALL_FACULTIES);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFaculty, setSelectedFaculty] = useState<FacultyDisplay | null>(
    null,
  );
  const [members, setMembers] = useState<FacultyMember[]>([]);
  const [leaders, setLeaders] = useState<FacultyLeader[]>([]);
  const [extras, setExtras] = useState<FacultyPageExtras>(
    DEFAULT_FACULTY_PAGE_EXTRAS,
  );
  const [programs, setPrograms] = useState<Program[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [memberData, leaderData, extrasData, programsRes] =
          await Promise.all([
            fetchPublishedFacultyMembers(),
            fetchPublishedFacultyLeaders(),
            fetchFacultyPageExtras(),
            fetch("/api/public/programs", { cache: "no-store" }),
          ]);
        let programList: Program[] = [];
        if (programsRes.ok) {
          const json = (await programsRes.json()) as { programs?: Program[] };
          programList = (json.programs ?? []).filter(
            (p) => p.status === "active" || p.active,
          );
        }
        if (!cancelled) {
          setMembers(memberData);
          setLeaders(leaderData);
          setExtras(extrasData);
          setPrograms(programList);
        }
      } catch {
        /* defaults */
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const categories = useMemo(
    () => [ALL_FACULTIES, ...programs.map((p) => p.name)],
    [programs],
  );

  const sections: FacultyProgramSection[] = useMemo(() => {
    return programs.map((program) => {
      const facultyForProgram = members
        .filter((m) => m.programIds.includes(program.id))
        .sort((a, b) => a.order - b.order)
        .map(facultyMemberToDisplay);

      const description =
        program.shortDescription?.trim() ||
        program.fullDescription?.trim().slice(0, 280) ||
        "";

      return {
        id: program.id,
        name: program.name,
        description,
        category: program.name,
        faculty: facultyForProgram,
      };
    });
  }, [programs, members]);

  if (loading) {
    return (
      <div
        id={FACULTY_CONTENT_SECTION_ID}
        className="min-h-[40vh] bg-white flex items-center justify-center overflow-x-hidden"
      >
        <p className="text-sm text-muted-foreground">Loading faculty…</p>
      </div>
    );
  }

  return (
    <div
      id={FACULTY_CONTENT_SECTION_ID}
      className="min-h-screen bg-white font-sans antialiased overflow-x-hidden"
    >
      <FacultyStatisticsSection stats={extras.stats} />
      <FacultyFilterSection
        categories={categories}
        activeCategory={activeCategory}
        searchQuery={searchQuery}
        onCategoryChange={setActiveCategory}
        onSearchChange={setSearchQuery}
      />
      <FacultyDirectory
        sections={sections}
        onViewProfile={setSelectedFaculty}
        activeCategory={activeCategory}
        searchQuery={searchQuery}
      />
      <FacultyLeadershipSection leaders={leaders} />
      <FacultyWhyLearnSection features={extras.whyLearnFeatures} />
      <FacultyCtaSection cta={extras.cta} />
      <FacultyModal
        faculty={selectedFaculty}
        onClose={() => setSelectedFaculty(null)}
      />
    </div>
  );
}
