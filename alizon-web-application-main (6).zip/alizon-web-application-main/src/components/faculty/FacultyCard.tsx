"use client";

import { Mail, Clock, BookOpen } from "lucide-react";
import type { FacultyDisplay } from "@/types/cms";
import { cn } from "@/lib/utils";

const designationColors: Record<string, string> = {
  "Head of Department": "bg-red-100 text-red-800",
  Professor: "bg-stone-100 text-stone-800",
  "Associate Professor": "bg-amber-50 text-amber-800",
  "Assistant Professor": "bg-sky-50 text-sky-800",
  Lecturer: "bg-emerald-50 text-emerald-800",
};

type Props = {
  faculty: FacultyDisplay;
  onViewProfile: (f: FacultyDisplay) => void;
};

export function FacultyCard({ faculty, onViewProfile }: Props) {
  const badgeColor =
    designationColors[faculty.designation] ?? "bg-stone-100 text-stone-700";

  return (
    <div className="group bg-white rounded-2xl shadow-sm border border-stone-100 overflow-hidden hover:shadow-lg hover:-translate-y-1 transition-all duration-300 flex flex-col h-full">
      <div className="relative overflow-hidden h-48 sm:h-56 bg-stone-100">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={faculty.image}
          alt={faculty.name}
          className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />
        <div className="absolute top-3 left-3 right-3">
          <span
            className={cn(
              "inline-block max-w-full text-xs font-semibold px-3 py-1 rounded-full line-clamp-2",
              badgeColor,
            )}
          >
            {faculty.designation}
          </span>
        </div>
      </div>

      <div className="p-4 sm:p-5 flex flex-col flex-1">
        <h3 className="text-base font-bold text-stone-900 leading-tight mb-0.5">
          {faculty.name}
        </h3>
        <p className="text-red-700 text-xs font-semibold tracking-wide uppercase mb-3">
          {faculty.department}
        </p>

        <div className="space-y-2 mb-4 flex-1">
          <div className="flex items-start gap-2 text-stone-600 text-xs">
            <BookOpen size={13} className="text-stone-400 mt-0.5 flex-shrink-0" />
            <span className="line-clamp-2">
              <span className="font-medium">Qualification:</span>{" "}
              {faculty.qualification}
            </span>
          </div>
          <div className="flex items-start gap-2 text-stone-600 text-xs">
            <BookOpen size={13} className="text-stone-400 mt-0.5 flex-shrink-0" />
            <span className="line-clamp-2">
              <span className="font-medium">Specialization:</span>{" "}
              {faculty.specialization}
            </span>
          </div>
          <div className="flex items-center gap-2 text-stone-600 text-xs">
            <Clock size={13} className="text-stone-400 flex-shrink-0" />
            <span>{faculty.experience} Years Experience</span>
          </div>
          <div className="flex items-center gap-2 text-stone-600 text-xs min-w-0">
            <Mail size={13} className="text-stone-400 flex-shrink-0" />
            <a
              href={`mailto:${faculty.email}`}
              className="hover:text-red-700 transition-colors truncate min-w-0"
            >
              {faculty.email}
            </a>
          </div>
        </div>

        <button
          type="button"
          onClick={() => onViewProfile(faculty)}
          className="mt-auto w-full bg-stone-900 text-white text-sm font-semibold py-2.5 rounded-xl hover:bg-red-700 transition-colors duration-200"
        >
          View Profile
        </button>
      </div>
    </div>
  );
}
