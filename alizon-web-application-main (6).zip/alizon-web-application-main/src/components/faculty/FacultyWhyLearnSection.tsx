"use client";

import {
  Briefcase,
  FlaskConical,
  Globe,
  Award,
  Lightbulb,
  Users,
} from "lucide-react";
import type { FacultyWhyLearnFeature } from "@/types/cms";
import { cn } from "@/lib/utils";
import {
  facultyContainer,
  facultySectionPy,
  facultySectionTitleMb,
} from "@/components/faculty/faculty-layout";

const iconMap: Record<string, React.ElementType> = {
  Briefcase,
  FlaskConical,
  Globe,
  Award,
  Lightbulb,
  Users,
};

type Props = {
  features: FacultyWhyLearnFeature[];
};

export function FacultyWhyLearnSection({ features }: Props) {
  if (features.length === 0) return null;

  return (
    <section className={cn("bg-white", facultySectionPy)}>
      <div className={facultyContainer}>
        <div
          className={cn(
            "text-center max-w-2xl mx-auto",
            facultySectionTitleMb,
            "md:mb-16",
          )}
        >
          <div className="inline-flex items-center gap-2 text-red-700 text-xs font-bold tracking-widest uppercase mb-4">
            <span className="w-6 h-px bg-red-700" />
            Our Advantage
            <span className="w-6 h-px bg-red-700" />
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-stone-900 leading-tight mb-4">
            Why Learn From Our Faculty
          </h2>
          <p className="text-stone-500 text-sm sm:text-base leading-relaxed">
            Our faculty members are more than instructors — they are mentors,
            researchers, and innovators dedicated to your success.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {features.map((feature) => {
            const Icon = iconMap[feature.icon] || Briefcase;
            return (
              <div
                key={feature.title}
                className="group p-5 sm:p-6 lg:p-8 bg-stone-50 rounded-2xl border border-stone-100 hover:bg-white hover:shadow-lg hover:-translate-y-1 transition-all duration-300 cursor-default"
              >
                <div className="w-12 h-12 bg-white group-hover:bg-red-50 border border-stone-200 group-hover:border-red-200 rounded-xl flex items-center justify-center mb-5 transition-all duration-300 shadow-sm">
                  <Icon
                    size={22}
                    className="text-stone-600 group-hover:text-red-700 transition-colors duration-300"
                    strokeWidth={1.5}
                  />
                </div>
                <h3 className="text-lg font-bold text-stone-900 mb-3 font-serif">
                  {feature.title}
                </h3>
                <p className="text-stone-500 text-sm leading-relaxed">
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
