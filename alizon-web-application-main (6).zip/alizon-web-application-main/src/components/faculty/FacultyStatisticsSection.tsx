"use client";

import { useEffect, useRef, useState } from "react";
import { Users, BookOpen, GraduationCap, Star } from "lucide-react";
import type { FacultyPageStat } from "@/types/cms";
import { cn } from "@/lib/utils";
import {
  facultyContainer,
  facultySectionPy,
  facultySectionTitleMb,
} from "@/components/faculty/faculty-layout";

const iconMap: Record<string, React.ElementType> = {
  Users,
  BookOpen,
  GraduationCap,
  Star,
};

function useCountUp(target: number, duration = 1800, start: boolean) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!start) return;
    let startTime: number | null = null;
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(eased * target));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [target, duration, start]);

  return count;
}

function StatCard({
  stat,
  start,
}: {
  stat: FacultyPageStat;
  start: boolean;
}) {
  const numericValue =
    typeof stat.value === "number" ? stat.value : Number(stat.value) || 0;
  const count = useCountUp(numericValue, 1800, start);
  const Icon = iconMap[stat.icon] || Users;
  const displayValue =
    typeof stat.value === "number" || !Number.isNaN(Number(stat.value))
      ? count
      : stat.value;

  return (
    <div className="group relative bg-white rounded-2xl p-5 sm:p-6 lg:p-8 shadow-sm border border-stone-100 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-red-50 rounded-full translate-x-10 -translate-y-10 group-hover:bg-red-100 transition-colors duration-300" />
      <div className="relative z-10">
        <div className="inline-flex items-center justify-center w-12 h-12 sm:w-14 sm:h-14 bg-red-50 rounded-xl mb-4 sm:mb-5 group-hover:bg-red-100 transition-colors duration-300">
          <Icon className="text-red-700" size={26} strokeWidth={1.5} />
        </div>
        <div className="text-3xl md:text-4xl font-serif font-bold text-stone-900 mb-1">
          {displayValue}
          {stat.suffix ? (
            <span className="text-red-600">{stat.suffix}</span>
          ) : null}
        </div>
        <div className="text-stone-500 font-medium text-sm tracking-wide uppercase">
          {stat.label}
        </div>
      </div>
    </div>
  );
}

type Props = {
  stats: FacultyPageStat[];
};

export function FacultyStatisticsSection({ stats }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 },
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      className={cn("bg-stone-50 border-b border-stone-100", facultySectionPy)}
    >
      <div className={facultyContainer}>
        <div className={cn("text-center", facultySectionTitleMb)}>
          <p className="text-red-700 text-sm font-semibold tracking-widest uppercase mb-3">
            Faculty at a Glance
          </p>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-stone-900">
            Numbers That Speak for Themselves
          </h2>
        </div>

        <div
          ref={ref}
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6"
        >
          {stats.map((stat) => (
            <StatCard key={stat.label} stat={stat} start={visible} />
          ))}
        </div>
      </div>
    </section>
  );
}
