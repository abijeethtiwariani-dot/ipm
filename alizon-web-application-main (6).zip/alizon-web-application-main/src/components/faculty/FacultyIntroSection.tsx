import { PageIntroSection } from "@/components/hero-landing/PageIntroSection";
import {
  FACULTY_CONTENT_SECTION_ID,
  FACULTY_INTRO_SECTION_ID,
} from "@/lib/site-hero";

export function FacultyIntroSection() {
  return (
    <PageIntroSection
      id={FACULTY_INTRO_SECTION_ID}
      sectionClassName="py-12 md:py-14 lg:py-20"
      className="scroll-mt-[var(--site-header-height-mobile)] lg:scroll-mt-[var(--site-header-height)]"
      heading="Faculty & Staff Resources"
      intro="Access academic resources, research tools, administrative services, policies, and professional development opportunities."
      buttonText="Explore Resources"
      buttonScrollTargetId={FACULTY_CONTENT_SECTION_ID}
    />
  );
}
