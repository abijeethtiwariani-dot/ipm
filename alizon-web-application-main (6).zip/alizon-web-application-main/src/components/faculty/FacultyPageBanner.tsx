"use client";

import { useEffect, useState } from "react";
import Image, { type StaticImageData } from "next/image";
import { HomeHeroStack } from "@/components/home/HomeHeroStack";
import {
  DEFAULT_FACULTY_PAGE_BANNER,
  fetchFacultyPageBanner,
} from "@/lib/cms";
import { shouldUnoptimizeCmsSrc } from "@/lib/cms-image-url";
import {
  FACULTY_HERO_DATA_ATTR,
  FACULTY_INTRO_SECTION_ID,
} from "@/lib/site-hero";
import { cn } from "@/lib/utils";

type Props = {
  fallback: StaticImageData;
};

function bannerImageProps(src: string | StaticImageData) {
  return {
    src,
    unoptimized: typeof src === "string" && shouldUnoptimizeCmsSrc(src),
  };
}

export function FacultyPageBanner({ fallback }: Props) {
  const [banner, setBanner] = useState(DEFAULT_FACULTY_PAGE_BANNER);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await fetchFacultyPageBanner();
        if (!cancelled) setBanner(data);
      } catch {
        /* use defaults */
      } finally {
        if (!cancelled) setReady(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const imageSrc = banner.imageUrl.trim() || fallback;

  const stackProps = {
    showExploreBar: true as const,
    exploreLabel: "Explore Faculty & Staff",
    exploreTargetSectionId: FACULTY_INTRO_SECTION_ID,
    dataAttr: FACULTY_HERO_DATA_ATTR,
    "aria-label": "Faculty page hero" as const,
  };

  if (!ready) {
    return (
      <HomeHeroStack {...stackProps} className="bg-muted animate-pulse">
        <div className="h-full min-h-0 w-full" aria-hidden />
      </HomeHeroStack>
    );
  }

  return (
    <HomeHeroStack {...stackProps}>
      <section className="relative h-full min-h-0 w-full">
        <Image
          alt={banner.pageTitle}
          fill
          priority
          sizes="100vw"
          className="h-full w-full object-cover hero-image-rich"
          {...bannerImageProps(imageSrc)}
        />

        <div
          className="hero-unified-overlay pointer-events-none absolute inset-0 z-10"
          aria-hidden
        />

        <div className="absolute inset-0 z-20 site-hero-centered-shell">
          <div className="container mx-auto w-full px-4 sm:px-6 py-6 md:py-8">
            <div className="max-w-3xl mx-auto text-center">
              <h1
                className={cn(
                  "site-hero-title !text-white text-center mb-4",
                )}
              >
                {banner.pageTitle}
              </h1>
              {banner.pageSubtitle ? (
                <p
                  className={cn(
                    "site-hero-desc !text-white text-center font-medium",
                  )}
                >
                  {banner.pageSubtitle}
                </p>
              ) : null}
            </div>
          </div>
        </div>
      </section>
    </HomeHeroStack>
  );
}
