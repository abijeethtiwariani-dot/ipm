"use client";

import { Users } from "lucide-react";
import type { FacultyDisplay } from "@/types/cms";
import { FacultyCard } from "@/components/faculty/FacultyCard";
import { cn } from "@/lib/utils";
import {
  facultyContainer,
  facultySectionPy,
  facultySectionScrollAnchor,
} from "@/components/faculty/faculty-layout";

export type FacultyProgramSection = {
  id: string;
  name: string;
  description: string;
  category: string;
  faculty: FacultyDisplay[];
};

type Props = {
  sections: FacultyProgramSection[];
  onViewProfile: (f: FacultyDisplay) => void;
  activeCategory: string;
  searchQuery: string;
};

export function FacultyDirectory({
  sections,
  onViewProfile,
  activeCategory,
  searchQuery,
}: Props) {
  const q = searchQuery.toLowerCase().trim();

  const filtered = sections
    .filter((section) => {
      if (activeCategory !== "All Faculties" && section.category !== activeCategory) {
        return false;
      }
      return true;
    })
    .map((section) => ({
      ...section,
      faculty: section.faculty.filter((f) => {
        if (!q) return true;
        return (
          f.name.toLowerCase().includes(q) ||
          f.department.toLowerCase().includes(q) ||
          f.designation.toLowerCase().includes(q) ||
          f.specialization.toLowerCase().includes(q) ||
          f.qualification.toLowerCase().includes(q)
        );
      }),
    }))
    .filter((section) => section.faculty.length > 0);

  if (filtered.length === 0) {
    return (
      <section className={cn("bg-white", facultySectionPy)}>
        <div className={cn(facultyContainer, "text-center")}>
          <div className="w-16 h-16 bg-stone-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Users size={24} className="text-stone-400" />
          </div>
          <h3 className="text-xl font-semibold text-stone-800 mb-2">
            No faculty found
          </h3>
          <p className="text-stone-500 text-sm">
            Try adjusting your search or filter.
          </p>
        </div>
      </section>
    );
  }

  return (
    <section className={cn("bg-white", facultySectionPy)}>
      <div
        className={cn(
          facultyContainer,
          "space-y-12 md:space-y-16 lg:space-y-20",
        )}
      >
        {filtered.map((section) => (
          <div
            key={section.id}
            id={section.id}
            className={facultySectionScrollAnchor}
          >
            <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:gap-4 mb-8 md:mb-10 pb-6 border-b border-stone-100">
              <div className="flex-1 min-w-0">
                <div className="inline-flex items-center gap-2 text-red-700 text-xs font-bold tracking-widest uppercase mb-2">
                  <span className="w-6 h-px bg-red-700" />
                  Program
                </div>
                <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-900 mb-2">
                  {section.name}
                </h2>
                {section.description ? (
                  <p className="text-stone-500 text-sm leading-relaxed max-w-2xl">
                    {section.description}
                  </p>
                ) : null}
              </div>
              <div className="flex-shrink-0 flex items-center gap-2 text-stone-500 bg-stone-50 border border-stone-200 rounded-xl px-4 py-2 self-start sm:self-auto">
                <Users size={15} className="text-red-600" />
                <span className="text-sm font-semibold text-stone-700">
                  {section.faculty.length} Faculty
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
              {section.faculty.map((f) => (
                <FacultyCard
                  key={`${section.id}-${f.id}`}
                  faculty={f}
                  onViewProfile={onViewProfile}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
