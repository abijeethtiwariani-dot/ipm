"use client";

import { Award } from "lucide-react";
import type { FacultyLeader } from "@/types/cms";
import { cn } from "@/lib/utils";
import {
  facultyContainer,
  facultySectionTitleMb,
} from "@/components/faculty/faculty-layout";

type Props = {
  leaders: FacultyLeader[];
};

export function FacultyLeadershipSection({ leaders }: Props) {
  if (leaders.length === 0) return null;

  return (
    <section className="py-12 md:py-16 lg:py-24 bg-stone-50">
      <div className={facultyContainer}>
        <div className={cn("max-w-2xl", facultySectionTitleMb, "md:mb-16")}>
          <div className="inline-flex items-center gap-2 text-red-700 text-xs font-bold tracking-widest uppercase mb-4">
            <span className="w-6 h-px bg-red-700" />
            Senior Leadership
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-stone-900 leading-tight mb-4">
            Academic Leadership
          </h2>
          <p className="text-stone-500 text-sm sm:text-base leading-relaxed">
            Visionary academics who guide our institution with scholarship,
            integrity, and an unwavering commitment to educational excellence.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8">
          {leaders.map((leader, i) => (
            <div
              key={leader.id}
              className={cn(
                "group bg-white rounded-3xl overflow-hidden shadow-sm border border-stone-100 hover:shadow-xl transition-all duration-300 flex flex-col",
                i === 0 ? "md:col-span-2 md:flex-row" : "md:flex-row",
              )}
            >
              <div
                className={cn(
                  "relative overflow-hidden flex-shrink-0 w-full",
                  i === 0
                    ? "h-56 md:h-auto md:w-56 lg:w-72"
                    : "h-48 md:h-auto md:w-48 lg:w-56",
                )}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={leader.imageUrl}
                  alt={leader.name}
                  className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-stone-900/30 via-transparent to-transparent md:bg-gradient-to-r md:from-transparent md:to-transparent" />
              </div>

              <div
                className={cn(
                  "flex flex-col justify-center min-w-0 p-5 sm:p-7",
                  i === 0 && "md:py-10",
                )}
              >
                <div className="text-red-700 text-xs font-bold tracking-widest uppercase mb-2">
                  {leader.department}
                </div>
                <h3
                  className={cn(
                    "font-serif font-bold text-stone-900 mb-1",
                    i === 0 ? "text-xl sm:text-2xl lg:text-3xl" : "text-lg sm:text-xl",
                  )}
                >
                  {leader.name}
                </h3>
                <p className="text-stone-500 text-sm font-medium mb-4">
                  {leader.position}
                </p>
                <p className="text-stone-600 text-sm leading-relaxed mb-5 line-clamp-3">
                  {leader.bio}
                </p>

                <ul className="space-y-2">
                  {leader.achievements
                    .slice(0, i === 0 ? 3 : 2)
                    .map((ach, j) => (
                      <li
                        key={j}
                        className="flex items-start gap-2 text-xs text-stone-600"
                      >
                        <Award
                          size={13}
                          className="text-amber-500 mt-0.5 flex-shrink-0"
                        />
                        {ach}
                      </li>
                    ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
