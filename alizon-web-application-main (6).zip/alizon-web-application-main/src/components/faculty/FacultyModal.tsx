"use client";

import { useEffect } from "react";
import {
  X,
  Mail,
  Clock,
  GraduationCap,
  BookOpen,
  Award,
  FlaskConical,
  Star,
} from "lucide-react";
import type { FacultyDisplay } from "@/types/cms";
import { cn } from "@/lib/utils";

type Props = {
  faculty: FacultyDisplay | null;
  onClose: () => void;
};

export function FacultyModal({ faculty, onClose }: Props) {
  useEffect(() => {
    if (faculty) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [faculty]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);

  if (!faculty) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      onClick={onClose}
      role="presentation"
    >
      <div className="absolute inset-0 bg-stone-950/70 backdrop-blur-sm animate-fade-in" />

      <div
        className="relative z-10 bg-white rounded-3xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto animate-slide-up"
        onClick={(e) => e.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-labelledby="faculty-modal-title"
      >
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 sm:top-5 sm:right-5 z-20 w-9 h-9 flex items-center justify-center bg-stone-100 hover:bg-red-100 text-stone-600 hover:text-red-700 rounded-full transition-colors"
        >
          <X size={18} />
        </button>

        <div className="relative bg-gradient-to-br from-stone-900 to-stone-800 rounded-t-3xl p-4 sm:p-6 lg:p-8 pb-0 overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-red-700/10 rounded-full translate-x-24 -translate-y-24" />
          <div className="absolute bottom-0 left-1/2 w-full h-px bg-stone-700" />

          <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-end pb-6 sm:pb-8 relative z-10">
            <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-2xl overflow-hidden flex-shrink-0 border-4 border-white/10 shadow-xl">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={faculty.image}
                alt={faculty.name}
                className="w-full h-full object-cover object-top"
              />
            </div>
            <div className="flex-1 min-w-0">
              <div className="inline-block bg-red-700/20 border border-red-500/30 text-red-400 text-xs font-semibold tracking-widest uppercase px-3 py-1 rounded-full mb-3">
                {faculty.designation}
              </div>
              <h2
                id="faculty-modal-title"
                className="text-2xl sm:text-3xl font-serif font-bold text-white mb-1"
              >
                {faculty.name}
              </h2>
              <p className="text-stone-400 text-sm font-medium">
                {faculty.department} Department
              </p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 border-b border-stone-100">
          <div
            className={cn(
              "py-3 px-4 sm:py-4 sm:px-6 text-center border-stone-100",
              "border-b sm:border-b-0 sm:border-r",
            )}
          >
            <div className="flex items-center justify-center gap-1.5 text-stone-400 text-xs mb-1">
              <GraduationCap size={13} />
              Qualification
            </div>
            <p className="text-stone-800 text-xs font-semibold leading-tight break-words">
              {faculty.qualification.split(",")[0]}
            </p>
          </div>
          <div
            className={cn(
              "py-3 px-4 sm:py-4 sm:px-6 text-center border-stone-100",
              "border-b sm:border-b-0 sm:border-r",
            )}
          >
            <div className="flex items-center justify-center gap-1.5 text-stone-400 text-xs mb-1">
              <Clock size={13} />
              Experience
            </div>
            <p className="text-stone-800 text-sm font-bold">
              {faculty.experience}
              <span className="text-xs font-normal ml-1">yrs</span>
            </p>
          </div>
          <div className="py-3 px-4 sm:py-4 sm:px-6 text-center">
            <div className="flex items-center justify-center gap-1.5 text-stone-400 text-xs mb-1">
              <Mail size={13} />
              Contact
            </div>
            <a
              href={`mailto:${faculty.email}`}
              className="text-red-700 text-xs font-medium hover:underline break-all inline-block max-w-full"
            >
              {faculty.email}
            </a>
          </div>
        </div>

        <div className="p-4 sm:p-6 lg:p-8 space-y-6 sm:space-y-8">
          <div>
            <h3 className="text-xs font-bold tracking-widest uppercase text-stone-400 mb-3">
              Biography
            </h3>
            <p className="text-stone-700 text-sm leading-relaxed">{faculty.bio}</p>
          </div>

          {faculty.expertise.length > 0 ? (
            <div>
              <h3 className="flex items-center gap-2 text-xs font-bold tracking-widest uppercase text-stone-400 mb-3">
                <Star size={13} /> Areas of Expertise
              </h3>
              <div className="flex flex-wrap gap-2">
                {faculty.expertise.map((e) => (
                  <span
                    key={e}
                    className="px-3 py-1 bg-stone-100 text-stone-700 text-xs font-medium rounded-full border border-stone-200"
                  >
                    {e}
                  </span>
                ))}
              </div>
            </div>
          ) : null}

          {faculty.researchInterests.length > 0 ? (
            <div>
              <h3 className="flex items-center gap-2 text-xs font-bold tracking-widest uppercase text-stone-400 mb-3">
                <FlaskConical size={13} /> Research Interests
              </h3>
              <div className="flex flex-wrap gap-2">
                {faculty.researchInterests.map((r) => (
                  <span
                    key={r}
                    className="px-3 py-1 bg-red-50 text-red-800 text-xs font-medium rounded-full border border-red-100"
                  >
                    {r}
                  </span>
                ))}
              </div>
            </div>
          ) : null}

          {faculty.publications.length > 0 ? (
            <div>
              <h3 className="flex items-center gap-2 text-xs font-bold tracking-widest uppercase text-stone-400 mb-3">
                <BookOpen size={13} /> Selected Publications
              </h3>
              <ul className="space-y-2">
                {faculty.publications.map((p, i) => (
                  <li
                    key={i}
                    className="flex items-start gap-2.5 text-sm text-stone-700"
                  >
                    <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-red-600 flex-shrink-0" />
                    {p}
                  </li>
                ))}
              </ul>
            </div>
          ) : null}

          {faculty.awards.length > 0 ? (
            <div>
              <h3 className="flex items-center gap-2 text-xs font-bold tracking-widest uppercase text-stone-400 mb-3">
                <Award size={13} /> Awards & Achievements
              </h3>
              <ul className="space-y-2">
                {faculty.awards.map((a, i) => (
                  <li
                    key={i}
                    className="flex items-start gap-2.5 text-sm text-stone-700"
                  >
                    <Award
                      size={14}
                      className="text-amber-500 mt-0.5 flex-shrink-0"
                    />
                    {a}
                  </li>
                ))}
              </ul>
            </div>
          ) : null}

          <div className="pt-2">
            <a
              href={`mailto:${faculty.email}`}
              className="inline-flex items-center justify-center gap-2 w-full sm:w-auto bg-red-700 hover:bg-red-800 text-white text-sm font-semibold px-6 py-3 rounded-xl transition-colors"
            >
              <Mail size={15} />
              Contact {faculty.name.split(" ")[0]}
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}
