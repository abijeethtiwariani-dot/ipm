"use client";

import Image from "next/image";
import type { CareersWhyWorkContent } from "@/types/cms";
import { buildWhyWorkGradient } from "@/lib/careers-why-work-style";
import { cn } from "@/lib/utils";

interface WhyWorkBackgroundProps {
  content: CareersWhyWorkContent;
  className?: string;
}

export function WhyWorkBackground({ content, className }: WhyWorkBackgroundProps) {
  const useImage = content.backgroundType === "image" && Boolean(content.backgroundImageUrl);
  const mobileImage = content.backgroundMobileImageUrl || content.backgroundImageUrl;

  return (
    <div className={cn("pointer-events-none absolute inset-0 overflow-hidden", className)} aria-hidden>
      {useImage ? (
        <>
          {content.backgroundImageUrl && (
            <Image
              src={content.backgroundImageUrl}
              alt=""
              fill
              priority={false}
              className="hidden object-cover md:block"
              sizes="100vw"
            />
          )}
          {mobileImage && (
            <Image
              src={mobileImage}
              alt=""
              fill
              priority={false}
              className="object-cover md:hidden"
              sizes="100vw"
            />
          )}
        </>
      ) : (
        <div
          className="absolute inset-0"
          style={{ background: buildWhyWorkGradient(content) }}
        />
      )}

      <div
        className="absolute inset-0"
        style={{
          backgroundColor: content.overlayColor,
          opacity: content.overlayOpacity,
        }}
      />

      <div className="absolute -left-24 top-1/4 h-72 w-72 rounded-full bg-white/10 blur-3xl" />
      <div className="absolute -right-16 bottom-1/4 h-64 w-64 rounded-full bg-indigo-400/20 blur-3xl" />
    </div>
  );
}
