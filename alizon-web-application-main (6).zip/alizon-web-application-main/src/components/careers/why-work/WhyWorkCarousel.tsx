"use client";

import { useEffect, useMemo, useState } from "react";
import AutoScroll from "embla-carousel-auto-scroll";
import { motion } from "framer-motion";
import type { CareersWhyWorkCard, CareersWhyWorkContent } from "@/types/cms";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { getWhyWorkCarouselBasisClasses } from "@/lib/careers-why-work-style";
import { WhyWorkGlassCard } from "@/components/careers/why-work/WhyWorkGlassCard";
import { useIsMobile } from "@/hooks/use-mobile";
import { cn } from "@/lib/utils";

interface WhyWorkCarouselProps {
  content: CareersWhyWorkContent;
  cards: CareersWhyWorkCard[];
  visible: boolean;
  className?: string;
}

function usePrefersReducedMotion(): boolean {
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const update = () => setReduced(media.matches);
    update();
    media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);

  return reduced;
}

export function WhyWorkCarousel({
  content,
  cards,
  visible,
  className,
}: WhyWorkCarouselProps) {
  const prefersReducedMotion = usePrefersReducedMotion();
  const isMobile = useIsMobile();
  const canLoop = content.carouselLoop && cards.length > 1;
  const enableAutoScroll =
    content.carouselAutoScroll && cards.length > 1 && !prefersReducedMotion && !isMobile;

  const plugins = useMemo(() => {
    if (!enableAutoScroll) return undefined;
    return [
      AutoScroll({
        speed: content.carouselScrollSpeed,
        stopOnInteraction: true,
        stopOnMouseEnter: true,
      }),
    ];
  }, [content.carouselScrollSpeed, enableAutoScroll]);

  const basisClass = getWhyWorkCarouselBasisClasses(
    content.carouselCardsPerViewMobile,
    content.carouselCardsPerViewTablet,
    content.carouselCardsPerViewDesktop,
  );

  if (cards.length === 0) return null;

  return (
    <motion.div
      className={cn(
        "relative z-10 w-full py-4 md:py-8 lg:py-12 lg:pl-0 lg:pr-8",
        className,
      )}
      initial={{ opacity: 0, y: 32 }}
      animate={visible ? { opacity: 1, y: 0 } : { opacity: 0, y: 32 }}
      transition={{ duration: 0.6, delay: 0.15, ease: [0.22, 1, 0.36, 1] }}
    >
      <Carousel
        opts={{
          align: "start",
          loop: canLoop,
          dragFree: false,
          watchDrag: !isMobile,
        }}
        plugins={plugins}
        className="w-full"
        aria-label="Why work at Alizon highlights"
      >
        <CarouselContent className="-ml-4">
          {cards.map((card) => (
            <CarouselItem key={card.id} className={cn("pl-4", basisClass)}>
              <WhyWorkGlassCard card={card} />
            </CarouselItem>
          ))}
        </CarouselContent>
        {cards.length > 1 && (
          <>
            <CarouselPrevious
              className="left-3 z-10 border-white/20 bg-white/10 text-white shadow-md backdrop-blur-sm hover:bg-white/20 disabled:opacity-40"
              aria-label="Previous highlight"
            />
            <CarouselNext
              className="right-3 z-10 border-white/20 bg-white/10 text-white shadow-md backdrop-blur-sm hover:bg-white/20 disabled:opacity-40"
              aria-label="Next highlight"
            />
          </>
        )}
      </Carousel>
    </motion.div>
  );
}
