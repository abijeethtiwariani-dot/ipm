"use client";

import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { motion } from "framer-motion";
import type { CareersWhyWorkContent } from "@/types/cms";
import { Button } from "@/components/ui/button";
import { scrollToHeroSection } from "@/lib/site-hero";
import { cn } from "@/lib/utils";

interface WhyWorkContentPanelProps {
  content: CareersWhyWorkContent;
  visible: boolean;
  className?: string;
}

function resolveScrollTarget(href: string): string | null {
  const trimmed = href.trim();
  if (!trimmed.startsWith("#")) return null;
  const id = trimmed.slice(1);
  return id || null;
}

export function WhyWorkContentPanel({
  content,
  visible,
  className,
}: WhyWorkContentPanelProps) {
  const scrollTarget = resolveScrollTarget(content.ctaHref);
  const showCta = Boolean(content.ctaText?.trim());

  return (
    <motion.div
      className={cn("relative z-10 w-full py-8 md:py-12 lg:px-6 lg:py-16", className)}
      initial={{ opacity: 0, y: 32 }}
      animate={visible ? { opacity: 1, y: 0 } : { opacity: 0, y: 32 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
    >
      <div className="mx-auto w-full max-w-3xl text-center lg:mx-0 lg:max-w-none lg:text-left">
        <p
          className="mb-4 text-xs font-semibold uppercase tracking-[0.2em]"
          style={{ color: "var(--why-work-eyebrow-color)" }}
        >
          {content.eyebrow}
        </p>
        <h2
          id="careers-why-work-heading"
          className="site-section-heading mb-5 lg:text-[2.75rem]"
          style={{ color: "var(--why-work-heading-color)" }}
        >
          {content.heading}
        </h2>
        {content.subtitle ? (
          <p
            className="site-section-intro mx-auto mb-8 mt-0 max-w-none text-center lg:mx-0 lg:text-left"
            style={{ color: "var(--why-work-description-color)" }}
          >
            {content.subtitle}
          </p>
        ) : null}
        {showCta ? (
          scrollTarget ? (
            <Button
              size="lg"
              variant="secondary"
              className="w-fit border-white/20 bg-white/10 text-[var(--why-work-cta-color)] hover:bg-white/20"
              asChild
            >
              <a
                href={content.ctaHref}
                onClick={(event) => {
                  event.preventDefault();
                  scrollToHeroSection(scrollTarget);
                }}
              >
                {content.ctaText}
                <ArrowRight className="h-5 w-5" />
              </a>
            </Button>
          ) : (
            <Button
              size="lg"
              variant="secondary"
              className="w-fit border-white/20 bg-white/10 text-[var(--why-work-cta-color)] hover:bg-white/20"
              asChild
            >
              <Link href={content.ctaHref}>
                {content.ctaText}
                <ArrowRight className="h-5 w-5" />
              </Link>
            </Button>
          )
        ) : null}
      </div>
    </motion.div>
  );
}
