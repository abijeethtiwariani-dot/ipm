"use client";

import Image from "next/image";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import type { CareersWhyWorkCard } from "@/types/cms";
import { getCareersIcon } from "@/lib/careers-icon-map";
import { scrollToHeroSection } from "@/lib/site-hero";
import { cn } from "@/lib/utils";

interface WhyWorkGlassCardProps {
  card: CareersWhyWorkCard;
  className?: string;
}

function resolveScrollTarget(href: string): string | null {
  const trimmed = href.trim();
  if (!trimmed.startsWith("#")) return null;
  const id = trimmed.slice(1);
  return id || null;
}

export function WhyWorkGlassCard({ card, className }: WhyWorkGlassCardProps) {
  const Icon = getCareersIcon(card.icon);
  const hasImage = Boolean(card.imageUrl?.trim());
  const showCta = Boolean(card.ctaText?.trim() && card.ctaLink?.trim());
  const scrollTarget = card.ctaLink ? resolveScrollTarget(card.ctaLink) : null;

  return (
    <article
      className={cn(
        "group flex h-full flex-col overflow-hidden rounded-3xl border transition-all duration-300",
        "hover:-translate-y-1 hover:shadow-[0_24px_48px_rgba(0,0,0,0.25)]",
        className,
      )}
      style={{
        backgroundColor: "var(--why-work-card-bg)",
        opacity: "var(--why-work-card-opacity)",
        backdropFilter: "blur(var(--why-work-card-blur))",
        WebkitBackdropFilter: "blur(var(--why-work-card-blur))",
        borderColor: "var(--why-work-card-border)",
      }}
    >
      <div className="relative aspect-[21/9] w-full overflow-hidden sm:aspect-[2/1] lg:aspect-[16/10]">
        {hasImage ? (
          <Image
            src={card.imageUrl!}
            alt=""
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
            sizes="(max-width: 768px) 100vw, 50vw"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-white/5">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-white/10">
              <Icon className="h-8 w-8 text-white/90" aria-hidden />
            </div>
          </div>
        )}
      </div>
      <div className="flex flex-1 flex-col p-4 sm:p-5 lg:p-6">
        <h3
          className="mb-1.5 text-base font-semibold leading-snug lg:mb-2 lg:text-lg"
          style={{ color: "var(--why-work-card-title)" }}
        >
          {card.title}
        </h3>
        <p
          className="line-clamp-3 flex-1 text-sm leading-relaxed sm:line-clamp-none"
          style={{ color: "var(--why-work-card-desc)" }}
        >
          {card.description}
        </p>
        {showCta ? (
          scrollTarget ? (
            <a
              href={card.ctaLink}
              className="mt-4 inline-flex items-center gap-1 text-sm font-medium transition-opacity hover:opacity-80"
              style={{ color: "var(--why-work-card-cta)" }}
              onClick={(event) => {
                event.preventDefault();
                scrollToHeroSection(scrollTarget);
              }}
            >
              {card.ctaText}
              <ArrowRight className="h-4 w-4" />
            </a>
          ) : (
            <Link
              href={card.ctaLink!}
              className="mt-4 inline-flex items-center gap-1 text-sm font-medium transition-opacity hover:opacity-80"
              style={{ color: "var(--why-work-card-cta)" }}
            >
              {card.ctaText}
              <ArrowRight className="h-4 w-4" />
            </Link>
          )
        ) : null}
      </div>
    </article>
  );
}
