"use client";

import { buildCareersExperienceBlockStyle, CAREERS_EXPERIENCE_OVERLAY } from "@/lib/careers-experience-style";
import { cn } from "@/lib/utils";

type CareersExperienceBackgroundProps = {
  className?: string;
};

export function CareersExperienceBackground({
  className,
}: CareersExperienceBackgroundProps) {
  return (
    <div
      className={cn("pointer-events-none absolute inset-0 overflow-hidden", className)}
      aria-hidden
    >
      <div
        className="absolute inset-0"
        style={{ background: buildCareersExperienceBlockStyle().background }}
      />
      <div
        className="absolute inset-0"
        style={{ backgroundColor: CAREERS_EXPERIENCE_OVERLAY }}
      />

      <div className="absolute -left-32 top-[8%] h-96 w-96 rounded-full bg-blue-500/10 blur-3xl" />
      <div className="absolute left-1/3 top-[35%] h-80 w-80 rounded-full bg-white/5 blur-3xl" />
      <div className="absolute -right-24 top-[55%] h-72 w-72 rounded-full bg-primary/15 blur-3xl" />
      <div className="absolute bottom-[5%] right-1/4 h-64 w-64 rounded-full bg-indigo-400/10 blur-3xl" />
    </div>
  );
}
