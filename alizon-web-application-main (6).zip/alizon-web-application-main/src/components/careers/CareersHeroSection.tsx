"use client";

import { useState } from "react";
import Image from "next/image";
import { Search } from "lucide-react";
import { HomeHeroStack } from "@/components/home/HomeHeroStack";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { shouldUnoptimizeCmsSrc } from "@/lib/cms-image-url";
import {
  CAREERS_HERO_DATA_ATTR,
  CAREERS_INTRO_SECTION_ID,
} from "@/lib/site-hero";
import { cn } from "@/lib/utils";
import type { CareersHeroContent } from "@/types/cms";

const OPEN_POSITIONS_SECTION_ID = "careers-open-positions";

interface CareersHeroSectionProps {
  content: CareersHeroContent;
}

export function CareersHeroSection({ content }: CareersHeroSectionProps) {
  const [query, setQuery] = useState("");

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    document
      .getElementById(OPEN_POSITIONS_SECTION_ID)
      ?.scrollIntoView({ behavior: "smooth" });
  };

  const stackProps = {
    showExploreBar: true as const,
    exploreLabel: "Explore Careers",
    exploreTargetSectionId: CAREERS_INTRO_SECTION_ID,
    dataAttr: CAREERS_HERO_DATA_ATTR,
    "aria-label": "Careers page hero" as const,
  };

  return (
    <HomeHeroStack {...stackProps}>
      <section className="relative h-full min-h-0 w-full">
        {content.heroVideoUrl ? (
          <video
            autoPlay
            muted
            loop
            playsInline
            className="absolute inset-0 h-full w-full object-cover hero-image-rich"
            poster={content.heroImageUrl}
          >
            <source src={content.heroVideoUrl} />
          </video>
        ) : (
          <Image
            src={content.heroImageUrl}
            alt={content.imageAlt}
            fill
            priority
            sizes="100vw"
            unoptimized={shouldUnoptimizeCmsSrc(content.heroImageUrl)}
            className="h-full w-full object-cover hero-image-rich"
          />
        )}

        <div
          className="hero-unified-overlay pointer-events-none absolute inset-0 z-10"
          aria-hidden
        />

        <div className="absolute inset-0 z-20 site-hero-centered-shell">
          <div className="container mx-auto w-full px-4 sm:px-6 py-6 md:py-8">
            <div className="max-w-4xl mx-auto text-center">
              <h1
                className={cn(
                  "site-hero-title !text-white text-center mb-4",
                )}
              >
                {content.title}
              </h1>
              {content.subtitle ? (
                <p
                  className={cn(
                    "site-hero-desc !text-white text-center font-medium mb-10",
                  )}
                >
                  {content.subtitle}
                </p>
              ) : null}
              <form
                onSubmit={handleSearch}
                className="mx-auto flex max-w-xl flex-col gap-3 sm:flex-row"
              >
                <Input
                  type="search"
                  placeholder={content.searchPlaceholder || "Search Open Positions"}
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="h-12 border-0 bg-white/95 text-foreground placeholder:text-muted-foreground"
                />
                <Button type="submit" size="lg" className="h-12 shrink-0 px-8">
                  <Search className="mr-2 h-4 w-4" />
                  Search
                </Button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </HomeHeroStack>
  );
}
