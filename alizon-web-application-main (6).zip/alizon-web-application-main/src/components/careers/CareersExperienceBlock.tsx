"use client";

import type { ReactNode } from "react";
import {
  buildCareersExperienceBlockStyle,
  CAREERS_EXPERIENCE_BLOCK_PY,
} from "@/lib/careers-experience-style";
import { CareersExperienceBackground } from "@/components/careers/CareersExperienceBackground";
import { cn } from "@/lib/utils";

type CareersExperienceBlockProps = {
  children: ReactNode;
  className?: string;
};

export function CareersExperienceBlock({
  children,
  className,
}: CareersExperienceBlockProps) {
  return (
    <div
      className={cn(
        "relative overflow-x-hidden text-white",
        CAREERS_EXPERIENCE_BLOCK_PY,
        className,
      )}
      style={buildCareersExperienceBlockStyle()}
    >
      <CareersExperienceBackground />
      <div className="relative z-10">{children}</div>
    </div>
  );
}
