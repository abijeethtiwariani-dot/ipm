"use client";

import { useEffect, useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { SiteSectionHeader } from "@/components/site/SiteSectionHeader";
import { JobCard } from "@/components/jobs/JobCard";
import type { CareersOpenPositionsContent } from "@/types/cms";
import type { Job } from "@/types/job";

interface CareersFeaturedJobsSectionProps {
  content: CareersOpenPositionsContent;
}

export function CareersFeaturedJobsSection({
  content,
}: CareersFeaturedJobsSectionProps) {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    void (async () => {
      try {
        const limit = content.featuredCount || 6;
        const res = await fetch(
          `/api/public/jobs?featured=true&limit=${limit}&sort=latest`,
        );
        const data = (await res.json()) as { jobs?: Job[] };
        setJobs(data.jobs ?? []);
      } catch {
        setJobs([]);
      } finally {
        setLoading(false);
      }
    })();
  }, [content.featuredCount]);

  return (
    <section
      id="careers-open-positions"
      className="scroll-mt-[var(--site-header-height-mobile)] lg:scroll-mt-[var(--site-header-height)] py-16 md:py-20"
    >
      <div className="container mx-auto px-4">
        <SiteSectionHeader
          id="careers-open-positions-heading"
          title={content.heading}
          intro={content.subtitle}
        />
        {loading ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: content.featuredCount || 6 }).map((_, i) => (
              <Skeleton key={i} className="h-64 w-full rounded-lg" />
            ))}
          </div>
        ) : jobs.length === 0 ? (
          <p className="text-center text-muted-foreground">
            No featured positions at the moment. Check back soon.
          </p>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {jobs.map((job) => (
              <JobCard key={job.id} job={job} variant="compact" />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
