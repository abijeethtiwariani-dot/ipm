import Image from "next/image";
import type { CareersLoveWorkingContent } from "@/types/cms";
import {
  buildCareersExperiencePhotoOverlayStyle,
  CAREERS_EXPERIENCE_PHOTO_SECTION_GAP,
} from "@/lib/careers-experience-style";
import { CareersExperienceBackground } from "@/components/careers/CareersExperienceBackground";
import { cn } from "@/lib/utils";

interface CareersLoveWorkingSectionProps {
  content: CareersLoveWorkingContent;
  /** When true, renders inside CareersExperienceBlock without its own gradient */
  embedded?: boolean;
  /** Adds transition spacing when this section follows another in the same block */
  followsPrior?: boolean;
}

function LoveWorkingBlurOrbs() {
  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden>
      <div className="absolute -left-32 top-[8%] h-96 w-96 rounded-full bg-blue-500/10 blur-3xl" />
      <div className="absolute left-1/3 top-[35%] h-80 w-80 rounded-full bg-white/5 blur-3xl" />
      <div className="absolute -right-24 top-[55%] h-72 w-72 rounded-full bg-primary/15 blur-3xl" />
      <div className="absolute bottom-[5%] right-1/4 h-64 w-64 rounded-full bg-indigo-400/10 blur-3xl" />
    </div>
  );
}

export function CareersLoveWorkingSection({
  content,
  embedded = false,
  followsPrior = false,
}: CareersLoveWorkingSectionProps) {
  const mobileImage = content.backgroundMobileImageUrl || content.backgroundImageUrl;

  return (
    <section
      className={cn(
        "relative min-h-[320px] py-10 md:min-h-[560px] md:py-20",
        embedded && followsPrior && CAREERS_EXPERIENCE_PHOTO_SECTION_GAP,
      )}
    >
      {!embedded && <CareersExperienceBackground />}
      <Image
        src={content.backgroundImageUrl}
        alt=""
        fill
        className="hidden object-cover md:block"
        sizes="100vw"
        priority={false}
      />
      <Image
        src={mobileImage}
        alt=""
        fill
        className="object-cover md:hidden"
        sizes="100vw"
        priority={false}
      />
      <div
        className="absolute inset-0"
        style={buildCareersExperiencePhotoOverlayStyle()}
        aria-hidden
      />
      <LoveWorkingBlurOrbs />
      <div className="relative z-10 container mx-auto px-4">
        <div className="max-w-2xl text-white">
          <h2 className="site-section-heading text-left text-[#ffffff] mb-3 md:mb-4">
            {content.title}
          </h2>
          {content.description && (
            <p className="site-section-intro text-left max-w-none text-[#ffffff] font-medium md:font-normal md:text-white/90 mb-6 md:mb-10">
              {content.description}
            </p>
          )}
        </div>
        {content.stats.length > 0 && (
          <div className="grid gap-5 sm:grid-cols-2 md:gap-8 lg:grid-cols-4 max-w-4xl">
            {content.stats.map((stat, i) => (
              <div key={i} className="text-center sm:text-left">
                <div className="site-stat-value text-[#ffffff] text-[2rem] leading-tight md:text-[length:var(--site-stat-value-size)] md:leading-[1.1]">
                  {stat.value}
                </div>
                <div className="site-stat-label text-[#ffffff] md:text-white/80">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
