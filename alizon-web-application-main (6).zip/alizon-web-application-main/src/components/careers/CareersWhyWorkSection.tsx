"use client";

import { useRef } from "react";
import { useInView } from "framer-motion";
import type { CareersWhyWorkCard, CareersWhyWorkContent } from "@/types/cms";
import { buildWhyWorkSectionStyle } from "@/lib/careers-why-work-style";
import { WhyWorkBackground } from "@/components/careers/why-work/WhyWorkBackground";
import { WhyWorkContentPanel } from "@/components/careers/why-work/WhyWorkContentPanel";
import { WhyWorkCarousel } from "@/components/careers/why-work/WhyWorkCarousel";
import { cn } from "@/lib/utils";

interface CareersWhyWorkSectionProps {
  content: CareersWhyWorkContent;
  cards: CareersWhyWorkCard[];
  /** When true, renders inside CareersExperienceBlock without its own background */
  embedded?: boolean;
}

export function CareersWhyWorkSection({
  content,
  cards,
  embedded = false,
}: CareersWhyWorkSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: "-40px" });
  const hasCards = cards.length > 0;

  return (
    <section
      ref={sectionRef}
      id="careers-why-work"
      className={cn(
        "relative w-full overflow-x-hidden text-white",
        embedded ? "scroll-mt-24 md:scroll-mt-28" : "scroll-mt-24 overflow-hidden py-0 md:scroll-mt-28",
      )}
      style={buildWhyWorkSectionStyle(content)}
      aria-labelledby="careers-why-work-heading"
    >
      {!embedded ? <WhyWorkBackground content={content} /> : null}

      <div
        className={cn(
          "relative z-10 mx-auto w-full px-4",
          embedded ? "container" : "max-w-[1400px]",
        )}
      >
        <div
          className={cn(
            "flex flex-col lg:items-center",
            hasCards && "lg:grid lg:grid-cols-2",
          )}
        >
          <WhyWorkContentPanel content={content} visible={isInView} />
          {hasCards ? (
            <WhyWorkCarousel
              content={content}
              cards={cards}
              visible={isInView}
              className="lg:-mr-[max(0px,calc((100vw-1400px)/2))]"
            />
          ) : null}
        </div>
      </div>
    </section>
  );
}
