import { PageIntroSection } from "@/components/hero-landing/PageIntroSection";
import { CAREERS_INTRO_SECTION_ID } from "@/lib/site-hero";

const DEFAULT_INTRO =
  "Join a community of educators, researchers, innovators, and professionals shaping tomorrow's healthcare and technology landscape.";

const OPEN_POSITIONS_SECTION_ID = "careers-open-positions";

type CareersIntroSectionProps = {
  hasOpenPositions?: boolean;
};

export function CareersIntroSection({
  hasOpenPositions = false,
}: CareersIntroSectionProps) {
  return (
    <PageIntroSection
      id={CAREERS_INTRO_SECTION_ID}
      sectionClassName="py-12 md:py-14 lg:py-20"
      className="scroll-mt-[var(--site-header-height-mobile)] lg:scroll-mt-[var(--site-header-height)]"
      heading="Explore Careers at Alizon"
      intro={DEFAULT_INTRO}
      buttonText={hasOpenPositions ? "Explore Opportunities" : undefined}
      buttonScrollTargetId={
        hasOpenPositions ? OPEN_POSITIONS_SECTION_ID : undefined
      }
    />
  );
}
