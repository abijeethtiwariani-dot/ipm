import { Card } from "@/components/ui/card";
import { SiteSectionHeader } from "@/components/site/SiteSectionHeader";
import { CareersExperienceBackground } from "@/components/careers/CareersExperienceBackground";
import { getCareersIcon } from "@/lib/careers-icon-map";
import {
  CAREERS_EXPERIENCE_GLASS,
  CAREERS_EXPERIENCE_ZONE_GAP,
} from "@/lib/careers-experience-style";
import type { CareersBenefitCard } from "@/types/cms";
import { cn } from "@/lib/utils";

interface CareersBenefitsSectionProps {
  cards: CareersBenefitCard[];
  /** When true, renders inside CareersExperienceBlock without its own gradient */
  embedded?: boolean;
  /** Adds transition spacing when this section follows another in the same block */
  followsPrior?: boolean;
}

export function CareersBenefitsSection({
  cards,
  embedded = false,
  followsPrior = false,
}: CareersBenefitsSectionProps) {
  if (cards.length === 0) return null;

  return (
    <section
      className={cn(
        "relative py-16 md:py-20",
        !embedded && "text-white",
        embedded && followsPrior && CAREERS_EXPERIENCE_ZONE_GAP,
      )}
    >
      {!embedded && <CareersExperienceBackground />}
      <div className="relative z-10 container mx-auto px-4">
        <SiteSectionHeader
          id="careers-benefits"
          title="Benefits & Culture"
          intro="We invest in our people with comprehensive benefits and a culture of growth."
          tone="onPrimary"
        />
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {cards.map((card) => {
            const Icon = getCareersIcon(card.icon);
            return (
              <Card
                key={card.id}
                className="p-6 shadow-soft card-hover"
                style={{
                  background: CAREERS_EXPERIENCE_GLASS.background,
                  backdropFilter: CAREERS_EXPERIENCE_GLASS.backdropFilter,
                  WebkitBackdropFilter: CAREERS_EXPERIENCE_GLASS.WebkitBackdropFilter,
                  border: CAREERS_EXPERIENCE_GLASS.border,
                }}
              >
                <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="site-card-title mb-2 text-white">{card.title}</h3>
                <p className="site-card-desc text-white/80">{card.description}</p>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}
