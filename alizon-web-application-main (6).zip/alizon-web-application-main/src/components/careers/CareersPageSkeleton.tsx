import { Skeleton } from "@/components/ui/skeleton";

export function CareersPageSkeleton() {
  return (
    <div className="min-h-screen" aria-hidden>
      <Skeleton className="aspect-[21/9] w-full max-h-[70vh]" />
      <section className="py-16">
        <div className="container mx-auto space-y-8 px-4">
          <div className="mx-auto max-w-3xl space-y-4 text-center">
            <Skeleton className="mx-auto h-10 w-2/3" />
            <Skeleton className="mx-auto h-6 w-full" />
            <Skeleton className="mx-auto h-6 w-4/5" />
          </div>
        </div>
      </section>
      <section className="py-16">
        <div className="container mx-auto grid gap-8 px-4 lg:grid-cols-2">
          <div className="space-y-4">
            <Skeleton className="h-6 w-40" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-24 w-full" />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <Skeleton className="h-64 rounded-3xl" />
            <Skeleton className="h-64 rounded-3xl" />
          </div>
        </div>
      </section>
    </div>
  );
}
