"use client";

import type { CareersStory } from "@/types/cms";
import {
  CAREERS_STORIES_LABELS,
  type StoriesSectionLabels,
} from "@/lib/stories-section-labels";
import { CareerStoriesContentPanel } from "@/components/careers/stories/CareerStoriesContentPanel";
import { CareerStoriesFeaturedImage } from "@/components/careers/stories/CareerStoriesFeaturedImage";

type CareerStoriesSlideProps = {
  story: CareersStory;
  slideKey: string;
  isActive: boolean;
  onReadFullStory: () => void;
  labels?: StoriesSectionLabels;
};

export function CareerStoriesSlide({
  story,
  slideKey,
  isActive,
  onReadFullStory,
  labels = CAREERS_STORIES_LABELS,
}: CareerStoriesSlideProps) {
  return (
    <div className="grid w-full items-stretch gap-6 lg:grid-cols-[2fr_3fr] lg:items-center lg:gap-8">
      <div className="flex justify-center lg:justify-start">
        <CareerStoriesFeaturedImage
          imageUrl={story.photoUrl}
          alt={story.name}
          slideKey={isActive ? slideKey : story.id}
          className="w-full max-w-md lg:max-w-none"
        />
      </div>
      <CareerStoriesContentPanel
        story={story}
        slideKey={isActive ? slideKey : story.id}
        onReadFullStory={onReadFullStory}
        labels={labels}
      />
    </div>
  );
}
