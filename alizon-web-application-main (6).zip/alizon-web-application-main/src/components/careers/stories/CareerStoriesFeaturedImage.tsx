"use client";

import Image from "next/image";
import { motion, useReducedMotion } from "framer-motion";
import { isRemoteCmsImage } from "@/components/news/resolveCmsImage";
import {
  CAREER_STORIES_GLASS,
} from "@/lib/careers-stories-style";
import { cn } from "@/lib/utils";

type CareerStoriesFeaturedImageProps = {
  imageUrl: string;
  alt: string;
  slideKey: string;
  className?: string;
};

export function CareerStoriesFeaturedImage({
  imageUrl,
  alt,
  slideKey,
  className,
}: CareerStoriesFeaturedImageProps) {
  const reducedMotion = useReducedMotion();

  return (
    <div
      className={cn("rounded-3xl p-2.5 md:p-3", className)}
      style={CAREER_STORIES_GLASS}
    >
      <motion.div
        key={slideKey}
        initial={reducedMotion ? { opacity: 0 } : { opacity: 0, scale: 1.05 }}
        animate={reducedMotion ? { opacity: 1 } : { opacity: 1, scale: 1 }}
        transition={{ duration: reducedMotion ? 0.15 : 0.45, ease: [0.22, 1, 0.36, 1] as const }}
        className="relative mx-auto h-[380px] w-full max-w-[280px] overflow-hidden rounded-2xl md:h-[420px] md:max-w-[320px] lg:mx-0 lg:h-[480px] lg:max-w-none"
      >
        {imageUrl ? (
          <Image
            src={imageUrl}
            alt={alt}
            fill
            className="object-cover"
            sizes="(min-width: 1024px) 40vw, 100vw"
            unoptimized={isRemoteCmsImage(imageUrl)}
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-white/5 text-sm text-white/50">
            No photo
          </div>
        )}
      </motion.div>
    </div>
  );
}
