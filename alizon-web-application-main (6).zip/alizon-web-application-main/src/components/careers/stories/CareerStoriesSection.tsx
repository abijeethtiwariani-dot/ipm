"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import type { CareersStory } from "@/types/cms";
import { CAREERS_EXPERIENCE_ZONE_GAP } from "@/lib/careers-experience-style";
import {
  buildCareerStoriesSectionStyle,
  CAREER_STORIES_SECTION_PY,
} from "@/lib/careers-stories-style";
import {
  CAREERS_STORIES_LABELS,
  type StoriesSectionLabels,
} from "@/lib/stories-section-labels";
import { CareerStoriesCarousel } from "@/components/careers/stories/CareerStoriesCarousel";
import {
  CareerStoriesArrowNav,
  CareerStoriesProgressLines,
} from "@/components/careers/stories/CareerStoriesNav";
import { cn } from "@/lib/utils";

type CareerStoriesSectionProps = {
  stories: CareersStory[];
  /** When true, renders inside CareersExperienceBlock without its own background */
  embedded?: boolean;
  /** Adds transition spacing when Career Stories follows Why Work in the same block */
  followsWhyWork?: boolean;
  labels?: StoriesSectionLabels;
};

export function CareerStoriesSection({
  stories,
  embedded = false,
  followsWhyWork = false,
  labels = CAREERS_STORIES_LABELS,
}: CareerStoriesSectionProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: "-40px" });

  if (stories.length === 0) return null;

  return (
    <section
      ref={sectionRef}
      id="careers-stories"
      className={cn(
        "relative text-white",
        embedded
          ? cn("scroll-mt-24 md:scroll-mt-28", followsWhyWork && CAREERS_EXPERIENCE_ZONE_GAP)
          : cn("scroll-mt-24 overflow-hidden md:scroll-mt-28", CAREER_STORIES_SECTION_PY),
      )}
      style={embedded ? undefined : buildCareerStoriesSectionStyle()}
      aria-labelledby="careers-stories-heading"
    >
      {!embedded ? (
        <>
          <div
            aria-hidden
            className="pointer-events-none absolute -left-24 top-1/4 h-72 w-72 rounded-full bg-white/5 blur-3xl"
          />
          <div
            aria-hidden
            className="pointer-events-none absolute -right-16 bottom-1/4 h-64 w-64 rounded-full bg-primary/20 blur-3xl"
          />
        </>
      ) : null}

      <div className={cn("relative z-10 mx-auto px-4", embedded ? "max-w-6xl" : "container")}>
        <CareerStoriesCarousel stories={stories} labels={labels}>
          {(nav) => (
            <motion.div
              className="mb-6 md:mb-8"
              initial={{ opacity: 0, y: 24 }}
              animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 24 }}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
            >
              <div className="flex flex-wrap items-start justify-between gap-4">
                <header className="max-w-xl text-left">
                  <h2
                    id="careers-stories-heading"
                    className="site-section-heading text-white"
                  >
                    {labels.sectionTitle}
                  </h2>
                  <p className="mt-3 max-w-xl text-base leading-relaxed text-white/75 md:text-lg">
                    {labels.sectionIntro}
                  </p>
                </header>

                {nav.count > 1 ? (
                  <CareerStoriesArrowNav
                    onPrev={nav.onPrev}
                    onNext={nav.onNext}
                    className="hidden shrink-0 md:flex"
                  />
                ) : null}
              </div>

              {nav.count > 1 ? (
                <CareerStoriesProgressLines
                  {...nav}
                  slidesAriaLabel={labels.slidesAriaLabel}
                  className="mt-5 justify-center sm:justify-start"
                />
              ) : null}
            </motion.div>
          )}
        </CareerStoriesCarousel>
      </div>
    </section>
  );
}
