"use client";

import { ArrowRight } from "lucide-react";
import { motion, useReducedMotion } from "framer-motion";
import type { CareersStory } from "@/types/cms";
import { CAREER_STORIES_GLASS, CAREER_STORIES_IMAGE_MAX_HEIGHT } from "@/lib/careers-stories-style";
import {
  getCareerStoryRoleLine,
  splitCareerStoryTestimonial,
} from "@/lib/careers-story-copy";
import {
  CAREERS_STORIES_LABELS,
  type StoriesSectionLabels,
} from "@/lib/stories-section-labels";
import { cn } from "@/lib/utils";

type CareerStoriesContentPanelProps = {
  story: CareersStory;
  slideKey: string;
  onReadFullStory: () => void;
  className?: string;
  labels?: StoriesSectionLabels;
};

const EASE_OUT = [0.22, 1, 0.36, 1] as const;

const staggerItem = {
  hidden: { opacity: 0, y: 12 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.08, duration: 0.4, ease: EASE_OUT },
  }),
};

export function CareerStoriesContentPanel({
  story,
  slideKey,
  onReadFullStory,
  className,
  labels = CAREERS_STORIES_LABELS,
}: CareerStoriesContentPanelProps) {
  const reducedMotion = useReducedMotion();
  const { title, excerpt } = splitCareerStoryTestimonial(story.testimonial, story.name);
  const roleLine = getCareerStoryRoleLine(story.designation, story.department);
  const summary = excerpt || story.testimonial;

  const motionProps = reducedMotion
    ? { initial: { opacity: 0 }, animate: { opacity: 1 }, transition: { duration: 0.15 } }
    : {
        initial: { opacity: 0, x: 12 },
        animate: { opacity: 1, x: 0 },
        transition: { duration: 0.45, ease: EASE_OUT },
      };

  return (
    <motion.div
      key={slideKey}
      className={cn(
        "flex min-w-0 flex-col justify-center rounded-3xl p-5 md:p-6 lg:max-h-[480px] lg:overflow-hidden lg:p-7",
        "shadow-[0_20px_40px_rgba(0,0,0,0.22)]",
        className,
      )}
      style={{
        ...CAREER_STORIES_GLASS,
        maxHeight: CAREER_STORIES_IMAGE_MAX_HEIGHT.lg,
      }}
      {...motionProps}
    >
      <motion.p
        custom={0}
        variants={staggerItem}
        initial="hidden"
        animate="visible"
        className="mb-2 text-xs font-semibold uppercase tracking-[0.2em] text-primary"
      >
        {labels.storyEyebrow}
      </motion.p>

      <motion.h3
        custom={1}
        variants={staggerItem}
        initial="hidden"
        animate="visible"
        className="font-serif text-xl font-bold leading-tight text-white md:text-2xl lg:text-3xl"
      >
        {title}
      </motion.h3>

      <motion.p
        custom={2}
        variants={staggerItem}
        initial="hidden"
        animate="visible"
        className="mt-2 text-base font-semibold text-white md:text-lg"
      >
        {story.name}
      </motion.p>

      {roleLine ? (
        <motion.p
          custom={3}
          variants={staggerItem}
          initial="hidden"
          animate="visible"
          className="mt-0.5 text-sm text-white/70"
        >
          {roleLine}
        </motion.p>
      ) : null}

      <motion.p
        custom={4}
        variants={staggerItem}
        initial="hidden"
        animate="visible"
        className="mt-3 line-clamp-3 text-sm leading-snug text-white/80 md:text-base"
      >
        {summary}
      </motion.p>

      <motion.div custom={5} variants={staggerItem} initial="hidden" animate="visible">
        <button
          type="button"
          onClick={onReadFullStory}
          className="group mt-4 inline-flex min-h-[44px] items-center gap-2 text-sm font-semibold text-primary transition-colors hover:text-primary/90"
        >
          Read Full Story
          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
        </button>
      </motion.div>
    </motion.div>
  );
}
