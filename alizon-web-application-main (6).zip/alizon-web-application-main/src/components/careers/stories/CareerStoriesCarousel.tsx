"use client";

import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  type CarouselApi,
} from "@/components/ui/carousel";
import type { CareersStory } from "@/types/cms";
import { splitCareerStoryTestimonial } from "@/lib/careers-story-copy";
import {
  CAREERS_STORIES_LABELS,
  type StoriesSectionLabels,
} from "@/lib/stories-section-labels";
import {
  CareerStoriesArrowNav,
  type CareerStoriesNavState,
} from "@/components/careers/stories/CareerStoriesNav";
import { CareerStoriesSlide } from "@/components/careers/stories/CareerStoriesSlide";
import { CareerStoryFullDialog } from "@/components/careers/stories/CareerStoryFullDialog";

type CareerStoriesCarouselProps = {
  stories: CareersStory[];
  labels?: StoriesSectionLabels;
  children?: (nav: CareerStoriesNavState) => ReactNode;
};

export function CareerStoriesCarousel({
  stories,
  labels = CAREERS_STORIES_LABELS,
  children,
}: CareerStoriesCarouselProps) {
  const [api, setApi] = useState<CarouselApi>();
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [activeStory, setActiveStory] = useState<CareersStory | null>(null);

  const onSelect = useCallback((carouselApi: CarouselApi) => {
    if (!carouselApi) return;
    setSelectedIndex(carouselApi.selectedScrollSnap());
  }, []);

  useEffect(() => {
    if (!api) return;

    onSelect(api);
    api.on("select", onSelect);
    api.on("reInit", onSelect);

    return () => {
      api.off("select", onSelect);
      api.off("reInit", onSelect);
    };
  }, [api, onSelect]);

  const scrollTo = useCallback(
    (index: number) => {
      api?.scrollTo(index);
    },
    [api],
  );

  const scrollPrev = useCallback(() => {
    api?.scrollPrev();
  }, [api]);

  const scrollNext = useCallback(() => {
    api?.scrollNext();
  }, [api]);

  const openFullStory = useCallback((story: CareersStory) => {
    setActiveStory(story);
    setDialogOpen(true);
  }, []);

  const navState = useMemo<CareerStoriesNavState>(
    () => ({
      count: stories.length,
      selectedIndex,
      onSelect: scrollTo,
      onPrev: scrollPrev,
      onNext: scrollNext,
    }),
    [stories.length, selectedIndex, scrollTo, scrollPrev, scrollNext],
  );

  const dialogTitle = activeStory
    ? splitCareerStoryTestimonial(activeStory.testimonial, activeStory.name).title
    : "";

  return (
    <>
      {children?.(navState)}

      <div
        className="mx-auto w-full max-w-6xl"
        aria-roledescription="carousel"
        aria-label={labels.carouselAriaLabel}
      >
        <Carousel
          setApi={setApi}
          opts={{ loop: stories.length > 1, align: "start" }}
          className="w-full"
        >
          <CarouselContent className="-ml-0">
            {stories.map((story, index) => (
              <CarouselItem key={story.id} className="basis-full pl-0">
                <CareerStoriesSlide
                  story={story}
                  slideKey={`${story.id}-${selectedIndex}`}
                  isActive={index === selectedIndex}
                  onReadFullStory={() => openFullStory(story)}
                  labels={labels}
                />
              </CarouselItem>
            ))}
          </CarouselContent>
        </Carousel>

        {stories.length > 1 ? (
          <CareerStoriesArrowNav
            onPrev={scrollPrev}
            onNext={scrollNext}
            className="mt-6 flex justify-center md:hidden"
          />
        ) : null}
      </div>

      <CareerStoryFullDialog
        story={activeStory}
        open={dialogOpen}
        onOpenChange={setDialogOpen}
        title={dialogTitle}
      />
    </>
  );
}
