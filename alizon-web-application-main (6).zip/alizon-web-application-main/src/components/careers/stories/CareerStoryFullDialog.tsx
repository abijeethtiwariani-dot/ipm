"use client";

import type { CareersStory } from "@/types/cms";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { getCareerStoryRoleLine } from "@/lib/careers-story-copy";

type CareerStoryFullDialogProps = {
  story: CareersStory | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
};

export function CareerStoryFullDialog({
  story,
  open,
  onOpenChange,
  title,
}: CareerStoryFullDialogProps) {
  if (!story) return null;

  const roleLine = getCareerStoryRoleLine(story.designation, story.department);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <p className="font-semibold text-foreground">{story.name}</p>
            {roleLine ? (
              <p className="text-sm text-muted-foreground">{roleLine}</p>
            ) : null}
          </div>
          <blockquote className="border-l-4 border-primary pl-4 text-base leading-relaxed text-foreground">
            &ldquo;{story.testimonial}&rdquo;
          </blockquote>
        </div>
      </DialogContent>
    </Dialog>
  );
}
