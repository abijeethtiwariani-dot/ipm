"use client";

import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

export type CareerStoriesNavState = {
  count: number;
  selectedIndex: number;
  onSelect: (index: number) => void;
  onPrev: () => void;
  onNext: () => void;
};

type CareerStoriesArrowNavProps = Pick<
  CareerStoriesNavState,
  "onPrev" | "onNext"
> & {
  className?: string;
};

type CareerStoriesProgressLinesProps = CareerStoriesNavState & {
  className?: string;
  slidesAriaLabel?: string;
};

const glassButtonClass =
  "flex h-10 w-10 items-center justify-center rounded-full border border-white/20 bg-white/10 text-white backdrop-blur-md transition-all duration-300 hover:scale-105 hover:bg-white/15 hover:shadow-[0_0_20px_rgba(255,255,255,0.15)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-transparent";

export function CareerStoriesArrowNav({
  onPrev,
  onNext,
  className,
}: CareerStoriesArrowNavProps) {
  return (
    <div className={cn("flex items-center gap-2.5", className)}>
      <button
        type="button"
        onClick={onPrev}
        aria-label="Previous story"
        className={glassButtonClass}
      >
        <ChevronLeft className="h-5 w-5" />
      </button>
      <button
        type="button"
        onClick={onNext}
        aria-label="Next story"
        className={glassButtonClass}
      >
        <ChevronRight className="h-5 w-5" />
      </button>
    </div>
  );
}

export function CareerStoriesProgressLines({
  count,
  selectedIndex,
  onSelect,
  className,
  slidesAriaLabel = "Career story slides",
}: CareerStoriesProgressLinesProps) {
  if (count <= 1) return null;

  return (
    <div
      className={cn("flex items-center gap-2", className)}
      role="tablist"
      aria-label={slidesAriaLabel}
    >
      {Array.from({ length: count }).map((_, index) => (
        <button
          key={index}
          type="button"
          role="tab"
          aria-selected={index === selectedIndex}
          aria-label={`Go to story ${index + 1}`}
          onClick={() => onSelect(index)}
          className={cn(
            "h-1 rounded-full transition-all duration-300",
            index === selectedIndex
              ? "w-10 bg-primary"
              : "w-6 bg-white/25 hover:bg-white/40",
          )}
        />
      ))}
    </div>
  );
}
