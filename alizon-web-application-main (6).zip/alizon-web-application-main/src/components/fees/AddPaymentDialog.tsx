"use client";

import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { apiCreateFeePayment, apiFetchFeeStudents } from "@/lib/admin-fees-api";
import {
  calculateFinalPayableFee,
  calculateScholarshipDiscount,
  formatCurrency,
  PAYMENT_METHODS,
} from "@/lib/fees";
import type { StudentFeeSummary } from "@/types/fees";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const schema = z.object({
  studentId: z.string().min(1),
  amount: z.coerce.number().positive(),
  paymentDate: z.string().min(1),
  paymentMethod: z.string().min(1),
  transactionId: z.string().optional(),
  notes: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

export function AddPaymentDialog({
  open,
  onOpenChange,
  defaultStudentId,
  onSuccess,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  defaultStudentId?: string;
  onSuccess?: () => void;
}) {
  const [students, setStudents] = useState<StudentFeeSummary[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      studentId: defaultStudentId ?? "",
      amount: 0,
      paymentDate: new Date().toISOString().slice(0, 10),
      paymentMethod: "Cash",
      transactionId: "",
      notes: "",
    },
  });

  const studentId = form.watch("studentId");
  const selected = useMemo(
    () => students.find((s) => s.studentId === studentId),
    [students, studentId],
  );

  const discount = selected
    ? calculateScholarshipDiscount(selected.courseFee, selected.scholarshipPercentage)
    : 0;
  const finalFee = selected
    ? calculateFinalPayableFee(selected.courseFee, selected.scholarshipPercentage)
    : 0;

  useEffect(() => {
    if (!open) return;
    setLoading(true);
    void apiFetchFeeStudents()
      .then((data) => setStudents(data.students))
      .catch((e) => toast.error(e instanceof Error ? e.message : "Failed to load students"))
      .finally(() => setLoading(false));
  }, [open]);

  useEffect(() => {
    if (open && defaultStudentId) {
      form.setValue("studentId", defaultStudentId);
    }
  }, [open, defaultStudentId, form]);

  const submit = form.handleSubmit(async (values) => {
    if (!selected?.programId) {
      toast.error("Student has no program assigned.");
      return;
    }
    setSaving(true);
    try {
      await apiCreateFeePayment({
        studentId: values.studentId,
        programId: selected.programId,
        amount: values.amount,
        paymentDate: values.paymentDate,
        paymentMethod: values.paymentMethod as (typeof PAYMENT_METHODS)[number],
        transactionId: values.transactionId,
        notes: values.notes,
      });
      toast.success("Payment recorded.");
      onOpenChange(false);
      form.reset({
        studentId: "",
        amount: 0,
        paymentDate: new Date().toISOString().slice(0, 10),
        paymentMethod: "Cash",
        transactionId: "",
        notes: "",
      });
      onSuccess?.();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Failed to save payment.");
    } finally {
      setSaving(false);
    }
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Add Payment</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-2">
            <Label>Student</Label>
            <Select
              value={studentId || "none"}
              onValueChange={(v) => form.setValue("studentId", v === "none" ? "" : v)}
              disabled={loading || !!defaultStudentId}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select student" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Select student</SelectItem>
                {students.map((s) => (
                  <SelectItem key={s.studentId} value={s.studentId}>
                    {s.studentName} ({s.registrationId})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selected ? (
            <div className="grid gap-2 rounded-lg bg-muted/50 p-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Program</span>
                <span>{selected.programName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Course Fee</span>
                <span>{formatCurrency(selected.courseFee)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Scholarship</span>
                <span>{selected.scholarshipPercentage}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Discount</span>
                <span>{formatCurrency(discount)}</span>
              </div>
              <div className="flex justify-between font-medium">
                <span>Final Payable Fee</span>
                <span className="text-primary">{formatCurrency(finalFee)}</span>
              </div>
            </div>
          ) : null}

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Amount Paid (₹)</Label>
              <Input type="number" min={1} step={1} {...form.register("amount")} />
            </div>
            <div className="space-y-2">
              <Label>Payment Date</Label>
              <Input type="date" {...form.register("paymentDate")} />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Payment Method</Label>
            <Select
              value={form.watch("paymentMethod")}
              onValueChange={(v) => form.setValue("paymentMethod", v)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {PAYMENT_METHODS.map((m) => (
                  <SelectItem key={m} value={m}>
                    {m}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Transaction ID</Label>
            <Input {...form.register("transactionId")} />
          </div>

          <div className="space-y-2">
            <Label>Notes</Label>
            <Textarea rows={2} {...form.register("notes")} />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving || !studentId}>
              {saving ? "Saving..." : "Save Payment"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
