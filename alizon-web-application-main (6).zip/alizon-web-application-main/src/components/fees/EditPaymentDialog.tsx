"use client";

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { apiUpdateFeePayment } from "@/lib/admin-fees-api";
import { PAYMENT_METHODS } from "@/lib/fees";
import type { FeePayment } from "@/types/fees";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { timestampToLocaleDateString } from "@/lib/firestore-timestamp";

const schema = z.object({
  amount: z.coerce.number().positive(),
  paymentDate: z.string().min(1),
  paymentMethod: z.string().min(1),
  transactionId: z.string().optional(),
  notes: z.string().optional(),
});

type FormValues = z.infer<typeof schema>;

function toDateInputValue(paymentDate: string): string {
  if (/^\d{4}-\d{2}-\d{2}/.test(paymentDate)) return paymentDate.slice(0, 10);
  const formatted = timestampToLocaleDateString(paymentDate);
  if (formatted === "—") return new Date().toISOString().slice(0, 10);
  const parsed = new Date(formatted);
  if (Number.isNaN(parsed.getTime())) return new Date().toISOString().slice(0, 10);
  return parsed.toISOString().slice(0, 10);
}

export function EditPaymentDialog({
  payment,
  open,
  onOpenChange,
  onSuccess,
}: {
  payment: FeePayment | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess?: () => void;
}) {
  const [saving, setSaving] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      amount: 0,
      paymentDate: "",
      paymentMethod: "Cash",
      transactionId: "",
      notes: "",
    },
  });

  useEffect(() => {
    if (!payment) return;
    form.reset({
      amount: payment.amount,
      paymentDate: toDateInputValue(payment.paymentDate),
      paymentMethod: payment.paymentMethod,
      transactionId: payment.transactionId,
      notes: payment.notes,
    });
  }, [payment, form]);

  const submit = form.handleSubmit(async (values) => {
    if (!payment) return;
    setSaving(true);
    try {
      await apiUpdateFeePayment(payment.id, {
        amount: values.amount,
        paymentDate: values.paymentDate,
        paymentMethod: values.paymentMethod as (typeof PAYMENT_METHODS)[number],
        transactionId: values.transactionId,
        notes: values.notes,
      });
      toast.success("Payment updated.");
      onOpenChange(false);
      onSuccess?.();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Update failed.");
    } finally {
      setSaving(false);
    }
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Edit Payment</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Amount (₹)</Label>
              <Input type="number" min={1} {...form.register("amount")} />
            </div>
            <div className="space-y-2">
              <Label>Payment Date</Label>
              <Input type="date" {...form.register("paymentDate")} />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Payment Method</Label>
            <Select
              value={form.watch("paymentMethod")}
              onValueChange={(v) => form.setValue("paymentMethod", v)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {PAYMENT_METHODS.map((m) => (
                  <SelectItem key={m} value={m}>
                    {m}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Transaction ID</Label>
            <Input {...form.register("transactionId")} />
          </div>
          <div className="space-y-2">
            <Label>Notes</Label>
            <Textarea rows={2} {...form.register("notes")} />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
