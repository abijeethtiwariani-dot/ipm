"use client";

import { Cell, Pie, PieChart } from "recharts";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
} from "@/components/ui/chart";
import type { FeesDashboardStats } from "@/types/fees";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const pendingConfig = {
  amount: { label: "Amount", color: "hsl(var(--primary))" },
};

const PIE_COLORS = [
  "hsl(var(--primary))",
  "hsl(var(--warning))",
  "hsl(142 71% 45%)",
];

export function FeeCharts({ stats }: { stats: FeesDashboardStats }) {
  return (
    <div className="mx-auto max-w-md">
      <Card className="border-0 shadow-soft">
        <CardHeader>
          <CardTitle className="text-base font-heading">Pending Payments</CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer config={pendingConfig} className="h-[280px] w-full">
            <PieChart>
              <ChartTooltip content={<ChartTooltipContent />} />
              <Pie
                data={stats.pendingPayments}
                dataKey="count"
                nameKey="status"
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={2}
              >
                {stats.pendingPayments.map((_, index) => (
                  <Cell key={index} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                ))}
              </Pie>
            </PieChart>
          </ChartContainer>
        </CardContent>
      </Card>
    </div>
  );
}
