"use client";

import { Progress } from "@/components/ui/progress";
import { formatCurrency } from "@/lib/fees";

export function FeeProgressBar({
  percent,
  totalPaid,
  finalPayableFee,
}: {
  percent: number;
  totalPaid: number;
  finalPayableFee: number;
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-sm">
        <span className="font-medium">Fee Payment Progress</span>
        <span className="text-muted-foreground">{percent}%</span>
      </div>
      <Progress value={percent} className="h-3" />
      <p className="text-xs text-muted-foreground">
        {formatCurrency(totalPaid)} paid of {formatCurrency(finalPayableFee)}
      </p>
    </div>
  );
}
