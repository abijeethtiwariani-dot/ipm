"use client";

import alizonLogo from "@/assets/alizon-logo.png";
import { formatCurrency } from "@/lib/fees";
import { timestampToLocaleDateString } from "@/lib/firestore-timestamp";
import {
  INSTITUTION_PRIMARY_NAME,
  INSTITUTION_TAGLINE,
} from "@/lib/site-branding";
import type { FeeReceiptData } from "@/types/fees";

export function FeeReceiptContent({ receipt }: { receipt: FeeReceiptData }) {
  return (
    <div id="fee-receipt-print" className="mx-auto max-w-lg space-y-6 bg-white p-8 text-foreground">
      <div className="flex flex-col items-center gap-3 border-b border-border pb-4">
        <img
          src={alizonLogo.src}
          alt={INSTITUTION_PRIMARY_NAME}
          width={48}
          height={48}
          className="h-12 w-12 rounded-full object-contain"
        />
        <div className="flex flex-col items-center gap-0.5 text-center">
          <span className="font-heading text-xs font-bold uppercase tracking-[0.12em] text-foreground sm:text-sm">
            {INSTITUTION_PRIMARY_NAME}
          </span>
          <span className="text-[10px] font-medium uppercase tracking-[0.18em] text-muted-foreground">
            {INSTITUTION_TAGLINE}
          </span>
        </div>
        <p className="text-sm text-muted-foreground">Fee Payment Receipt</p>
      </div>

      <div className="grid gap-2 text-sm">
        <div className="flex justify-between">
          <span className="text-muted-foreground">Student</span>
          <span className="font-medium">{receipt.student.name}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Registration ID</span>
          <span>{receipt.student.registrationId}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Program</span>
          <span>{receipt.program.name}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Payment Date</span>
          <span>{timestampToLocaleDateString(receipt.payment.paymentDate)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted-foreground">Method</span>
          <span>{receipt.payment.paymentMethod}</span>
        </div>
        {receipt.payment.transactionId ? (
          <div className="flex justify-between">
            <span className="text-muted-foreground">Transaction ID</span>
            <span className="font-mono text-xs">{receipt.payment.transactionId}</span>
          </div>
        ) : null}
      </div>

      <div className="rounded-lg bg-muted/50 p-4 text-center">
        <p className="text-sm text-muted-foreground">Amount Paid</p>
        <p className="text-3xl font-bold text-primary">
          {formatCurrency(receipt.payment.amount)}
        </p>
      </div>

      <div className="grid gap-1 border-t border-border pt-4 text-xs text-muted-foreground">
        <div className="flex justify-between">
          <span>Course Fee</span>
          <span>{formatCurrency(receipt.summary.courseFee)}</span>
        </div>
        <div className="flex justify-between">
          <span>Scholarship ({receipt.summary.scholarshipPercentage}%)</span>
          <span>-{formatCurrency(receipt.summary.discountAmount)}</span>
        </div>
        <div className="flex justify-between font-medium text-foreground">
          <span>Final Payable</span>
          <span>{formatCurrency(receipt.summary.finalPayableFee)}</span>
        </div>
        <div className="flex justify-between">
          <span>Total Paid</span>
          <span>{formatCurrency(receipt.summary.totalPaid)}</span>
        </div>
        <div className="flex justify-between">
          <span>Balance Due</span>
          <span>{formatCurrency(receipt.summary.dueAmount)}</span>
        </div>
      </div>

      {receipt.payment.notes ? (
        <p className="text-xs text-muted-foreground">Note: {receipt.payment.notes}</p>
      ) : null}

      <p className="text-center text-xs text-muted-foreground">
        For queries, contact the administration office.
      </p>
    </div>
  );
}
