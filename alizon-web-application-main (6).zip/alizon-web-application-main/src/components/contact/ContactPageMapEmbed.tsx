"use client";

import {
  resolveContactPageEmbedUrl,
  resolveContactPageLocationUrl,
} from "@/lib/contact-page-cms";

type ContactPageMapEmbedProps = {
  embedUrl?: string;
  locationUrl?: string;
  className?: string;
};

export function ContactPageMapEmbed({
  embedUrl = "",
  locationUrl = "",
  className,
}: ContactPageMapEmbedProps) {
  const iframeSrc = resolveContactPageEmbedUrl(embedUrl);
  const openUrl = resolveContactPageLocationUrl(locationUrl);

  return (
    <div className={`relative h-full ${className ?? ""}`}>
      <iframe
        src={iframeSrc}
        width="100%"
        height="100%"
        className="pointer-events-none h-full w-full"
        style={{ border: 0 }}
        allowFullScreen
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
        title="Alizon Campus Location"
      />
      <a
        href={openUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="absolute inset-0 z-10 flex items-end justify-center pb-4 group"
        aria-label="Open location in Google Maps"
      >
        <span className="rounded-full bg-background/90 px-3 py-1.5 text-xs font-medium text-foreground shadow-sm opacity-0 transition-opacity group-hover:opacity-100">
          Open in Google Maps
        </span>
      </a>
    </div>
  );
}
