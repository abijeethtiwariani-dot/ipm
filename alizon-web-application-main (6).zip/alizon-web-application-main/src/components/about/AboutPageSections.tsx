"use client";

import { AboutOurStorySection } from "@/components/about/AboutOurStorySection";
import { AboutAccreditationSection } from "@/components/about/AboutAccreditationSection";
import { AboutInstituteSection } from "@/components/about/AboutInstituteSection";
import { AboutInstituteStatsSection } from "@/components/about/AboutInstituteStatsSection";

export function AboutPageSections() {
  return (
    <main className="bg-background text-foreground">
      <AboutOurStorySection />
      <AboutAccreditationSection />
      <AboutInstituteSection />
      <AboutInstituteStatsSection />
    </main>
  );
}
