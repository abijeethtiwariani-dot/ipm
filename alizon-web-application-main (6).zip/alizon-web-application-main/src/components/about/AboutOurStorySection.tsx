"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { fetchAboutPageOurStoryContent } from "@/lib/about-page-cms";
import { resolveAboutStoryImage } from "@/lib/about-image-fallbacks";
import type { AboutPageOurStoryContent } from "@/types/cms";
import { cn } from "@/lib/utils";
import {
  aboutContainer,
  aboutEase,
  aboutEyebrow,
  aboutFadeUpVariants,
  aboutNoiseTexture,
  aboutSectionPy,
} from "@/components/about/about-layout";
import { AboutOurStorySectionSkeleton } from "@/components/about/AboutPageSkeletons";
import { ParallaxTiltImage } from "@/components/about/ParallaxTiltImage";
import { WordRevealHeading } from "@/components/about/WordRevealHeading";

export function AboutOurStorySection() {
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState<AboutPageOurStoryContent | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await fetchAboutPageOurStoryContent();
        if (!cancelled) setContent(data);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) return <AboutOurStorySectionSkeleton />;
  if (!content) return null;

  const imageSrc = resolveAboutStoryImage(content.imageUrl);

  return (
    <section
      className={cn("relative overflow-hidden", aboutSectionPy)}
      style={{
        background: "linear-gradient(135deg, #fff5f6 0%, #f8fafc 100%)",
      }}
      aria-labelledby="about-our-story-heading"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 z-0 opacity-[0.035]"
        style={aboutNoiseTexture}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -left-24 top-16 z-0 h-72 w-72 rounded-full bg-red-200/30 blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -right-16 bottom-10 z-0 h-80 w-80 rounded-full bg-rose-200/25 blur-3xl"
      />

      <div className={cn("relative z-[1]", aboutContainer)}>
        <div className="flex flex-col gap-10 lg:flex-row lg:items-center lg:gap-16 xl:gap-20">
          <motion.div
            initial={false}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease: aboutEase }}
            className="relative w-full lg:w-[46%] lg:shrink-0"
          >
            <div className="relative mx-auto aspect-[4/3] max-w-xl lg:max-w-none">
              <ParallaxTiltImage
                src={imageSrc}
                alt={content.imageAlt}
                className="h-full min-h-[280px] sm:min-h-[320px] lg:min-h-[400px]"
                sizes="(max-width: 1024px) 100vw, 46vw"
              />
            </div>
          </motion.div>

          <motion.div
            initial={false}
            animate="visible"
            variants={{
              hidden: {},
              visible: {
                transition: { staggerChildren: 0.12, delayChildren: 0.1 },
              },
            }}
            className="relative flex-1"
          >
            <div className="rounded-[20px] border border-white/40 bg-white/65 p-6 shadow-[0_20px_60px_rgba(15,23,42,0.08)] backdrop-blur-[20px] sm:p-8 lg:p-10">
              <motion.div variants={aboutFadeUpVariants}>
                <p className={aboutEyebrow}>{content.eyebrow}</p>
                <div
                  aria-hidden
                  className="mt-3 h-0.5 w-12 rounded-full bg-gradient-to-r from-primary to-primary/30"
                />
              </motion.div>

              <motion.div variants={aboutFadeUpVariants} className="mt-5">
                <WordRevealHeading
                  id="about-our-story-heading"
                  text={content.heading}
                  className="site-section-heading text-foreground"
                  ready
                />
              </motion.div>

              <motion.p
                variants={aboutFadeUpVariants}
                className="site-section-intro mt-5 max-w-none text-left text-muted-foreground"
              >
                {content.body}
              </motion.p>

              <motion.div variants={aboutFadeUpVariants} className="mt-8">
                <Link
                  href={content.ctaHref}
                  className="group inline-flex items-center gap-2 rounded-md bg-primary px-6 py-3 text-sm font-semibold uppercase tracking-wide text-primary-foreground shadow-red transition-all duration-300 hover:bg-primary-dark hover:shadow-[0_8px_24px_rgba(177,4,14,0.35)]"
                >
                  {content.ctaText}
                  <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
                </Link>
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
