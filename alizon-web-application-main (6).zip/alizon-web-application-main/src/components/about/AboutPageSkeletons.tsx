import { Skeleton } from "@/components/ui/skeleton";
import { aboutContainer, aboutSectionPy } from "@/components/about/about-layout";
import { cn } from "@/lib/utils";

export function AboutHeroSectionSkeleton() {
  return <Skeleton className="h-[300px] md:h-[400px] w-full" />;
}

export function AboutOurStorySectionSkeleton() {
  return (
    <section className={cn("relative overflow-hidden", aboutSectionPy)}>
      <div className={aboutContainer}>
        <div className="flex flex-col gap-10 lg:flex-row lg:items-center">
          <Skeleton className="aspect-[4/3] w-full lg:w-[46%] rounded-[24px]" />
          <div className="flex-1 space-y-4">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-10 w-full max-w-md" />
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-12 w-48" />
          </div>
        </div>
      </div>
    </section>
  );
}

export function AboutAccreditationSectionSkeleton() {
  return (
    <section className={cn("relative overflow-hidden", aboutSectionPy)}>
      <div className={aboutContainer}>
        <div className="mx-auto max-w-3xl space-y-4 text-center">
          <Skeleton className="h-4 w-40 mx-auto" />
          <Skeleton className="h-10 w-full max-w-lg mx-auto" />
        </div>
        <div className="mt-12 grid gap-6 md:grid-cols-2">
          <Skeleton className="h-64 w-full rounded-[20px]" />
          <Skeleton className="h-64 w-full rounded-[20px]" />
        </div>
      </div>
    </section>
  );
}

export function AboutInstituteSectionSkeleton() {
  return (
    <section className={cn("relative overflow-hidden", aboutSectionPy)}>
      <div className={aboutContainer}>
        <div className="mb-10 space-y-4 text-center">
          <Skeleton className="h-4 w-20 mx-auto" />
          <Skeleton className="h-10 w-full max-w-sm mx-auto" />
        </div>
        <Skeleton className="h-[480px] w-full rounded-3xl" />
      </div>
    </section>
  );
}

export function AboutInstituteStatsSectionSkeleton() {
  return (
    <section className={cn("relative overflow-hidden", aboutSectionPy)}>
      <div className={aboutContainer}>
        <Skeleton className="mx-auto mb-10 h-10 w-full max-w-md md:mb-12" />
        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          <Skeleton className="h-28 w-full rounded-[20px]" />
          <Skeleton className="h-28 w-full rounded-[20px]" />
          <Skeleton className="h-28 w-full rounded-[20px]" />
        </div>
      </div>
    </section>
  );
}
