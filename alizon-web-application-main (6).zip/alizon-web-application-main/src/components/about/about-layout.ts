export const aboutSectionPy = "py-16 md:py-20 lg:py-24";

export const aboutContainer = "container mx-auto max-w-7xl px-4 lg:px-8";

export const aboutWideContainer = "mx-auto max-w-[1400px] px-4 lg:px-8 xl:px-10";

export const aboutEyebrow =
  "text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground";

export const aboutGlassCard =
  "rounded-[20px] border border-white/45 bg-white/70 backdrop-blur-[12px] shadow-[0_8px_32px_rgba(0,0,0,0.06)]";

export const aboutGlassCardHover =
  "transition-all duration-500 hover:-translate-y-1.5 hover:border-primary/25 hover:shadow-[0_16px_48px_rgba(177,4,14,0.12)]";

export const aboutPremiumGlassCard =
  "rounded-3xl border border-white/50 bg-white/65 backdrop-blur-[16px] shadow-[0_12px_40px_rgba(0,0,0,0.08)]";

export const aboutNoiseTexture = {
  backgroundImage:
    "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")",
};

export const aboutEase = [0.22, 1, 0.36, 1] as const;

export const aboutFadeUpVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: aboutEase },
  },
};
