"use client";

import { useEffect, useState } from "react";
import { PageBanner } from "@/components/layout/PageBanner";
import { fetchAboutPageHeroContent } from "@/lib/about-page-cms";
import { resolveAboutHeroImage } from "@/lib/about-image-fallbacks";
import type { AboutPageHeroContent } from "@/types/cms";
import { AboutHeroSectionSkeleton } from "@/components/about/AboutPageSkeletons";

export function AboutHeroSection() {
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState<AboutPageHeroContent | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await fetchAboutPageHeroContent();
        if (!cancelled) setContent(data);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) return <AboutHeroSectionSkeleton />;
  if (!content) return null;

  const heroImage = resolveAboutHeroImage(content.heroImageUrl);
  const mobileImage = content.mobileHeroImageUrl?.trim()
    ? content.mobileHeroImageUrl
    : undefined;

  return (
    <PageBanner
      title={content.title}
      subtitle={content.subtitle}
      image={heroImage}
      mobileImage={mobileImage}
    />
  );
}
