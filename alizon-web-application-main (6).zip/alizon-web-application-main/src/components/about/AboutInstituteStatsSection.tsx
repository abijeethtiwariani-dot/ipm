"use client";

import { useEffect, useRef, useState } from "react";
import CountUp from "react-countup";
import { motion } from "framer-motion";
import { fetchAboutPageInstituteStatsContent } from "@/lib/about-page-cms";
import { getAboutIcon } from "@/lib/about-icon-map";
import type { AboutPageInstituteStatsContent } from "@/types/cms";
import { cn } from "@/lib/utils";
import {
  aboutContainer,
  aboutEase,
  aboutFadeUpVariants,
  aboutGlassCard,
  aboutGlassCardHover,
  aboutSectionPy,
} from "@/components/about/about-layout";
import { AboutInstituteStatsSectionSkeleton } from "@/components/about/AboutPageSkeletons";
import { WordRevealHeading } from "@/components/about/WordRevealHeading";
import { useReducedMotion } from "@/components/about/useReducedMotion";

function StatCounter({
  value,
  isInView,
  reduceMotion,
}: {
  value: number;
  isInView: boolean;
  reduceMotion: boolean;
}) {
  if (reduceMotion) {
    return <span>{value.toLocaleString()}</span>;
  }

  if (!isInView) {
    return <span>{value.toLocaleString()}</span>;
  }

  return (
    <CountUp
      key={value}
      start={0}
      end={value}
      duration={2.2}
      separator=","
      useEasing
      easingFn={(t, b, c, d) => {
        const progress = t / d;
        return c * (1 - Math.pow(1 - progress, 3)) + b;
      }}
    />
  );
}

export function AboutInstituteStatsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const reduceMotion = useReducedMotion();
  const [hasAnimated, setHasAnimated] = useState(reduceMotion);
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState<AboutPageInstituteStatsContent | null>(
    null,
  );

  useEffect(() => {
    if (reduceMotion) setHasAnimated(true);
  }, [reduceMotion]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await fetchAboutPageInstituteStatsContent();
        if (!cancelled) setContent(data);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) return <AboutInstituteStatsSectionSkeleton />;
  if (!content) return null;

  return (
    <motion.section
      ref={sectionRef}
      initial={reduceMotion ? false : { opacity: 0, y: 28 }}
      whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.6, ease: aboutEase }}
      onViewportEnter={() => setHasAnimated(true)}
      className={cn("relative overflow-hidden", aboutSectionPy)}
      style={{
        background: "linear-gradient(180deg, #eef4ff 0%, #f5f8fc 100%)",
      }}
      aria-labelledby="about-institute-stats-heading"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent"
      />

      <div className={aboutContainer}>
        <motion.div
          initial={false}
          animate="visible"
          variants={aboutFadeUpVariants}
          className="mb-10 text-center md:mb-12"
        >
          <WordRevealHeading
            id="about-institute-stats-heading"
            text={content.sectionHeading}
            className="site-section-heading justify-center text-foreground"
            ready
          />
        </motion.div>

        <motion.div
          initial={false}
          animate="visible"
          variants={{
            hidden: {},
            visible: {
              transition: { staggerChildren: 0.15 },
            },
          }}
          className="grid grid-cols-1 gap-6 md:grid-cols-3"
        >
          {content.stats.map((stat, index) => {
            const Icon = getAboutIcon(stat.icon);
            return (
              <motion.article
                key={`${stat.label}-${index}`}
                variants={aboutFadeUpVariants}
                transition={{ duration: 0.6, ease: aboutEase }}
                className={cn(
                  aboutGlassCard,
                  aboutGlassCardHover,
                  "group flex items-center justify-between p-6 sm:p-8",
                )}
              >
                <div>
                  <p className="site-stat-value text-foreground">
                    <StatCounter
                      value={stat.animateValue}
                      isInView={hasAnimated}
                      reduceMotion={reduceMotion}
                    />
                  </p>
                  <p className="mt-1 text-sm font-medium text-muted-foreground sm:text-base">
                    {stat.label}
                  </p>
                </div>

                <motion.div
                  whileHover={reduceMotion ? undefined : { scale: 1.08 }}
                  transition={{ duration: 0.3, ease: aboutEase }}
                  className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-primary/10 transition-colors duration-300 group-hover:bg-primary/15"
                >
                  <Icon
                    className="h-7 w-7 text-primary"
                    strokeWidth={1.5}
                    aria-hidden
                  />
                </motion.div>
              </motion.article>
            );
          })}
        </motion.div>
      </div>
    </motion.section>
  );
}
