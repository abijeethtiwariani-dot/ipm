"use client";

import { useEffect, useRef, useState } from "react";
import Image, { type StaticImageData } from "next/image";
import {
  motion,
  useMotionValue,
  useSpring,
  useTransform,
} from "framer-motion";
import { cn } from "@/lib/utils";
import { unoptimizedForImageSrc } from "@/lib/cms-image-url";
import { useReducedMotion } from "@/components/about/useReducedMotion";

const imageFloat = {
  y: [0, -8, 0],
  transition: {
    duration: 6,
    repeat: Infinity,
    ease: "easeInOut" as const,
  },
};

type ParallaxTiltImageProps = {
  src: StaticImageData | string;
  alt: string;
  className?: string;
  imageClassName?: string;
  sizes?: string;
  priority?: boolean;
};

export function ParallaxTiltImage({
  src,
  alt,
  className,
  imageClassName,
  sizes = "(max-width: 1024px) 100vw, 50vw",
  priority = false,
}: ParallaxTiltImageProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const reduceMotion = useReducedMotion();
  const [isCoarsePointer, setIsCoarsePointer] = useState(false);

  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const rotateX = useSpring(useTransform(mouseY, [-0.5, 0.5], [6, -6]), {
    stiffness: 180,
    damping: 22,
  });
  const rotateY = useSpring(useTransform(mouseX, [-0.5, 0.5], [-6, 6]), {
    stiffness: 180,
    damping: 22,
  });

  useEffect(() => {
    const mq = window.matchMedia("(pointer: coarse)");
    const apply = () => setIsCoarsePointer(mq.matches);
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);

  const enableTilt = !reduceMotion && !isCoarsePointer;

  function handleMouseMove(event: React.MouseEvent<HTMLDivElement>) {
    if (!enableTilt || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - 0.5;
    const y = (event.clientY - rect.top) / rect.height - 0.5;
    mouseX.set(x);
    mouseY.set(y);
  }

  function handleMouseLeave() {
    mouseX.set(0);
    mouseY.set(0);
  }

  return (
    <motion.div
      ref={containerRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      animate={reduceMotion ? undefined : imageFloat}
      style={
        enableTilt
          ? {
              rotateX,
              rotateY,
              transformPerspective: 1000,
            }
          : undefined
      }
      className={cn(
        "group relative overflow-visible rounded-[24px] border border-white/35 bg-white/20 p-2 shadow-[0_30px_80px_rgba(0,0,0,0.12)] backdrop-blur-sm transition-shadow duration-700 hover:shadow-[0_36px_90px_rgba(0,0,0,0.16)]",
        className,
      )}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 z-[1] rounded-[inherit] bg-gradient-to-br from-white/35 via-white/10 to-transparent"
      />
      <div className="relative h-full w-full overflow-hidden rounded-[20px]">
        <Image
          src={src}
          alt={alt}
          fill
          priority={priority}
          unoptimized={unoptimizedForImageSrc(src)}
          className={cn(
            "object-cover object-center transition-transform duration-500 ease-out group-hover:scale-[1.03]",
            imageClassName,
          )}
          sizes={sizes}
        />
      </div>
    </motion.div>
  );
}
