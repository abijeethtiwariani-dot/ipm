"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { fetchAboutPageAccreditationContent } from "@/lib/about-page-cms";
import type { AboutPageAccreditationContent } from "@/types/cms";
import { cn } from "@/lib/utils";
import {
  aboutContainer,
  aboutEase,
  aboutEyebrow,
  aboutFadeUpVariants,
  aboutGlassCard,
  aboutGlassCardHover,
  aboutNoiseTexture,
  aboutSectionPy,
} from "@/components/about/about-layout";
import { AboutAccreditationSectionSkeleton } from "@/components/about/AboutPageSkeletons";
import { WordRevealHeading } from "@/components/about/WordRevealHeading";

export function AboutAccreditationSection() {
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState<AboutPageAccreditationContent | null>(
    null,
  );

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await fetchAboutPageAccreditationContent();
        if (!cancelled) setContent(data);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) return <AboutAccreditationSectionSkeleton />;
  if (!content) return null;

  return (
    <section
      className={cn("relative overflow-hidden", aboutSectionPy)}
      style={{
        background: "linear-gradient(180deg, #f0f7ff 0%, #f8fafc 100%)",
      }}
      aria-labelledby="about-accreditation-heading"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 z-0 opacity-[0.03]"
        style={aboutNoiseTexture}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute left-1/2 top-0 z-0 h-64 w-64 -translate-x-1/2 rounded-full bg-blue-200/25 blur-3xl"
      />

      <div className={cn("relative z-[1]", aboutContainer)}>
        <motion.div
          initial={false}
          animate="visible"
          variants={{
            hidden: {},
            visible: {
              transition: { staggerChildren: 0.1 },
            },
          }}
          className="mx-auto max-w-3xl text-center"
        >
          <motion.p variants={aboutFadeUpVariants} className={aboutEyebrow}>
            {content.eyebrow}
          </motion.p>
          <motion.div variants={aboutFadeUpVariants} className="mt-4">
            <WordRevealHeading
              id="about-accreditation-heading"
              text={content.heading}
              className="site-section-heading justify-center text-foreground"
              ready
            />
          </motion.div>
        </motion.div>

        <motion.div
          initial={false}
          animate="visible"
          variants={{
            hidden: {},
            visible: {
              transition: { staggerChildren: 0.12, delayChildren: 0.2 },
            },
          }}
          className="mt-12 grid gap-6 md:grid-cols-2 md:gap-8"
        >
          {content.cards.map((card) => (
            <motion.article
              key={card.title}
              variants={aboutFadeUpVariants}
              transition={{ duration: 0.6, ease: aboutEase }}
              className={cn(
                aboutGlassCard,
                aboutGlassCardHover,
                "group p-6 sm:p-8",
              )}
            >
              <div
                aria-hidden
                className="mb-4 h-0.5 w-10 rounded-full bg-primary/80 transition-all duration-500 group-hover:w-14 group-hover:bg-primary"
              />
              <h3 className="site-card-title text-foreground">{card.title}</h3>
              <p className="site-card-desc mt-4 text-muted-foreground">
                {card.body}
              </p>
            </motion.article>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
