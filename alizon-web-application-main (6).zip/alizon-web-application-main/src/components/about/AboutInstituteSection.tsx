"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { motion } from "framer-motion";
import { fetchAboutPageInstituteContent } from "@/lib/about-page-cms";
import { resolveAboutInstituteImage } from "@/lib/about-image-fallbacks";
import { getAboutIcon } from "@/lib/about-icon-map";
import { shouldUnoptimizeCmsSrc } from "@/lib/cms-image-url";
import type { AboutPageInstituteContent } from "@/types/cms";
import { cn } from "@/lib/utils";
import {
  aboutContainer,
  aboutEase,
  aboutEyebrow,
  aboutFadeUpVariants,
  aboutNoiseTexture,
  aboutPremiumGlassCard,
  aboutSectionPy,
} from "@/components/about/about-layout";
import { AboutInstituteSectionSkeleton } from "@/components/about/AboutPageSkeletons";
import { WordRevealHeading } from "@/components/about/WordRevealHeading";

export function AboutInstituteSection() {
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState<AboutPageInstituteContent | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await fetchAboutPageInstituteContent();
        if (!cancelled) setContent(data);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) return <AboutInstituteSectionSkeleton />;
  if (!content) return null;

  const imageSrc = resolveAboutInstituteImage(content.imageUrl);
  const imageIsRemote =
    typeof imageSrc === "string" && shouldUnoptimizeCmsSrc(imageSrc);

  return (
    <section
      className={cn("relative overflow-hidden", aboutSectionPy)}
      style={{
        background: "linear-gradient(135deg, #fafafa 0%, #fff5f6 50%, #f8fafc 100%)",
      }}
      aria-labelledby="about-institute-heading"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 z-0 opacity-[0.03]"
        style={aboutNoiseTexture}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -right-20 top-20 z-0 h-72 w-72 rounded-full bg-rose-100/40 blur-3xl"
      />

      <div className={cn("relative z-[1]", aboutContainer)}>
        <motion.div
          initial={false}
          animate="visible"
          variants={{
            hidden: {},
            visible: { transition: { staggerChildren: 0.1 } },
          }}
          className="mb-10 text-center md:mb-12"
        >
          <motion.p variants={aboutFadeUpVariants} className={aboutEyebrow}>
            {content.eyebrow}
          </motion.p>
          <motion.div variants={aboutFadeUpVariants} className="mt-4">
            <WordRevealHeading
              id="about-institute-heading"
              text={content.heading}
              className="site-section-heading justify-center text-foreground"
              ready
            />
          </motion.div>
        </motion.div>

        <motion.div
          initial={false}
          animate="visible"
          variants={{
            hidden: {},
            visible: { transition: { staggerChildren: 0.15, delayChildren: 0.1 } },
          }}
          className={cn(aboutPremiumGlassCard, "overflow-hidden p-6 sm:p-8 lg:p-12")}
        >
          <div className="grid gap-8 lg:grid-cols-2 lg:items-center lg:gap-12">
            <motion.div
              variants={aboutFadeUpVariants}
              className="group relative mx-auto aspect-square w-full max-w-md overflow-hidden rounded-2xl border border-white/40 shadow-[0_20px_50px_rgba(0,0,0,0.1)] lg:max-w-none"
            >
              <Image
                src={imageSrc}
                alt={content.imageAlt}
                fill
                unoptimized={imageIsRemote}
                className="object-cover transition-transform duration-500 group-hover:scale-[1.03]"
                sizes="(max-width: 1024px) 100vw, 50vw"
              />
              <div
                aria-hidden
                className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/10 to-transparent"
              />
            </motion.div>

            <motion.div variants={aboutFadeUpVariants} className="space-y-6">
              <h3 className="site-card-title text-foreground lg:text-xl">
                {content.programTitle}
              </h3>

              <ul className="space-y-3">
                {content.meta.map((item) => {
                  const Icon = getAboutIcon(item.icon);
                  return (
                    <li
                      key={item.label}
                      className="group/meta flex items-center gap-3 text-sm font-medium text-foreground sm:text-base"
                    >
                      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 transition-transform duration-300 group-hover/meta:scale-110">
                        <Icon className="h-5 w-5 text-primary" aria-hidden />
                      </span>
                      {item.label}
                    </li>
                  );
                })}
              </ul>

              <div>
                <h4 className="site-card-title mb-3 text-foreground">
                  {content.aboutHeading}
                </h4>
                <p className="site-card-desc text-muted-foreground">
                  {content.aboutBody}
                </p>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
