"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { cn } from "@/lib/utils";
import { aboutEase } from "@/components/about/about-layout";
import { useReducedMotion } from "@/components/about/useReducedMotion";

type WordRevealHeadingProps = {
  text: string;
  as?: "h2" | "h3";
  className?: string;
  id?: string;
  /** When true, reveal immediately (e.g. CMS content already loaded). */
  ready?: boolean;
};

export function WordRevealHeading({
  text,
  as: Tag = "h2",
  className,
  id,
  ready = false,
}: WordRevealHeadingProps) {
  const ref = useRef<HTMLHeadingElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-60px" });
  const reduceMotion = useReducedMotion();
  const words = text.split(" ");
  const showWords = ready || isInView || reduceMotion;

  if (reduceMotion || ready) {
    return (
      <Tag id={id} className={className}>
        {text}
      </Tag>
    );
  }

  return (
    <Tag
      ref={ref}
      id={id}
      className={cn("flex flex-wrap gap-x-[0.28em] gap-y-1", className)}
      aria-label={text}
    >
      {words.map((word, index) => (
        <motion.span
          key={`${word}-${index}`}
          className="inline-block"
          initial={{ opacity: 0, y: 20 }}
          animate={showWords ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{
            duration: 0.5,
            delay: index * 0.08,
            ease: aboutEase,
          }}
          aria-hidden
        >
          {word}
        </motion.span>
      ))}
    </Tag>
  );
}
