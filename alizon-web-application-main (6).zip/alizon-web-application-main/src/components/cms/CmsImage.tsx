"use client";

import Image, { type ImageProps } from "next/image";
import { shouldUnoptimizeCmsSrc } from "@/lib/cms-image-url";

type CmsImageProps = Omit<ImageProps, "src" | "unoptimized"> & {
  src: string;
  /** Skip Next.js optimizer only for blob/data URLs */
  forceUnoptimized?: boolean;
};

function shouldUnoptimize(src: string, forceUnoptimized?: boolean): boolean {
  if (forceUnoptimized) return true;
  return shouldUnoptimizeCmsSrc(src);
}

export function CmsImage({
  src,
  forceUnoptimized,
  fill,
  width,
  height,
  ...props
}: CmsImageProps) {
  return (
    <Image
      src={src}
      unoptimized={shouldUnoptimize(src, forceUnoptimized)}
      {...props}
      {...(fill ? { fill: true } : { width, height })}
    />
  );
}
