"use client";

import Image from "next/image";
import type { AlumniTestimonial } from "@/types/cms";
import { cn } from "@/lib/utils";
import { shouldUnoptimizeCmsSrc } from "@/lib/cms-image-url";
import {
  alumniGlassCard,
  alumniGlassCardHover,
} from "@/components/alumni/alumni-layout";

type AlumniTestimonialCardProps = {
  testimonial: AlumniTestimonial;
  className?: string;
};

export function AlumniTestimonialCard({
  testimonial,
  className,
}: AlumniTestimonialCardProps) {
  return (
    <div className={cn("group/card h-full", className)}>
      <div
        className={cn(
          alumniGlassCard,
          alumniGlassCardHover,
          "flex h-full flex-col p-6 md:p-8",
        )}
      >
        <div className="flex items-center gap-4">
          {testimonial.photoUrl ? (
            <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-full border border-white/60 shadow-sm">
              <Image
                src={testimonial.photoUrl}
                alt={testimonial.name}
                fill
                className="object-cover transition-transform duration-500 group-hover/card:scale-110"
                sizes="56px"
                unoptimized={shouldUnoptimizeCmsSrc(testimonial.photoUrl)}
              />
            </div>
          ) : null}
          <div className="min-w-0">
            <p className="font-semibold text-foreground">{testimonial.name}</p>
            {testimonial.graduationYear ? (
              <p className="text-sm text-primary">
                Class of {testimonial.graduationYear}
              </p>
            ) : null}
            <p className="text-xs text-muted-foreground">
              {testimonial.currentRole}
            </p>
          </div>
        </div>

        <p className="site-card-desc mt-5 flex-1 leading-relaxed">
          &ldquo;{testimonial.testimonial}&rdquo;
        </p>
      </div>
    </div>
  );
}
