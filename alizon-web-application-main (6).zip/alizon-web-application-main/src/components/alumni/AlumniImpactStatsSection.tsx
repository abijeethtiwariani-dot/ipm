"use client";

import { useEffect, useRef, useState } from "react";
import CountUp from "react-countup";
import { motion, useInView } from "framer-motion";
import { SCHOLARSHIP_ICON_MAP } from "@/lib/scholarship-content";
import { fetchAlumniStatistics } from "@/lib/alumni-page-cms";
import type { AlumniStatistic } from "@/types/cms";
import { cn } from "@/lib/utils";
import { WordRevealHeading } from "@/components/about/WordRevealHeading";
import { useReducedMotion } from "@/components/about/useReducedMotion";
import {
  AlumniSectionShell,
  alumniFadeUpVariants,
  alumniGlassCard,
  alumniGlassCardHover,
  alumniSectionHeadingCenteredClass,
  alumniSectionHeadingClass,
  alumniStaggerContainer,
} from "@/components/alumni/alumni-layout";

function formatCounterValue(end: number, suffix?: string) {
  return `${end.toLocaleString()}${suffix ?? ""}`;
}

function StatCounter({
  end,
  suffix,
  isInView,
  reduceMotion,
}: {
  end: number;
  suffix?: string;
  isInView: boolean;
  reduceMotion: boolean;
}) {
  if (reduceMotion || !isInView) {
    return <span>{formatCounterValue(end, suffix)}</span>;
  }

  return (
    <CountUp
      start={0}
      end={end}
      duration={2.2}
      separator=","
      suffix={suffix ?? ""}
      useEasing
      easingFn={(t, b, c, d) => {
        const progress = t / d;
        return c * (1 - Math.pow(1 - progress, 3)) + b;
      }}
    />
  );
}

export function AlumniImpactStatsSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const [stats, setStats] = useState<AlumniStatistic[]>([]);
  const [loaded, setLoaded] = useState(false);
  const statsInView = useInView(sectionRef, { once: true, margin: "-60px" });
  const [counterReady, setCounterReady] = useState(false);
  const reduceMotion = useReducedMotion();

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const data = await fetchAlumniStatistics();
      if (!cancelled) {
        setStats(data);
        setLoaded(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Async CMS mount can miss useInView(once:true) if the section is already visible.
  useEffect(() => {
    if (!loaded) return;
    if (statsInView || reduceMotion) {
      setCounterReady(true);
      return;
    }
    const node = sectionRef.current;
    if (!node) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setCounterReady(true);
          observer.disconnect();
        }
      },
      { rootMargin: "-60px 0px", threshold: 0.15 },
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [loaded, statsInView, reduceMotion]);

  if (!loaded || stats.length === 0) return null;

  const animateCounters = counterReady || statsInView;

  return (
    <AlumniSectionShell
      sectionIndex={4}
      entry="fromRight"
      ariaLabelledBy="alumni-impact-heading"
    >
      <div className="mb-10 text-center md:mb-12">
        <WordRevealHeading
          id="alumni-impact-heading"
          text="Alumni Success & Impact"
          className={cn(
            alumniSectionHeadingClass,
            alumniSectionHeadingCenteredClass,
          )}
          ready={loaded || reduceMotion}
        />
        <p className="site-section-intro mx-auto mt-4 max-w-2xl">
          The reach and influence of our alumni network across the globe.
        </p>
      </div>

      <motion.div
        ref={sectionRef}
        variants={alumniStaggerContainer}
        initial={reduceMotion ? false : "hidden"}
        whileInView="visible"
        viewport={{ once: true, margin: "-60px" }}
        className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4"
      >
        {stats.map((stat) => {
          const Icon =
            SCHOLARSHIP_ICON_MAP[
              stat.icon as keyof typeof SCHOLARSHIP_ICON_MAP
            ];
          const useAnimatedCounter =
            stat.counterEnd !== undefined && stat.counterEnd > 0;

          return (
            <motion.div
              key={stat.id}
              variants={alumniFadeUpVariants}
              className="group/card"
            >
              <div
                className={cn(
                  alumniGlassCard,
                  alumniGlassCardHover,
                  "flex h-full flex-col items-center p-6 text-center",
                )}
              >
                <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                  {Icon ? <Icon className="h-5 w-5" /> : null}
                </div>
                <div className="font-heading text-3xl font-bold text-foreground md:text-4xl">
                  {useAnimatedCounter ? (
                    <StatCounter
                      end={stat.counterEnd!}
                      suffix={stat.counterSuffix}
                      isInView={animateCounters}
                      reduceMotion={reduceMotion}
                    />
                  ) : (
                    stat.value
                  )}
                </div>
                <p className="mt-3 text-sm text-muted-foreground md:text-base">
                  {stat.title}
                </p>
              </div>
            </motion.div>
          );
        })}
      </motion.div>
    </AlumniSectionShell>
  );
}
