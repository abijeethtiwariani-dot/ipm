"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { ArrowRight, Calendar } from "lucide-react";
import { motion } from "framer-motion";
import type {
  AlumniNotification,
  AlumniNotificationsHeaderContent,
} from "@/types/cms";
import {
  fetchAlumniNotificationsHeaderContent,
  fetchPublishedAlumniNotifications,
} from "@/lib/alumni-page-cms";
import { cn } from "@/lib/utils";
import { Card } from "@/components/ui/card";
import { WordRevealHeading } from "@/components/about/WordRevealHeading";
import { useReducedMotion } from "@/components/about/useReducedMotion";
import { shouldUnoptimizeCmsSrc } from "@/lib/cms-image-url";
import {
  AlumniSectionEmptyState,
  alumniFadeUpVariants,
  alumniSectionHeadingCenteredClass,
  alumniSectionHeadingClass,
  alumniStaggerContainer,
} from "@/components/alumni/alumni-layout";

export function AlumniNotificationsSection() {
  const [header, setHeader] = useState<AlumniNotificationsHeaderContent | null>(
    null,
  );
  const [notifications, setNotifications] = useState<AlumniNotification[]>(
    [],
  );
  const [loaded, setLoaded] = useState(false);
  const reduceMotion = useReducedMotion();

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const [headerData, notificationsData] = await Promise.all([
        fetchAlumniNotificationsHeaderContent(),
        fetchPublishedAlumniNotifications(),
      ]);
      if (!cancelled) {
        setHeader(headerData);
        setNotifications(notificationsData);
        setLoaded(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (!loaded) return null;
  if (!header && notifications.length === 0) return null;

  return (
    <section className="py-16 section-cream">
      <div className="container mx-auto px-4">
        {header?.heading || header?.intro ? (
          <div className="mb-10 text-center md:mb-12">
            {header?.heading ? (
              <WordRevealHeading
                id="alumni-notifications"
                text={header.heading}
                className={cn(
                  alumniSectionHeadingClass,
                  alumniSectionHeadingCenteredClass,
                )}
                ready={loaded || reduceMotion}
              />
            ) : null}
            {header?.intro ? (
              <p className="site-section-intro mx-auto mt-4 max-w-2xl">
                {header.intro}
              </p>
            ) : null}
          </div>
        ) : null}

        {notifications.length === 0 ? (
          <div className="mx-auto max-w-2xl">
            <AlumniSectionEmptyState message="Notifications will appear here once published in the admin panel." />
          </div>
        ) : (
          <motion.div
            variants={alumniStaggerContainer}
            initial={reduceMotion ? false : "hidden"}
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3"
          >
            {notifications.map((notification) => {
              const card = (
                <Card
                  className={cn(
                    "group h-full overflow-hidden border-0 shadow-soft card-hover transition-all hover:shadow-elevated",
                  )}
                >
                  {notification.imageUrl ? (
                    <div className="relative aspect-[4/3] overflow-hidden">
                      <Image
                        src={notification.imageUrl}
                        alt={notification.title}
                        fill
                        className="object-cover transition-transform duration-500 group-hover:scale-105"
                        sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                        unoptimized={shouldUnoptimizeCmsSrc(
                          notification.imageUrl,
                        )}
                      />
                    </div>
                  ) : null}
                  <div className="p-5">
                    <h3 className="font-semibold text-foreground mb-2">
                      {notification.title}
                    </h3>
                    <p className="site-card-desc mb-4 line-clamp-3">
                      {notification.description}
                    </p>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
                      <Calendar className="w-4 h-4 shrink-0" />
                      <span>{notification.eventDate}</span>
                    </div>
                    {notification.linkUrl ? (
                      <span className="inline-flex items-center gap-2 text-sm font-semibold text-primary">
                        Read more
                        <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                      </span>
                    ) : null}
                  </div>
                </Card>
              );

              return (
                <motion.div key={notification.id} variants={alumniFadeUpVariants}>
                  {notification.linkUrl ? (
                    <Link
                      href={notification.linkUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block h-full"
                    >
                      {card}
                    </Link>
                  ) : (
                    card
                  )}
                </motion.div>
              );
            })}
          </motion.div>
        )}
      </div>
    </section>
  );
}
