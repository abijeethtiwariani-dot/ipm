"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import type { AlumniCommunityGroup } from "@/types/cms";
import { fetchAlumniCommunityLinksContent } from "@/lib/alumni-page-cms";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { WordRevealHeading } from "@/components/about/WordRevealHeading";
import { useReducedMotion } from "@/components/about/useReducedMotion";
import {
  AlumniSectionShell,
  alumniGlassCard,
  alumniGlassCardHover,
  alumniFadeUpVariants,
  alumniSectionHeadingCenteredClass,
  alumniSectionHeadingClass,
  alumniStaggerContainer,
} from "@/components/alumni/alumni-layout";
import { TelegramIcon, WhatsAppIcon } from "@/components/alumni/AlumniCommunityIcons";

type CommunityCardProps = {
  platform: "whatsapp" | "telegram";
  group: AlumniCommunityGroup;
};

function CommunityCard({ platform, group }: CommunityCardProps) {
  const Icon = platform === "whatsapp" ? WhatsAppIcon : TelegramIcon;
  const label = platform === "whatsapp" ? "Join WhatsApp Group" : "Join Telegram Group";
  const iconColor =
    platform === "whatsapp" ? "text-[#25D366]" : "text-[#229ED9]";

  return (
    <motion.div variants={alumniFadeUpVariants} className="h-full">
      <div
        className={cn(
          alumniGlassCard,
          alumniGlassCardHover,
          "flex h-full flex-col p-8 md:p-10",
        )}
      >
        <div
          className={cn(
            "mb-6 flex h-14 w-14 items-center justify-center rounded-2xl bg-white/80 shadow-sm",
            iconColor,
          )}
        >
          <Icon className="h-8 w-8" />
        </div>
        <h3 className="font-heading text-2xl font-bold text-foreground mb-3">
          {group.groupName}
        </h3>
        {group.description ? (
          <p className="site-card-desc flex-1 mb-8">{group.description}</p>
        ) : (
          <div className="flex-1 mb-8" />
        )}
        <Button asChild size="lg" className="w-full sm:w-auto">
          <Link href={group.groupLink} target="_blank" rel="noopener noreferrer">
            {label}
          </Link>
        </Button>
      </div>
    </motion.div>
  );
}

export function AlumniCommunitySection() {
  const [whatsapp, setWhatsapp] = useState<AlumniCommunityGroup | null>(null);
  const [telegram, setTelegram] = useState<AlumniCommunityGroup | null>(null);
  const [loaded, setLoaded] = useState(false);
  const reduceMotion = useReducedMotion();

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const data = await fetchAlumniCommunityLinksContent();
      if (!cancelled) {
        const wa = data?.whatsapp;
        const tg = data?.telegram;
        setWhatsapp(wa?.groupLink?.trim() ? wa : null);
        setTelegram(tg?.groupLink?.trim() ? tg : null);
        setLoaded(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (!loaded || (!whatsapp && !telegram)) return null;

  return (
    <AlumniSectionShell sectionIndex={3} entry="fromLeft" id="join-alumni-community">
      <div className="mb-10 text-center md:mb-12">
        <WordRevealHeading
          text="Join Our Alumni Community"
          className={cn(
            alumniSectionHeadingClass,
            alumniSectionHeadingCenteredClass,
          )}
          ready={loaded || reduceMotion}
        />
        <p className="site-section-intro mx-auto mt-0 max-w-3xl">
          Stay connected with fellow alumni, receive updates, network across
          industries, and participate in events that keep our community thriving.
        </p>
      </div>

      <motion.div
        variants={alumniStaggerContainer}
        initial={reduceMotion ? false : "hidden"}
        whileInView="visible"
        viewport={{ once: true, margin: "-60px" }}
        className={cn(
          "mx-auto grid gap-6",
          whatsapp && telegram ? "max-w-5xl md:grid-cols-2" : "max-w-xl",
        )}
      >
        {whatsapp ? (
          <CommunityCard platform="whatsapp" group={whatsapp} />
        ) : null}
        {telegram ? (
          <CommunityCard platform="telegram" group={telegram} />
        ) : null}
      </motion.div>
    </AlumniSectionShell>
  );
}
