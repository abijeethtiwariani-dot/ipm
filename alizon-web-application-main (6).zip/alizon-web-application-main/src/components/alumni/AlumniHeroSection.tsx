"use client";

import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { PageBanner } from "@/components/layout/PageBanner";
import { fetchAlumniPageHeroContent } from "@/lib/alumni-page-cms";
import { useReducedMotion } from "@/components/about/useReducedMotion";

export function AlumniHeroSection() {
  const [loading, setLoading] = useState(true);
  const [hero, setHero] = useState<Awaited<
    ReturnType<typeof fetchAlumniPageHeroContent>
  > | null>(null);
  const reduceMotion = useReducedMotion();

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await fetchAlumniPageHeroContent();
        if (!cancelled) setHero(data);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading || !hero || !hero.heroImageUrl.trim() || !hero.title.trim()) {
    return null;
  }

  return (
    <motion.div
      initial={reduceMotion ? false : { opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
    >
      <PageBanner
        title={hero.title}
        subtitle={hero.subtitle}
        image={hero.heroImageUrl}
        mobileImage={hero.mobileHeroImageUrl || undefined}
        ctaText={hero.ctaText}
        ctaLink={hero.ctaLink}
      />
    </motion.div>
  );
}
