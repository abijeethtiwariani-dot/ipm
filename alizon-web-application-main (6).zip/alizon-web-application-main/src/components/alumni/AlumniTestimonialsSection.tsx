"use client";

import { useEffect, useState } from "react";
import { fetchAlumniTestimonials } from "@/lib/alumni-page-cms";
import type { AlumniTestimonial } from "@/types/cms";
import { WordRevealHeading } from "@/components/about/WordRevealHeading";
import { useReducedMotion } from "@/components/about/useReducedMotion";
import { cn } from "@/lib/utils";
import { AlumniSectionShell, alumniSectionHeadingCenteredClass, alumniSectionHeadingClass } from "@/components/alumni/alumni-layout";
import { AlumniTestimonialsCarousel } from "@/components/alumni/AlumniTestimonialsCarousel";

export function AlumniTestimonialsSection() {
  const [testimonials, setTestimonials] = useState<AlumniTestimonial[]>([]);
  const [loaded, setLoaded] = useState(false);
  const reduceMotion = useReducedMotion();

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const data = await fetchAlumniTestimonials();
      if (!cancelled) {
        setTestimonials(data);
        setLoaded(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (!loaded || testimonials.length === 0) return null;

  return (
    <AlumniSectionShell sectionIndex={5} entry="fadeUp" id="alumni-testimonials">
      <div className="mb-10 text-center md:mb-12">
        <WordRevealHeading
          text="Alumni Testimonials"
          className={cn(
            alumniSectionHeadingClass,
            alumniSectionHeadingCenteredClass,
          )}
          ready={loaded || reduceMotion}
        />
        <p className="site-section-intro mx-auto mt-4 max-w-2xl">
          Stories from alumni who continue to shape industries and communities
          worldwide.
        </p>
      </div>

      <AlumniTestimonialsCarousel testimonials={testimonials} />
    </AlumniSectionShell>
  );
}
