"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
  type CarouselApi,
} from "@/components/ui/carousel";
import type { AlumniTestimonial } from "@/types/cms";
import { cn } from "@/lib/utils";
import { AlumniTestimonialCard } from "@/components/alumni/AlumniTestimonialCard";
import { admissionCardGlass } from "@/components/scholarships/scholarships-layout";

const navButtonClass = cn(
  admissionCardGlass,
  "h-10 w-10 rounded-full border-white/40 bg-white/75 text-foreground shadow-md backdrop-blur-md",
  "hover:border-primary/25 hover:bg-white/90 disabled:opacity-40",
);

type AlumniTestimonialsCarouselProps = {
  testimonials: AlumniTestimonial[];
};

export function AlumniTestimonialsCarousel({
  testimonials,
}: AlumniTestimonialsCarouselProps) {
  const [api, setApi] = useState<CarouselApi>();
  const [selectedIndex, setSelectedIndex] = useState(0);

  const onSelect = useCallback((carouselApi: CarouselApi) => {
    if (!carouselApi) return;
    setSelectedIndex(carouselApi.selectedScrollSnap());
  }, []);

  useEffect(() => {
    if (!api) return;

    onSelect(api);
    api.on("select", onSelect);
    api.on("reInit", onSelect);

    return () => {
      api.off("select", onSelect);
      api.off("reInit", onSelect);
    };
  }, [api, onSelect]);

  const scrollTo = useCallback(
    (index: number) => {
      api?.scrollTo(index);
    },
    [api],
  );

  if (testimonials.length === 0) return null;

  return (
    <div className="relative w-full" aria-label="Alumni testimonials">
      <Carousel
        setApi={setApi}
        opts={{ align: "start", loop: testimonials.length > 1 }}
        className="relative w-full px-12 sm:px-14 md:px-16"
      >
        <CarouselContent className="-ml-4">
          {testimonials.map((testimonial) => (
            <CarouselItem
              key={testimonial.id}
              className="basis-full pl-4 sm:basis-1/2 lg:basis-1/3"
            >
              <AlumniTestimonialCard testimonial={testimonial} />
            </CarouselItem>
          ))}
        </CarouselContent>

        {testimonials.length > 1 && (
          <>
            <CarouselPrevious
              className={cn(
                navButtonClass,
                "left-0 top-1/2 z-20 -translate-y-1/2",
              )}
              aria-label="Previous testimonial"
            />
            <CarouselNext
              className={cn(
                navButtonClass,
                "right-0 top-1/2 z-20 -translate-y-1/2",
              )}
              aria-label="Next testimonial"
            />
          </>
        )}
      </Carousel>

      {testimonials.length > 1 && (
        <div className="mt-6 flex justify-center gap-2">
          {testimonials.map((testimonial, index) => (
            <button
              key={testimonial.id}
              type="button"
              aria-label={`Go to testimonial ${index + 1}`}
              onClick={() => scrollTo(index)}
              className={cn(
                "h-2 rounded-full transition-all duration-300",
                selectedIndex === index
                  ? "w-8 bg-primary"
                  : "w-2 bg-primary/30 hover:bg-primary/50",
              )}
            />
          ))}
        </div>
      )}
    </div>
  );
}
