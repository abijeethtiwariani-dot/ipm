"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Linkedin } from "lucide-react";
import { motion } from "framer-motion";
import type { AlumniLeader, AlumniLeadershipHeaderContent } from "@/types/cms";
import {
  fetchAlumniLeadershipHeaderContent,
  fetchPublishedAlumniLeaders,
} from "@/lib/alumni-page-cms";
import { cn } from "@/lib/utils";
import { WordRevealHeading } from "@/components/about/WordRevealHeading";
import { useReducedMotion } from "@/components/about/useReducedMotion";
import {
  facultyContainer,
  facultySectionTitleMb,
} from "@/components/faculty/faculty-layout";
import {
  AlumniSectionEmptyState,
  alumniFadeUpVariants,
  alumniSectionHeadingClass,
  alumniStaggerContainer,
} from "@/components/alumni/alumni-layout";

export function AlumniLeadershipSection() {
  const [header, setHeader] = useState<AlumniLeadershipHeaderContent | null>(
    null,
  );
  const [leaders, setLeaders] = useState<AlumniLeader[]>([]);
  const [loaded, setLoaded] = useState(false);
  const headingRef = useRef<HTMLDivElement>(null);
  const reduceMotion = useReducedMotion();
  const headingReady = loaded || reduceMotion;

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const [headerData, leadersData] = await Promise.all([
        fetchAlumniLeadershipHeaderContent(),
        fetchPublishedAlumniLeaders(),
      ]);
      if (!cancelled) {
        setHeader(headerData);
        setLeaders(leadersData);
        setLoaded(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (!loaded) return null;
  if (!header && leaders.length === 0) return null;

  return (
    <section className="py-12 md:py-16 lg:py-24 bg-stone-50">
      <div className={facultyContainer}>
        {header ? (
          <div
            ref={headingRef}
            className={cn("max-w-2xl", facultySectionTitleMb, "md:mb-16")}
          >
            {header.eyebrow ? (
              <div className="inline-flex items-center gap-2 text-red-700 text-xs font-bold tracking-widest uppercase mb-4">
                <span className="w-6 h-px bg-red-700" />
                {header.eyebrow}
              </div>
            ) : null}
            {header.heading ? (
              <WordRevealHeading
                id="alumni-leadership-heading"
                text={header.heading}
                className={alumniSectionHeadingClass}
                ready={headingReady}
              />
            ) : null}
            {header.intro ? (
              <p className="text-stone-500 text-sm sm:text-base leading-relaxed">
                {header.intro}
              </p>
            ) : null}
          </div>
        ) : null}

        {leaders.length === 0 ? (
          <AlumniSectionEmptyState message="Leadership profiles will appear here once added in the admin panel." />
        ) : (
          <motion.div
            variants={alumniStaggerContainer}
            initial={reduceMotion ? false : "hidden"}
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8"
          >
            {leaders.map((leader, i) => (
              <motion.div
                key={leader.id}
                variants={alumniFadeUpVariants}
                className={cn(
                  "group bg-white rounded-3xl overflow-hidden shadow-sm border border-stone-100 hover:shadow-xl transition-all duration-300 flex flex-col",
                  i === 0 ? "md:col-span-2 md:flex-row" : "md:flex-row",
                )}
              >
                <div
                  className={cn(
                    "relative overflow-hidden flex-shrink-0 w-full",
                    i === 0
                      ? "h-56 md:h-auto md:w-56 lg:w-72"
                      : "h-48 md:h-auto md:w-48 lg:w-56",
                  )}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={leader.imageUrl}
                    alt={leader.name}
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-900/30 via-transparent to-transparent md:bg-gradient-to-r md:from-transparent md:to-transparent" />
                </div>

                <div
                  className={cn(
                    "flex flex-col justify-center min-w-0 p-5 sm:p-7",
                    i === 0 && "md:py-10",
                  )}
                >
                  <div className="text-red-700 text-xs font-bold tracking-widest uppercase mb-2">
                    {leader.department}
                  </div>
                  <h3
                    className={cn(
                      "font-serif font-bold text-stone-900 mb-1",
                      i === 0
                        ? "text-xl sm:text-2xl lg:text-3xl"
                        : "text-lg sm:text-xl",
                    )}
                  >
                    {leader.name}
                  </h3>
                  <p className="text-stone-500 text-sm font-medium mb-1">
                    {leader.designation}
                  </p>
                  {leader.graduationYear ? (
                    <p className="text-stone-400 text-xs font-medium mb-4">
                      Class of {leader.graduationYear}
                    </p>
                  ) : null}
                  <p className="text-stone-600 text-sm leading-relaxed mb-5 line-clamp-3">
                    {leader.bio}
                  </p>

                  {leader.linkedInUrl ? (
                    <Link
                      href={leader.linkedInUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-xs font-semibold text-red-700 hover:text-red-800 transition-colors"
                    >
                      <Linkedin size={14} />
                      View LinkedIn profile
                    </Link>
                  ) : null}
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>
    </section>
  );
}
