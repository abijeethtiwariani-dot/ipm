"use client";

import { useRef, type ReactNode } from "react";
import { motion, useInView } from "framer-motion";
import { cn } from "@/lib/utils";
import { useReducedMotion } from "@/components/about/useReducedMotion";
import {
  aboutNoiseTexture,
  admissionSectionPy,
  admissionWideContainer,
  scholarshipGlassCard,
  scholarshipGlassCardHover,
  scholarshipSectionBackgrounds,
  scholarshipSlideVariants,
  scholarshipStaggerContainer,
  aboutFadeUpVariants,
  aboutEyebrow,
} from "@/components/scholarships/scholarships-layout";

export {
  scholarshipGlassCard as alumniGlassCard,
  scholarshipGlassCardHover as alumniGlassCardHover,
  scholarshipSlideVariants as alumniSlideVariants,
  scholarshipStaggerContainer as alumniStaggerContainer,
  aboutFadeUpVariants as alumniFadeUpVariants,
  aboutEyebrow as alumniEyebrow,
};

export const alumniSectionHeadingClass =
  "text-3xl sm:text-4xl lg:text-5xl font-serif font-bold text-stone-900 leading-tight mb-4";

export const alumniSectionHeadingCenteredClass = "justify-center";

type AlumniSectionShellProps = {
  children: ReactNode;
  sectionIndex?: number;
  className?: string;
  containerClassName?: string;
  id?: string;
  ariaLabelledBy?: string;
  entry?: "fadeUp" | "fromLeft" | "fromRight";
};

export function AlumniSectionShell({
  children,
  sectionIndex = 0,
  className,
  containerClassName,
  id,
  ariaLabelledBy,
  entry = "fadeUp",
}: AlumniSectionShellProps) {
  const ref = useRef<HTMLElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-40px" });
  const reduceMotion = useReducedMotion();
  const show = isInView || reduceMotion;
  const bg =
    scholarshipSectionBackgrounds[
      sectionIndex % scholarshipSectionBackgrounds.length
    ];
  const variantKey =
    entry === "fromLeft"
      ? "fromLeft"
      : entry === "fromRight"
        ? "fromRight"
        : "fadeUp";

  return (
    <section
      ref={ref}
      id={id}
      className={cn("relative overflow-hidden", admissionSectionPy, className)}
      style={{ background: bg }}
      aria-labelledby={ariaLabelledBy}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 z-0 opacity-[0.035]"
        style={aboutNoiseTexture}
      />

      <div
        aria-hidden
        className="pointer-events-none absolute -left-24 top-16 z-0 h-72 w-72 rounded-full bg-red-200/30 blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -right-16 bottom-10 z-0 h-80 w-80 rounded-full bg-rose-200/25 blur-3xl"
      />

      <motion.div
        className={cn("relative z-[1]", admissionWideContainer, containerClassName)}
        initial={reduceMotion ? false : "hidden"}
        animate={show ? "visible" : "hidden"}
        variants={scholarshipSlideVariants[variantKey]}
      >
        {children}
      </motion.div>
    </section>
  );
}

export function AlumniSectionEmptyState({ message }: { message: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-border/80 bg-background/40 px-6 py-12 text-center">
      <p className="text-sm text-muted-foreground">{message}</p>
    </div>
  );
}
