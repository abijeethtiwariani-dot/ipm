"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import Image, { type StaticImageData } from "next/image";
import { ArrowRight } from "lucide-react";
import {
  ensureCampusLifeCardsMigrated,
  fetchCampusLifeCards,
} from "@/lib/cms";
import type { CampusLifeCard, CampusSectionKey } from "@/types/cms";
import { CAMPUS_SECTIONS } from "@/types/cms";
import { Skeleton } from "@/components/ui/skeleton";

export type CampusCardWithImage = {
  id?: string;
  title: string;
  description: string;
  link: string;
  linkText: string;
  imageUrl?: string;
  image?: StaticImageData;
};

type CampusLifeSectionsProps = {
  fallback: Record<CampusSectionKey, CampusCardWithImage[]>;
};

function resolveImage(card: CampusCardWithImage): string | StaticImageData {
  if (card.imageUrl) return card.imageUrl;
  if (card.image) return card.image;
  return "";
}

function SectionCards({
  title,
  cards,
}: {
  title: string;
  cards: CampusCardWithImage[];
}) {
  if (cards.length === 0) return null;

  return (
    <section className="py-16 md:py-20">
      <section className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-center text-foreground mb-12">
          {title}
        </h2>
        <section className="grid md:grid-cols-3 gap-8">
          {cards.map((card) => {
            const imageSrc = resolveImage(card);
            const isRemote =
              typeof imageSrc === "string" && imageSrc.startsWith("http");

            return (
              <article key={card.id ?? card.title} className="group">
                <section className="aspect-[4/3] rounded-lg overflow-hidden mb-4 relative bg-muted">
                  {imageSrc ? (
                    <Image
                      src={imageSrc}
                      alt={card.title}
                      fill
                      sizes="(min-width: 768px) 33vw, 100vw"
                      className="object-cover group-hover:scale-105 transition-transform duration-500"
                      unoptimized={isRemote}
                    />
                  ) : null}
                </section>
                <h3 className="text-lg font-heading font-bold text-foreground mb-2">
                  {card.title}
                </h3>
                <p className="site-card-desc mb-3">
                  {card.description}
                </p>
                <Link
                  href={card.link}
                  className="inline-flex items-center gap-1 text-sm text-primary font-medium hover:underline"
                >
                  {card.linkText}
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </article>
            );
          })}
        </section>
      </section>
    </section>
  );
}

function campusLifeCardToDisplay(card: CampusLifeCard): CampusCardWithImage {
  return {
    id: card.id,
    title: card.title,
    description: card.description,
    link: card.link,
    linkText: card.linkText,
    imageUrl: card.imageUrl,
  };
}

function fallbackToDisplay(
  fallback: CampusLifeSectionsProps["fallback"],
): Record<CampusSectionKey, CampusCardWithImage[]> {
  const result = {} as Record<CampusSectionKey, CampusCardWithImage[]>;
  for (const { key } of CAMPUS_SECTIONS) {
    result[key] = (fallback[key] ?? []).map((card, index) => ({
      ...card,
      id: card.id || `fallback-${key}-${index}`,
    }));
  }
  return result;
}

export function CampusLifeSections({ fallback }: CampusLifeSectionsProps) {
  const [cardsBySection, setCardsBySection] = useState<
    Record<CampusSectionKey, CampusCardWithImage[]>
  >(() => fallbackToDisplay(fallback));
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        await ensureCampusLifeCardsMigrated();
        const cards = await fetchCampusLifeCards();
        if (!cancelled && cards.length > 0) {
          const grouped = {} as Record<CampusSectionKey, CampusCardWithImage[]>;
          for (const { key } of CAMPUS_SECTIONS) {
            grouped[key] = cards
              .filter((c) => c.section === key)
              .map(campusLifeCardToDisplay);
          }
          setCardsBySection(grouped);
        } else if (!cancelled) {
          setCardsBySection(fallbackToDisplay(fallback));
        }
      } catch {
        if (!cancelled) setCardsBySection(fallbackToDisplay(fallback));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [fallback]);

  const sectionsToRender = useMemo(() => {
    return CAMPUS_SECTIONS.map((section) => ({
      ...section,
      cards: cardsBySection[section.key] ?? [],
    })).filter((section) => section.cards.length > 0);
  }, [cardsBySection]);

  if (loading) {
    return (
      <section className="py-16">
        <section className="container mx-auto px-4 space-y-8">
          <Skeleton className="h-10 w-64 mx-auto" />
          <section className="grid md:grid-cols-3 gap-8">
            <Skeleton className="h-64" />
            <Skeleton className="h-64" />
            <Skeleton className="h-64" />
          </section>
        </section>
      </section>
    );
  }

  if (sectionsToRender.length === 0) {
    return null;
  }

  return (
    <>
      {sectionsToRender.map((section, index) => (
        <section
          key={section.key}
          className={index === 1 ? "bg-muted/30" : undefined}
        >
          <SectionCards title={section.title} cards={section.cards} />
        </section>
      ))}
    </>
  );
}
