"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image, { type StaticImageData } from "next/image";
import { ArrowRight } from "lucide-react";
import {
  DEFAULT_CAMPUS_LIFE_GETTING_AROUND,
  fetchCampusLifeGettingAround,
} from "@/lib/cms";
import { shouldUnoptimizeCmsSrc } from "@/lib/cms-image-url";
import type { CampusLifeGettingAround } from "@/types/cms";
import { Skeleton } from "@/components/ui/skeleton";

type CampusLifeGettingAroundProps = {
  fallbackImage: StaticImageData;
};

export function CampusLifeGettingAroundSection({
  fallbackImage,
}: CampusLifeGettingAroundProps) {
  const [content, setContent] = useState<CampusLifeGettingAround | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await fetchCampusLifeGettingAround();
        if (!cancelled) setContent(data);
      } catch {
        if (!cancelled) {
          setContent({
            ...DEFAULT_CAMPUS_LIFE_GETTING_AROUND,
            updatedAt: undefined,
          });
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const section = content ?? {
    ...DEFAULT_CAMPUS_LIFE_GETTING_AROUND,
    updatedAt: undefined,
  };

  const imageSrc = section.imageUrl?.trim()
    ? section.imageUrl.trim()
    : fallbackImage;
  const links =
    section.links.filter((l) => l.label.trim() && l.href.trim()).length > 0
      ? section.links
      : DEFAULT_CAMPUS_LIFE_GETTING_AROUND.links;

  if (loading) {
    return (
      <section className="py-16 md:py-20 bg-muted/30">
        <div className="container mx-auto px-4 max-w-5xl space-y-8">
          <Skeleton className="h-10 w-64 mx-auto" />
          <Skeleton className="h-48 w-full rounded-lg" />
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 md:py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <h2 className="site-section-heading text-center text-foreground mb-12">
          {section.sectionHeading}
        </h2>
        <div className="grid md:grid-cols-2 gap-8 items-center max-w-5xl mx-auto">
          <div>
            <p className="site-section-intro mt-0 mb-6">{section.sectionIntro}</p>
            <div className="flex flex-col gap-2">
              {links.map((link) => (
                <Link
                  key={`${link.label}-${link.href}`}
                  href={link.href}
                  className="inline-flex items-center gap-1 text-sm text-primary font-medium hover:underline"
                >
                  {link.label}
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              ))}
            </div>
          </div>
          <div className="aspect-[16/9] rounded-lg overflow-hidden relative bg-muted">
            <Image
              src={imageSrc}
              alt={section.sectionHeading}
              fill
              sizes="(min-width: 1024px) 50vw, 100vw"
              className="object-cover"
              unoptimized={
                typeof imageSrc === "string" && shouldUnoptimizeCmsSrc(imageSrc)
              }
            />
          </div>
        </div>
      </div>
    </section>
  );
}
