"use client";

import { useEffect, useState } from "react";
import Image, { type StaticImageData } from "next/image";
import {
  DEFAULT_CAMPUS_LIFE_PAGE_BANNER,
  fetchCampusLifePageBanner,
} from "@/lib/cms";
import { shouldUnoptimizeCmsSrc } from "@/lib/cms-image-url";
import type { CampusLifePageBanner } from "@/types/cms";
import { Skeleton } from "@/components/ui/skeleton";

type CampusLifeBannerProps = {
  fallbackPrimaryImage: StaticImageData;
  fallbackSecondaryImage: StaticImageData;
};

function resolveImageSrc(
  url: string | undefined,
  fallback: StaticImageData,
): string | StaticImageData {
  const trimmed = url?.trim();
  return trimmed ? trimmed : fallback;
}

export function CampusLifeBanner({
  fallbackPrimaryImage,
  fallbackSecondaryImage,
}: CampusLifeBannerProps) {
  const [banner, setBanner] = useState<CampusLifePageBanner | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await fetchCampusLifePageBanner();
        if (!cancelled) setBanner(data);
      } catch {
        if (!cancelled) {
          setBanner({
            ...DEFAULT_CAMPUS_LIFE_PAGE_BANNER,
            updatedAt: undefined,
          });
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const content = banner ?? {
    ...DEFAULT_CAMPUS_LIFE_PAGE_BANNER,
    updatedAt: undefined,
  };

  const primarySrc = resolveImageSrc(
    content.primaryImageUrl,
    fallbackPrimaryImage,
  );
  const secondarySrc = resolveImageSrc(
    content.secondaryImageUrl,
    fallbackSecondaryImage,
  );
  const stats =
    content.stats.filter((s) => s.value.trim() && s.label.trim()).length >= 1
      ? content.stats
      : DEFAULT_CAMPUS_LIFE_PAGE_BANNER.stats;

  if (loading) {
    return (
      <section className="pt-6 text-center md:pt-8">
        <div className="container mx-auto px-4 mb-8 space-y-4">
          <Skeleton className="h-12 w-64 mx-auto" />
          <Skeleton className="h-6 w-full max-w-2xl mx-auto" />
        </div>
        <div className="container mx-auto px-4">
          <Skeleton className="h-64 max-w-5xl mx-auto rounded-lg" />
        </div>
      </section>
    );
  }

  return (
    <section className="pt-6 text-center md:pt-8">
      <div className="container mx-auto px-4 mb-8">
        <h1 className="text-4xl md:text-5xl font-heading font-bold text-foreground mb-4">
          {content.pageTitle}
        </h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          {content.pageIntro}
        </p>
      </div>

      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-5xl mx-auto">
          <div className="md:col-span-2 aspect-[16/9] rounded-lg overflow-hidden relative bg-muted">
            <Image
              src={primarySrc}
              alt={content.pageTitle}
              fill
              priority
              sizes="(min-width: 768px) 66vw, 100vw"
              className="object-cover"
              unoptimized={
                typeof primarySrc === "string" &&
                shouldUnoptimizeCmsSrc(primarySrc)
              }
            />
          </div>
          <div className="aspect-[4/3] md:aspect-auto rounded-lg overflow-hidden relative bg-muted min-h-[200px] md:min-h-0">
            <Image
              src={secondarySrc}
              alt="Campus activities"
              fill
              priority
              sizes="(min-width: 768px) 33vw, 100vw"
              className="object-cover"
              unoptimized={
                typeof secondarySrc === "string" &&
                shouldUnoptimizeCmsSrc(secondarySrc)
              }
            />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-10">
        <div className="flex flex-wrap justify-center gap-12 md:gap-20">
          {stats.map((stat) => (
            <div key={`${stat.value}-${stat.label}`} className="text-center">
              <p className="site-stat-value text-primary">{stat.value}</p>
              <p className="site-stat-label mt-1">{stat.label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
