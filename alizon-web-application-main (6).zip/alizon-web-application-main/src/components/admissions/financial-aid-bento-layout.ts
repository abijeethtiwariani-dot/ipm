import type { AdmissionPageFinancialAidCardCms } from "@/types/cms";

/** Grid placement for the 5-card bento at lg+ (matches static admissions layout). */
export const BENTO_GRID_CLASSES = [
  "md:col-span-2 lg:col-span-1 lg:row-span-2 lg:row-start-1 lg:col-start-1 min-h-[380px] lg:min-h-[460px]",
  "lg:col-start-2 lg:row-start-1 min-h-[200px]",
  "lg:col-start-3 lg:row-start-1 min-h-[200px]",
  "lg:col-start-2 lg:row-start-2 min-h-[200px]",
  "lg:col-start-3 lg:row-start-2 min-h-[200px]",
] as const;

export function getBentoGridClassName(index: number): string {
  return BENTO_GRID_CLASSES[index] ?? "min-h-[200px]";
}

/**
 * Order cards for the bento grid by kind (not CMS card id).
 * Slot 0: featured | 1–3: glass, image, glass | 4: cta
 */
export function sortFinancialAidBentoCards(
  cards: AdmissionPageFinancialAidCardCms[],
): AdmissionPageFinancialAidCardCms[] {
  const featured = cards.find((c) => c.kind === "featured");
  const image = cards.find((c) => c.kind === "image");
  const cta = cards.find((c) => c.kind === "cta");
  const glasses = cards.filter((c) => c.kind === "glass");
  const used = new Set(
    [featured, glasses[0], image, glasses[1], cta].filter(Boolean),
  );
  const overflow = cards.filter((c) => !used.has(c));

  return [
    featured,
    glasses[0],
    image,
    glasses[1],
    cta,
    ...overflow,
  ].filter((c): c is AdmissionPageFinancialAidCardCms => c !== undefined);
}
