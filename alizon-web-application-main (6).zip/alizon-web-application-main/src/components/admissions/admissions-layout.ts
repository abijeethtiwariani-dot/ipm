export const admissionSectionPy = "py-12 md:py-14 lg:py-[72px]";

export const admissionContainer = "mx-auto max-w-7xl px-6 lg:px-8";

/** Wider container for Undergraduates / Graduate Studies two-column layouts */
export const admissionWideContainer =
  "mx-auto max-w-[1400px] px-6 lg:px-8 xl:px-10";

export const admissionSectionTitle =
  "site-section-heading text-foreground";

export const admissionSectionTitleMb = "mb-8 md:mb-10";

export const admissionBodyText =
  "site-section-intro mx-auto text-left max-w-[65ch] mt-0";

export const admissionCardGlass =
  "rounded-[20px] border border-white/40 bg-white/75 backdrop-blur-[10px] shadow-[0_8px_30px_rgba(0,0,0,0.06)]";

export const admissionCardHover =
  "hover:-translate-y-1.5 hover:border-primary/25 hover:shadow-[0_15px_40px_rgba(177,4,14,0.12)]";

export const admissionFeatureCardTitle =
  "site-card-title text-foreground";

export const admissionFeatureCardBody =
  "site-card-desc line-clamp-4";

export const admissionFeatureCardLink =
  "site-card-link mt-4 inline-flex items-center gap-2 text-primary transition-[gap,color] duration-300 group-hover/card:gap-2.5 group-hover/card:text-primary-dark";
