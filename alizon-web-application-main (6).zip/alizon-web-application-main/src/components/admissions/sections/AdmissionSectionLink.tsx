import Link from "next/link";
import type { AdmissionPageLinkItemCms } from "@/types/cms";
import {
  admissionCardGlass,
  admissionCardHover,
} from "@/components/admissions/admissions-layout";
import { cn } from "@/lib/utils";

function isExternalLink(href: string): boolean {
  return /^https?:\/\//i.test(href);
}

export function AdmissionSectionLink({
  item,
  variant = "plain",
}: {
  item: AdmissionPageLinkItemCms;
  variant?: "plain" | "card";
}) {
  const linkClassName =
    "text-[0.8125rem] font-semibold text-primary transition-colors hover:text-primary-dark";

  const content = (
    <>
      <h3
        className={cn(
          "site-card-title text-foreground",
          variant === "card" ? "" : "mb-2",
        )}
      >
        {item.title}
      </h3>
      {item.body ? (
        <p
          className={cn(
            "site-card-desc",
            variant === "card"
              ? "mt-2 line-clamp-4"
              : "mb-2",
          )}
        >
          {item.body}
        </p>
      ) : null}
      {isExternalLink(item.href) ? (
        <a
          href={item.href}
          target="_blank"
          rel="noopener noreferrer"
          className={cn(linkClassName, variant === "card" && "mt-4 inline-block")}
        >
          {item.linkLabel} ›
        </a>
      ) : (
        <Link
          href={item.href}
          className={cn(linkClassName, variant === "card" && "mt-4 inline-block")}
        >
          {item.linkLabel} ›
        </Link>
      )}
    </>
  );

  if (variant === "card") {
    return (
      <article
        className={cn(
          admissionCardGlass,
          admissionCardHover,
          "h-full p-6 transition-all duration-300",
        )}
      >
        {content}
      </article>
    );
  }

  return <div>{content}</div>;
}
