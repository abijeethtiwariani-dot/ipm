"use client";

import { useEffect, useState } from "react";
import { PageBanner } from "@/components/layout/PageBanner";
import { fetchAdmissionPageHeroContent } from "@/lib/admission-page-cms";
import type { AdmissionPageHeroContent } from "@/types/cms";
import { AdmissionHeroSectionSkeleton } from "@/components/admissions/sections/AdmissionSectionSkeletons";

export function AdmissionHeroSection() {
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState<AdmissionPageHeroContent | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await fetchAdmissionPageHeroContent();
        if (!cancelled) setContent(data);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) return <AdmissionHeroSectionSkeleton />;
  if (!content) return null;

  return (
    <div className="mb-10">
      <PageBanner
        title={content.title}
        subtitle={content.subtitle}
        image={content.heroImageUrl}
        mobileImage={content.mobileHeroImageUrl}
      />
    </div>
  );
}
