"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import type { AdmissionPageLinkItemCms } from "@/types/cms";
import {
  admissionCardGlass,
  admissionCardHover,
  admissionFeatureCardBody,
  admissionFeatureCardLink,
  admissionFeatureCardTitle,
} from "@/components/admissions/admissions-layout";
import { cn } from "@/lib/utils";

function isExternalLink(href: string): boolean {
  return /^https?:\/\//i.test(href);
}

function useReducedMotion() {
  const [reduceMotion, setReduceMotion] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const apply = () => setReduceMotion(mq.matches);
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);

  return reduceMotion;
}

const blockVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: (index: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      delay: 0.1 + index * 0.12,
      ease: [0.22, 1, 0.36, 1] as const,
    },
  }),
};

const cardTransition = {
  duration: 0.4,
  ease: [0.16, 1, 0.3, 1] as const,
};

const linkClassName = cn(
  admissionFeatureCardLink,
  "group-hover/card:gap-2.5",
);

export function AdmissionUndergradContentBlock({
  item,
  index,
  isVisible,
  isHovered,
  isDimmed,
  onHoverStart,
  onHoverEnd,
}: {
  item: AdmissionPageLinkItemCms;
  index: number;
  isVisible: boolean;
  isHovered: boolean;
  isDimmed: boolean;
  onHoverStart: () => void;
  onHoverEnd: () => void;
}) {
  const reduceMotion = useReducedMotion();
  const effectiveVisible = isVisible || reduceMotion;
  const interactionActive = isHovered || isDimmed;

  const linkContent = (
    <>
      <span className="relative">
        {item.linkLabel}
        <span className="absolute bottom-0 left-0 h-px w-0 bg-primary transition-all duration-300 group-hover/card:w-full" />
      </span>
      <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover/card:translate-x-1.5" />
    </>
  );

  return (
    <motion.article
      custom={index}
      initial={reduceMotion ? false : "hidden"}
      animate={
        !effectiveVisible
          ? "hidden"
          : interactionActive
            ? reduceMotion
              ? {
                  opacity: isDimmed ? 0.85 : 1,
                  y: 0,
                  scale: 1,
                  filter: "blur(0px)",
                }
              : {
                  opacity: isDimmed ? 0.85 : 1,
                  y: isHovered ? -6 : 0,
                  scale: isHovered ? 1.01 : isDimmed ? 0.98 : 1,
                  filter: isDimmed ? "blur(1px)" : "blur(0px)",
                }
            : "visible"
      }
      variants={blockVariants}
      transition={cardTransition}
      onHoverStart={onHoverStart}
      onHoverEnd={onHoverEnd}
      className={cn(
        "group/card relative overflow-hidden p-6 transition-[background-color,border-color,box-shadow,backdrop-filter] duration-[400ms] ease-[cubic-bezier(0.16,1,0.3,1)]",
        admissionCardGlass,
        admissionCardHover,
        "hover:bg-white/[0.92] hover:backdrop-blur-[20px] hover:border-primary/35 hover:shadow-[0_0_0_1px_rgba(177,4,14,0.15),0_15px_40px_rgba(177,4,14,0.12),0_8px_25px_rgba(0,0,0,0.08)]",
      )}
    >
      <div
        aria-hidden
        className="pointer-events-none absolute left-0 top-0 z-[1] h-0 w-1 rounded-full bg-gradient-to-b from-primary to-primary-light transition-[height] duration-[400ms] ease-[cubic-bezier(0.16,1,0.3,1)] group-hover/card:h-full"
      />

      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 z-[1] bg-gradient-to-br from-white/20 via-transparent to-transparent opacity-0 transition-opacity duration-[400ms] group-hover/card:opacity-100"
      />

      <div
        aria-hidden
        className={cn(
          "pointer-events-none absolute inset-0 z-[2] bg-gradient-to-r from-transparent via-white/25 to-transparent motion-reduce:hidden",
          "group-hover/card:animate-admission-card-shimmer",
        )}
      />

      <div className="relative z-10">
        <h3
          className={cn(
            admissionFeatureCardTitle,
            "transition-colors duration-300 group-hover/card:text-primary",
          )}
        >
          {item.title}
        </h3>
        <p className={admissionFeatureCardBody}>{item.body}</p>
        {isExternalLink(item.href) ? (
          <a
            href={item.href}
            target="_blank"
            rel="noopener noreferrer"
            className={linkClassName}
          >
            {linkContent}
          </a>
        ) : (
          <Link href={item.href} className={linkClassName}>
            {linkContent}
          </Link>
        )}
      </div>
    </motion.article>
  );
}
