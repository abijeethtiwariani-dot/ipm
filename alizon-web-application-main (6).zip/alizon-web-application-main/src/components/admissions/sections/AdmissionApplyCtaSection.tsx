"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { AdmissionApplicationDialog } from "@/components/admissions/AdmissionApplicationDialog";
import type { AdmissionPageApplyCtaContent } from "@/types/cms";
import { fetchAdmissionPageApplyCtaContent } from "@/lib/admission-page-cms";
import { Button } from "@/components/ui/button";
import { AdmissionApplyCtaSectionSkeleton } from "@/components/admissions/sections/AdmissionSectionSkeletons";

export function AdmissionApplyCtaSection() {
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState<AdmissionPageApplyCtaContent | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await fetchAdmissionPageApplyCtaContent();
        if (!cancelled) setContent(data);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) return <AdmissionApplyCtaSectionSkeleton />;
  if (!content) return null;

  return (
    <section className="bg-primary py-12 text-primary-foreground md:py-14 lg:py-16">
      <div className="container mx-auto px-4 text-center">
        <h2 className="mb-4 font-heading text-2xl font-bold md:text-3xl">
          {content.title}
        </h2>
        <p className="text-primary-foreground/80 max-w-xl mx-auto mb-8">
          {content.description}
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <AdmissionApplicationDialog
            trigger={
              <Button
                size="lg"
                className="bg-background text-foreground hover:bg-background/90"
              >
                Start Application
                <ArrowRight className="w-5 h-5" />
              </Button>
            }
          />
          {content.contactHref ? (
            <Button size="lg" variant="hero-outline" asChild>
              <Link href={content.contactHref}>Need Help? Contact Us</Link>
            </Button>
          ) : null}
        </div>
      </div>
    </section>
  );
}
