"use client";

import { useEffect, useState } from "react";
import type { AdmissionPageLinkItemCms } from "@/types/cms";
import { fetchAdmissionPageOtherProgramsContent } from "@/lib/admission-page-cms";
import { AdmissionSectionLink } from "@/components/admissions/sections/AdmissionSectionLink";
import {
  admissionContainer,
  admissionSectionPy,
  admissionSectionTitle,
  admissionSectionTitleMb,
} from "@/components/admissions/admissions-layout";
import { AdmissionOtherProgramsSectionSkeleton } from "@/components/admissions/sections/AdmissionSectionSkeletons";
import { cn } from "@/lib/utils";

export function AdmissionOtherProgramsSection() {
  const [loading, setLoading] = useState(true);
  const [items, setItems] = useState<AdmissionPageLinkItemCms[]>([]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await fetchAdmissionPageOtherProgramsContent();
        if (!cancelled && data) setItems(data.items);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) return <AdmissionOtherProgramsSectionSkeleton />;
  if (items.length === 0) return null;

  return (
    <section className={cn(admissionSectionPy)}>
      <div className={admissionContainer}>
        <h2
          className={cn(
            "text-center",
            admissionSectionTitle,
            admissionSectionTitleMb,
          )}
        >
          Applying To Other Programs
        </h2>
        <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
          {items.map((item, index) => (
            <AdmissionSectionLink
              key={`${item.title}-${index}`}
              item={item}
              variant="card"
            />
          ))}
        </div>
      </div>
    </section>
  );
}
