"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import { motion, useInView } from "framer-motion";
import type { AdmissionPageGradContent } from "@/types/cms";
import { fetchAdmissionPageGradContent } from "@/lib/admission-page-cms";
import { cn } from "@/lib/utils";
import { AdmissionUndergradContentBlock } from "@/components/admissions/sections/AdmissionUndergradContentBlock";
import {
  admissionSectionPy,
  admissionSectionTitle,
  admissionSectionTitleMb,
  admissionWideContainer,
} from "@/components/admissions/admissions-layout";
import { AdmissionUndergradSectionSkeleton } from "@/components/admissions/sections/AdmissionSectionSkeletons";

const sectionVariants = {
  hidden: { opacity: 0, y: 32 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] as const },
  },
};

const imageFloat = {
  y: [0, -8, 0],
  transition: {
    duration: 6,
    repeat: Infinity,
    ease: "easeInOut" as const,
  },
};

export function AdmissionGraduateStudiesSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: "-40px" });
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState<AdmissionPageGradContent | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await fetchAdmissionPageGradContent();
        if (!cancelled) setContent(data);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) return <AdmissionUndergradSectionSkeleton />;
  if (!content) return null;

  // Reveal once CMS content is ready; async mount can miss useInView with once:true
  const showContent = Boolean(content) && (isInView || !loading);

  return (
    <section
      ref={sectionRef}
      className={cn("relative overflow-hidden", admissionSectionPy)}
      style={{
        background: "linear-gradient(135deg, #f8fafc 0%, #eef4ff 100%)",
      }}
      aria-labelledby="admission-grad-heading"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 z-0 opacity-[0.035]"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")",
        }}
      />

      <div
        aria-hidden
        className="pointer-events-none absolute -left-24 top-16 z-0 h-72 w-72 rounded-full bg-red-200/30 blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -right-16 bottom-10 z-0 h-80 w-80 rounded-full bg-rose-200/25 blur-3xl"
      />

      <div className={cn("relative z-[1]", admissionWideContainer)}>
        <motion.h2
          id="admission-grad-heading"
          initial={false}
          animate={showContent ? "visible" : "hidden"}
          variants={sectionVariants}
          className={cn(
            "text-center",
            admissionSectionTitle,
            admissionSectionTitleMb,
          )}
        >
          Graduate Studies
        </motion.h2>

        <div className="relative flex flex-col gap-8 lg:flex-row lg:items-center lg:gap-0">
          <motion.div
            initial={false}
            animate={
              showContent ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }
            }
            transition={{
              duration: 0.7,
              delay: 0.2,
              ease: [0.22, 1, 0.36, 1] as const,
            }}
            className="relative order-1 w-full lg:z-20 lg:w-[380px] lg:shrink-0 lg:-mr-[50px] xl:w-[420px] xl:-mr-[60px]"
          >
            <motion.div
              animate={imageFloat}
              className="group relative h-[420px] overflow-visible rounded-[24px] border border-white/35 bg-white/20 p-2 shadow-[0_30px_80px_rgba(0,0,0,0.15)] backdrop-blur-sm transition-shadow duration-700 hover:shadow-[0_36px_90px_rgba(0,0,0,0.18)] lg:-rotate-[1.5deg]"
            >
              <div
                aria-hidden
                className="pointer-events-none absolute inset-0 z-[1] rounded-[inherit] bg-gradient-to-br from-white/35 via-white/10 to-transparent"
              />
              <div className="relative h-full w-full overflow-hidden rounded-[20px]">
                <Image
                  src={content.imageUrl}
                  alt={content.imageAlt || "Graduate student"}
                  fill
                  className="object-cover object-center transition-transform duration-500 ease-out group-hover:scale-[1.03]"
                  sizes="(max-width: 1024px) 100vw, 420px"
                  unoptimized={content.imageUrl.startsWith("http")}
                />
              </div>

              {content.floatingStats.length > 0 ? (
                <motion.div
                  animate={imageFloat}
                  className="absolute bottom-5 left-5 z-30 rounded-[20px] border border-white/40 bg-white/75 px-4 py-3 shadow-[0_12px_40px_rgba(15,23,42,0.12)] backdrop-blur-[12px]"
                >
                  <div className="flex flex-col gap-3 sm:flex-row sm:gap-6">
                    {content.floatingStats.map((stat) => (
                      <div key={stat.label}>
                        <p className="font-sans text-base font-bold text-foreground md:text-lg">
                          {stat.value}
                        </p>
                        <p className="font-sans text-xs font-medium text-muted-foreground md:text-sm">
                          {stat.label}
                        </p>
                      </div>
                    ))}
                  </div>
                </motion.div>
              ) : null}
            </motion.div>
          </motion.div>

          <div className="relative order-2 z-10 min-w-0 flex-1 space-y-4 rounded-[20px] border border-white/40 bg-white/65 p-6 shadow-[0_20px_60px_rgba(15,23,42,0.08)] backdrop-blur-[20px] lg:p-8 lg:pl-[120px]">
            {content.items.map((item, index) => (
              <AdmissionUndergradContentBlock
                key={`${item.title}-${index}`}
                item={item}
                index={index}
                isVisible={showContent}
                isHovered={hoveredIndex === index}
                isDimmed={hoveredIndex !== null && hoveredIndex !== index}
                onHoverStart={() => setHoveredIndex(index)}
                onHoverEnd={() => setHoveredIndex(null)}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
