import { Skeleton } from "@/components/ui/skeleton";
import {
  admissionContainer,
  admissionSectionPy,
  admissionWideContainer,
} from "@/components/admissions/admissions-layout";
import { cn } from "@/lib/utils";

export function AdmissionHeroSectionSkeleton() {
  return (
    <div className="mb-10">
      <Skeleton className="aspect-[21/9] w-full max-w-6xl mx-auto rounded-lg" />
    </div>
  );
}

export function AdmissionStatsSectionSkeleton() {
  return (
    <section className={cn(admissionSectionPy, admissionContainer)}>
      <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
        {[0, 1, 2].map((i) => (
          <div key={i} className="text-center space-y-3 py-6">
            <Skeleton className="h-10 w-32 mx-auto" />
            <Skeleton className="h-4 w-40 mx-auto" />
          </div>
        ))}
      </div>
    </section>
  );
}

export function AdmissionUndergradSectionSkeleton() {
  return (
    <section className={cn("relative overflow-hidden", admissionSectionPy)}>
      <div className={cn(admissionWideContainer, "space-y-8")}>
        <Skeleton className="h-10 w-48 mx-auto" />
        <div className="flex flex-col gap-8 lg:flex-row lg:items-center">
          <div className="flex-1 space-y-4 rounded-[20px] p-6 border border-border">
            {[0, 1, 2].map((i) => (
              <div key={i} className="space-y-2">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-16 w-full" />
              </div>
            ))}
          </div>
          <Skeleton className="h-[420px] w-full lg:w-[380px] rounded-[24px] shrink-0" />
        </div>
      </div>
    </section>
  );
}

export function AdmissionFinancialAidSectionSkeleton() {
  return (
    <section className={cn("relative overflow-hidden", admissionSectionPy)}>
      <div className={cn(admissionContainer, "space-y-10")}>
        <div className="text-center space-y-4">
          <Skeleton className="h-10 w-56 mx-auto" />
          <Skeleton className="h-4 w-96 max-w-full mx-auto" />
        </div>
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3">
          <Skeleton className="min-h-[380px] md:col-span-2 lg:col-span-1 lg:row-span-2 rounded-[20px]" />
          <Skeleton className="min-h-[200px] rounded-[20px]" />
          <Skeleton className="min-h-[200px] rounded-[20px]" />
          <Skeleton className="min-h-[200px] rounded-[20px]" />
          <Skeleton className="min-h-[200px] rounded-[20px]" />
        </div>
      </div>
    </section>
  );
}

export function AdmissionOtherProgramsSectionSkeleton() {
  return (
    <section className={cn(admissionSectionPy, admissionContainer)}>
      <Skeleton className="h-10 w-64 mx-auto mb-10" />
      <div className="grid gap-6 md:grid-cols-3">
        {[0, 1, 2].map((i) => (
          <Skeleton key={i} className="h-64 rounded-[20px]" />
        ))}
      </div>
    </section>
  );
}

export function AdmissionApplyCtaSectionSkeleton() {
  return (
    <section className={cn(admissionSectionPy, admissionContainer)}>
      <div className="text-center max-w-xl mx-auto space-y-4">
        <Skeleton className="h-10 w-72 mx-auto" />
        <Skeleton className="h-20 w-full" />
        <div className="flex justify-center gap-4 pt-4">
          <Skeleton className="h-12 w-36" />
          <Skeleton className="h-12 w-40" />
        </div>
      </div>
    </section>
  );
}
