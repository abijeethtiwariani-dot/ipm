"use client";

import { useEffect, useState } from "react";
import CountUp from "react-countup";
import { motion } from "framer-motion";
import type { AdmissionPageStatCms } from "@/types/cms";
import { fetchAdmissionPageStatsContent } from "@/lib/admission-page-cms";
import { admissionContainer } from "@/components/admissions/admissions-layout";
import { AdmissionStatsSectionSkeleton } from "@/components/admissions/sections/AdmissionSectionSkeletons";
import { cn } from "@/lib/utils";

function useReducedMotion() {
  const [reduceMotion, setReduceMotion] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const apply = () => setReduceMotion(mq.matches);
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);

  return reduceMotion;
}

function AdmissionCounterValue({
  stat,
  isInView,
  reduceMotion,
}: {
  stat: AdmissionPageStatCms;
  isInView: boolean;
  reduceMotion: boolean;
}) {
  if (reduceMotion || !stat.counterEnd) {
    return <span>{stat.value}</span>;
  }

  if (!isInView) {
    return <span>0{stat.counterSuffix ?? ""}</span>;
  }

  return (
    <CountUp
      start={0}
      end={stat.counterEnd}
      duration={2.5}
      separator=","
      suffix={stat.counterSuffix ?? ""}
      useEasing
      easingFn={(t, b, c, d) => {
        const progress = t / d;
        return c * (1 - Math.pow(1 - progress, 3)) + b;
      }}
    />
  );
}

function AdmissionFeaturedValue({
  stat,
  isInView,
  reduceMotion,
}: {
  stat: AdmissionPageStatCms;
  isInView: boolean;
  reduceMotion: boolean;
}) {
  if (reduceMotion) {
    return (
      <>
        <div className="font-heading text-3xl font-bold text-[#1a1a1a] md:text-4xl">
          {stat.value}
        </div>
        <p className="mt-3 text-sm text-[#6b6b6b] md:text-base">{stat.label}</p>
      </>
    );
  }

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 24, scale: 0.96, letterSpacing: "0.02em" }}
        animate={
          isInView
            ? {
                opacity: 1,
                y: 0,
                scale: 1,
                letterSpacing: "0em",
              }
            : { opacity: 0, y: 24, scale: 0.96, letterSpacing: "0.02em" }
        }
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="font-heading text-3xl font-bold text-[#1a1a1a] md:text-4xl"
      >
        {stat.value}
      </motion.div>
      <motion.p
        initial={{ opacity: 0, y: 16 }}
        animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 16 }}
        transition={{ duration: 0.8, ease: "easeOut", delay: 0.3 }}
        className="mt-3 text-sm text-[#6b6b6b] md:text-base"
      >
        {stat.label}
      </motion.p>
    </>
  );
}

function AdmissionStatCard({
  stat,
  isInView,
  reduceMotion,
}: {
  stat: AdmissionPageStatCms;
  isInView: boolean;
  reduceMotion: boolean;
}) {
  const isFeatured = stat.kind === "featured";

  return (
    <article
      className={cn(
        "rounded-[20px] border border-[#e6e6e6] bg-white p-6 text-center shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-all duration-[400ms] ease-[cubic-bezier(0.16,1,0.3,1)]",
        !reduceMotion &&
          "hover:-translate-y-1.5 hover:border-primary hover:shadow-[0_0_0_1px_rgba(177,4,14,0.15),0_15px_40px_rgba(177,4,14,0.12),0_8px_25px_rgba(0,0,0,0.08)]",
      )}
    >
      {isFeatured ? (
        <AdmissionFeaturedValue
          stat={stat}
          isInView={isInView}
          reduceMotion={reduceMotion}
        />
      ) : (
        <>
          <div className="font-heading text-3xl font-bold text-[#1a1a1a] md:text-4xl">
            <AdmissionCounterValue
              stat={stat}
              isInView={isInView}
              reduceMotion={reduceMotion}
            />
          </div>
          <p className="mt-3 text-sm text-[#6b6b6b] md:text-base">{stat.label}</p>
        </>
      )}

      <div
        aria-hidden
        className="mx-auto mt-4 h-0.5 w-10 rounded-full bg-primary"
      />
    </article>
  );
}

export function AdmissionStatsSection() {
  const reduceMotion = useReducedMotion();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<AdmissionPageStatCms[]>([]);
  const [hasAnimated, setHasAnimated] = useState(reduceMotion);

  useEffect(() => {
    if (reduceMotion) setHasAnimated(true);
  }, [reduceMotion]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await fetchAdmissionPageStatsContent();
        if (!cancelled && data) setStats(data.stats);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) return <AdmissionStatsSectionSkeleton />;
  if (stats.length === 0) return null;

  return (
    <motion.section
      initial={reduceMotion ? false : { opacity: 0, y: 40 }}
      whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-80px" }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      onViewportEnter={() => setHasAnimated(true)}
      className="border-t border-[#e6e6e6] pt-5 pb-12 md:pb-14 lg:pb-[72px]"
      style={{
        background:
          "linear-gradient(180deg, rgba(177,4,14,0.02) 0%, #ffffff 100%)",
      }}
      aria-label="Admissions statistics"
    >
      <div className={admissionContainer}>
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3 lg:gap-6">
          {stats.map((stat) => (
            <AdmissionStatCard
              key={`${stat.label}-${stat.value}`}
              stat={stat}
              isInView={hasAnimated}
              reduceMotion={reduceMotion}
            />
          ))}
        </div>
      </div>
    </motion.section>
  );
}
