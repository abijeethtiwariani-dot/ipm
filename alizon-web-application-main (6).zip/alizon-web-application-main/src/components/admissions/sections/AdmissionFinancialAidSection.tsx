"use client";

import { useEffect, useRef, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import CountUp from "react-countup";
import { motion, useInView } from "framer-motion";
import {
  ArrowRight,
  DollarSign,
  GraduationCap,
  Home,
  type LucideIcon,
} from "lucide-react";
import type {
  AdmissionPageFinancialAidCardCms,
  AdmissionPageFinancialAidContent,
} from "@/types/cms";
import { fetchAdmissionPageFinancialAidContent } from "@/lib/admission-page-cms";
import {
  getBentoGridClassName,
  sortFinancialAidBentoCards,
} from "@/components/admissions/financial-aid-bento-layout";
import { AdmissionFinancialAidSectionSkeleton } from "@/components/admissions/sections/AdmissionSectionSkeletons";
import {
  admissionBodyText,
  admissionCardGlass,
  admissionCardHover,
  admissionContainer,
  admissionSectionPy,
  admissionSectionTitle,
  admissionSectionTitleMb,
} from "@/components/admissions/admissions-layout";
import { cn } from "@/lib/utils";

const ICON_MAP: Record<
  NonNullable<AdmissionPageFinancialAidCardCms["icon"]>,
  LucideIcon
> = {
  graduation: GraduationCap,
  dollar: DollarSign,
  home: Home,
};

function useReducedMotion() {
  const [reduceMotion, setReduceMotion] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const apply = () => setReduceMotion(mq.matches);
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);

  return reduceMotion;
}

const glassCardBase = cn(
  admissionCardGlass,
  "transition-all duration-[400ms] ease-[cubic-bezier(0.16,1,0.3,1)]",
);

const glassCardHover = cn(
  admissionCardHover,
  "hover:bg-white/85 hover:backdrop-blur-[24px] hover:border-primary/35 hover:shadow-[0_0_0_1px_rgba(177,4,14,0.15),0_15px_40px_rgba(177,4,14,0.12),0_8px_25px_rgba(0,0,0,0.08)]",
);

function FeaturedCounter({
  end,
  suffix,
  counterKey,
  isVisible,
  reduceMotion,
}: {
  end: number;
  suffix: string;
  counterKey: string;
  isVisible: boolean;
  reduceMotion: boolean;
}) {
  if (reduceMotion) {
    return (
      <span>
        {end}
        {suffix}
      </span>
    );
  }

  if (!isVisible) {
    return <span>0{suffix}</span>;
  }

  return (
    <CountUp
      key={counterKey}
      start={0}
      end={end}
      duration={2.5}
      suffix={suffix}
      useEasing
      easingFn={(t, b, c, d) => {
        const progress = t / d;
        return c * (1 - Math.pow(1 - progress, 3)) + b;
      }}
    />
  );
}

function BentoCard({
  card,
  index,
  gridClassName,
  isInView,
  counterVisible,
  reduceMotion,
}: {
  card: AdmissionPageFinancialAidCardCms;
  index: number;
  gridClassName: string;
  isInView: boolean;
  counterVisible: boolean;
  reduceMotion: boolean;
}) {
  const hoverClasses = reduceMotion ? "" : glassCardHover;

  if (card.kind === "featured" && card.imageUrl) {
    const Icon = card.icon ? ICON_MAP[card.icon] : GraduationCap;

    return (
      <motion.article
        initial={reduceMotion ? false : { opacity: 0, y: 40 }}
        whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-40px" }}
        transition={{ duration: 0.8, ease: "easeOut", delay: index * 0.1 }}
        className={cn(
          "group relative h-full w-full overflow-hidden rounded-[20px]",
          gridClassName,
          !reduceMotion && hoverClasses,
        )}
      >
        <Image
          src={card.imageUrl}
          alt={card.imageAlt || card.title}
          fill
          className="object-cover transition-transform duration-700 ease-out group-hover:scale-105"
          sizes="(min-width: 1024px) 33vw, 100vw"
          unoptimized={card.imageUrl.startsWith("http")}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/20" />

        <div className="absolute inset-x-0 bottom-0 p-5">
          <div className="rounded-2xl border border-white/20 bg-white/10 p-5 backdrop-blur-xl">
            <div className="flex items-start gap-3">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-white/15 text-white backdrop-blur-sm">
                <Icon className="h-5 w-5" aria-hidden />
              </div>
              <div>
                <p className="font-heading text-[3.5rem] font-bold leading-none text-white">
                  <FeaturedCounter
                    end={card.counterEnd ?? 0}
                    suffix={card.counterSuffix ?? ""}
                    counterKey={`${card.id}-${card.counterEnd ?? 0}-${card.counterSuffix ?? ""}`}
                    isVisible={counterVisible}
                    reduceMotion={reduceMotion}
                  />
                </p>
                <p className="mt-2 font-heading text-xl font-semibold text-white">
                  {card.title}
                </p>
                <p className="mt-2 font-sans text-sm leading-[1.7] text-white/80">
                  {card.description}
                </p>
              </div>
            </div>
          </div>
        </div>
      </motion.article>
    );
  }

  if (card.kind === "glass") {
    const Icon = card.icon ? ICON_MAP[card.icon] : DollarSign;

    return (
      <motion.article
        initial={reduceMotion ? false : { opacity: 0, y: 40 }}
        whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-40px" }}
        transition={{ duration: 0.8, ease: "easeOut", delay: index * 0.1 }}
        className={cn(
          glassCardBase,
          "flex h-full w-full flex-col justify-center p-6",
          gridClassName,
          hoverClasses,
        )}
      >
        <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <Icon className="h-5 w-5" aria-hidden />
        </div>
        <h3 className="font-heading text-xl font-bold text-[#1a1a1a]">
          {card.title}
        </h3>
        <p className="mt-2 font-sans text-sm leading-[1.7] text-[#6b6b6b]">
          {card.description}
        </p>
        <div
          aria-hidden
          className="mt-4 h-0.5 w-10 rounded-full bg-primary"
        />
      </motion.article>
    );
  }

  if (card.kind === "image" && card.imageUrl) {
    return (
      <motion.article
        initial={reduceMotion ? false : { opacity: 0, y: 40 }}
        whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-40px" }}
        transition={{ duration: 0.8, ease: "easeOut", delay: index * 0.1 }}
        className={cn(
          "group relative h-full w-full overflow-hidden rounded-[20px]",
          gridClassName,
          !reduceMotion && hoverClasses,
        )}
      >
        <Image
          src={card.imageUrl}
          alt={card.imageAlt || card.title}
          fill
          className="object-cover transition-transform duration-700 ease-out group-hover:scale-105"
          sizes="(min-width: 1024px) 33vw, 100vw"
          unoptimized={card.imageUrl.startsWith("http")}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/35 to-black/10 transition-all duration-500 group-hover:from-black/80 group-hover:via-black/45" />

        <div className="absolute inset-x-0 bottom-0 p-5">
          <div className="rounded-2xl border border-white/25 bg-white/15 p-4 backdrop-blur-[16px] transition-all duration-500 group-hover:bg-white/20 group-hover:backdrop-blur-[24px]">
            <h3 className="font-heading text-xl font-bold text-white">
              {card.title}
            </h3>
            <p className="mt-2 font-sans text-sm leading-[1.7] text-white/85">
              {card.description}
            </p>
          </div>
        </div>
      </motion.article>
    );
  }

  if (card.kind === "cta") {
    return (
      <motion.article
        initial={reduceMotion ? false : { opacity: 0, y: 40 }}
        whileInView={reduceMotion ? undefined : { opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-40px" }}
        transition={{ duration: 0.8, ease: "easeOut", delay: index * 0.1 }}
        className={cn(
          "flex h-full w-full flex-col justify-between rounded-[20px] bg-gradient-to-br from-primary via-primary to-[#8f030b] p-6 text-primary-foreground shadow-[0_10px_40px_rgba(177,4,14,0.25)] transition-all duration-[400ms] ease-[cubic-bezier(0.16,1,0.3,1)]",
          gridClassName,
          !reduceMotion &&
            "hover:-translate-y-1.5 hover:shadow-[0_0_0_1px_rgba(177,4,14,0.2),0_20px_50px_rgba(177,4,14,0.35),0_10px_30px_rgba(0,0,0,0.12)]",
        )}
      >
        <div>
          <h3 className="font-heading text-xl font-bold">{card.title}</h3>
          <p className="mt-2 font-sans text-sm leading-[1.7] text-primary-foreground/85">
            {card.description}
          </p>
        </div>

        {card.href && card.ctaLabel ? (
          <Link
            href={card.href}
            className="group/cta mt-6 inline-flex items-center gap-2 font-sans text-sm font-semibold text-primary-foreground transition-[gap] duration-300 hover:gap-2.5"
          >
            <span>{card.ctaLabel}</span>
            <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover/cta:translate-x-1.5" />
          </Link>
        ) : null}
      </motion.article>
    );
  }

  return null;
}

export function AdmissionFinancialAidSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: "-80px" });
  const reduceMotion = useReducedMotion();
  const [loading, setLoading] = useState(true);
  const [content, setContent] = useState<AdmissionPageFinancialAidContent | null>(
    null,
  );

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const data = await fetchAdmissionPageFinancialAidContent();
        if (!cancelled) setContent(data);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) return <AdmissionFinancialAidSectionSkeleton />;
  if (!content) return null;

  const orderedCards = sortFinancialAidBentoCards(content.cards);
  const showContent = orderedCards.length > 0 && (isInView || !loading);

  return (
    <section
      ref={sectionRef}
      className={cn("relative overflow-hidden", admissionSectionPy)}
      style={{
        background:
          "linear-gradient(135deg, rgba(177,4,14,0.03) 0%, #ffffff 50%, rgba(177,4,14,0.02) 100%)",
      }}
      aria-labelledby="admission-financial-aid-heading"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -left-32 top-20 h-80 w-80 rounded-full bg-primary/5 blur-[120px]"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -right-24 bottom-10 h-96 w-96 rounded-full bg-primary/5 blur-[120px]"
      />

      <div className={cn("relative z-[1]", admissionContainer)}>
        <motion.div
          initial={false}
          animate={
            showContent ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }
          }
          transition={{ duration: 0.8, ease: "easeOut" }}
          className={cn("text-center", admissionSectionTitleMb)}
        >
          <h2
            id="admission-financial-aid-heading"
            className={admissionSectionTitle}
          >
            {content.heading}
          </h2>
          <p className={cn("mx-auto mt-4", admissionBodyText)}>
            {content.tagline}
          </p>
        </motion.div>

        <div className="grid auto-rows-fr grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-3 lg:grid-rows-2">
          {orderedCards.map((card, index) => (
            <BentoCard
              key={card.id}
              card={card}
              index={index}
              gridClassName={getBentoGridClassName(index)}
              isInView={isInView}
              counterVisible={showContent || isInView}
              reduceMotion={reduceMotion}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
