"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

export type ApplyAdmissionButtonVariant = "nav" | "topBar" | "overlay";

export interface ApplyAdmissionButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ApplyAdmissionButtonVariant;
  children: React.ReactNode;
}

export const ApplyAdmissionButton = React.forwardRef<
  HTMLButtonElement,
  ApplyAdmissionButtonProps
>(function ApplyAdmissionButton(
  { variant = "nav", className, children, type = "button", ...props },
  ref,
) {
  return (
    <button
      ref={ref}
      type={type}
      className={cn(
        "apply-admission-btn",
        variant === "topBar"
          ? "apply-admission-btn--topBar"
          : variant === "overlay"
            ? "apply-admission-btn--overlay"
            : "apply-admission-btn--nav",
        className,
      )}
      {...props}
    >
      <span>{children}</span>
    </button>
  );
});
