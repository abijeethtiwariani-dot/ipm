"use client";

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { toast } from "sonner";
import { CheckCircle } from "lucide-react";
import {
  admissionSubmitSchema,
  type AdmissionSubmitValues,
} from "@/lib/admission-schema";
import type { Course } from "@/types/student";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const GENDER_OPTIONS = [
  { value: "male", label: "Male" },
  { value: "female", label: "Female" },
  { value: "other", label: "Other" },
  { value: "prefer_not_to_say", label: "Prefer not to say" },
] as const;

export function AdmissionApplicationForm() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const form = useForm<AdmissionSubmitValues>({
    resolver: zodResolver(admissionSubmitSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      courseInterested: "",
      dateOfBirth: "",
      gender: "male",
      address: "",
      message: "",
      whatsappConsent: false,
    },
  });

  useEffect(() => {
    fetch("/api/student/courses")
      .then((res) => res.json())
      .then((data: { courses?: Course[] }) => setCourses(data.courses ?? []))
      .catch(() => setCourses([]));
  }, []);

  const onSubmit = async (values: AdmissionSubmitValues) => {
    setSubmitting(true);
    try {
      const res = await fetch("/api/admissions/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(values),
      });
      const data = (await res.json()) as { error?: string; success?: boolean };
      if (!res.ok) {
        toast.error(data.error ?? "Failed to submit application.");
        return;
      }
      setSubmitted(true);
      toast.success("Application submitted successfully!");
      form.reset();
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to submit application.";
      toast.error(message);
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div className="py-8 text-center">
        <div className="w-16 h-16 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-4">
          <CheckCircle className="w-8 h-8 text-success" />
        </div>
        <h3 className="text-xl font-heading font-semibold text-foreground mb-2">
          Application Received
        </h3>
        <p className="text-muted-foreground text-sm">
          Thank you for applying. Our admissions team will contact you soon.
        </p>
        <Button
          variant="outline"
          className="mt-6"
          onClick={() => setSubmitted(false)}
        >
          Submit another application
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="space-y-2 sm:col-span-2">
          <Label htmlFor="admission-name">Full Name</Label>
          <Input id="admission-name" {...form.register("name")} />
          {form.formState.errors.name && (
            <p className="text-sm text-destructive">
              {form.formState.errors.name.message}
            </p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="admission-email">Email</Label>
          <Input id="admission-email" type="email" {...form.register("email")} />
          {form.formState.errors.email && (
            <p className="text-sm text-destructive">
              {form.formState.errors.email.message}
            </p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="admission-phone">Phone Number</Label>
          <Input id="admission-phone" type="tel" {...form.register("phone")} />
          {form.formState.errors.phone && (
            <p className="text-sm text-destructive">
              {form.formState.errors.phone.message}
            </p>
          )}
        </div>

        <div className="space-y-2 sm:col-span-2">
          <Label>Course Interested In</Label>
          <Select
            value={form.watch("courseInterested") || ""}
            onValueChange={(v) => form.setValue("courseInterested", v)}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select a course" />
            </SelectTrigger>
            <SelectContent>
              {courses.map((c) => (
                <SelectItem key={c.id} value={c.name}>
                  {c.name}
                </SelectItem>
              ))}
              <SelectItem value="Other">Other</SelectItem>
            </SelectContent>
          </Select>
          {form.formState.errors.courseInterested && (
            <p className="text-sm text-destructive">
              {form.formState.errors.courseInterested.message}
            </p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="admission-dob">Date of Birth</Label>
          <Input
            id="admission-dob"
            type="date"
            {...form.register("dateOfBirth")}
          />
          {form.formState.errors.dateOfBirth && (
            <p className="text-sm text-destructive">
              {form.formState.errors.dateOfBirth.message}
            </p>
          )}
        </div>

        <div className="space-y-2">
          <Label>Gender</Label>
          <Select
            value={form.watch("gender")}
            onValueChange={(v) =>
              form.setValue(
                "gender",
                v as AdmissionSubmitValues["gender"],
              )
            }
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Select gender" />
            </SelectTrigger>
            <SelectContent>
              {GENDER_OPTIONS.map((g) => (
                <SelectItem key={g.value} value={g.value}>
                  {g.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {form.formState.errors.gender && (
            <p className="text-sm text-destructive">
              {form.formState.errors.gender.message}
            </p>
          )}
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="admission-address">Address</Label>
        <Textarea
          id="admission-address"
          rows={3}
          {...form.register("address")}
        />
        {form.formState.errors.address && (
          <p className="text-sm text-destructive">
            {form.formState.errors.address.message}
          </p>
        )}
      </div>

      <div className="space-y-2">
        <Label htmlFor="admission-message">Message / Notes</Label>
        <Textarea
          id="admission-message"
          rows={3}
          placeholder="Optional"
          {...form.register("message")}
        />
        {form.formState.errors.message && (
          <p className="text-sm text-destructive">
            {form.formState.errors.message.message}
          </p>
        )}
      </div>

      <div className="flex items-start gap-3">
        <Checkbox
          id="admission-whatsapp"
          checked={form.watch("whatsappConsent")}
          onCheckedChange={(checked) =>
            form.setValue("whatsappConsent", checked === true)
          }
        />
        <Label
          htmlFor="admission-whatsapp"
          className="text-sm font-normal leading-snug cursor-pointer"
        >
          I agree to be contacted via WhatsApp regarding my admission application
        </Label>
      </div>

      <Button type="submit" className="w-full" disabled={submitting}>
        {submitting ? "Submitting..." : "Submit Application"}
      </Button>
    </form>
  );
}
