"use client";

import * as React from "react";
import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ApplyAdmissionButton } from "./ApplyAdmissionButton";
import { AdmissionApplicationForm } from "./AdmissionApplicationForm";

type TriggerVariant = "nav" | "topBar" | "overlay";

interface AdmissionApplicationDialogProps {
  triggerVariant?: TriggerVariant;
  /** Custom trigger element (e.g. homepage CTA). Must accept ref and click events. */
  trigger?: React.ReactNode;
}

export function AdmissionApplicationDialog({
  triggerVariant = "nav",
  trigger,
}: AdmissionApplicationDialogProps) {
  const [open, setOpen] = useState(false);

  const triggerLabel =
    triggerVariant === "topBar" ? (
      <>
        <span className="sm:hidden">Apply</span>
        <span className="hidden sm:inline">Apply for Admission</span>
      </>
    ) : triggerVariant === "overlay" ? (
      <>
        <span className="sm:hidden">Apply</span>
        <span className="hidden sm:inline">Apply for Admission</span>
      </>
    ) : (
      "Apply for Admission"
    );

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger ?? (
          <ApplyAdmissionButton variant={triggerVariant}>
            {triggerLabel}
          </ApplyAdmissionButton>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-heading text-xl">
            Apply for Admission
          </DialogTitle>
          <DialogDescription>
            Complete the form below and our admissions team will get in touch
            with you.
          </DialogDescription>
        </DialogHeader>
        <AdmissionApplicationForm />
      </DialogContent>
    </Dialog>
  );
}
