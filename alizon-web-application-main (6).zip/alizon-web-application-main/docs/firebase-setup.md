# Firebase setup for Alizon

## 1. Create / configure project

1. Open [Firebase Console](https://console.firebase.google.com/).
2. Select your project (e.g. `alizon-sandbox`).
3. Add a **Web app** if you have not already, and copy the config into `.env.local` (see `.env.example`).

## 2. Authentication

1. Go to **Build → Authentication → Sign-in method**.
2. Enable **Email/Password**.
3. Go to **Users** and **Add user** with the email/password your admins will use.

## 3. Firestore

1. Go to **Build → Firestore Database** and create a database.
2. Open the **Rules** tab and paste the contents of [firestore-database.rules](firestore-database.rules), then **Publish**.

   Or from this repo (after `npm i -g firebase-tools` and `firebase login`):

   ```sh
   firebase use YOUR_PROJECT_ID
   npm run deploy:firebase-rules
   ```

   Student portal reads fail with `Missing or insufficient permissions` until these rules are published to the same project as `NEXT_PUBLIC_FIREBASE_PROJECT_ID`.

## 4. Storage

1. Go to **Build → Storage** and get started with the default bucket.
2. Open the **Rules** tab and paste the contents of [storage-bucket.rules](storage-bucket.rules).

## 5. Firebase Admin SDK (server routes)

1. Go to **Project settings → Service accounts**.
2. Click **Generate new private key** and download the JSON file.
3. Add to `.env.local`:

```
FIREBASE_ADMIN_PROJECT_ID=your-project-id
FIREBASE_ADMIN_CLIENT_EMAIL=firebase-adminsdk-...@your-project.iam.gserviceaccount.com
FIREBASE_ADMIN_PRIVATE_KEY="-----BEGIN PRIVATE KEY-----\n...\n-----END PRIVATE KEY-----\n"
```

Required for: custom password reset, deleting students, session cookies.

## 6. Seed admin account

After creating an admin user in Authentication, add a Firestore document:

| Collection | Document ID | Fields |
|------------|-------------|--------|
| `admins` | `{admin Firebase Auth UID}` | `email`, `createdAt` (timestamp) |

Without this document, admin login will sign out immediately and CMS writes will be denied.

## 7. Seed courses (optional)

Add documents to the `courses` collection for student registration and module lists:

```json
{
  "name": "B.Tech Computer Science",
  "modules": ["Mathematics", "Programming", "Database Systems"],
  "active": true,
  "updatedAt": "<server timestamp>"
}
```

## 8. Data model

### CMS

| Path | Description |
|------|-------------|
| `cms_newsCards/{id}` | News cards (Featured Research on `/news`; featured items on homepage) |
| `cms_homeNews/content` | Homepage Campus News section heading, intro, panel image, and CTA |
| `cms_newsHero/content` | News page hero (featured story + sidebar) |
| `cms_newsInTheNews/content` | News page In the news section |
| `cms_newsResearchMatters/content` | News page Research Matters banner |
| `cms_newsFeaturedReadingCards/{id}` | News page Featured Reading carousel (max 3) |
| `cms_newsCommunity/content` | News page community stories |
| `cms_newsStoriesInMotion/content` | News page Stories in Motion video block |
| `cms_newsRecentStories/content` | News page Recent Stories section |
| `cms_newsReportSignup/content` | News page Alizon Report signup block |
| `cms_academicsCards/{id}` | Homepage Academics featured cards |
| `cms_academicsHome/content` | Homepage Academics section copy and school links |
| `cms_homeTestimonials/{id}` | Homepage student testimonial bands (featured, max 3) |
| `cms_homeCampusLife/content` | Homepage Campus Life section copy and CTA |
| `cms_homeCampusLifeCards/{id}` | Homepage Campus Life featured cards (max 3) |
| `cms_homeArts/content` | Homepage The Arts section copy and CTA |
| `cms_homeArtsCards/{id}` | Homepage The Arts featured cards (max 3) |
| `cms_homeEvents/content` | Homepage Upcoming Events section copy and CTA |
| `cms_homeEventCards/{id}` | Homepage Upcoming Events featured cards (max 4) |
| `cms_homePartners/content` | Homepage Our Trusted Partners section copy |
| `cms_homePartnerLogos/{id}` | Homepage partner logo marquee items |
| `cms_homeHealthCare/content` | Homepage Health Care section copy and CTA |
| `cms_homeHealthCareCards/{id}` | Homepage Health Care featured cards (max 3) |
| `cms_homeAthletics/content` | Homepage Athletics section copy and CTA |
| `cms_homeAthleticsCards/{id}` | Homepage Athletics featured cards (max 3) |
| `cms_homeAdmission/content` | Homepage Admission section (hero image and two-column copy) |
| `cms_homeHeroSlides/{id}` | Homepage hero carousel slides (max 4) |
| `cms_homeMission/content` | Homepage mission block below hero |
| `cms_homeSectionVisibility/content` | Homepage section publish/unpublish flags |
| `cms_homeResearch/content` | Homepage Research section copy and CTA |
| `cms_homeHumanCenteredAi/content` | Homepage Human-Centered AI sticky/scroll section |
| `cms_homeShapingInnovation/content` | Homepage Shaping the future through innovation sticky/scroll section |
| `cms_homeInnovationInfrastructure/content` | Homepage Infrastructure for Innovation map + carousel |
| `cms_homeFeaturedVideo/content` | Homepage full-width featured video after Campus News |
| `cms_homeResearchStats/{id}` | Homepage Research stat tiles (max 6) |
| `cms_admissionPageHero/content` | Public `/admissions` page hero banner |
| `cms_admissionPageStats/content` | Public `/admissions` statistics row |
| `cms_admissionPageUndergrad/content` | Public `/admissions` undergraduates block |
| `cms_admissionPageGrad/content` | Public `/admissions` graduate studies block |
| `cms_admissionPageFinancialAid/content` | Public `/admissions` financial aid (`heading`, `tagline`, bento `cards`) |
| `cms_admissionPageOtherPrograms/content` | Public `/admissions` other programs cards |
| `cms_admissionPageApplyCta/content` | Public `/admissions` apply CTA block |
| `cms_campusLifeCards/{id}` | Campus Life cards |
| `cms_campusLife/content` | Legacy document (auto-migrated) |
| `cms_notifications/{id}` | Latest ticker notifications (featured items after nav) |
| `cms_footerQuickLinks/{id}` | Site footer Quick Links column |
| `cms_footerResourceLinks/{id}` | Site footer Resources column |
| `cms_footerAbout/content` | Site footer about/description text |
| `cms_footerContact/content` | Site footer contact information |
| `cms_footerSocial/content` | Site footer social media profiles |

### Student Portal

| Path | Description |
|------|-------------|
| `students/{uid}` | Student profile (`registrationId`, `name`, `email`, `phone`, `course`, `role`) |
| `assignments/{id}` | Assignment submissions; optional `grievance: { message, submittedAt }` after student disputes a graded result |
| `studentEvaluations/{studentId}` | Viva, internship, and elective evaluation; each component may include `grievance: { message, submittedAt }` |
| `results/{id}` | Graded results (synced from assignments) |
| `courses/{id}` | Course catalog with modules |
| `counters/registration` | Auto-increment counter for student registration IDs (starts at ALZ077) |
| `admins/{uid}` | Admin allowlist |

## 9. Firestore indexes

Create these composite indexes in Firebase Console (or follow console error links):

| Collection | Fields |
|------------|--------|
| `assignments` | `studentId` Asc, `submittedAt` Desc |
| `assignments` | `status` Asc, `submittedAt` Desc |
| `results` | `studentId` Asc, `gradedAt` Desc |
| `courses` | `active` Asc, `name` Asc |
| `cms_newsCards` | `featured` Asc, `order` Asc |
| `cms_newsFeaturedReadingCards` | `order` Asc |
| `cms_academicsCards` | `featured` Asc, `order` Asc |
| `cms_homeTestimonials` | `featured` Asc, `order` Asc |
| `cms_homeCampusLifeCards` | `featured` Asc, `order` Asc |
| `cms_homeArtsCards` | `featured` Asc, `order` Asc |
| `cms_homeEventCards` | `featured` Asc, `order` Asc |
| `cms_homeHealthCareCards` | `featured` Asc, `order` Asc |
| `cms_homeAthleticsCards` | `featured` Asc, `order` Asc |
| `cms_homeHeroSlides` | `order` Asc |
| `cms_homeResearchStats` | `order` Asc |
| `cms_homePartnerLogos` | `order` Asc |
| `cms_notifications` | `featured` Asc, `order` Asc |
| `cms_footerQuickLinks` | `displayOrder` Asc |
| `cms_footerResourceLinks` | `displayOrder` Asc |

## 10. Homepage CMS images (Phase 1)

Admin uploads under **Pages → Home page content** are processed server-side into high-quality WebP variants (quality ~92) and stored in Firebase Storage. Recommended upload sizes match the live site layout:

| Section | Recommended size |
|---------|------------------|
| Hero desktop banner | 2560 × 1097 px (21:9) |
| Hero mobile banner (optional) | 1080 × 1920 px (9:16) |
| Section cards (Academics, Campus Life, Arts, etc.) | 1200 × 900 px (4:3) |
| Event cards | 960 × 1200 px (4:5) |
| Testimonial background | 2560 × 1097 px (21:9) |
| Testimonial avatar | 512 × 512 px (1:1) |
| Admission block hero | 2560 × 1097 px (21:9) |

**After deploying this pipeline**, re-upload existing hero slides and card images in the admin panel. Older records may still point at 800px-wide URLs from the previous uploader and will look soft on large screens until replaced.

## 11. Local development

```sh
cp .env.example .env.local
# Edit .env.local with your Firebase values
npm run dev
```

- Admin: `http://localhost:3000/admin/login` → **Home page content** for hero and section images
- Student register: `http://localhost:3000/student-register`
- Student login: `http://localhost:3000/student-login`
