import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { applyIndexingHeaders } from "@/lib/middleware-headers";
import { ADMIN_SESSION_COOKIE, STUDENT_SESSION_COOKIE } from "@/lib/student-constants";

const PROTECTED_STUDENT_PATHS = ["/student-dashboard", "/student-results"];
const PROTECTED_ADMIN_PATHS = ["/admin"];

const PUBLIC_STUDENT_AUTH_PATHS = [
  "/student-login",
  "/student-register",
  "/forgot-password",
];

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  const isProtected = PROTECTED_STUDENT_PATHS.some(
    (p) => pathname === p || pathname.startsWith(`${p}/`),
  );
  const isAdminProtected = PROTECTED_ADMIN_PATHS.some(
    (p) =>
      (pathname === p || pathname.startsWith(`${p}/`)) &&
      !pathname.startsWith("/admin/login"),
  );

  if (!isProtected && !isAdminProtected) {
    return applyIndexingHeaders(NextResponse.next());
  }

  const sessionCookie = request.cookies.get(STUDENT_SESSION_COOKIE)?.value;

  if (isProtected && !sessionCookie) {
    const loginUrl = new URL("/student-login", request.url);
    loginUrl.searchParams.set("redirect", pathname);
    return applyIndexingHeaders(NextResponse.redirect(loginUrl));
  }

  const adminSession = request.cookies.get(ADMIN_SESSION_COOKIE)?.value;
  if (isAdminProtected && !adminSession) {
    const loginUrl = new URL("/admin/login", request.url);
    loginUrl.searchParams.set("redirect", pathname);
    return applyIndexingHeaders(NextResponse.redirect(loginUrl));
  }

  return applyIndexingHeaders(NextResponse.next());
}

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico)$).*)",
  ],
};
